<?php
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../public/user.php';
require_once __DIR__ . '/../Lib/csrf.php';

if (!isset($_SESSION['user'])) {
header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit;
}

$currentUser = $_SESSION['user'];

if (!isset($currentUser['role']) || strtolower($currentUser['role']) !== 'directeur général') {
    http_response_code(403);
    die("Accès refusé : seul le Directeur Général peut modifier les utilisateurs.");
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$user = User::getById($id);

if (!$user) {
    die("Utilisateur introuvable");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validate();
    $data = [
        'nom' => $_POST['nom'] ?? $user['nom'],
        'prenom' => $_POST['prenom'] ?? $user['prenom'],
        'email' => $_POST['email'] ?? $user['email'],
        'role' => $_POST['role'] ?? $user['role'],
        'password' => $_POST['password'] ?? null,
    ];
    if (User::update($id, $data)) {
header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/public/user.php");
        exit;
    } else {
        $error = "Erreur lors de la mise à jour";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Modifier Utilisateur</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Modifier Utilisateur</h2>
    <?php if(!empty($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
    <form method="POST">
        <?= csrf_field() ?>
        <div class="mb-3">
            <label>Nom</label>
            <input type="text" name="nom" class="form-control" value="<?= htmlspecialchars($user['nom']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Prénom</label>
            <input type="text" name="prenom" class="form-control" value="<?= htmlspecialchars($user['prenom']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Rôle</label>
            <select name="role" class="form-select" required>
                <?php
                $roles = ['demandeur','chef_service','directeur','directeur_general','informatique','moyens_generaux'];
                foreach($roles as $role) {
                    $selected = ($role === $user['role']) ? 'selected' : '';
                    echo "<option value='$role' $selected>$role</option>";
                }
                ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Mot de passe (laisser vide pour ne pas changer)</label>
            <input type="password" name="password" class="form-control">
        </div>
        <button type="submit" class="btn btn-success">Enregistrer</button>
        <button type="submit" class="btn btn-danger">Annuler</button>
    </form>
</div>
</body>
</html>
