<?php
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $designation = htmlspecialchars(trim($_POST['designation'] ?? ''));
    $justification = htmlspecialchars(trim($_POST['justification'] ?? ''));
    $errors = [];
    if (empty($designation)) {
        $errors[] = "La désignation du matériel est obligatoire.";
    }
    if (empty($justification)) {
        $errors[] = "La justification de la demande est obligatoire.";
    }
    if (empty($errors)) {
        // Example: Database save using PDO
        try {
            $pdo = new PDO("mysql:host=localhost;dbname=demande_db;charset=utf8", "root", "");
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $pdo->prepare(
              "INSERT INTO demandes (designation, justification) VALUES (:designation, :justification)"
            );
            $stmt->execute([
              ':designation' => $designation,
              ':justification' => $justification
            ]);
            // Redirect with success
header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/index.php?success=1");
            exit;
        } catch (PDOException $e) {
            die("Erreur : " . $e->getMessage());
        }
    } else {
        // Redirect back with error messages in query or session
        $_SESSION['errors'] = $errors;
        header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/public/index.php");
        exit;
    }
} else {
header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/public/index.php");
    exit;
}
