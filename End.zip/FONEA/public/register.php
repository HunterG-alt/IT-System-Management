<?php
require_once '../Config/session.php';

if (is_logged_in()) {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/index.php");
    exit();
}
$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once '../Config/db.php';
    $nom = trim($_POST['nom'] ?? '');
    $prenom = trim($_POST['prenom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';
    
    if (!csrf_verify($csrf)) {
        $error = "Erreur de sécurité (token invalide).";
    } elseif (!$nom || !$prenom || !$email || !$password || !$role) {
        $error = "Veuillez remplir tous les champs.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Format d'email invalide.";
    } elseif (strlen($password) < 6) {
        $error = "Le mot de passe doit contenir au moins 6 caractères.";
    } elseif (!in_array($role, ['agent_demandeur', 'chef_service', 'directeur', 'informatique', 'moyens_generaux'])) {
        $error = "Rôle invalide sélectionné.";
    } else {
        try {
            $pdo = db(); 
            
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = "Cet email est déjà utilisé.";
            } else {
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (nom, prenom, email, password, role, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                if ($stmt->execute([$nom, $prenom, $email, $hashed, $role])) {
                    $success = "Compte créé avec succès. Vous pouvez maintenant vous connecter.";
                    
                    $nom = $prenom = $email = $role = '';
                } else {
                    $error = "Erreur lors de la création du compte.";
                }
            }
        } catch (PDOException $e) {
            error_log("Erreur inscription: " . $e->getMessage());
            $error = "Erreur système. Veuillez réessayer plus tard.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FONEA - Inscription</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: radial-gradient(circle at 20% 30%, #0f172a 0%, #1e293b 50%, #0f172a 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            overflow: hidden;
            color: #1e293b;
        }

        body::before {
            content: '';
            position: absolute;
            inset: 0;
            background: radial-gradient(circle at 30% 30%, rgba(255, 255, 255, 0.05), transparent 40%),
                        radial-gradient(circle at 70% 70%, rgba(255, 255, 255, 0.05), transparent 40%);
            backdrop-filter: blur(60px);
            z-index: -1;
            animation: subtleFloat 20s ease-in-out infinite alternate;
        }

        @keyframes subtleFloat {
            0% { transform: translate(0, 0); }
            50% { transform: translate(-20px, 20px); }
            100% { transform: translate(20px, -20px); }
        }

        .registration-container {
            background: rgba(255, 255, 255, 0.95);
            border: 1px solid rgba(255, 255, 255, 0.4);
            border-radius: 8px;
            padding: 40px;
            width: 100%;
            max-width: 450px;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
            animation: slideUp 0.8s ease-out;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(40px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .title {
            text-align: center;
            color: #0f172a;
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 30px;
            letter-spacing: 1px;
        }

        .alert {
            padding: 14px 18px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 14px;
            border: 1px solid;
            animation: alertSlide 0.5s ease-out;
        }

        @keyframes alertSlide {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background: #ecfdf5;
            border-color: #10b981;
            color: #047857;
        }

        .alert-error {
            background: #fef2f2;
            border-color: #ef4444;
            color: #b91c1c;
        }

        .form-group {
            margin-bottom: 20px;
            position: relative;
        }

        .input-container {
            position: relative;
            display: flex;
            align-items: center;
        }

        .input-icon {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 18px;
        }

        .form-input,
        .form-select {
            width: 100%;
            padding: 14px 14px 14px 50px;
            background: rgba(255, 255, 255, 0.7);
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            color: #0f172a;
            font-size: 16px;
            transition: all 0.3s ease;
            outline: none;
        }

        .form-input::placeholder {
            color: #94a3b8;
        }

        .form-input:focus,
        .form-select:focus {
            border-color: #14b8a6;
            background: #fff;
            box-shadow: 0 0 0 3px rgba(20, 184, 166, 0.2);
        }

        .form-input:focus + .input-icon {
            color: #14b8a6;
            transform: translateY(-50%) scale(1.1);
        }

        .form-select {
            appearance: none;
            background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2364748b' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6,9 12,15 18,9'%3e%3c/polyline%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 14px center;
            background-size: 18px;
            cursor: pointer;
        }

        .submit-btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #14b8a6, #10b981);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 17px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-top: 10px;
        }

        .submit-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s;
        }

        .submit-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(20, 184, 166, 0.4);
        }

        .submit-btn:hover::before {
            left: 100%;
        }

        .submit-btn:active {
            transform: translateY(-1px);
        }

        .login-link {
            text-align: center;
            margin-top: 25px;
            color: #475569;
            font-size: 14px;
        }

        .login-link a {
            color: #0d9488;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        .login-link a:hover {
            color: #14b8a6;
        }

        @media (max-width: 480px) {
            .registration-container {
                padding: 30px 25px;
            }
            .title {
                font-size: 24px;
            }
        }

        .loading {
            pointer-events: none;
            opacity: 0.7;
        }

        .loading .submit-btn {
            background: linear-gradient(135deg, #6b7280, #9ca3af);
            cursor: not-allowed;
        }
</style>

</head>
<body>
    <div class="registration-container">
        
        <h1 class="title">INSCRIPTION FONEA</h1>
        
        <div id="alertContainer" style="display: none;">
            <div class="alert alert-success" id="successAlert" style="display: none;">
                ✓ Compte créé avec succès ! Redirection en cours...
            </div>
            <div class="alert alert-error" id="errorAlert" style="display: none;">
                ⚠ Erreur lors de la création du compte. Veuillez vérifier vos informations.
            </div>
        </div>
        
        <form id="registrationForm" method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
            <div class="form-group">
                <div class="input-container">
                    <input type="text" 
                           class="form-input" 
                           id="nom" 
                           name="nom" 
                           placeholder="Nom" 
                           required>
                    <i class="fas fa-user input-icon"></i>
                </div>
            </div>
            <div class="form-group">
                <div class="input-container">
                    <input type="text" 
                           class="form-input" 
                           id="prenom" 
                           name="prenom" 
                           placeholder="Prénom" 
                           required>
                    <i class="fas fa-user input-icon"></i>
                </div>
            </div>
            <div class="form-group">
                <div class="input-container">
                    <input type="email" 
                           class="form-input" 
                           id="email" 
                           name="email" 
                           placeholder="Email" 
                           required>
                    <i class="fas fa-envelope input-icon"></i>
                </div>
            </div>
            <div class="form-group">
                <div class="input-container">
                    <input type="password" 
                           class="form-input" 
                           id="password" 
                           name="password" 
                           placeholder="Mot de passe" 
                           required>
                    <i class="fas fa-lock input-icon"></i>
                </div>
            </div>
            <div class="form-group">
                <div class="input-container">
                    <select class="form-select" id="role" name="role" required>
                        <option value="">Sélectionnez un rôle</option>
                        <option value="agent_demandeur">Agent Demandeur</option>
                        <option value="chef_service">Chef de Service</option>
                        <option value="directeur">Directeur</option>
                        <option value="informatique">Informatique</option>
                        <option value="moyens_generaux">Moyens Généraux</option>
                    </select>
                   <i class="fas fa-masks-theater input-icon"></i>
                </div>
            </div>
            <button type="submit" class="submit-btn">
                Créer le compte
            </button>
        </form>
        <div class="login-link">
            Vous avez déjà un compte ? <a href="login.php" onclick="showLoginMessage()">Connectez-vous ici</a>
        </div>
    </div>
    <script>
        // Show alert messages
        function showAlert(type, message) {
            const alertContainer = document.getElementById('alertContainer');
            const successAlert = document.getElementById('successAlert');
            const errorAlert = document.getElementById('errorAlert');
            // Hide all alerts first
            successAlert.style.display = 'none';
            errorAlert.style.display = 'none';
            // Show appropriate alert
            if (type === 'success') {
                successAlert.style.display = 'block';
                successAlert.textContent = message;
            } else if (type === 'error') {
                errorAlert.style.display = 'block';
                errorAlert.textContent = message;
            }
            alertContainer.style.display = 'block';
            // Auto hide after 5 seconds
            setTimeout(() => {
                alertContainer.style.display = 'none';
            }, 5000);
        }
        // Form validation
        function validateForm() {
            const nom = document.getElementById('nom').value.trim();
            const prenom = document.getElementById('prenom').value.trim();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            const role = document.getElementById('role').value;
            if (!nom || !prenom) {
                showAlert('error', '⚠ Veuillez saisir votre nom et prénom');
                return false;
            }
            if (!email || !email.includes('@')) {
                showAlert('error', '⚠ Veuillez saisir une adresse email valide');
                return false;
            }
            if (!password || password.length < 6) {
                showAlert('error', '⚠ Le mot de passe doit contenir au moins 6 caractères');
                return false;
            }
            if (!role) {
                showAlert('error', '⚠ Veuillez sélectionner un rôle');
                return false;
            }
            return true;
        }
        // Form submission handler (client-side validation only; server handles creation)
        document.getElementById('registrationForm').addEventListener('submit', function(e) {
            if (!validateForm()) {
                e.preventDefault();
                return false;
            }
            const formBox = document.querySelector('.registration-container');
            formBox.classList.add('loading');
        });
        // Login link handler
        function showLoginMessage() {
            showAlert('success', '🔗 Redirection vers la page de connexion...');
        }
        // Enhanced form interactions
        const inputs = document.querySelectorAll('.form-input');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.style.transform = 'scale(1.02)';
            });
            input.addEventListener('blur', function() {
                this.parentElement.style.transform = 'scale(1)';
            });
        });
        // Role selector enhancement
        const roleSelect = document.getElementById('role');
        roleSelect.addEventListener('change', function() {
            if (this.value) {
                this.style.color = 'white';
            }
        });
        // Initialize
        updateProgress(currentStep);
    </script>
</body>
</html>