<?php

$pageTitles = [
    'dashboard_dg.php' => 'Dashboard Directeur Général',
    'dashboard_directeur.php' => 'Dashboard Directeur',
    'dashboard_moyens_generaux.php' => 'Dashboard Moyens Généraux',
    'dashboard_chef.php' => 'Dashboard Chef de Service',
    'dashboard_agent.php' => 'Dashboard Agent',
    'dashboard_informatique.php' => 'Dashboard Informatique',
];

if (!function_exists('get_page_title')) {
    function get_page_title(?string $scriptName = null, ?string $override = null): string {
        if (!empty($override)) {
            return $override;
        }
        $script = $scriptName ?? basename($_SERVER['PHP_SELF'] ?? '');
        global $pageTitles;
        return $pageTitles[$script] ?? 'FONEA';
    }
}

if (!function_exists('set_page_title')) {
    function set_page_title(string $title): void {
        $GLOBALS['pagetitle'] = $title;
    }
}
