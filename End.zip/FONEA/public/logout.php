<?php
require_once '../Config/session.php';

if (function_exists('set_flash_message')) {
    set_flash_message('success', 'Vous avez été déconnecté avec succès.');
}

if (function_exists('user_logout')) {
    user_logout(); 
}

session_unset();
session_destroy();

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

header("Location: /FONEA/public/login.php");
exit();
?>