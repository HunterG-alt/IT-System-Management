<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Système de Chargement Moderne</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        :root {
            --primary-color: #667eea;
            --secondary-color: #764ba2;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --dark-color: #1f2937;
            --light-color: #f9fafb;
            --border-color: #e5e7eb;
            --text-primary: #111827;
            --text-secondary: #6b7280;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            min-height: 100vh;
            color: var(--text-primary);
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        /* Navigation Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--border-color);
            z-index: 1000;
            overflow-y: auto;
            transition: transform 0.3s ease;
        }
        .sidebar-header {
            padding: 30px 25px;
            border-bottom: 1px solid var(--border-color);
            text-align: center;
        }
        .sidebar-header h2 {
            color: var(--primary-color);
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 5px;
        }
        .sidebar-header p {
            color: var(--text-secondary);
            font-size: 0.875rem;
        }
        .nav-menu {
            padding: 20px 0;
        }
        .nav-item {
            margin: 5px 20px;
        }
        .nav-link {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: 10px;
            transition: all 0.3s ease;
            font-weight: 500;
            position: relative;
            overflow: hidden;
        }
        .nav-link:hover {
            background: rgba(102, 126, 234, 0.1);
            color: var(--primary-color);
            transform: translateX(5px);
        }
        .nav-link.active {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            box-shadow: var(--shadow-lg);
        }
        .nav-link.active::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: rgba(255, 255, 255, 0.3);
        }
        .nav-link i {
            margin-right: 12px;
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }
        .nav-link .badge {
            margin-left: auto;
            background: var(--danger-color);
            color: white;
            font-size: 0.75rem;
            padding: 2px 8px;
            border-radius: 12px;
            font-weight: 600;
        }
        /* Main Content */
        .main-content {
            margin-left: 280px;
            min-height: 100vh;
            background: var(--light-color);
            transition: margin-left 0.3s ease;
        }
        .content-header {
            background: white;
            padding: 25px 30px;
            border-bottom: 1px solid var(--border-color);
            box-shadow: var(--shadow-sm);
        }
        .content-header h1 {
            font-size: 2rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 5px;
        }
        .content-header .breadcrumb {
            color: var(--text-secondary);
            font-size: 0.875rem;
        }
        .content-section {
            padding: 30px;
            display: none;
            animation: fadeInUp 0.6s ease forwards;
        }
        .content-section.active {
            display: block;
        }
        /* Cards */
        .card {
            background: white;
            border-radius: 16px;
            box-shadow: var(--shadow-md);
            border: 1px solid var(--border-color);
            overflow: hidden;
            transition: all 0.3s ease;
        }
        .card:hover {
            box-shadow: var(--shadow-xl);
            transform: translateY(-2px);
        }
        .card-header {
            padding: 25px 30px;
            border-bottom: 1px solid var(--border-color);
            background: linear-gradient(135deg, #f8fafc, #f1f5f9);
        }
        .card-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 5px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .card-body {
            padding: 30px;
        }
        /* Loading States */
        .loading-container {
            position: fixed;
            top: 0;
            left: 280px;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 999;
            transition: all 0.3s ease;
        }
        .loading-container.show {
            display: flex;
        }
        .loading-content {
            text-align: center;
            max-width: 300px;
        }
        /* Modern Loading Spinners */
        .loading-spinner {
            position: relative;
            margin: 0 auto 30px;
        }
        /* Spinner 1: Pulsing Dots */
        .spinner-dots {
            display: flex;
            gap: 8px;
            justify-content: center;
            margin-bottom: 20px;
        }
        .spinner-dots .dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: var(--primary-color);
            animation: pulse-dots 1.4s ease-in-out infinite both;
        }
        .spinner-dots .dot:nth-child(1) { animation-delay: -0.32s; }
        .spinner-dots .dot:nth-child(2) { animation-delay: -0.16s; }
        .spinner-dots .dot:nth-child(3) { animation-delay: 0s; }
        @keyframes pulse-dots {
            0%, 80%, 100% {
                transform: scale(0.8);
                opacity: 0.5;
            }
            40% {
                transform: scale(1);
                opacity: 1;
            }
        }
        /* Spinner 2: Rotating Ring */
        .spinner-ring {
            width: 60px;
            height: 60px;
            margin: 0 auto 20px;
            position: relative;
        }
        .spinner-ring::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            border: 4px solid var(--border-color);
            border-top: 4px solid var(--primary-color);
            border-radius: 50%;
            animation: spin-ring 1s linear infinite;
        }
        @keyframes spin-ring {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        /* Spinner 3: Morphing Circle */
        .spinner-morph {
            width: 50px;
            height: 50px;
            margin: 0 auto 20px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 50%;
            animation: morph 1.5s ease-in-out infinite;
        }
        @keyframes morph {
            0%, 100% {
                border-radius: 50%;
                transform: rotate(0deg) scale(1);
            }
            25% {
                border-radius: 25%;
                transform: rotate(90deg) scale(1.1);
            }
            50% {
                border-radius: 10%;
                transform: rotate(180deg) scale(0.9);
            }
            75% {
                border-radius: 25%;
                transform: rotate(270deg) scale(1.1);
            }
        }
        /* Loading Text */
        .loading-text {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 10px;
        }
        .loading-subtext {
            font-size: 0.875rem;
            color: var(--text-secondary);
            margin-bottom: 20px;
        }
        /* Progress Bar */
        .progress-container {
            width: 100%;
            height: 6px;
            background: var(--border-color);
            border-radius: 3px;
            overflow: hidden;
            margin-bottom: 15px;
        }
        .progress-bar {
            height: 100%;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
            border-radius: 3px;
            transition: width 0.3s ease;
            width: 0%;
        }
        /* Content Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            border-left: 4px solid var(--primary-color);
            transition: all 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-lg);
        }
        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 5px;
        }
        .stat-label {
            font-size: 0.875rem;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        /* Mobile Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.mobile-open {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
            }
            .loading-container {
                left: 0;
            }
            .content-header {
                padding: 20px;
            }
            .content-section {
                padding: 20px;
            }
        }
        /* Dark mode support */
        @media (prefers-color-scheme: dark) {
            :root {
                --light-color: #111827;
                --text-primary: #f9fafb;
                --text-secondary: #9ca3af;
                --border-color: #374151;
            }
            .sidebar {
                background: rgba(31, 41, 55, 0.95);
            }
            .card,
            .stat-card {
                background: #1f2937;
                border-color: var(--border-color);
            }
            .content-header {
                background: #1f2937;
                border-color: var(--border-color);
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar Navigation -->
    <nav class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h2><i class="fas fa-cogs"></i> Dashboard</h2>
            <p>Système de gestion moderne</p>
        </div>
        <div class="nav-menu">
            <div class="nav-item">
                <a href="#" class="nav-link active" data-section="dashboard" data-title="Tableau de bord" data-spinner="dots">
                    <i class="fas fa-chart-pie"></i>
                    Tableau de bord
                </a>
            </div>
            <div class="nav-item">
                <a href="#" class="nav-link" data-section="requests" data-title="Demandes" data-spinner="ring">
                    <i class="fas fa-clipboard-list"></i>
                    Demandes
                    <span class="badge">5</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="#" class="nav-link" data-section="materials" data-title="Matériels" data-spinner="morph">
                    <i class="fas fa-boxes"></i>
                    Matériels
                </a>
            </div>
            <div class="nav-item">
                <a href="#" class="nav-link" data-section="acquisitions" data-title="Acquisitions" data-spinner="dots">
                    <i class="fas fa-shopping-cart"></i>
                    Acquisitions
                </a>
            </div>
            <div class="nav-item">
                <a href="#" class="nav-link" data-section="users" data-title="Utilisateurs" data-spinner="ring">
                    <i class="fas fa-users"></i>
                    Utilisateurs
                </a>
            </div>
            <div class="nav-item">
                <a href="#" class="nav-link" data-section="settings" data-title="Paramètres" data-spinner="morph">
                    <i class="fas fa-cog"></i>
                    Paramètres
                </a>
            </div>
        </div>
    </nav>
    <!-- Main Content -->
    <main class="main-content">
        <!-- Content Header -->
        <header class="content-header">
            <h1 id="pageTitle">Tableau de bord</h1>
            <div class="breadcrumb" id="breadcrumb">
                Accueil > <span id="currentPage">Tableau de bord</span>
            </div>
        </header>
        <!-- Loading Container -->
        <div class="loading-container" id="loadingContainer">
            <div class="loading-content">
                <div class="loading-spinner" id="loadingSpinner">
                    <!-- Les spinners seront injectés ici par JavaScript -->
                </div>
                <div class="loading-text" id="loadingText">Chargement en cours...</div>
                <div class="loading-subtext" id="loadingSubtext">Veuillez patienter</div>
                <div class="progress-container">
                    <div class="progress-bar" id="progressBar"></div>
                </div>
            </div>
        </div>
        <!-- Content Sections -->
        <section id="dashboard" class="content-section active">
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value">1,234</div>
                    <div class="stat-label">Total des demandes</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">89</div>
                    <div class="stat-label">En attente</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">456</div>
                    <div class="stat-label">Matériels</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">€12,345</div>
                    <div class="stat-label">Budget utilisé</div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-chart-line"></i>
                        Tableau de bord principal
                    </h3>
                </div>
                <div class="card-body">
                    <p>Bienvenue sur votre tableau de bord. Ici vous pouvez voir un aperçu de toutes vos données importantes.</p>
                    <p>Utilisez la navigation à gauche pour explorer les différentes sections de l'application.</p>
                </div>
            </div>
        </section>
        <section id="requests" class="content-section">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-clipboard-list"></i>
                        Gestion des demandes
                    </h3>
                </div>
                <div class="card-body">
                    <p>Cette section contient la gestion complète des demandes.</p>
                    <ul>
                        <li>Nouvelles demandes en attente</li>
                        <li>Demandes en cours de traitement</li>
                        <li>Historique des demandes</li>
                    </ul>
                </div>
            </div>
        </section>
        <section id="materials" class="content-section">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-boxes"></i>
                        Inventaire des matériels
                    </h3>
                </div>
                <div class="card-body">
                    <p>Gérez votre inventaire de matériels ici.</p>
                    <ul>
                        <li>Stock disponible</li>
                        <li>Matériels en cours d'utilisation</li>
                        <li>Maintenance et réparations</li>
                    </ul>
                </div>
            </div>
        </section>
        <section id="acquisitions" class="content-section">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-shopping-cart"></i>
                        Suivi des acquisitions
                    </h3>
                </div>
                <div class="card-body">
                    <p>Suivez toutes vos acquisitions et commandes.</p>
                    <ul>
                        <li>Commandes en cours</li>
                        <li>Livraisons attendues</li>
                        <li>Budget et dépenses</li>
                    </ul>
                </div>
            </div>
        </section>
        <section id="users" class="content-section">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-users"></i>
                        Gestion des utilisateurs
                    </h3>
                </div>
                <div class="card-body">
                    <p>Administration des comptes utilisateurs.</p>
                    <ul>
                        <li>Utilisateurs actifs</li>
                        <li>Permissions et rôles</li>
                        <li>Activité récente</li>
                    </ul>
                </div>
            </div>
        </section>
        <section id="settings" class="content-section">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-cog"></i>
                        Configuration système
                    </h3>
                </div>
                <div class="card-body">
                    <p>Paramètres et configuration de l'application.</p>
                    <ul>
                        <li>Préférences générales</li>
                        <li>Configuration des notifications</li>
                        <li>Paramètres de sécurité</li>
                    </ul>
                </div>
            </div>
        </section>
    </main>
    <script>
        class ModernLoadingSystem {
            constructor() {
                this.navLinks = document.querySelectorAll('.nav-link');
                this.contentSections = document.querySelectorAll('.content-section');
                this.loadingContainer = document.getElementById('loadingContainer');
                this.loadingSpinner = document.getElementById('loadingSpinner');
                this.loadingText = document.getElementById('loadingText');
                this.loadingSubtext = document.getElementById('loadingSubtext');
                this.progressBar = document.getElementById('progressBar');
                this.pageTitle = document.getElementById('pageTitle');
                this.currentPage = document.getElementById('currentPage');
                this.loadingMessages = {
                    dashboard: ['Chargement du tableau de bord...', 'Récupération des statistiques'],
                    requests: ['Chargement des demandes...', 'Synchronisation des données'],
                    materials: ['Chargement de l\'inventaire...', 'Mise à jour du stock'],
                    acquisitions: ['Chargement des acquisitions...', 'Vérification des commandes'],
                    users: ['Chargement des utilisateurs...', 'Vérification des permissions'],
                    settings: ['Chargement des paramètres...', 'Configuration du système']
                };
                this.spinnerTypes = {
                    dots: this.createDotsSpinner,
                    ring: this.createRingSpinner,
                    morph: this.createMorphSpinner
                };
                this.init();
            }
            init() {
                this.setupNavigation();
                this.setupKeyboardShortcuts();
                this.setupMobileMenu();
                this.preloadContent();
            }
            setupNavigation() {
                this.navLinks.forEach(link => {
                    link.addEventListener('click', (e) => {
                        e.preventDefault();
                        this.handleNavigation(link);
                    });
                });
            }
            setupKeyboardShortcuts() {
                document.addEventListener('keydown', (e) => {
                    if (e.altKey) {
                        const shortcuts = {
                            '1': 'dashboard',
                            '2': 'requests',
                            '3': 'materials',
                            '4': 'acquisitions',
                            '5': 'users',
                            '6': 'settings'
                        };
                        if (shortcuts[e.key]) {
                            e.preventDefault();
                            const targetLink = document.querySelector(`[data-section="${shortcuts[e.key]}"]`);
                            if (targetLink) {
                                this.handleNavigation(targetLink);
                            }
                        }
                    }
                });
            }
            setupMobileMenu() {
                // Ajout du bouton menu mobile si nécessaire
                if (window.innerWidth <= 768) {
                    this.createMobileMenuButton();
                }
                window.addEventListener('resize', () => {
                    if (window.innerWidth <= 768 && !document.querySelector('.mobile-menu-btn')) {
                        this.createMobileMenuButton();
                    }
                });
            }
            createMobileMenuButton() {
                const button = document.createElement('button');
                button.className = 'mobile-menu-btn';
                button.innerHTML = '<i class="fas fa-bars"></i>';
                button.style.cssText = `
                    position: fixed;
                    top: 20px;
                    left: 20px;
                    z-index: 1001;
                    background: var(--primary-color);
                    color: white;
                    border: none;
                    border-radius: 8px;
                    padding: 12px;
                    cursor: pointer;
                    box-shadow: var(--shadow-lg);
                `;
                button.addEventListener('click', () => {
                    document.getElementById('sidebar').classList.toggle('mobile-open');
                });
                document.body.appendChild(button);
            }
            handleNavigation(link) {
                const targetSection = link.getAttribute('data-section');
                const pageTitle = link.getAttribute('data-title');
                const spinnerType = link.getAttribute('data-spinner') || 'dots';
                // Mise à jour de l'état actif
                this.navLinks.forEach(l => l.classList.remove('active'));
                link.classList.add('active');
                // Mise à jour du titre
                this.pageTitle.textContent = pageTitle;
                this.currentPage.textContent = pageTitle;
                // Affichage du loading avec le bon spinner
                this.showLoading(targetSection, spinnerType);
                // Simulation du chargement avec progression
                this.simulateLoading(targetSection);
            }
            showLoading(section, spinnerType) {
                // Masquer toutes les sections
                this.contentSections.forEach(s => {
                    s.style.display = 'none';
                    s.classList.remove('active');
                });
                // Afficher le loading
                this.loadingContainer.classList.add('show');
                // Créer le spinner approprié
                this.loadingSpinner.innerHTML = '';
                this.spinnerTypes[spinnerType].call(this);
                // Messages de chargement
                const messages = this.loadingMessages[section];
                if (messages) {
                    this.loadingText.textContent = messages[0];
                    this.loadingSubtext.textContent = messages[1];
                }
                // Reset de la barre de progression
                this.progressBar.style.width = '0%';
            }
            simulateLoading(targetSection) {
                let progress = 0;
                const increment = Math.random() * 15 + 10; // 10-25% par étape
                const totalTime = 800 + Math.random() * 700; // 800-1500ms
                const steps = Math.ceil(100 / increment);
                const stepTime = totalTime / steps;
                const progressInterval = setInterval(() => {
                    progress += increment;
                    if (progress >= 100) {
                        progress = 100;
                        this.progressBar.style.width = '100%';
                        setTimeout(() => {
                            clearInterval(progressInterval);
                            this.showContent(targetSection);
                        }, 200);
                    } else {
                        this.progressBar.style.width = `${progress}%`;
                    }
                }, stepTime);
            }
            showContent(targetSection) {
                // Masquer le loading
                this.loadingContainer.classList.remove('show');
                // Afficher la section cible
                const section = document.getElementById(targetSection);
                if (section) {
                    section.style.display = 'block';
                    section.classList.add('active');
                    // Animation d'entrée
                    section.style.opacity = '0';
                    section.style.transform = 'translateY(20px)';
                    requestAnimationFrame(() => {
                        section.style.transition = 'all 0.4s ease';
                        section.style.opacity = '1';
                        section.style.transform = 'translateY(0)';
                    });
                }
                // Fermer le menu mobile si ouvert
                document.getElementById('sidebar').classList.remove('mobile-open');
            }
            createDotsSpinner() {
                const dotsContainer = document.createElement('div');
                dotsContainer.className = 'spinner-dots';
                for (let i = 0; i < 3; i++) {
                    const dot = document.createElement('div');
                    dot.className = 'dot';
                    dotsContainer.appendChild(dot);
                }
                this.loadingSpinner.appendChild(dotsContainer);
            }
            createRingSpinner() {
                const ring = document.createElement('div');
                ring.className = 'spinner-ring';
                this.loadingSpinner.appendChild(ring);
            }
            createMorphSpinner() {
                const morph = document.createElement('div');
                morph.className = 'spinner-morph';
                this.loadingSpinner.appendChild(morph);
            }
            preloadContent() {
                // Simulation du preload pour améliorer les performances
                const preloadData = () => {
                    // Ici vous pourriez précharger les données critiques
                    console.log('Préchargement des données...');
                };
                // Précharger après le chargement initial
                setTimeout(preloadData, 1000);
            }
        }
        // Initialisation du système
        document.addEventListener('DOMContentLoaded', () => {
            new ModernLoadingSystem();
            // Easter egg: Animation de bienvenue
            setTimeout(() => {
                const cards = document.querySelectorAll('.stat-card');
                cards.forEach((card, index) => {
                    card.style.opacity = '0';
                    card.style.transform = 'translateY(30px) scale(0.95)';
                    card.style.transition = 'all 0.6s cubic-bezier(0.4, 0, 0.2, 1)';
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0) scale(1)';
                    }, index * 150);
                });
            }, 500);
            // Notification toast pour les raccourcis clavier
            const showKeyboardHint = () => {
                if (!localStorage.getItem('keyboardHintShown')) {
                    const toast = document.createElement('div');
                    toast.style.cssText = `
                        position: fixed;
                        top: 20px;
                        right: 20px;
                        background: rgba(102, 126, 234, 0.95);
                        color: white;
                        padding: 15px 20px;
                        border-radius: 10px;
                        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                        backdrop-filter: blur(10px);
                        z-index: 2000;
                        opacity: 0;
                        transform: translateX(100%);
                        transition: all 0.4s ease;
                        max-width: 300px;
                        font-size: 14px;
                    `;
                    toast.innerHTML = `
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <i class="fas fa-keyboard" style="font-size: 18px;"></i>
                            <div>
                                <strong>Astuce :</strong> Utilisez Alt + 1-6 pour naviguer rapidement !
                            </div>
                        </div>
                    `;
                    document.body.appendChild(toast);
                    setTimeout(() => {
                        toast.style.opacity = '1';
                        toast.style.transform = 'translateX(0)';
                    }, 1000);
                    setTimeout(() => {
                        toast.style.opacity = '0';
                        toast.style.transform = 'translateX(100%)';
                        setTimeout(() => document.body.removeChild(toast), 400);
                    }, 5000);
                    localStorage.setItem('keyboardHintShown', 'true');
                }
            };
            setTimeout(showKeyboardHint, 3000);
        });
        // Gestionnaire d'événements global pour les erreurs et la récupération
        class ErrorRecoverySystem {
            constructor() {
                this.retryAttempts = new Map();
                this.maxRetries = 3;
                this.init();
            }
            init() {
                // Gestion des erreurs globales
                window.addEventListener('error', (e) => {
                    console.error('Erreur détectée:', e.error);
                    this.handleError('Script Error', e.filename + ':' + e.lineno);
                });
                // Gestion des promesses rejetées
                window.addEventListener('unhandledrejection', (e) => {
                    console.error('Promise rejetée:', e.reason);
                    this.handleError('Promise Rejection', e.reason);
                });
                // Surveillance de la connectivité
                window.addEventListener('online', () => {
                    this.showConnectivityStatus('Connexion rétablie', 'success');
                });
                window.addEventListener('offline', () => {
                    this.showConnectivityStatus('Connexion perdue', 'warning');
                });
            }
            handleError(type, details) {
                const errorId = `${type}_${Date.now()}`;
                if (!this.retryAttempts.has(errorId)) {
                    this.retryAttempts.set(errorId, 0);
                }
                const attempts = this.retryAttempts.get(errorId);
                if (attempts < this.maxRetries) {
                    this.retryAttempts.set(errorId, attempts + 1);
                    console.log(`Tentative de récupération ${attempts + 1}/${this.maxRetries}`);
                    // Tentative de récupération automatique
                    this.attemptRecovery(type);
                } else {
                    this.showErrorMessage(type, details);
                }
            }
            attemptRecovery(errorType) {
                switch (errorType) {
                    case 'Script Error':
                        // Rechargement de la navigation si erreur JS
                        setTimeout(() => {
                            window.location.reload();
                        }, 2000);
                        break;
                    case 'Network Error':
                        // Retry des requêtes échouées
                        this.retryFailedRequests();
                        break;
                    default:
                        console.log('Récupération générique tentée');
                }
            }
            showErrorMessage(type, details) {
                const errorToast = document.createElement('div');
                errorToast.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: rgba(239, 68, 68, 0.95);
                    color: white;
                    padding: 20px;
                    border-radius: 10px;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                    backdrop-filter: blur(10px);
                    z-index: 2001;
                    max-width: 350px;
                    font-size: 14px;
                    opacity: 0;
                    transform: translateX(100%);
                    transition: all 0.4s ease;
                `;
                errorToast.innerHTML = `
                    <div style="display: flex; align-items: flex-start; gap: 12px;">
                        <i class="fas fa-exclamation-triangle" style="font-size: 20px; margin-top: 2px;"></i>
                        <div>
                            <strong>Erreur détectée</strong>
                            <div style="margin-top: 5px; opacity: 0.9;">${type}</div>
                            <button onclick="window.location.reload()" style="
                                margin-top: 10px;
                                background: rgba(255,255,255,0.2);
                                border: 1px solid rgba(255,255,255,0.3);
                                color: white;
                                padding: 8px 15px;
                                border-radius: 6px;
                                cursor: pointer;
                                font-size: 12px;
                            ">
                                <i class="fas fa-refresh"></i> Actualiser la page
                            </button>
                        </div>
                    </div>
                `;
                document.body.appendChild(errorToast);
                setTimeout(() => {
                    errorToast.style.opacity = '1';
                    errorToast.style.transform = 'translateX(0)';
                }, 100);
                // Auto-suppression après 10 secondes
                setTimeout(() => {
                    errorToast.style.opacity = '0';
                    errorToast.style.transform = 'translateX(100%)';
                    setTimeout(() => {
                        if (document.body.contains(errorToast)) {
                            document.body.removeChild(errorToast);
                        }
                    }, 400);
                }, 10000);
            }
            showConnectivityStatus(message, type) {
                const statusToast = document.createElement('div');
                const bgColor = type === 'success' ? 'rgba(16, 185, 129, 0.95)' : 'rgba(245, 158, 11, 0.95)';
                const icon = type === 'success' ? 'fas fa-wifi' : 'fas fa-wifi-slash';
                statusToast.style.cssText = `
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    background: ${bgColor};
                    color: white;
                    padding: 15px 20px;
                    border-radius: 10px;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                    backdrop-filter: blur(10px);
                    z-index: 2000;
                    font-size: 14px;
                    opacity: 0;
                    transform: translateY(100%);
                    transition: all 0.4s ease;
                `;
                statusToast.innerHTML = `
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <i class="${icon}" style="font-size: 16px;"></i>
                        <strong>${message}</strong>
                    </div>
                `;
                document.body.appendChild(statusToast);
                setTimeout(() => {
                    statusToast.style.opacity = '1';
                    statusToast.style.transform = 'translateY(0)';
                }, 100);
                setTimeout(() => {
                    statusToast.style.opacity = '0';
                    statusToast.style.transform = 'translateY(100%)';
                    setTimeout(() => {
                        if (document.body.contains(statusToast)) {
                            document.body.removeChild(statusToast);
                        }
                    }, 400);
                }, 3000);
            }
            retryFailedRequests() {
                // Placeholder pour retry de requêtes échouées
                console.log('Retry des requêtes échouées...');
            }
        }
        // Système de performance monitoring
        class PerformanceMonitor {
            constructor() {
                this.metrics = new Map();
                this.thresholds = {
                    loadTime: 3000, // 3 secondes
                    navigationTime: 1000, // 1 seconde
                    memoryUsage: 50 * 1024 * 1024 // 50MB
                };
                this.init();
            }
            init() {
                // Mesure du temps de chargement initial
                window.addEventListener('load', () => {
                    const loadTime = performance.now();
                    this.recordMetric('initialLoad', loadTime);
                    if (loadTime > this.thresholds.loadTime) {
                        console.warn(`Temps de chargement élevé: ${loadTime.toFixed(2)}ms`);
                    }
                });
                // Surveillance de la mémoire
                if (performance.memory) {
                    setInterval(() => {
                        const memoryUsage = performance.memory.usedJSHeapSize;
                        this.recordMetric('memoryUsage', memoryUsage);
                        if (memoryUsage > this.thresholds.memoryUsage) {
                            console.warn(`Utilisation mémoire élevée: ${(memoryUsage / 1024 / 1024).toFixed(2)}MB`);
                        }
                    }, 30000); // Vérification toutes les 30 secondes
                }
                // Surveillance des navigations
                this.monitorNavigations();
            }
            recordMetric(name, value) {
                if (!this.metrics.has(name)) {
                    this.metrics.set(name, []);
                }
                const values = this.metrics.get(name);
                values.push({ value, timestamp: Date.now() });
                // Garder seulement les 100 dernières mesures
                if (values.length > 100) {
                    values.splice(0, values.length - 100);
                }
            }
            monitorNavigations() {
                const originalHandleNavigation = ModernLoadingSystem.prototype.handleNavigation;
                ModernLoadingSystem.prototype.handleNavigation = function(link) {
                    const startTime = performance.now();
                    originalHandleNavigation.call(this, link);
                    setTimeout(() => {
                        const navigationTime = performance.now() - startTime;
                        performanceMonitor.recordMetric('navigationTime', navigationTime);
                        if (navigationTime > performanceMonitor.thresholds.navigationTime) {
                            console.warn(`Navigation lente: ${navigationTime.toFixed(2)}ms`);
                        }
                    }, 0);
                };
            }
            getMetrics() {
                const result = {};
                this.metrics.forEach((values, name) => {
                    result[name] = {
                        current: values[values.length - 1]?.value || 0,
                        average: values.reduce((sum, item) => sum + item.value, 0) / values.length,
                        count: values.length
                    };
                });
                return result;
            }
        }
        // Initialisation des systèmes
        const errorRecovery = new ErrorRecoverySystem();
        const performanceMonitor = new PerformanceMonitor();
        // API globale pour le debugging
        window.debugSystem = {
            getPerformanceMetrics: () => performanceMonitor.getMetrics(),
            clearMetrics: () => {
                performanceMonitor.metrics.clear();
                console.log('Métriques de performance effacées');
            },
            simulateError: () => {
                throw new Error('Erreur de test simulée');
            },
            toggleDarkMode: () => {
                document.body.classList.toggle('dark-mode');
            }
        };
        console.log(' Système de chargement moderne initialisé');
        console.log(' Utilisez window.debugSystem pour les outils de debug');
    </script>
</body>
</html>