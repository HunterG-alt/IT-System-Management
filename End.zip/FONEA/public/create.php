<?php
session_start();
require_once '../Config/session.php';
require_once __DIR__ . '/../Lib/csrf.php';
require_once __DIR__ . '/../Config/config.php';
// Start session and check authentication
require_login();

$pdo = Database::getInstance()->getConnection();
$success = $error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF protection
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = "Token CSRF invalide. Veuillez recharger la page.";
    } else {
        // Sauvegarde partielle des champs du formulaire
        $formDataBackup = [
            'designation_materiel' => trim($_POST['designation_materiel'] ?? ''),
            'justification' => trim($_POST['justification'] ?? ''),
            'date_limite' => $_POST['date_limite'] ?? null,
            'materiels' => $_POST['materiels'] ?? []
        ];

        try {
            $pdo->beginTransaction();

            // Find agent ID from user_id
            $stmt = $pdo->prepare("SELECT id_agent FROM agents WHERE id_agent = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $agent = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$agent) {
                throw new Exception("Profil agent introuvable. Contactez l'administrateur.");
            }
            $agent_id = $agent['id_agent'];

            // Validate required fields
            if (empty($formDataBackup['designation_materiel'])) {
                throw new Exception("La désignation du matériel est obligatoire.");
            }
            if (empty($formDataBackup['justification'])) {
                throw new Exception("La justification est obligatoire.");
            }
            // Validate date limite if provided
            if ($formDataBackup['date_limite'] && !DateTime::createFromFormat('Y-m-d', $formDataBackup['date_limite'])) {
                throw new Exception("Format de date limite invalide.");
            }

            // Handle file upload if present
            $fichier_joint = null;
            if (isset($_FILES['fichier_joint']) && $_FILES['fichier_joint']['error'] === UPLOAD_ERR_OK) {
                $upload_dir = '../uploads/besoins/';
                if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

                $file_extension = pathinfo($_FILES['fichier_joint']['name'], PATHINFO_EXTENSION);
                $allowed_extensions = ['pdf', 'doc', 'docx', 'txt', 'jpg', 'jpeg', 'png'];
                if (!in_array(strtolower($file_extension), $allowed_extensions)) {
                    throw new Exception("Type de fichier non autorisé. Formats acceptés: " . implode(', ', $allowed_extensions));
                }

                $fichier_joint = uniqid() . '.' . $file_extension;
                $file_path = $upload_dir . $fichier_joint;
                if (!move_uploaded_file($_FILES['fichier_joint']['tmp_name'], $file_path)) {
                    throw new Exception("Erreur lors du téléchargement du fichier.");
                }
            }

            // Insert into etat_de_besoin
            $stmt = $pdo->prepare("
                INSERT INTO etat_de_besoin (
                    id_agent, 
                    designation_materiel, 
                    justification, 
                    fichier_joint,
                    date_limite,
                    statut
                ) VALUES (?, ?, ?, ?, ?, 'en_attente')
            ");
            $stmt->execute([
                $agent_id,
                $formDataBackup['designation_materiel'],
                $formDataBackup['justification'],
                $fichier_joint,
                $formDataBackup['date_limite']
            ]);
            $besoin_id = $pdo->lastInsertId();

            // Insert materials if provided
            $materiels = $formDataBackup['materiels'];
            if (!empty($materiels)) {
                $stmt_materiel = $pdo->prepare("
                    INSERT INTO besoin_materiel (id_besoin, nom, quantite, caracteristiques) 
                    VALUES (?, ?, ?, ?)
                ");
                foreach ($materiels as $materiel) {
                    if (!empty(trim($materiel['nom'] ?? ''))) {
                        $stmt_materiel->execute([
                            $besoin_id,
                            trim($materiel['nom']),
                            max(1, (int)($materiel['quantite'] ?? 1)),
                            trim($materiel['caracteristiques'] ?? '')
                        ]);
                    }
                }
            }

            // Create notification for chef de service
            $stmt = $pdo->prepare("SELECT id_agent FROM agents WHERE role = 'chef_service' LIMIT 1");
            $stmt->execute();
            $chef = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($chef) {
                $stmt = $pdo->prepare("
                    INSERT INTO notifications (id_agent, id_besoin, message) 
                    VALUES (?, ?, ?)
                ");
                $stmt->execute([
                    $chef['id_agent'],
                    $besoin_id,
                    "Nouvel état de besoin soumis: " . $formDataBackup['designation_materiel']
                ]);
            }

            // Log activity
            $stmt = $pdo->prepare("
                INSERT INTO activity_log (user_id, action, entity_type, entity_id, description) 
                VALUES (?, 'CREATE', 'besoin', ?, ?)
            ");
            $stmt->execute([
                $_SESSION['user_id'],
                $besoin_id,
                "Création d'un état de besoin: " . $formDataBackup['designation_materiel']
            ]);

            $pdo->commit();
            $success = "État de besoin soumis avec succès ! (ID: #$besoin_id)";
            $_POST = []; // Reset form data

        } catch (Exception $e) {
            $pdo->rollback();
            $error = "Erreur : " . $e->getMessage();
            // Restore user input if error occurred
            $_POST = $formDataBackup;
            if (isset($file_path) && file_exists($file_path)) unlink($file_path);
        }
    }
}
// Get material types for dropdown
$stmt = $pdo->query("SELECT id_type, libelle FROM type_materiel ORDER BY libelle");
$types_materiel = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Generate CSRF token
$csrf_token = csrf_token();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créer un État de Besoin - FONEA</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
:root {
  --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  --accent-gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
  --glass-bg: rgba(255, 255, 255, 0.12);
  --glass-border: rgba(255, 255, 255, 0.25);
  --text-color: #f9fafb;
  --card-shadow: 0 20px 50px rgba(0, 0, 0, 0.25);
  --radius: 20px;
  --transition: all 0.3s ease;
}
/* === BACKGROUND === */
body {
  background: var(--primary-gradient);
  font-family: 'Inter', sans-serif;
  color: var(--text-color);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}
/* Subtle floating particles */
body::before {
  content: "";
  position: fixed;
  top: -50%;
  left: -50%;
  width: 200%;
  height: 200%;
  background: radial-gradient(circle at 20% 30%, rgba(255, 255, 255, 0.08), transparent 40%),
    radial-gradient(circle at 80% 70%, rgba(255, 255, 255, 0.06), transparent 40%);
  animation: floatBg 15s linear infinite alternate;
  z-index: -1;
}
@keyframes floatBg {
  0% { transform: translate(0,0) scale(1);}
  100%{ transform: translate(-20px,-20px) scale(1.05);}
}
/* === CARD STYLING === */
.card {
  background: var(--glass-bg);
  backdrop-filter: blur(20px) saturate(180%);
  border: 1px solid var(--glass-border);
  border-radius: var(--radius);
  box-shadow: var(--card-shadow);
  overflow: hidden;
  transition: var(--transition);
}
.card:hover {
  transform: translateY(-4px);
  box-shadow: 0 25px 60px rgba(0,0,0,0.35);
}
.card-header {
  background: var(--primary-gradient);
  color: white;
  padding: 2rem;
  border-bottom: none;
  position: relative;
}
.card-header::after {
  content: "";
  position: absolute;
  top: -40px;
  right: -40px;
  width: 120px;
  height: 120px;
  background: radial-gradient(circle, rgba(255,255,255,0.12) 0%, transparent 70%);
  border-radius: 50%;
}
.card-body { padding: 2.5rem; }
/* === FORM SECTIONS === */
.form-section {
  background: rgba(255,255,255,0.08);
  border: 1px solid var(--glass-border);
  border-left: 4px solid transparent;
  border-image: var(--primary-gradient) 1;
  border-radius: var(--radius);
  padding: 2rem;
  margin-bottom: 2rem;
  backdrop-filter: blur(15px);
  transition: var(--transition);
}
.form-section:hover {
  transform: translateY(-2px);
  box-shadow: 0 12px 40px rgba(0,0,0,0.2);
}
/* === LABELS & INPUTS === */
.form-label {
  font-weight: 600;
  color: #e5e7eb;
  margin-bottom: 0.6rem;
  font-size: 0.95rem;
}
.form-control, .form-select {
  background: rgba(255,255,255,0.18);
  color: #1f2937;
  border: 1px solid rgba(255,255,255,0.25);
  border-radius: 12px;
  padding: 0.9rem 1.1rem;
  transition: var(--transition);
  backdrop-filter: blur(10px);
  font-size: 0.95rem;
  min-height: 48px;
  width: 100%;
}
.form-control::placeholder {
  color: #6b7280;
  opacity: 0.8;
}
.form-control:focus, .form-select:focus {
  border-color: #a78bfa;
  box-shadow: 0 0 0 0.25rem rgba(102,126,234,0.25);
  background: rgba(255,255,255,0.28);
  outline: none;
}
/* Dynamic textarea */
textarea.form-control {
  resize: none;
  overflow-y: hidden;
  min-height: 48px;
  max-height: 400px;
  transition: height 0.2s ease;
  line-height: 1.6;
}
/* Ensure consistent height for all inputs */
input[type="text"].form-control,
input[type="date"].form-control,
input[type="number"].form-control,
input[type="file"].form-control,
.form-select {
  height: 48px;
}
/* === MATERIAL ITEMS === */
.material-item {
  background: rgba(255,255,255,0.1);
  border: 1px solid var(--glass-border);
  border-radius: var(--radius);
  padding: 1.8rem;
  backdrop-filter: blur(15px);
  margin-bottom: 1.8rem;
  transition: var(--transition);
}
.material-item:hover {
  transform: translateY(-3px);
  box-shadow: 0 12px 40px rgba(0,0,0,0.25);
}
.remove-material {
  position: absolute;
  top: 1rem;
  right: 1rem;
  background: var(--accent-gradient);
  border: none;
  color: white;
  border-radius: 50%;
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 5px 15px rgba(0,0,0,0.2);
  cursor: pointer;
}
/* === BUTTONS === */
.btn-primary {
  background: var(--primary-gradient);
  border: none;
  color: white;
  font-weight: 600;
  border-radius: 12px;
  padding: 0.8rem 1.6rem;
  box-shadow: 0 4px 15px rgba(0,0,0,0.25);
}
.btn-primary:hover {
  background: linear-gradient(135deg,#5a67d8,#6b46c1);
  transform: translateY(-2px);
}
.add-material-btn {
  background: rgba(255,255,255,0.08);
  border: 2px dashed rgba(255,255,255,0.25);
  color: #e0e7ff;
  padding: 2rem;
  border-radius: var(--radius);
  backdrop-filter: blur(15px);
}
.add-material-btn:hover {
  background: var(--primary-gradient);
  color: white;
  border-color: transparent;
  transform: translateY(-3px);
}
/* === ALERTS === */
.alert {
  background: rgba(255,255,255,0.12);
  border-left: 4px solid #4facfe;
  backdrop-filter: blur(15px);
  border-radius: var(--radius);
  color: #e0f2fe;
}
.alert-success {
  border-left-color: #34d399;
}
.alert-danger {
  border-left-color: #f87171;
}
.alert .btn-close {
  filter: invert(1);
}
    </style>
</head>
<body>
<div class="container mt-4">
    <div class="row">
        <div class="col-lg-10 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">
                        <i class="fas fa-plus-circle me-2"></i>
                        Créer un État de Besoin
                    </h4>
                </div>
                <div class="card-body">
                    <!-- Messages -->
                    <?php if ($success): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle me-2"></i>
                            <?php echo htmlspecialchars($success); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?php echo htmlspecialchars($error); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    <form method="POST" enctype="multipart/form-data" id="besoin-form">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <!-- Informations générales -->
                        <div class="form-section">
                            <h5 class="mb-3"><i class="fas fa-info-circle me-2"></i>Informations Générales</h5>
                            <div class="row">
                                <div class="col-md-8 mb-3">
                                    <label class="form-label required-field">Désignation du matériel</label>
                                    <input type="text" 
                                           name="designation_materiel" 
                                           class="form-control" 
                                           value="<?php echo htmlspecialchars($_POST['designation_materiel'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                           placeholder="Ex: Ordinateur portable pour comptabilité"
                                           required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Date limite souhaitée</label>
                                    <input type="date" 
                                           name="date_limite" 
                                           class="form-control"
                                           value="<?php echo htmlspecialchars($_POST['date_limite'] ?? ''); ?>"
                                           min="<?php echo date('Y-m-d'); ?>">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label required-field">Justification de la demande</label>
                                <textarea name="justification" 
                                          class="form-control" 
                                          placeholder="Expliquez pourquoi ce matériel est nécessaire..."
                                          required><?php echo htmlspecialchars($_POST['justification'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Fichier joint (optionnel)</label>
                                <input type="file" 
                                       name="fichier_joint" 
                                       class="form-control"
                                       accept=".pdf">
                                <div class="form-text">
                                    Formats acceptés: PDF
                                </div>
                            </div>
                        </div>
                        <!-- Matériels demandés -->
                        <div class="form-section">
                            <h5 class="mb-3">
                                <i class="fas fa-boxes me-2"></i>Matériels Demandés
                            </h5>
                            <div id="materiels-container">
                                <div class="material-item">
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Nom du matériel</label>
                                            <input type="text" 
                                                   name="materiels[0][nom]" 
                                                   class="form-control"
                                                   placeholder="Ex: Ordinateur portable HP">
                                        </div>
                                        <div class="col-md-2 mb-3">
                                            <label class="form-label">Quantité</label>
                                            <input type="number" 
                                                   name="materiels[0][quantite]" 
                                                   class="form-control"
                                                   value="1"
                                                   min="1">
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label class="form-label">Type</label>
                                            <select name="materiels[0][type]" class="form-control">
                                                <option value="">-- Sélectionner --</option>
                                                <?php foreach ($types_materiel as $type): ?>
                                                    <option value="<?php echo $type['id_type']; ?>">
                                                        <?php echo htmlspecialchars($type['libelle']); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Caractéristiques techniques</label>
                                        <textarea name="materiels[0][caracteristiques]" 
                                                  class="form-control" 
                                                  placeholder="Ex: RAM 8Go, SSD 256Go, Écran 15.6 pouces..."></textarea>
                                    </div>
                                </div>
                            </div>
                            <button type="button" class="btn add-material-btn w-100" onclick="addMaterial()">
                                <i class="fas fa-plus me-2"></i>Ajouter un autre matériel
                            </button>
                        </div>
                        <!-- Boutons d'action -->
                        <div class="text-end">
                            <button type="button" class="btn btn-outline-secondary me-2" onclick="resetForm()">
                                <i class="fas fa-undo me-2"></i>Réinitialiser
                            </button>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane me-2"></i>Soumettre la demande
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<script>
let materialCount = 1;
// Auto-resize textarea functionality
function autoResizeTextarea(textarea) {
    // Reset height to get accurate scrollHeight
    textarea.style.height = 'auto';
    // Set new height with max limit
    const newHeight = Math.min(textarea.scrollHeight, 400);
    textarea.style.height = newHeight + 'px';
    // Show scrollbar only if at max height
    if (textarea.scrollHeight > 400) {
        textarea.style.overflowY = 'auto';
    } else {
        textarea.style.overflowY = 'hidden';
    }
}
// Initialize auto-resize for existing textareas
document.addEventListener('DOMContentLoaded', function() {
    const textareas = document.querySelectorAll('textarea.form-control');
    textareas.forEach(textarea => {
        // Auto-resize on input
        textarea.addEventListener('input', function() {
            autoResizeTextarea(this);
        });
        // Auto-resize on focus (in case content was pasted)
        textarea.addEventListener('focus', function() {
            autoResizeTextarea(this);
        });
        // Initial resize
        autoResizeTextarea(textarea);
    });
});
function addMaterial() {
    const container = document.getElementById('materiels-container');
    const materialItem = document.createElement('div');
    materialItem.className = 'material-item';
    materialItem.innerHTML = `
        <button type="button" class="btn btn-sm btn-outline-danger remove-material" onclick="removeMaterial(this)">
            <i class="fas fa-times"></i>
        </button>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Nom du matériel</label>
                <input type="text" name="materiels[${materialCount}][nom]" class="form-control" placeholder="Ex: Souris sans fil">
            </div>
            <div class="col-md-2 mb-3">
                <label class="form-label">Quantité</label>
                <input type="number" name="materiels[${materialCount}][quantite]" class="form-control" value="1" min="1">
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label">Type</label>
                <select name="materiels[${materialCount}][type]" class="form-control">
                    <option value="">-- Sélectionner --</option>
                    <?php foreach ($types_materiel as $type): ?>
                        <option value="<?php echo $type['id_type']; ?>"><?php echo htmlspecialchars($type['libelle']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="mb-3">
            <label class="form-label">Caractéristiques techniques</label>
            <textarea name="materiels[${materialCount}][caracteristiques]" class="form-control" placeholder="Spécifications techniques..."></textarea>
        </div>
    `;
    container.appendChild(materialItem);
    // Add auto-resize functionality to the new textarea
    const newTextarea = materialItem.querySelector('textarea.form-control');
    newTextarea.addEventListener('input', function() {
        autoResizeTextarea(this);
    });
    // Initial resize for the new textarea
    autoResizeTextarea(newTextarea);
    materialCount++;
}
function removeMaterial(button) {
    button.parentElement.remove();
}
// FIXED: Reset form function
function resetForm() {
    if (confirm('Êtes-vous sûr de vouloir réinitialiser le formulaire ?')) {
        document.getElementById('besoin-form').reset();
        // Keep only the first material item
        const container = document.getElementById('materiels-container');
        const firstItem = container.querySelector('.material-item');
        container.innerHTML = '';
        container.appendChild(firstItem);
        materialCount = 1;
    }
}
// Form validation
document.getElementById('besoin-form').addEventListener('submit', function(e) {
    const designation = document.querySelector('[name="designation_materiel"]').value.trim();
    const justification = document.querySelector('[name="justification"]').value.trim();
    if (!designation || !justification) {
        e.preventDefault();
        alert('Veuillez remplir tous les champs obligatoires.');
        return false;
    }
    return confirm('Confirmer la soumission de cet état de besoin ?');
});
// Auto-dismiss alerts
setTimeout(function() {
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(alert => {
        const closeBtn = alert.querySelector('.btn-close');
        if (closeBtn) closeBtn.click();
    });
}, 5000);
</script>
</body>
</html>