<?php
// content.php - Dashboard content sections with database integration
require_once '../Config/db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit();
}

$pdo = Database::getInstance()->getConnection();
$user_role = $_SESSION['role'] ?? 'agent';

// Function to check if table exists
function tableExists($pdo, $tableName) {
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE '$tableName'");
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        return false;
    }
}

// Fetch recent activities from database
$recent_activities = [];
try {
    if (tableExists($pdo, 'activity_log')) {
        $stmt = $pdo->prepare("
            SELECT 
                DATE(created_at) as date_action,
                CASE 
                    WHEN table_name = 'EtatBesoin' THEN CONCAT('Nouvelle demande - ', description)
                    WHEN table_name = 'Validation' THEN CONCAT('Validation - ', description)
                    WHEN table_name = 'Acquisition' THEN CONCAT('Acquisition - ', description)
                    ELSE action_description
                END as action,
                u.nom as utilisateur,
                status
            FROM activity_log a
            LEFT JOIN Utilisateur u ON a.user_id = u.id_utilisateur
            ORDER BY a.created_at DESC 
            LIMIT 10
        ");
        $stmt->execute();
        $recent_activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    error_log("Error fetching activities: " . $e->getMessage());
}

// Fallback data if no activities found
if (empty($recent_activities)) {
    $recent_activities = [
        [
            'date_action' => date("Y-m-d"),
            'action' => 'Nouvelle demande - Ordinateur portable',
            'utilisateur' => 'Alice Agent',
            'status' => 'En attente'
        ],
        [
            'date_action' => date("Y-m-d", strtotime("-1 day")),
            'action' => 'Validation direction - RAM 32GB',
            'utilisateur' => 'Diane Directrice',
            'status' => 'Approuvé'
        ]
    ];
}

// Fetch états de besoin
$etats_besoin = [];
try {
    if (tableExists($pdo, 'EtatBesoin')) {
        $stmt = $pdo->query("
            SELECT eb.id_etat_de_besoin, eb.description, eb.date_demande, eb.statut,
                   u.nom as demandeur
            FROM EtatBesoin eb
            LEFT JOIN Utilisateur u ON eb.id_demandeur = u.id_utilisateur
            ORDER BY eb.date_demande DESC
            LIMIT 20
        ");
        $etats_besoin = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    error_log("Error fetching états de besoin: " . $e->getMessage());
}

// Fetch materials
$materiels = [];
try {
    if (tableExists($pdo, 'Materiel')) {
        $stmt = $pdo->query("
            SELECT m.id_materiel, m.reference, m.nom, m.marque, 
                   c.nom as categorie, m.statut
            FROM Materiel m
            LEFT JOIN Categorie c ON m.id_categorie = c.id_categorie
            ORDER BY m.nom
            LIMIT 20
        ");
        $materiels = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    error_log("Error fetching materials: " . $e->getMessage());
}

// Fetch acquisitions
$acquisitions = [];
try {
    if (tableExists($pdo, 'Acquisition')) {
        $stmt = $pdo->query("
            SELECT a.id_acquisition, eb.id_etat_besoin, f.nom as fournisseur,
                   c.date_commande, a.date_acquisition, a.statut
            FROM Acquisition a
            LEFT JOIN Commande c ON a.id_commande = c.id_commande
            LEFT JOIN Fournisseur f ON c.id_fournisseur = f.id_fournisseur
            LEFT JOIN EtatBesoin eb ON c.id_etat_besoin = eb.id_etat_besoin
            ORDER BY a.date_acquisition DESC
            LIMIT 20
        ");
        $acquisitions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    error_log("Error fetching acquisitions: " . $e->getMessage());
}

// Fetch users (only for admin/direction roles)
$users = [];
if (in_array($user_role, ['admin', 'direction'])) {
    try {
        if (tableExists($pdo, 'Utilisateur')) {
            $stmt = $pdo->query("
                SELECT u.id_utilisateur, u.nom, u.email, r.nom as role, u.date_creation
                FROM Utilisateur u
                LEFT JOIN Role r ON u.id_role = r.id_role
                ORDER BY u.nom
            ");
            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    } catch (PDOException $e) {
        error_log("Error fetching users: " . $e->getMessage());
    }
}

// Function to get status badge class
function getStatusBadgeClass($status) {
    switch (strtolower($status)) {
        case 'en attente':
        case 'pending':
            return 'status-pending';
        case 'approuvé':
        case 'approved':
        case 'validé':
            return 'status-approved';
        case 'rejeté':
        case 'rejected':
            return 'status-rejected';
        case 'en transit':
        case 'transit':
            return 'status-transit';
        case 'complété':
        case 'completed':
        case 'en cours':
            return 'status-completed';
        case 'disponible':
        case 'available':
            return 'status-available';
        case 'en utilisation':
            return 'status-in-use';
        default:
            return 'status-pending';
    }
}
?>

// Style pour les  tables et les badges
<style>
/* Custom table styling to match dashboard */
.table-container {
    background-color: #1c1c1e;
    padding: 20px;
    border-radius: 12px;
}
.table-container h3 {
    color: #ffffff;
}
.table-hover tbody tr:hover {
    background-color: rgba(255, 255, 255, 0.05);
}
.table thead th {
    text-align: left;
    font-weight: 600;
    border-bottom: 2px solid #444;
}
.table tbody td {
    vertical-align: middle;
}
/* First column darker teal */
.table tbody td:first-child {
    background-color: #0b5ed7;
    color: white;
    font-weight: 500;
}
/* Status badge styling */
.status-badge {
    padding: 4px 8px;
    border-radius: 8px;
    font-size: 0.85rem;
    font-weight: 500;
    display: inline-block;
}
/* Status colors */
.status-pending { background-color: #ffc107; color: #212529; }
.status-approved { background-color: #198754; color: white; }
.status-rejected { background-color: #dc3545; color: white; }
.status-transit { background-color: #0dcaf0; color: #212529; }
.status-completed { background-color: #20c997; color: white; }
.status-available { background-color: #0d6efd; color: white; }
/* Action buttons */
.btn-glass {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.3);
    color: #fff;
    border-radius: 8px;
}
.btn-glass:hover {
    background: rgba(255, 255, 255, 0.2);
}
</style>
<!-- Content Sections -->
<div id="dashboard" class="content-section active">
    <div class="row">
        <div class="col-12">
            <div class="table-container">
                <h3 class="text-white mb-4">
                    <i class="fas fa-chart-line me-2"></i>Activités Récentes
                </h3>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Action</th>
                            <th>Utilisateur</th>
                            <th>Statut</th>
                        </tr>
                    </thead>
                    <tbody id="recentActivities">
                        <?php foreach ($recent_activities as $activity): ?>
                        <tr>
                            <td><?php echo date("d/m/Y", strtotime($activity['date_action'])); ?></td>
                            <td><?php echo htmlspecialchars($activity['action']); ?></td>
                            <td><?php echo htmlspecialchars($activity['utilisateur'] ?? 'Système'); ?></td>
                            <td>
                                <span class="status-badge <?php echo getStatusBadgeClass($activity['status']); ?>">
                                    <?php echo htmlspecialchars($activity['status']); ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div id="requests" class="content-section">
    <div class="table-container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="text-white mb-0">
                <i class="fas fa-clipboard-list me-2"></i>Gestion des États de Besoin
            </h3>
            <?php if (in_array($user_role, ['agent', 'chef_service'])): ?>
            <button class="btn btn-glass" onclick="showModal('newRequestModal')">
                <i class="fas fa-plus me-2"></i>Nouvelle Demande
            </button>
            <?php endif; ?>
        </div>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Demandeur</th>
                    <th>Désignation</th>
                    <th>Date</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($etats_besoin as $etat): ?>
                <tr>
                    <td>#<?php echo str_pad($etat['id_etat_besoin'], 3, '0', STR_PAD_LEFT); ?></td>
                    <td><?php echo htmlspecialchars($etat['demandeur'] ?? 'Non assigné'); ?></td>
                    <td><?php echo htmlspecialchars($etat['description']); ?></td>
                    <td><?php echo date("d/m/Y", strtotime($etat['date_demande'])); ?></td>
                    <td>
                        <span class="status-badge <?php echo getStatusBadgeClass($etat['statut']); ?>">
                            <?php echo htmlspecialchars($etat['statut']); ?>
                        </span>
                    </td>
                    <td>
                        <button class="btn btn-sm btn-glass me-2" onclick="viewRequest(<?php echo $etat['id_etat_besoin']; ?>)">
                            <i class="fas fa-eye"></i>
                        </button>
                        <?php if (in_array($user_role, ['chef_service', 'direction', 'admin'])): ?>
                        <button class="btn btn-sm btn-glass" onclick="editRequest(<?php echo $etat['id_etat_besoin']; ?>)">
                            <i class="fas fa-edit"></i>
                        </button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<div id="materials" class="content-section">
    <div class="table-container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="text-white mb-0">
                <i class="fas fa-laptop me-2"></i>Gestion du Matériel
            </h3>
            <?php if (in_array($user_role, ['it', 'admin'])): ?>
            <button class="btn btn-glass" onclick="showModal('newMaterialModal')">
                <i class="fas fa-plus me-2"></i>Ajouter Matériel
            </button>
            <?php endif; ?>
        </div>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Référence</th>
                    <th>Désignation</th>
                    <th>Marque</th>
                    <th>Catégorie</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($materiels as $materiel): ?>
                <tr>
                    <td><?php echo htmlspecialchars($materiel['reference']); ?></td>
                    <td><?php echo htmlspecialchars($materiel['nom']); ?></td>
                    <td><?php echo htmlspecialchars($materiel['marque']); ?></td>
                    <td><?php echo htmlspecialchars($materiel['categorie'] ?? 'Non catégorisé'); ?></td>
                    <td>
                        <span class="status-badge <?php echo getStatusBadgeClass($materiel['statut']); ?>">
                            <?php echo htmlspecialchars($materiel['statut']); ?>
                        </span>
                    </td>
                    <td>
                        <button class="btn btn-sm btn-glass me-2" onclick="viewMaterial(<?php echo $materiel['id_materiel']; ?>)">
                            <i class="fas fa-eye"></i>
                        </button>
                        <?php if (in_array($user_role, ['it', 'admin'])): ?>
                        <button class="btn btn-sm btn-glass" onclick="editMaterial(<?php echo $materiel['id_materiel']; ?>)">
                            <i class="fas fa-edit"></i>
                        </button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<div id="acquisitions" class="content-section">
    <div class="table-container">
        <h3 class="text-white mb-4">
            <i class="fas fa-shopping-cart me-2"></i>Suivi des Acquisitions
        </h3>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>État de Besoin</th>
                    <th>Fournisseur</th>
                    <th>Date Commande</th>
                    <th>Date Réception</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($acquisitions as $acquisition): ?>
                <tr>
                    <td>#<?php echo str_pad($acquisition['id_etat_besoin'], 3, '0', STR_PAD_LEFT); ?></td>
                    <td><?php echo htmlspecialchars($acquisition['fournisseur'] ?? 'Non défini'); ?></td>
                    <td><?php echo $acquisition['date_commande'] ? date("d/m/Y", strtotime($acquisition['date_commande'])) : 'N/A'; ?></td>
                    <td><?php echo $acquisition['date_acquisition'] ? date("d/m/Y", strtotime($acquisition['date_acquisition'])) : 'En attente'; ?></td>
                    <td>
                        <span class="status-badge <?php echo getStatusBadgeClass($acquisition['statut']); ?>">
                            <?php echo htmlspecialchars($acquisition['statut']); ?>
                        </span>
                    </td>
                    <td>
                        <button class="btn btn-sm btn-glass" onclick="viewAcquisition(<?php echo $acquisition['id_acquisition']; ?>)">
                            <i class="fas fa-eye"></i>
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php if (in_array($user_role, ['admin', 'direction'])): ?>
<div id="users" class="content-section">
    <div class="table-container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="text-white mb-0">
                <i class="fas fa-users me-2"></i>Gestion des Utilisateurs
            </h3>
            <button class="btn btn-glass" onclick="showModal('newUserModal')">
                <i class="fas fa-user-plus me-2"></i>Nouvel Utilisateur
            </button>
        </div>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Email</th>
                    <th>Rôle</th>
                    <th>Date Création</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['nom']); ?></td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td><?php echo htmlspecialchars($user['role']); ?></td>
                    <td><?php echo date("d/m/Y", strtotime($user['date_creation'])); ?></td>
                    <td>
                        <button class="btn btn-sm btn-glass me-2" onclick="editUser(<?php echo $user['id_utilisateur']; ?>)">
                            <i class="fas fa-edit"></i>
                        </button>
                        <?php if ($user['id_utilisateur'] != $_SESSION['user_id']): ?>
                        <button class="btn btn-sm btn-glass" onclick="deleteUser(<?php echo $user['id_utilisateur']; ?>)">
                            <i class="fas fa-trash"></i>
                        </button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
<script>

function showModal(modalId) {
    
    console.log('Showing modal:', modalId);
    
}
function viewRequest(id) {
    window.location.href = `requests.php?action=view&id=${id}`;
}
function editRequest(id) {
    window.location.href = `requests.php?action=edit&id=${id}`;
}
function viewMaterial(id) {
    window.location.href = `material.php?action=view&id=${id}`;
}
function editMaterial(id) {
    window.location.href = `material.php?action=edit&id=${id}`;
}
function viewAcquisition(id) {
    window.location.href = `acquisition.php?action=view&id=${id}`;
}
function editUser(id) {
    window.location.href = `user.php?action=edit&id=${id}`;
}
function deleteUser(id) {
    if (confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?')) {
        window.location.href = `users.php?action=delete&id=${id}`;
    }
}
// Auto-refresh recent activities every 30 seconds
setInterval(function() {
    // You can implement AJAX call to refresh activities
    console.log('Refreshing activities...');
}, 30000);
</script>