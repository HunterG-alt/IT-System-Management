<?php
// Security & Authentication
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Lib/csrf.php';
// Start session and check authentication
require_login();
// Check user permissions (only certain roles can delete)
$allowed_roles = [ROLE_DIRECTEUR, ROLE_INFORMATIQUE, ROLE_MOYENS_GENERAUX];
if (!in_array($_SESSION['role'], $allowed_roles)) {
    die('Accès refusé - Vous n\'avez pas les permissions pour supprimer des éléments');
}
$pdo = Database::getInstance()->getConnection();
$success = $error = '';
// Check what entity to delete (besoin or materiel)
$entity_type = $_GET['type'] ?? 'besoin';
$allowed_types = ['besoin', 'materiel'];
if (!in_array($entity_type, $allowed_types)) {
    die("Type d'entité invalide.");
}
// Verification of ID parameter
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("⚠️ ID manquant ou invalide.");
}
$id = (int) $_GET['id'];
// Handle POST request (actual deletion)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF verification
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        die("⚠️ Token CSRF invalide !");
    }
    // Confirm deletion was requested
    if (!isset($_POST['confirm_delete'])) {
        $error = "Confirmation de suppression requise.";
    } else {
        try {
            $pdo->beginTransaction();
            if ($entity_type === 'besoin') {
                // Archive the need before deletion
                $stmt = $pdo->prepare("
                    INSERT INTO besoin_archive (
                        original_id, agent_id, designation, justification, 
                        date_soumission, statut, deleted_by
                    )
                    SELECT 
                        id_besoin, id_agent, designation_materiel, justification,
                        date_soumission, statut, ?
                    FROM etat_de_besoin 
                    WHERE id_besoin = ?
                ");
                $stmt->execute([$_SESSION['user_id'], $id]);
                // Delete the need (CASCADE will handle related records)
                $stmt = $pdo->prepare("DELETE FROM etat_de_besoin WHERE id_besoin = ?");
                $stmt->execute([$id]);
                if ($stmt->rowCount() === 0) {
                    throw new Exception("État de besoin introuvable ou déjà supprimé.");
                }
                // Log activity
                $stmt = $pdo->prepare("
                    INSERT INTO activity_log (user_id, action, entity_type, entity_id, description) 
                    VALUES (?, 'DELETE', 'besoin', ?, ?)
                ");
                $stmt->execute([
                    $_SESSION['user_id'], 
                    $id, 
                    "Suppression de l'état de besoin #$id"
                ]);
                $success = "État de besoin supprimé avec succès.";
                $redirect_url = "list_besoins.php";
            } else { // materiel
                // Check if material exists and get info for logging
                $stmt = $pdo->prepare("
                    SELECT designation, reference FROM materiel WHERE id_materiel = ?
                ");
                $stmt->execute([$id]);
                $materiel = $stmt->fetch(PDO::FETCH_ASSOC);
                if (!$materiel) {
                    throw new Exception("Matériel introuvable.");
                }
                // Delete material (CASCADE will handle related records)
                $stmt = $pdo->prepare("DELETE FROM materiel WHERE id_materiel = ?");
                $stmt->execute([$id]);
                if ($stmt->rowCount() === 0) {
                    throw new Exception("Matériel introuvable ou déjà supprimé.");
                }
                // Log activity
                $stmt = $pdo->prepare("
                    INSERT INTO activity_log (user_id, action, entity_type, entity_id, description) 
                    VALUES (?, 'DELETE', 'materiel', ?, ?)
                ");
                $stmt->execute([
                    $_SESSION['user_id'], 
                    $id, 
                    "Suppression du matériel: " . $materiel['designation'] . " (Ref: " . $materiel['reference'] . ")"
                ]);
                $success = "Matériel supprimé avec succès.";
                $redirect_url = "list_materiel.php";
            }
            $pdo->commit();
            // Redirect after successful deletion
            header("Location: " . $redirect_url . "?success=deleted&message=" . urlencode($success));
            exit;
        } catch (Exception $e) {
            $pdo->rollback();
            $error = "Erreur lors de la suppression : " . $e->getMessage();
        }
    }
}
// Get entity information for confirmation
try {
    if ($entity_type === 'besoin') {
        $stmt = $pdo->prepare("
            SELECT eb.*, a.nom, a.prenom
            FROM etat_de_besoin eb
            JOIN agents a ON eb.id_agent = a.id_agent
            WHERE eb.id_besoin = ?
        ");
        $stmt->execute([$id]);
        $entity = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$entity) {
            die("État de besoin introuvable.");
        }
        $entity_name = $entity['designation_materiel'];
        $entity_details = "Demandeur: " . $entity['prenom'] . " " . $entity['nom'] . 
                         "<br>Statut: " . $entity['statut'] . 
                         "<br>Date: " . date('d/m/Y', strtotime($entity['date_soumission']));
    } else { // materiel
        $stmt = $pdo->prepare("
            SELECT m.*, tm.libelle as type_libelle
            FROM materiel m
            LEFT JOIN type_materiel tm ON m.id_type = tm.id_type
            WHERE m.id_materiel = ?
        ");
        $stmt->execute([$id]);
        $entity = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$entity) {
            die("Matériel introuvable.");
        }
        $entity_name = $entity['designation'];
        $entity_details = "Référence: " . $entity['reference'] . 
                         "<br>Marque: " . $entity['marque'] . 
                         "<br>Modèle: " . $entity['modele'] .
                         "<br>Type: " . ($entity['type_libelle'] ?: 'Non défini');
    }
} catch (Exception $e) {
    die("Erreur lors de la récupération des données : " . $e->getMessage());
}
// Generate CSRF token
$csrf_token = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmer la suppression - FONEA</title>
    <link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .delete-confirmation {
            background: linear-gradient(135deg, #dc3545, #c82333);
            color: white;
        }
        .entity-details {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 20px;
        }
        .warning-icon {
            font-size: 4rem;
            color: #ffc107;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        .btn-delete {
            background: #dc3545;
            border-color: #dc3545;
            box-shadow: 0 4px 8px rgba(220, 53, 69, 0.3);
        }
        .btn-delete:hover {
            background: #c82333;
            border-color: #bd2130;
            box-shadow: 0 6px 12px rgba(220, 53, 69, 0.4);
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-lg border-0">
                <div class="card-header delete-confirmation text-center py-4">
                    <i class="fas fa-exclamation-triangle warning-icon d-block mb-3"></i>
                    <h3 class="mb-0">Confirmer la suppression</h3>
                </div>
                <div class="card-body p-4">
                    <?php if ($error): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?php echo htmlspecialchars($error); ?>
                        </div>
                    <?php endif; ?>
                    <div class="text-center mb-4">
                        <h5 class="text-danger">
                            <i class="fas fa-trash-alt me-2"></i>
                            Voulez-vous vraiment supprimer ce <?php echo $entity_type === 'besoin' ? 'besoin' : 'matériel'; ?> ?
                        </h5>
                        <p class="text-muted">Cette action est irréversible.</p>
                    </div>
                    <div class="entity-details mb-4">
                        <h6 class="fw-bold mb-3">
                            <i class="fas fa-info-circle me-2"></i>
                            Détails de l'élément à supprimer:
                        </h6>
                        <div class="row">
                            <div class="col-md-3">
                                <strong>ID:</strong>
                            </div>
                            <div class="col-md-9">
                                #<?php echo $id; ?>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-3">
                                <strong>Nom:</strong>
                            </div>
                            <div class="col-md-9">
                                <?php echo htmlspecialchars($entity_name); ?>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-3">
                                <strong>Détails:</strong>
                            </div>
                            <div class="col-md-9">
                                <?php echo $entity_details; ?>
                            </div>
                        </div>
                    </div>
                    <?php if ($entity_type === 'besoin'): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>Attention:</strong> La suppression de cet état de besoin supprimera également tous les éléments associés 
                        (matériels, validations, commandes, etc.). Les données seront archivées pour traçabilité.
                    </div>
                    <?php endif; ?>
                    <div class="d-flex justify-content-between mt-4">
                        <a href="javascript:history.back()" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>
                            Annuler
                        </a>
                        <form method="POST" class="d-inline" onsubmit="return confirmDelete()">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                            <input type="hidden" name="confirm_delete" value="1">
                            <button type="submit" class="btn btn-danger btn-delete">
                                <i class="fas fa-trash-alt me-2"></i>
                                Confirmer la suppression
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Additional warnings -->
            <div class="mt-4">
                <div class="alert alert-info">
                    <h6><i class="fas fa-info-circle me-2"></i>Informations importantes:</h6>
                    <ul class="mb-0">
                        <li>Cette suppression sera journalisée dans les logs système</li>
                        <li>Votre identité sera enregistrée comme auteur de la suppression</li>
                        <?php if ($entity_type === 'besoin'): ?>
                        <li>Les données seront archivées et pourront être consultées par les administrateurs</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../../assets/js/bootstrap.bundle.min.js"></script>
<script>
function confirmDelete() {
    return confirm('Êtes-vous absolument certain de vouloir supprimer cet élément ?\n\nCette action ne peut pas être annulée.');
}
// Auto-focus on cancel button for keyboard navigation
document.addEventListener('DOMContentLoaded', function() {
    const cancelBtn = document.querySelector('.btn-secondary');
    if (cancelBtn) {
        cancelBtn.focus();
    }
});
// Keyboard shortcut: ESC to cancel
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        history.back();
    }
});
</script>
</body>
</html>