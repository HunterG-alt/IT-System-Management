<?php
require_once '../Config/db.php';
try {
    $stmt = $pdo->query("
        SELECT id_besoin, statut, date_maj 
        FROM etat_de_besoin
        ORDER BY date_maj DESC
        LIMIT 5
    ");
    $decisions = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur SQL : " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Décisions Récentes</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    padding: 50px;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: flex-start;
    background: linear-gradient(135deg, #e0f7ff, #ffffff);
    overflow-x: hidden;
    position: relative;
}
@keyframes float {
    0% { transform: translateY(0) rotate(0deg); opacity: 0.5; }
    50% { transform: translateY(-15px) rotate(180deg); opacity: 0.7; }
    100% { transform: translateY(0) rotate(360deg); opacity: 0.5; }
}
.particle {
    position: absolute;
    width: 10px;
    height: 10px;
    background: rgba(135, 206, 250, 0.5);
    border-radius: 50%;
    animation: float 6s ease-in-out infinite;
}
.side-panel {
    backdrop-filter: blur(20px);
    background: rgba(255, 255, 255, 0.25);
    border-radius: 25px;
    padding: 30px 35px;
    box-shadow: 0 15px 40px rgba(0,0,0,0.25);
    width: 420px;
    position: relative;
    z-index: 1;
    overflow: hidden;
}
.panel-title {
    font-size: 22px;
    color: #fff;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 25px;
    text-shadow: 1px 1px 8px rgba(0,0,0,0.3);
}
.decision-item {
    display: flex;
    align-items: center;
    padding: 14px 18px;
    border-radius: 20px;
    margin-bottom: 18px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    transition: all 0.4s ease;
    background: rgba(255,255,255,0.2);
    box-shadow: 0 6px 20px rgba(0,0,0,0.1);
    animation: fadeInUp 0.6s ease forwards;
    opacity: 0;
}
.decision-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 30px rgba(0,0,0,0.25);
}
.decision-item::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: linear-gradient(135deg, #00c6ff, #0072ff, #00c6ff, #00f0ff);
    background-size: 400% 400%;
    animation: gradientAnim 6s ease infinite;
    opacity: 0.3;
    z-index: 0;
}
@keyframes gradientAnim {
    0%{background-position:0% 50%}
    50%{background-position:100% 50%}
    100%{background-position:0% 50%}
}
/* ---------- Fade-In Animation ---------- */
@keyframes fadeInUp {
    0% { opacity: 0; transform: translateY(20px); }
    100% { opacity: 1; transform: translateY(0); }
}
.decision-icon {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    margin-right: 15px;
    flex-shrink: 0;
    font-size: 20px;
    z-index: 1;
}
.icon-valid { background: linear-gradient(135deg, #00c853, #66ff95); }
.icon-refuse { background: linear-gradient(135deg, #ff1744, #ff8a80); }
.icon-pending { background: linear-gradient(135deg, #ff9100, #ffd180); }
.decision-info h6 {
    margin: 0;
    font-size: 15px;
    color: #fff;
    font-weight: 500;
    z-index: 1;
}
.decision-info p {
    margin: 3px 0 0;
    font-size: 12px;
    color: #e0f7ff;
    z-index: 1;
}
</style>
</head>
<body>
<!-- Floating particles -->
<div class="particle" style="top:20%; left:10%; width:12px; height:12px;"></div>
<div class="particle" style="top:50%; left:80%; width:8px; height:8px;"></div>
<div class="particle" style="top:70%; left:30%; width:10px; height:10px;"></div>
<div class="particle" style="top:35%; left:60%; width:6px; height:6px;"></div>
<div class="side-panel">
    <h4 class="panel-title">
        <i class="fas fa-tasks"></i>
        Décisions Récentes
    </h4>
    <?php if (count($decisions) > 0): ?>
        <?php foreach ($decisions as $decision): ?>
            <?php
                $iconClass = "icon-pending fas fa-clock";
                if (strpos(strtolower($decision['statut']), 'valide') !== false || $decision['statut'] === 'cloturee') {
                    $iconClass = "icon-valid fas fa-check";
                } elseif (strpos(strtolower($decision['statut']), 'refuse') !== false) {
                    $iconClass = "icon-refuse fas fa-times";
                }
            ?>
            <div class="decision-item" onclick="window.location.href='decision.php?id=<?= $decision['id_besoin'] ?>'">
                <div class="decision-icon <?= explode(' ', $iconClass)[0] ?>">
                    <i class="<?= explode(' ', $iconClass)[1] . ' ' . explode(' ', $iconClass)[2] ?>"></i>
                </div>
                <div class="decision-info">
                    <h6>Demande #<?= $decision['id_besoin'] ?> <?= ucfirst($decision['statut']) ?></h6>
                    <p><?= date("d/m/Y H:i", strtotime($decision['date_maj'])) ?></p>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p style="color: #fff;">Aucune décision récente trouvée.</p>
    <?php endif; ?>
</div>
</body>
</html>
