delete type materiel.php :
 <?php 
require_once '../Config/db.php'; 
require_login();  
$pdo = Database::getInstance()->getConnection();  
// Vérifier que l'ID est fourni 
$id = $_GET['id'] ?? null; 
if (!$id) {     
    die("ID type manquant."); 
}  
// Vérifier que le type existe 
try {     
    $stmt = $pdo->prepare("SELECT * FROM Type_Materiel WHERE id_type = :id");     
    $stmt->execute([':id' => $id]);     
    $type = $stmt->fetch(PDO::FETCH_ASSOC);      
    if (!$type) {         
        die("Type de matériel non trouvé.");     
    } 
} catch (PDOException $e) {     
    die("Erreur : " . $e->getMessage()); 
}  
// Vérifier s'il y a des matériels associés à ce type
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM Materiel WHERE id_type = :id");
    $stmt->execute([':id' => $id]);
    $count = $stmt->fetchColumn();
    if ($count > 0) {
        header("Location: type_materiel.php?error=Impossible de supprimer ce type car " . $count . " matériel(s) y sont associés");
        exit;
    }
} catch (PDOException $e) {
    die("Erreur : " . $e->getMessage());
}
// Suppression 
try {     
    $stmt = $pdo->prepare("DELETE FROM Type_Materiel WHERE id_type = :id");     
    $stmt->execute([':id' => $id]);     
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/type_materiel.php?msg=Type supprimé avec succès");     
    exit; 
} catch (PDOException $e) {     
    header("Location: type_materiel.php?error=Erreur lors de la suppression : " . $e->getMessage());
    exit;
}