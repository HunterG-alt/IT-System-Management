<?php
// Shim login.php (keeps compatibility with old redirects to /login.php)
// Redirects to the canonical public login page using dynamic base URL.
require_once __DIR__ . '/Config/session.php';
$base = (class_exists('SessionAuth') && method_exists('SessionAuth','getBaseUrl')) ? SessionConfig::getBaseUrl() : '';
$qs = '';
if (!empty($_GET)) {
    // preserve redirect param if present
    if (isset($_GET['redirect'])) {
        $qs = '?redirect=' . urlencode($_GET['redirect']);
    } elseif (isset($_SERVER['QUERY_STRING'])) {
        $qs = '?' . $_SERVER['QUERY_STRING'];
    }
}
$target = rtrim($base, '/') . '/public/login.php' . $qs;
if (!headers_sent()) {
    header('Location: ' . $target);
    exit();
} else {
    echo '<script>window.location.href = ' . json_encode($target) . ';</script>';
    exit();
}
