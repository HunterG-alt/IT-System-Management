<?php
require_once "../Config/db.php"; 
// Initialize variables
$message = '';
$message_type = 'info';
// Handle form submission
if (isset($_POST['ajout'])) {
    try {
        $nom = trim($_POST['nom']);
        $description = trim($_POST['description']);
        $valeur_defaut = trim($_POST['valeur_defaut']);
        $id_type = (int)$_POST['id_type'];
        if (empty($nom) || $id_type <= 0) {
            throw new Exception("Le nom et le type sont obligatoires.");
        }
        // Check if characteristic already exists for this type
        $checkSql = "SELECT COUNT(*) FROM caracteristique WHERE nom = :nom AND id_type = :id_type";
        $checkStmt = $pdo->prepare($checkSql);
        $checkStmt->execute([':nom' => $nom, ':id_type' => $id_type]);
        if ($checkStmt->fetchColumn() > 0) {
            throw new Exception("Cette caractéristique existe déjà pour ce type.");
        }
        // Insert new characteristic
        $sql = "INSERT INTO caracteristique (nom, description, valeur_defaut, id_type) 
                VALUES (:nom, :description, :valeur_defaut, :id_type)";
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([
            ':nom' => $nom,
            ':description' => $description,
            ':valeur_defaut' => $valeur_defaut,
            ':id_type' => $id_type
        ]);
        if ($result) {
            $message = "Caractéristique ajoutée avec succès.";
            $message_type = 'success';
        } else {
            $message = "Erreur lors de l'ajout de la caractéristique.";
            $message_type = 'danger';
        }
    } catch (Exception $e) {
        $message = "Erreur : " . $e->getMessage();
        $message_type = 'danger';
    }
}
// Function to assign characteristic to material
function assignCaracteristiqueToMateriel($idMateriel, $idCaracteristique, $valeurAcquise) {
    global $pdo;
    try {
        // Start transaction
        $pdo->beginTransaction();
        // 1. Get material type
        $sql = "SELECT id_type FROM materiel WHERE id = :idMateriel";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':idMateriel' => $idMateriel]);
        $materiel = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$materiel) {
            throw new Exception("Matériel introuvable.");
        }
        // 2. Get characteristic type
        $sql = "SELECT id_type FROM caracteristique WHERE id = :idCaracteristique";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':idCaracteristique' => $idCaracteristique]);
        $carac = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$carac) {
            throw new Exception("Caractéristique introuvable.");
        }
        // 3. Verify type correspondence
        if ($materiel['id_type'] != $carac['id_type']) {
            throw new Exception("Incohérence : le type du matériel et celui de la caractéristique ne correspondent pas.");
        }
        // 4. Insert or update acquired value in a junction table
        $sql = "INSERT INTO materiel_caracteristique (id_materiel, id_caracteristique, valeur_acquise) 
                VALUES (:idMateriel, :idCaracteristique, :valeur)
                ON DUPLICATE KEY UPDATE valeur_acquise = VALUES(valeur_acquise)";
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([
            ':idMateriel' => $idMateriel,
            ':idCaracteristique' => $idCaracteristique,
            ':valeur' => $valeurAcquise
        ]);
        $pdo->commit();
        return $result;
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}
// Get types for dropdown
$types = [];
try {
    $types = $pdo->query("SELECT * FROM type ORDER BY nom")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $message = "Erreur lors du chargement des types : " . $e->getMessage();
    $message_type = 'danger';
}
// Get characteristics with types
$caracteristiques = [];
try {
    $caracteristiques = $pdo->query("
        SELECT c.*, t.nom AS type_nom 
        FROM caracteristique c 
        LEFT JOIN type t ON c.id_type = t.id 
        ORDER BY c.id DESC
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $message = "Erreur lors du chargement des caractéristiques : " . $e->getMessage();
    $message_type = 'danger';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Caractéristiques</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card {
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .form-section {
            background: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1><i class="fas fa-cogs"></i> Gestion des Caractéristiques</h1>
            <a href="../dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left"></i> Retour
            </a>
        </div>
        <!-- Messages -->
        <?php if (!empty($message)): ?>
            <div class="alert alert-<?= $message_type ?> alert-dismissible fade show" role="alert">
                <?= htmlspecialchars($message) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <!-- Form Section -->
        <div class="form-section">
            <h4 class="mb-3"><i class="fas fa-plus-circle"></i> Nouvelle Caractéristique</h4>
            <form method="post" class="needs-validation" novalidate>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="nom" class="form-label">Nom de la caractéristique *</label>
                        <input type="text" name="nom" id="nom" class="form-control" 
                               placeholder="Ex: RAM, Processeur, etc." required>
                        <div class="invalid-feedback">
                            Veuillez saisir un nom de caractéristique.
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="id_type" class="form-label">Type *</label>
                        <select name="id_type" id="id_type" class="form-select" required>
                            <option value="">Sélectionner un type</option>
                            <?php foreach ($types as $t): ?>
                                <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['nom']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback">
                            Veuillez sélectionner un type.
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea name="description" id="description" class="form-control" 
                                  placeholder="Description détaillée de la caractéristique" rows="3"></textarea>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="valeur_defaut" class="form-label">Valeur par défaut</label>
                        <input type="text" name="valeur_defaut" id="valeur_defaut" class="form-control" 
                               placeholder="Ex: 8 Go, Intel i5, etc.">
                        <div class="form-text">Valeur suggérée ou standard pour cette caractéristique</div>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button type="submit" name="ajout" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Ajouter la Caractéristique
                    </button>
                    <button type="reset" class="btn btn-outline-secondary">
                        <i class="fas fa-undo"></i> Réinitialiser
                    </button>
                </div>
            </form>
        </div>
        <!-- Characteristics List -->
        <div class="card">
            <div class="card-header bg-light">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-list"></i> Liste des Caractéristiques</h5>
                    <span class="badge bg-primary"><?= count($caracteristiques) ?> caractéristique(s)</span>
                </div>
            </div>
            <div class="card-body">
                <?php if (empty($caracteristiques)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-cogs fa-3x text-muted mb-3"></i>
                        <p class="text-muted">Aucune caractéristique créée pour le moment.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover align-middle">
                            <thead class="table-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Nom</th>
                                    <th>Description</th>
                                    <th>Valeur par défaut</th>
                                    <th>Type</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($caracteristiques as $c): ?>
                                <tr>
                                    <td><strong><?= $c['id'] ?></strong></td>
                                    <td>
                                        <i class="fas fa-tag text-primary me-2"></i>
                                        <?= htmlspecialchars($c['nom']) ?>
                                    </td>
                                    <td>
                                        <div class="text-truncate" style="max-width: 200px;" 
                                             title="<?= htmlspecialchars($c['description']) ?>">
                                            <?= htmlspecialchars(substr($c['description'], 0, 50)) ?>
                                            <?= strlen($c['description']) > 50 ? '...' : '' ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if (!empty($c['valeur_defaut'])): ?>
                                            <span class="badge bg-light text-dark">
                                                <?= htmlspecialchars($c['valeur_defaut']) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($c['type_nom'])): ?>
                                            <span class="badge bg-info">
                                                <?= htmlspecialchars($c['type_nom']) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-warning">Type manquant</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <button type="button" class="btn btn-sm btn-outline-primary" 
                                                    onclick="editCaracteristique(<?= $c['id'] ?>)" 
                                                    title="Modifier">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-outline-danger" 
                                                    onclick="deleteCaracteristique(<?= $c['id'] ?>, '<?= htmlspecialchars($c['nom']) ?>')" 
                                                    title="Supprimer">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script>
        // Form validation
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                var forms = document.getElementsByClassName('needs-validation');
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();
        // Edit characteristic function
function editCaracteristique(id) {
    const newNom = prompt("Entrez le nouveau nom de la caractéristique :");
    if (newNom && newNom.trim() !== "") {
        fetch("edit_caracteristique.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id: id, nom: newNom })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("Caractéristique mise à jour avec succès !");
                location.reload(); // Refresh to show changes
            } else {
                alert("Erreur lors de la mise à jour : " + data.message);
            }
        })
        .catch(error => {
            console.error("Erreur:", error);
            alert("Une erreur est survenue !");
        });
    }
}
// Delete characteristic function
function deleteCaracteristique(id, nom) {
    if (confirm('Êtes-vous sûr de vouloir supprimer la caractéristique "' + nom + '" ?')) {
        fetch("delete_caracteristique.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id: id })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("Caractéristique supprimée avec succès !");
                location.reload(); // Refresh to remove deleted item
            } else {
                alert("Erreur lors de la suppression : " + data.message);
            }
        })
        .catch(error => {
            console.error("Erreur:", error);
            alert("Une erreur est survenue !");
        });
    }
}
    </script>
</body>
</html>