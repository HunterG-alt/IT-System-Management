<?php
require_once __DIR__ . '/../Config/session.php';
$message = $_GET['msg'] ?? 'Une erreur est survenue.';
http_response_code(400);
?><!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Erreur</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center" style="min-height:100vh;">
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card shadow-sm">
        <div class="card-body p-4">
          <h1 class="h4 mb-3 text-danger">Erreur</h1>
          <p class="mb-4"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p>
<a class="btn btn-secondary" href="../public/index.php">Retour</a>
        </div>
      </div>
    </div>
  </div>
  <?php FlashMessage::display(); ?>
</div>
</body>
</html>
