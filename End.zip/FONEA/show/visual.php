<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FONEA - Gestion des Acquisitions du materiel informatique</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --glass-bg: rgba(255, 255, 255, 0.15);
            --glass-border: rgba(255, 255, 255, 0.2);
            --shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background: var(--primary-gradient);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow-x: hidden;
        }
        /* Animated background */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><radialGradient id="a" cx="50" cy="50" r="50"><stop offset="0%" stop-color="rgba(255,255,255,0.1)"/><stop offset="100%" stop-color="transparent"/></radialGradient></defs><circle cx="20" cy="20" r="2" fill="url(%23a)" opacity="0.8"><animate attributeName="cy" values="20;80;20" dur="3s" repeatCount="indefinite"/></circle><circle cx="80" cy="80" r="3" fill="url(%23a)" opacity="0.6"><animate attributeName="cx" values="80;20;80" dur="4s" repeatCount="indefinite"/></circle><circle cx="40" cy="60" r="1.5" fill="url(%23a)" opacity="0.9"><animate attributeName="r" values="1.5;3;1.5" dur="2s" repeatCount="indefinite"/></circle></svg>');
            pointer-events: none;
            z-index: -1;
        }
        /* Glass morphism effects */
        .glass {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            box-shadow: var(--shadow);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .glass:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 40px rgba(31, 38, 135, 0.5);
            background: rgba(255, 255, 255, 0.2);
        }
        /* Header with colorful title */
        .header {
            padding: 2rem 0;
            text-align: center;
            margin-bottom: 2rem;
        }
        .colorful-title {
            font-size: 4rem;
            font-weight: 800;
            letter-spacing: 0.1em;
            margin-bottom: 0.5rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .colorful-title .letter {
            display: inline-block;
            animation: bounce 2s infinite;
            transition: all 0.3s ease;
        }
        .colorful-title .letter:nth-child(1) { color: #1130abff; animation-delay: 0.1s; }
        .colorful-title .letter:nth-child(2) { color: #a90f0fff; animation-delay: 0.2s; }
        .colorful-title .letter:nth-child(3) { color: #45b7d1; animation-delay: 0.3s; }
        .colorful-title .letter:nth-child(4) { color: #a2d00cff; animation-delay: 0.4s; }
        .colorful-title .letter:nth-child(5) { color: #feca57; animation-delay: 0.5s; }
        .subtitle {
            color: white;
            font-size: 1.5rem;
            font-weight: 300;
            opacity: 0.9;
        }
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
            40% { transform: translateY(-10px); }
            60% { transform: translateY(-5px); }
        }
        /* Dashboard cards */
        .dashboard-card {
            padding: 2rem;
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
        }
        .dashboard-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, #ff6b6b, #4ecdc4, #45b7d1, #96ceb4);
        }
        .card-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: white;
            opacity: 0.8;
        }
        .card-title {
            font-size: 1.8rem;
            color: white;
            margin-bottom: 1rem;
            font-weight: 600;
        }
        .card-value {
            font-size: 3rem;
            font-weight: 800;
            color: white;
            margin-bottom: 0.5rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .card-description {
            color: rgba(255,255,255,0.8);
            font-size: 1.1rem;
        }
        /* Mini dashboard specific styles */
        .mini-dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }
        /* Navigation */
        .nav-container {
            margin-bottom: 3rem;
        }
        .nav-pills .nav-link {
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            color: white;
            margin: 0 0.5rem;
            border-radius: 15px;
            padding: 1rem 2rem;
            transition: all 0.3s ease;
            font-weight: 500;
            font-size: 1.1rem;
        }
        .nav-pills .nav-link:hover {
            background: rgba(255,255,255,0.3);
            transform: translateY(-2px);
        }
        .nav-pills .nav-link.active {
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-color: transparent;
        }
        /* Content sections */
        .content-section {
            display: none;
            animation: fadeInUp 0.6s ease-out;
        }
        .content-section.active {
            display: block;
        }
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        /* Tables */
        .table-container {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 2rem;
            border: 1px solid var(--glass-border);
        }
        .table {
            color: white;
            font-size: 1.1rem;
        }
        .table th {
            border-color: rgba(255,255,255,0.2);
            font-weight: 600;
            font-size: 1.2rem;
        }
        .table td {
            border-color: rgba(255,255,255,0.1);
        }
        /* Buttons */
        .btn-glass {
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            color: white;
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 0.8rem 2rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn-glass:hover {
            background: rgba(255,255,255,0.3);
            color: white;
            transform: translateY(-2px);
        }
        /* Status badges */
        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 500;
            font-size: 0.9rem;
        }
        .status-pending { background: rgba(255, 193, 7, 0.3); color: #ffc107; }
        .status-approved { background: rgba(40, 167, 69, 0.3); color: #28a745; }
        .status-rejected { background: rgba(220, 53, 69, 0.3); color: #dc3545; }
        /* Responsive design */
        @media (max-width: 768px) {
            .colorful-title {
                font-size: 2.5rem;
            }
            .mini-dashboard {
                grid-template-columns: 1fr;
            }
            .dashboard-card {
                padding: 1.5rem;
            }
        }
        /* Loading animation */
        .loading {
            display: none;
            text-align: center;
            padding: 3rem;
        }
        .spinner {
            width: 50px;
            height: 50px;
            border: 3px solid rgba(255,255,255,0.3);
            border-top: 3px solid white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 1rem;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        /* Notification styles */
        .dropdown-menu {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 15px;
        }
        .dropdown-item {
            color: white;
            transition: all 0.3s ease;
        }
        .dropdown-item:hover {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        /* Form styles */
        .form-control, .form-select {
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            color: white;
            border-radius: 10px;
        }
        .form-control:focus, .form-select:focus {
            background: rgba(255,255,255,0.2);
            border-color: var(--glass-border);
            color: white;
            box-shadow: 0 0 0 0.25rem rgba(255,255,255,0.1);
        }
        .form-control::placeholder {
            color: rgba(255,255,255,0.7);
        }
        .form-label {
            color: white;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <div class="container-fluid px-4">
        <!-- Header -->
        <div class="header">
            <h1 class="colorful-title">
                <span class="letter">F</span>
                <span class="letter">O</span>
                <span class="letter">N</span>
                <span class="letter">E</span>
                <span class="letter">A</span>
            </h1>
            <p class="subtitle">Système de Gestion des Acquisitions du materiel Informatiques - FONEA</p>
        </div>
        <!-- Loading indicator -->
        <div id="loading" class="loading">
            <div class="spinner"></div>
            <p style="color: white;">Chargement...</p>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>