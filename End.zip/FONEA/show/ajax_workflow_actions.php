<?php
/**
 * WORKFLOW ACTION HANDLERS
 * This file contains all the workflow transition handlers
 * Save as: ajax_workflow_actions.php
 */

require_once '../Config/db.php';
require_once '../Config/session.php';
require_once '../modules/permission.php';

header('Content-Type: application/json');

// Check authentication
if (!isset($_SESSION['user_data'])) {
    echo json_encode(['success' => false, 'message' => 'Non authentifié']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

try {
    $action = $_POST['action'] ?? '';
    $request_id = intval($_POST['request_id'] ?? 0);
    $commentaire = trim($_POST['commentaire'] ?? '');
    
    $user_data = $_SESSION['user_data'];
    $user_role = $user_data['role'];
    $id_agent = $user_data['id_agent'];
    
    if (!$request_id) {
        throw new Exception('ID de demande invalide');
    }
    
    // Get request details
    $stmt = $pdo->prepare("SELECT * FROM etat_de_besoin WHERE id_besoin = ?");
    $stmt->execute([$request_id]);
    $request = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$request) {
        throw new Exception('Demande introuvable');
    }
    
    // Route to appropriate handler
    switch ($action) {
        case 'pre_validate':
            handlePreValidation($pdo, $request, $user_data, $commentaire);
            break;
            
        case 'reject_pre_validation':
            handlePreValidationRejection($pdo, $request, $user_data, $commentaire);
            break;
            
        case 'validate':
            handleValidation($pdo, $request, $user_data, $commentaire);
            break;
            
        case 'reject_validation':
            handleValidationRejection($pdo, $request, $user_data, $commentaire);
            break;
            
        case 'authorize':
            handleAuthorization($pdo, $request, $user_data, $commentaire);
            break;
            
        case 'reject_authorization':
            handleAuthorizationRejection($pdo, $request, $user_data, $commentaire);
            break;
            
        case 'process':
            handleProcessing($pdo, $request, $user_data, $commentaire);
            break;
            
        case 'complete':
            handleCompletion($pdo, $request, $user_data, $commentaire);
            break;
            
        default:
            throw new Exception('Action invalide');
    }
    
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    error_log("Workflow error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

// STEP 1: CHEF DE SERVICE PRE-VALIDATION
function handlePreValidation($pdo, $request, $user_data, $commentaire) {
    // Check role
    if ($user_data['role'] !== ROLE_CHEF_SERVICE) {
        throw new Exception('Seul le Chef de Service peut pré-valider');
    }
    
    // Check status
    if ($request['statut'] !== STATUS_EN_ATTENTE) {
        throw new Exception('Cette demande ne peut plus être pré-validée');
    }
    
    // Cannot validate own request
    if ($request['id_agent'] == $user_data['id_agent']) {
        throw new Exception('Vous ne pouvez pas valider votre propre demande');
    }
    
    $pdo->beginTransaction();
    
    // Update request status to pre_validated
    $stmt = $pdo->prepare("
        UPDATE etat_de_besoin 
        SET statut = ?, 
            date_pre_validation = NOW(),
            id_chef_service = ?,
            date_modification = NOW()
        WHERE id_besoin = ?
    ");
    
    $stmt->execute([STATUS_PRE_VALIDEE, $user_data['id_agent'], $request['id_besoin']]);
    
    // Log action
    logAction($pdo, $request['id_besoin'], $user_data['id_agent'], 'pre_validation', $commentaire ?: 'Pré-validé par Chef de Service');
    
    // Notify Directeur for validation
    notifyRole($pdo, ROLE_DIRECTEUR, $request, 'validation', 
        "Demande pré-validée à valider - {$request['objet']}", 
        $request['id_departement']);
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Demande pré-validée avec succès. Le Directeur a été notifié.',
        'next_step' => 'validation',
        'next_validator' => 'Directeur'
    ]);
}

function handlePreValidationRejection($pdo, $request, $user_data, $commentaire) {
    if ($user_data['role'] !== ROLE_CHEF_SERVICE) {
        throw new Exception('Seul le Chef de Service peut rejeter');
    }
    
    if ($request['statut'] !== STATUS_EN_ATTENTE) {
        throw new Exception('Cette demande ne peut plus être rejetée');
    }
    
    if (empty($commentaire)) {
        throw new Exception('Un commentaire est requis pour le rejet');
    }
    
    $pdo->beginTransaction();
    
    $stmt = $pdo->prepare("
        UPDATE etat_de_besoin 
        SET statut = ?, 
            date_modification = NOW()
        WHERE id_besoin = ?
    ");
    
    $stmt->execute([STATUS_REFUSEE_CHEF, $request['id_besoin']]);
    
    logAction($pdo, $request['id_besoin'], $user_data['id_agent'], 'rejet_chef', $commentaire);
    
    // Notify requester
    notifyUser($pdo, $request['id_agent'], $request, 'rejection', 
        "Votre demande a été rejetée par le Chef de Service");
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Demande rejetée. Le demandeur a été notifié.'
    ]);
}


// STEP 2: DIRECTEUR VALIDATION
function handleValidation($pdo, $request, $user_data, $commentaire) {
    if ($user_data['role'] !== ROLE_DIRECTEUR) {
        throw new Exception('Seul le Directeur peut valider');
    }
    
    if ($request['statut'] !== STATUS_PRE_VALIDEE) {
        throw new Exception('Cette demande n\'est pas en attente de validation');
    }
    
    if ($request['id_agent'] == $user_data['id_agent']) {
        throw new Exception('Vous ne pouvez pas valider votre propre demande');
    }
    
    $pdo->beginTransaction();
    
    $stmt = $pdo->prepare("
        UPDATE etat_de_besoin 
        SET statut = ?, 
            date_validation = NOW(),
            id_directeur = ?,
            date_modification = NOW()
        WHERE id_besoin = ?
    ");
    
    $stmt->execute([STATUS_VALIDEE_DIRECTEUR, $user_data['id_agent'], $request['id_besoin']]);
    
    logAction($pdo, $request['id_besoin'], $user_data['id_agent'], 'validation', $commentaire ?: 'Validé par Directeur');
    
    // Notify Directeur Général for authorization
    notifyRole($pdo, ROLE_DIRECTEUR_GENERAL, $request, 'autorisation', 
        "Demande validée à autoriser - {$request['objet']}");
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Demande validée avec succès. Le Directeur Général a été notifié.',
        'next_step' => 'autorisation',
        'next_validator' => 'Directeur Général'
    ]);
}

function handleValidationRejection($pdo, $request, $user_data, $commentaire) {
    if ($user_data['role'] !== ROLE_DIRECTEUR) {
        throw new Exception('Seul le Directeur peut rejeter');
    }
    
    if ($request['statut'] !== STATUS_PRE_VALIDEE) {
        throw new Exception('Cette demande ne peut plus être rejetée');
    }
    
    if (empty($commentaire)) {
        throw new Exception('Un commentaire est requis pour le rejet');
    }
    
    $pdo->beginTransaction();
    
    $stmt = $pdo->prepare("
        UPDATE etat_de_besoin 
        SET statut = ?, 
            date_modification = NOW()
        WHERE id_besoin = ?
    ");
    
    $stmt->execute([STATUS_REFUSEE_DIRECTEUR, $request['id_besoin']]);
    
    logAction($pdo, $request['id_besoin'], $user_data['id_agent'], 'rejet_directeur', $commentaire);
    
    notifyUser($pdo, $request['id_agent'], $request, 'rejection', 
        "Votre demande a été rejetée par le Directeur");
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Demande rejetée. Le demandeur a été notifié.'
    ]);
}


// STEP 3: DIRECTEUR GÉNÉRAL AUTHORIZATION
function handleAuthorization($pdo, $request, $user_data, $commentaire) {
    if ($user_data['role'] !== ROLE_DIRECTEUR_GENERAL) {
        throw new Exception('Seul le Directeur Général peut autoriser');
    }
    
    if ($request['statut'] !== STATUS_VALIDEE_DIRECTEUR) {
        throw new Exception('Cette demande n\'est pas en attente d\'autorisation');
    }
    
    $pdo->beginTransaction();
    
    $stmt = $pdo->prepare("
        UPDATE etat_de_besoin 
        SET statut = ?, 
            date_autorisation = NOW(),
            id_directeur_general = ?,
            date_modification = NOW()
        WHERE id_besoin = ?
    ");
    
    $stmt->execute([STATUS_EN_ANALYSE_TECHNIQUE, $user_data['id_agent'], $request['id_besoin']]);
    
    logAction($pdo, $request['id_besoin'], $user_data['id_agent'], 'autorisation', $commentaire ?: 'Autorisé par Directeur Général');
    
    // Notify Moyens Généraux for processing
    notifyRole($pdo, ROLE_MOYENS_GENERAUX, $request, 'traitement', 
        "Demande autorisée à traiter - {$request['objet']}");
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Demande autorisée avec succès. Les Moyens Généraux ont été notifiés.',
        'next_step' => 'traitement',
        'next_validator' => 'Moyens Généraux'
    ]);
}

function handleAuthorizationRejection($pdo, $request, $user_data, $commentaire) {
    if ($user_data['role'] !== ROLE_DIRECTEUR_GENERAL) {
        throw new Exception('Seul le Directeur Général peut rejeter');
    }
    
    if ($request['statut'] !== STATUS_VALIDEE_DIRECTEUR) {
        throw new Exception('Cette demande ne peut plus être rejetée');
    }
    
    if (empty($commentaire)) {
        throw new Exception('Un commentaire est requis pour le rejet');
    }
    
    $pdo->beginTransaction();
    
    $stmt = $pdo->prepare("
        UPDATE etat_de_besoin 
        SET statut = 'refusee_dg', 
            date_modification = NOW()
        WHERE id_besoin = ?
    ");
    
    $stmt->execute([$request['id_besoin']]);
    
    logAction($pdo, $request['id_besoin'], $user_data['id_agent'], 'rejet_dg', $commentaire);
    
    notifyUser($pdo, $request['id_agent'], $request, 'rejection', 
        "Votre demande a été rejetée par le Directeur Général");
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Demande rejetée. Le demandeur a été notifié.'
    ]);
}


// STEP 4: MOYENS GÉNÉRAUX PROCESSING
function handleProcessing($pdo, $request, $user_data, $commentaire) {
    if ($user_data['role'] !== ROLE_MOYENS_GENERAUX) {
        throw new Exception('Seuls les Moyens Généraux peuvent traiter');
    }
    
    if (!in_array($request['statut'], [STATUS_EN_ANALYSE_TECHNIQUE, STATUS_VALIDEE_DIRECTEUR])) {
        throw new Exception('Cette demande ne peut pas être traitée');
    }
    
    $pdo->beginTransaction();
    
    $stmt = $pdo->prepare("
        UPDATE etat_de_besoin 
        SET statut = ?, 
            date_traitement = NOW(),
            id_moyens_generaux = ?,
            date_modification = NOW()
        WHERE id_besoin = ?
    ");
    
    $stmt->execute([STATUS_EN_ACQUISITION, $user_data['id_agent'], $request['id_besoin']]);
    
    logAction($pdo, $request['id_besoin'], $user_data['id_agent'], 'traitement', $commentaire ?: 'Prise en charge par Moyens Généraux');
    
    notifyUser($pdo, $request['id_agent'], $request, 'processing', 
        "Votre demande est en cours de traitement");
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Demande prise en charge. Le demandeur a été notifié.'
    ]);
}

function handleCompletion($pdo, $request, $user_data, $commentaire) {
    if ($user_data['role'] !== ROLE_MOYENS_GENERAUX) {
        throw new Exception('Seuls les Moyens Généraux peuvent clôturer');
    }
    
    if ($request['statut'] !== STATUS_EN_ACQUISITION) {
        throw new Exception('Cette demande ne peut pas être clôturée');
    }
    
    $pdo->beginTransaction();
    
    $stmt = $pdo->prepare("
        UPDATE etat_de_besoin 
        SET statut = ?, 
            date_cloture = NOW(),
            date_modification = NOW()
        WHERE id_besoin = ?
    ");
    
    $stmt->execute([STATUS_CLOTUREE, $request['id_besoin']]);
    
    logAction($pdo, $request['id_besoin'], $user_data['id_agent'], 'cloture', $commentaire ?: 'Demande clôturée');
    
    notifyUser($pdo, $request['id_agent'], $request, 'completion', 
        "Votre demande a été traitée et clôturée");
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Demande clôturée avec succès.'
    ]);
}


// HELPER FUNCTIONS
function logAction($pdo, $id_besoin, $id_agent, $action, $commentaire) {
    $stmt = $pdo->prepare("
        INSERT INTO historique_besoin 
        (id_besoin, id_agent, action, commentaire, date_action) 
        VALUES (?, ?, ?, ?, NOW())
    ");
    
    $stmt->execute([$id_besoin, $id_agent, $action, $commentaire]);
}

function notifyRole($pdo, $role, $request, $type, $message, $departement_id = null) {
    $query = "SELECT id_agent FROM agents WHERE role = ? AND statut = 'actif'";
    $params = [$role];
    
    if ($departement_id) {
        $query .= " AND id_departement = ?";
        $params[] = $departement_id;
    }
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($users as $user) {
        $stmt = $pdo->prepare("
            INSERT INTO notifications 
            (id_agent, type, titre, message, lien, statut, date_creation) 
            VALUES (?, ?, ?, ?, ?, 'non_lu', NOW())
        ");
        
        $stmt->execute([
            $user['id_agent'],
            'demande_' . $type,
            'Action requise',
            $message,
            'demande_details.php?id=' . $request['id_besoin']
        ]);
    }
}

function notifyUser($pdo, $id_agent, $request, $type, $message) {
    $stmt = $pdo->prepare("
        INSERT INTO notifications 
        (id_agent, type, titre, message, lien, statut, date_creation) 
        VALUES (?, ?, ?, ?, ?, 'non_lu', NOW())
    ");
    
    $stmt->execute([
        $id_agent,
        'demande_' . $type,
        'Mise à jour de demande',
        $message,
        'demande_details.php?id=' . $request['id_besoin']
    ]);
}
?>