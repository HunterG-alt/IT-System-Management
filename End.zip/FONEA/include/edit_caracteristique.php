<?php
header('Content-Type: application/json');
include '../Config/db.php'; // Connexion PDO
$data = json_decode(file_get_contents("php://input"), true);
if (isset($data['id'], $data['nom'])) {
    $stmt = $pdo->prepare("UPDATE caracteristiques SET nom = ? WHERE id = ?");
    $success = $stmt->execute([$data['nom'], $data['id']]);
    echo json_encode(["success" => $success]);
} else {
    echo json_encode(["success" => false, "message" => "Paramètres manquants"]);
}
