edit_besoin.php:
 <?php
session_start();
require_once '../Config/db.php';
require_once '../modules/logique.php'; // For user functions
// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
// Authentication check
if (!isset($_SESSION['user_id']) && !function_exists('current_user')) {
    $_SESSION['message'] = "Accès non autorisé.";
    $_SESSION['message_type'] = "danger";
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit;
}
// Get current user
$current_user = null;
if (function_exists('current_user')) {
    $current_user = current_user();
} elseif (isset($_SESSION['user_id'])) {
    $current_user = ['id' => $_SESSION['user_id']];
}
if (!$current_user) {
    $_SESSION['message'] = "Utilisateur non identifié.";
    $_SESSION['message_type'] = "danger";
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit;
}
// Validate ID parameter
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['message'] = "ID du besoin manquant.";
    $_SESSION['message_type'] = "danger";
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/besoin.php");
    exit;
}
$id = (int) $_GET['id'];
if ($id <= 0) {
    $_SESSION['message'] = "ID du besoin invalide.";
    $_SESSION['message_type'] = "danger";
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/besoin.php");
    exit;
}
$errors = [];
$besoin = null;
$materiels = [];
try {
    // Get database connection
    if (class_exists('Database')) {
        $pdo = Database::getInstance()->getConnection();
    } else {
        global $pdo;
        if (!$pdo) {
            throw new Exception("Connexion à la base de données indisponible");
        }
    }
    // Retrieve existing need with ownership check
    $stmt = $pdo->prepare("
        SELECT b.*, u.nom as agent_nom, u.prenom as agent_prenom
        FROM besoin b 
        LEFT JOIN utilisateurs u ON b.agent_id = u.id 
        WHERE b.id = ?
    ");
    $stmt->execute([$id]);
    $besoin = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$besoin) {
        $_SESSION['message'] = "Besoin introuvable.";
        $_SESSION['message_type'] = "danger";
        header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/besoin.php");
        exit;
    }
    // Security: Check if user owns this need or has admin privileges
    $user_can_edit = false;
    if ($besoin['agent_id'] == $current_user['id']) {
        $user_can_edit = true;
    }
    if (isset($current_user['role']) && in_array($current_user['role'], ['admin', 'manager'])) {
        $user_can_edit = true;
    }
    if (!$user_can_edit) {
        $_SESSION['message'] = "Vous n'avez pas l'autorisation de modifier ce besoin.";
        $_SESSION['message_type'] = "danger";
        header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/besoin.php");
        exit;
    }
    // Business rule: Only allow editing of pending needs
    if ($besoin['statut'] !== 'en_attente') {
        $_SESSION['message'] = "Impossible de modifier un besoin qui n'est pas en attente.";
        $_SESSION['message_type'] = "warning";
        header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/besoin.php");
        exit;
    }
    // Get associated materials for this need
    $materials_stmt = $pdo->prepare("
        SELECT * FROM besoin_materiel 
        WHERE id_besoin = ? 
        ORDER BY id ASC
    ");
    $materials_stmt->execute([$id]);
    $materiels = $materials_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("Erreur de récupération du besoin: " . $e->getMessage());
    $_SESSION['message'] = "Erreur lors de la récupération du besoin.";
    $_SESSION['message_type'] = "danger";
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/besoin.php");
    exit;
}
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF Protection
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $errors[] = "Token de sécurité invalide.";
    }
    // Validate input
    $designation = trim($_POST['designation'] ?? '');
    $besoin_desc = trim($_POST['besoin'] ?? '');
    $justification = trim($_POST['justification'] ?? '');
    $date_limite = trim($_POST['date_limite'] ?? '');
    $materiel_data = $_POST['materiel'] ?? [];
    // Validation rules
    if (empty($designation)) {
        $errors[] = "La désignation est obligatoire.";
    } elseif (strlen($designation) < 3) {
        $errors[] = "La désignation doit contenir au moins 3 caractères.";
    }
    if (empty($besoin_desc)) {
        $errors[] = "La description du besoin est obligatoire.";
    } elseif (strlen($besoin_desc) < 10) {
        $errors[] = "La description du besoin doit contenir au moins 10 caractères.";
    }
    if (!empty($date_limite)) {
        $date_limite_obj = DateTime::createFromFormat('Y-m-d', $date_limite);
        if (!$date_limite_obj || $date_limite_obj < new DateTime('today')) {
            $errors[] = "La date limite doit être dans le futur.";
        }
    }
    // Validate materials
    $valid_materials = [];
    if (!empty($materiel_data)) {
        foreach ($materiel_data as $index => $mat) {
            if (!empty($mat['nom']) || !empty($mat['quantite'])) {
                $mat_nom = trim($mat['nom'] ?? '');
                $mat_quantite = (int)($mat['quantite'] ?? 0);
                $mat_caracteristiques = trim($mat['caracteristiques'] ?? '');
                if (empty($mat_nom)) {
                    $errors[] = "Le nom du matériel #" . ($index + 1) . " est obligatoire.";
                } elseif ($mat_quantite <= 0) {
                    $errors[] = "La quantité du matériel #" . ($index + 1) . " doit être supérieure à 0.";
                } else {
                    $valid_materials[] = [
                        'nom' => $mat_nom,
                        'quantite' => $mat_quantite,
                        'caracteristiques' => $mat_caracteristiques
                    ];
                }
            }
        }
    }
    // If no errors, update the need
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            // Update main need record
            $update_stmt = $pdo->prepare("
                UPDATE besoin 
                SET designation = ?, besoin = ?, justification = ?, date_limite = ?, updated_at = NOW()
                WHERE id = ?
            ");
            $result = $update_stmt->execute([
                $designation,
                $besoin_desc,
                $justification,
                $date_limite ?: null,
                $id
            ]);
            if (!$result) {
                throw new Exception("Erreur lors de la mise à jour du besoin");
            }
            // Delete existing materials
            $delete_materials_stmt = $pdo->prepare("DELETE FROM besoin_materiel WHERE id_besoin = ?");
            $delete_materials_stmt->execute([$id]);
            // Insert updated materials
            if (!empty($valid_materials)) {
                $insert_material_stmt = $pdo->prepare("
                    INSERT INTO besoin_materiel (id_besoin, nom, quantite, caracteristiques) 
                    VALUES (?, ?, ?, ?)
                ");
                foreach ($valid_materials as $material) {
                    $insert_material_stmt->execute([
                        $id,
                        $material['nom'],
                        $material['quantite'],
                        $material['caracteristiques']
                    ]);
                }
            }
            // Log the action
            $log_stmt = $pdo->prepare("
                INSERT INTO activity_log (user_id, action, entity_type, entity_id, description, created_at) 
                VALUES (?, 'UPDATE', 'besoin', ?, ?, NOW())
            ");
            $log_description = "Modification du besoin: " . $designation;
            $log_stmt->execute([$current_user['id'], $id, $log_description]);
            $pdo->commit();
            $_SESSION['message'] = "Besoin '" . htmlspecialchars($designation) . "' mis à jour avec succès.";
            $_SESSION['message_type'] = "success";
            header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/besoin.php");
            exit;
        } catch (Exception $e) {
            $pdo->rollBack();
            error_log("Erreur de mise à jour du besoin: " . $e->getMessage());
            $errors[] = "Erreur lors de la mise à jour du besoin.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un Besoin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .form-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            padding: 30px;
            margin-top: 30px;
        }
        .materiel-row {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            border-left: 4px solid #007bff;
        }
        .btn-remove-material {
            border: none;
            background: none;
            color: #dc3545;
            padding: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
            <h1><i class="fas fa-edit"></i> Modifier un Besoin</h1>
            <a href="besoin.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left"></i> Retour à la liste
            </a>
        </div>
        <!-- Error messages -->
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong><i class="fas fa-exclamation-triangle"></i> Erreurs:</strong>
                <ul class="mb-0 mt-2">
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <!-- Need Info -->
        <div class="alert alert-info">
            <i class="fas fa-info-circle"></i>
            <strong>Besoin à modifier:</strong> <?= htmlspecialchars($besoin['designation']) ?>
            <br><small>Créé le <?= date("d/m/Y", strtotime($besoin['date_soumission'])) ?> 
            - Statut: <span class="badge bg-warning"><?= ucfirst($besoin['statut']) ?></span></small>
        </div>
        <!-- Edit Form -->
        <div class="form-container">
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <!-- Basic Information -->
                <div class="row mb-4">
                    <div class="col-12">
                        <h5><i class="fas fa-clipboard-list"></i> Informations générales</h5>
                        <hr>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="designation" class="form-label">Désignation *</label>
                        <input type="text" name="designation" id="designation" class="form-control" 
                               value="<?= htmlspecialchars($besoin['designation']) ?>" 
                               required minlength="3">
                        <div class="invalid-feedback">La désignation est obligatoire (min. 3 caractères).</div>
                    </div>
                    <div class="col-md-6">
                        <label for="date_limite" class="form-label">Date limite souhaitée</label>
                        <input type="date" name="date_limite" id="date_limite" class="form-control" 
                               value="<?= $besoin['date_limite'] ? date('Y-m-d', strtotime($besoin['date_limite'])) : '' ?>" 
                               min="<?= date('Y-m-d') ?>">
                    </div>
                </div>
                <div class="mb-3">
                    <label for="besoin" class="form-label">Description du besoin *</label>
                    <textarea name="besoin" id="besoin" class="form-control" rows="4" 
                              required minlength="10" 
                              placeholder="Décrivez précisément votre besoin..."><?= htmlspecialchars($besoin['besoin']) ?></textarea>
                    <div class="invalid-feedback">La description est obligatoire (min. 10 caractères).</div>
                </div>
                <div class="mb-4">
                    <label for="justification" class="form-label">Justification</label>
                    <textarea name="justification" id="justification" class="form-control" rows="3" 
                              placeholder="Justifiez la nécessité de ce besoin..."><?= htmlspecialchars($besoin['justification']) ?></textarea>
                </div>
                <!-- Materials Section -->
                <div class="row mb-4">
                    <div class="col-12">
                        <h5><i class="fas fa-boxes"></i> Matériel associé</h5>
                        <hr>
                    </div>
                </div>
                <div id="materiels-container">
                    <?php if (empty($materiels)): ?>
                        <!-- Default empty material row -->
                        <div class="materiel-row" data-index="0">
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label class="form-label">Nom du matériel</label>
                                    <input type="text" name="materiel[0][nom]" class="form-control" 
                                           placeholder="Ex: Ordinateur portable">
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label">Quantité</label>
                                    <input type="number" name="materiel[0][quantite]" class="form-control" 
                                           placeholder="1" min="1">
                                </div>
                                <div class="col-md-5">
                                    <label class="form-label">Caractéristiques</label>
                                    <input type="text" name="materiel[0][caracteristiques]" class="form-control" 
                                           placeholder="Ex: 16GB RAM, SSD 512GB">
                                </div>
                                <div class="col-md-1">
                                    <label class="form-label">&nbsp;</label>
                                    <button type="button" class="btn btn-outline-success btn-sm d-block" 
                                            onclick="ajouterMateriel()" title="Ajouter">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($materiels as $index => $materiel): ?>
                            <div class="materiel-row" data-index="<?= $index ?>">
                                <div class="row g-3">
                                    <div class="col-md-4">
                                        <label class="form-label">Nom du matériel</label>
                                        <input type="text" name="materiel[<?= $index ?>][nom]" class="form-control" 
                                               value="<?= htmlspecialchars($materiel['nom']) ?>">
                                    </div>
                                    <div class="col-md-2">
                                        <label class="form-label">Quantité</label>
                                        <input type="number" name="materiel[<?= $index ?>][quantite]" class="form-control" 
                                               value="<?= $materiel['quantite'] ?>" min="1">
                                    </div>
                                    <div class="col-md-5">
                                        <label class="form-label">Caractéristiques</label>
                                        <input type="text" name="materiel[<?= $index ?>][caracteristiques]" class="form-control" 
                                               value="<?= htmlspecialchars($materiel['caracteristiques']) ?>">
                                    </div>
                                    <div class="col-md-1">
                                        <label class="form-label">&nbsp;</label>
                                        <div class="d-flex gap-1">
                                            <?php if ($index === 0): ?>
                                                <button type="button" class="btn btn-outline-success btn-sm" 
                                                        onclick="ajouterMateriel()" title="Ajouter">
                                                    <i class="fas fa-plus"></i>
                                                </button>
                                            <?php else: ?>
                                                <button type="button" class="btn btn-outline-danger btn-sm" 
                                                        onclick="supprimerMateriel(this)" title="Supprimer">
                                                    <i class="fas fa-minus"></i>
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <!-- Action Buttons -->
                <div class="d-flex gap-3 mt-4 pt-3 border-top">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Mettre à jour le besoin
                    </button>
                    <a href="besoin.php" class="btn btn-outline-secondary">
                        <i class="fas fa-times"></i> Annuler
                    </a>
                    <div class="ms-auto">
                        <small class="text-muted">
                            <i class="fas fa-clock"></i> 
                            Dernière modification: <?= $besoin['updated_at'] ? date("d/m/Y H:i", strtotime($besoin['updated_at'])) : 'Jamais' ?>
                        </small>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script>
        let materielCounter = <?= count($materiels) > 0 ? count($materiels) : 1 ?>;
        // Form validation
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                var forms = document.getElementsByClassName('needs-validation');
                Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();
        // Add material function
        function ajouterMateriel() {
            const container = document.getElementById('materiels-container');
            const newRow = document.createElement('div');
            newRow.className = 'materiel-row';
            newRow.setAttribute('data-index', materielCounter);
            newRow.innerHTML = `
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Nom du matériel</label>
                        <input type="text" name="materiel[${materielCounter}][nom]" class="form-control" 
                               placeholder="Ex: Ordinateur portable">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Quantité</label>
                        <input type="number" name="materiel[${materielCounter}][quantite]" class="form-control" 
                               placeholder="1" min="1">
                    </div>
                    <div class="col-md-5">
                        <label class="form-label">Caractéristiques</label>
                        <input type="text" name="materiel[${materielCounter}][caracteristiques]" class="form-control" 
                               placeholder="Ex: 16GB RAM, SSD 512GB">
                    </div>
                    <div class="col-md-1">
                        <label class="form-label">&nbsp;</label>
                        <button type="button" class="btn btn-outline-danger btn-sm" 
                                onclick="supprimerMateriel(this)" title="Supprimer">
                            <i class="fas fa-minus"></i>
                        </button>
                    </div>
                </div>
            `;
            container.appendChild(newRow);
            materielCounter++;
        }
        // Remove material function
        function supprimerMateriel(button) {
            if (confirm('Supprimer ce matériel ?')) {
                button.closest('.materiel-row').remove();
            }
        }
        // Auto-save draft functionality (optional)
        let saveTimeout;
        document.querySelectorAll('input, textarea').forEach(element => {
            element.addEventListener('input', function() {
                clearTimeout(saveTimeout);
                saveTimeout = setTimeout(() => {
                    // Could implement auto-save here
                    console.log('Auto-save triggered');
                }, 2000);
            });
        });
    </script>
</body>
</html>