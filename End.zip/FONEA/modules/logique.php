<?php
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../Lib/csrf.php';
// Security: Ensure user is logged in
require_login();
// Input validation and sanitization
$etat_id = filter_input(INPUT_GET, 'etat_id', FILTER_VALIDATE_INT);
$logs = [];
$current = null;
$etat_details = null;
$error_message = null;
if (!$etat_id) {
    $error_message = "ID d'état de besoin manquant ou invalide.";
} else {
    try {
        // Check if Workflow class exists and has required methods
        if (!class_exists('Workflow')) {
            throw new Exception("Classe Workflow non trouvée.");
        }
        // Get workflow logs
        $logs = Workflow::getLogs($etat_id);
        if ($logs === false) {
            throw new Exception("Erreur lors de la récupération des logs.");
        }
        // Get current status
        $current = Workflow::getCurrentStatus($etat_id);
        // Get additional details about the requirement
        $pdo = Database::getInstance()->getConnection();
        $stmt = $pdo->prepare("
            SELECT e.designation, e.description, e.created_at as date_creation,
                   u.nom, u.prenom, u.email,
                   s.nom as service_nom
            FROM etat_de_besoin e
            JOIN agents a ON e.agent_id = a.id
            JOIN users u ON a.user_id = u.id
            LEFT JOIN services s ON a.service_id = s.id
            WHERE e.id = ?
        ");
        $stmt->execute([$etat_id]);
        $etat_details = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$etat_details) {
            $error_message = "État de besoin introuvable.";
        }
    } catch (Exception $e) {
        $error_message = "Erreur: " . $e->getMessage();
        error_log("Workflow Error: " . $e->getMessage());
    }
}
// Enhanced badge class function with more statuses
function badgeClass($statut) {
    return match(strtoupper(trim($statut))) {
        'SOUMIS', 'EN_ATTENTE', 'PENDING' => 'warning',
        'VALIDE_SERVICE', 'APPROUVE', 'APPROVED', 'VALIDE' => 'success',
        'REJETE', 'REJECTED', 'REFUSE' => 'danger',
        'EN_COURS', 'IN_PROGRESS' => 'info',
        'TERMINE', 'COMPLETED' => 'primary',
        'ANNULE', 'CANCELLED' => 'secondary',
        default => 'secondary',
    };
}
// Function to get status display name
function getStatusDisplayName($statut) {
    return match(strtoupper(trim($statut))) {
        'SOUMIS' => 'Soumis',
        'EN_ATTENTE' => 'En attente',
        'VALIDE_SERVICE' => 'Validé par le service',
        'APPROUVE' => 'Approuvé',
        'REJETE' => 'Rejeté',
        'EN_COURS' => 'En cours',
        'TERMINE' => 'Terminé',
        'ANNULE' => 'Annulé',
        default => ucfirst(strtolower($statut)),
    };
}
// Function to get status icon
function getStatusIcon($statut) {
    return match(strtoupper(trim($statut))) {
        'SOUMIS', 'EN_ATTENTE' => 'fas fa-clock',
        'VALIDE_SERVICE', 'APPROUVE' => 'fas fa-check-circle',
        'REJETE' => 'fas fa-times-circle',
        'EN_COURS' => 'fas fa-spinner',
        'TERMINE' => 'fas fa-flag-checkered',
        'ANNULE' => 'fas fa-ban',
        default => 'fas fa-info-circle',
    };
}
// Calculate workflow duration
function calculateDuration($start_date, $end_date = null) {
    $start = new DateTime($start_date);
    $end = $end_date ? new DateTime($end_date) : new DateTime();
    $diff = $start->diff($end);
    if ($diff->days > 0) {
        return $diff->days . ' jour' . ($diff->days > 1 ? 's' : '');
    } elseif ($diff->h > 0) {
        return $diff->h . ' heure' . ($diff->h > 1 ? 's' : '');
    } else {
        return $diff->i . ' minute' . ($diff->i > 1 ? 's' : '');
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historique du Workflow - État de Besoin #<?php echo $etat_id; ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            padding: 20px 0;
        }
        .glass-container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px) saturate(180%);
            -webkit-backdrop-filter: blur(10px) saturate(180%);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            padding: 25px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            margin-bottom: 20px;
        }
        .page-header {
            color: white;
            text-align: center;
            margin-bottom: 30px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }
        .back-btn {
            background: rgba(255, 255, 255, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            transition: all 0.3s ease;
            margin-bottom: 20px;
        }
        .back-btn:hover {
            background: rgba(255, 255, 255, 0.25);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .details-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
        }
        .current-status {
            background: linear-gradient(45deg, rgba(255, 255, 255, 0.15), rgba(255, 255, 255, 0.05));
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 30px;
            color: white;
        }
        .timeline {
            position: relative;
            padding-left: 30px;
        }
        .timeline::before {
            content: '';
            position: absolute;
            left: 15px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: linear-gradient(to bottom, #667eea, #764ba2);
            border-radius: 2px;
        }
        .timeline-item {
            position: relative;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            margin-left: 15px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .timeline-item:hover {
            transform: translateX(5px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
        }
        .timeline-item::before {
            content: '';
            position: absolute;
            left: -23px;
            top: 25px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: white;
            border: 3px solid;
            box-shadow: 0 0 0 3px white;
        }
        .timeline-item.success::before { border-color: #28a745; }
        .timeline-item.warning::before { border-color: #ffc107; }
        .timeline-item.danger::before { border-color: #dc3545; }
        .timeline-item.info::before { border-color: #17a2b8; }
        .timeline-item.primary::before { border-color: #007bff; }
        .timeline-item.secondary::before { border-color: #6c757d; }
        .timeline-header {
            display: flex;
            justify-content: between;
            align-items: center;
            margin-bottom: 15px;
            flex-wrap: wrap;
            gap: 10px;
        }
        .timeline-date {
            font-size: 0.9rem;
            color: #6c757d;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .timeline-user {
            font-weight: 600;
            color: #495057;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .status-transition {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 10px 0;
            flex-wrap: wrap;
        }
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .transition-arrow {
            color: #6c757d;
            font-size: 1.2rem;
        }
        .commentaire {
            background: #f8f9fa;
            border-left: 4px solid #007bff;
            padding: 12px 15px;
            margin-top: 15px;
            border-radius: 0 8px 8px 0;
            font-style: italic;
            color: #495057;
        }
        .duration-badge {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            padding: 4px 8px;
            border-radius: 10px;
            font-size: 0.75rem;
            margin-left: 10px;
        }
        .stats-row {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .stat-item {
            text-align: center;
            color: white;
        }
        .stat-number {
            font-size: 1.5rem;
            font-weight: bold;
            display: block;
        }
        .stat-label {
            font-size: 0.8rem;
            opacity: 0.8;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: white;
            opacity: 0.8;
        }
        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.6;
        }
        .error-alert {
            background: rgba(220, 53, 69, 0.1);
            border: 1px solid rgba(220, 53, 69, 0.3);
            color: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
        }
        @media (max-width: 768px) {
            .timeline {
                padding-left: 20px;
            }
            .timeline::before {
                left: 10px;
            }
            .timeline-item {
                margin-left: 10px;
            }
            .timeline-item::before {
                left: -18px;
            }
            .timeline-header {
                flex-direction: column;
                align-items: flex-start;
            }
            .status-transition {
                justify-content: center;
            }
        }
        .print-btn {
            background: rgba(255, 255, 255, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
        }
        .print-btn:hover {
            background: rgba(255, 255, 255, 0.25);
            color: white;
        }
        @media print {
            body {
                background: white !important;
                color: black !important;
            }
            .glass-container {
                background: white !important;
                box-shadow: none !important;
                border: 1px solid #ccc !important;
            }
            .back-btn, .print-btn {
                display: none !important;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <!-- Back Button -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <a href="/demande.php" class="btn back-btn">
            <i class="fas fa-arrow-left me-2"></i>Retour aux demandes
        </a>
        <button onclick="window.print()" class="btn print-btn">
            <i class="fas fa-print me-2"></i>Imprimer
        </button>
    </div>
    <!-- Page Header -->
    <div class="page-header">
        <h1><i class="fas fa-project-diagram me-3"></i>Historique du Workflow</h1>
        <?php if ($etat_id): ?>
            <p class="lead">État de Besoin #<?php echo htmlspecialchars($etat_id); ?></p>
        <?php endif; ?>
    </div>
    <?php if ($error_message): ?>
        <div class="error-alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <?php echo htmlspecialchars($error_message); ?>
        </div>
    <?php else: ?>
        <!-- Requirement Details -->
        <?php if ($etat_details): ?>
            <div class="glass-container">
                <div class="details-card">
                    <h4 class="mb-3">
                        <i class="fas fa-file-alt me-2 text-primary"></i>
                        Détails de l'État de Besoin
                    </h4>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Désignation:</strong> <?php echo htmlspecialchars($etat_details['designation']); ?></p>
                            <p><strong>Demandeur:</strong> <?php echo htmlspecialchars($etat_details['prenom'] . ' ' . $etat_details['nom']); ?></p>
                            <p><strong>Email:</strong> <?php echo htmlspecialchars($etat_details['email']); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Service:</strong> <?php echo htmlspecialchars($etat_details['service_nom'] ?? 'Non spécifié'); ?></p>
                            <p><strong>Date de création:</strong> <?php echo date('d/m/Y H:i', strtotime($etat_details['date_creation'])); ?></p>
                        </div>
                    </div>
                    <?php if (!empty($etat_details['description'])): ?>
                        <div class="mt-3">
                            <strong>Description:</strong>
                            <p class="text-muted mt-2"><?php echo nl2br(htmlspecialchars($etat_details['description'])); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
        <!-- Current Status -->
        <?php if ($current): ?>
            <div class="glass-container">
                <div class="current-status">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h4 class="mb-2">
                                <i class="<?php echo getStatusIcon($current['to_statut']); ?> me-2"></i>
                                Statut Actuel
                            </h4>
                            <h5><?php echo getStatusDisplayName($current['to_statut']); ?></h5>
                            <small>
                                <i class="fas fa-calendar-alt me-1"></i>
                                Changé le <?php echo date('d/m/Y à H:i', strtotime($current['created_at'])); ?>
                                <span class="duration-badge">
                                    <i class="fas fa-clock me-1"></i>
                                    <?php echo calculateDuration($current['created_at']); ?>
                                </span>
                            </small>
                        </div>
                        <span class="badge bg-<?php echo badgeClass($current['to_statut']); ?> status-badge">
                            <?php echo getStatusDisplayName($current['to_statut']); ?>
                        </span>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!-- Statistics -->
        <?php if (!empty($logs)): ?>
            <div class="glass-container">
                <div class="stats-row">
                    <div class="row">
                        <div class="col-md-3 col-sm-6 mb-3">
                            <div class="stat-item">
                                <span class="stat-number"><?php echo count($logs); ?></span>
                                <span class="stat-label">Transitions</span>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 mb-3">
                            <div class="stat-item">
                                <span class="stat-number">
                                    <?php 
                                    $total_duration = calculateDuration($etat_details['date_creation']);
                                    echo $total_duration;
                                    ?>
                                </span>
                                <span class="stat-label">Durée totale</span>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 mb-3">
                            <div class="stat-item">
                                <span class="stat-number">
                                    <?php 
                                    $users = array_unique(array_column($logs, 'nom'));
                                    echo count($users);
                                    ?>
                                </span>
                                <span class="stat-label">Intervenants</span>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 mb-3">
                            <div class="stat-item">
                                <span class="stat-number">
                                    <?php 
                                    $comments = array_filter(array_column($logs, 'commentaire'));
                                    echo count($comments);
                                    ?>
                                </span>
                                <span class="stat-label">Commentaires</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!-- Workflow Timeline -->
        <div class="glass-container">
            <?php if (!empty($logs)): ?>
                <h4 class="mb-4 text-white">
                    <i class="fas fa-history me-2"></i>
                    Chronologie des Changements
                </h4>
                <div class="timeline">
                    <?php 
                    $previous_date = null;
                    foreach (array_reverse($logs) as $index => $log): 
                        $log_date = date('Y-m-d', strtotime($log['created_at']));
                        $badge_class = badgeClass($log['to_statut']);
                    ?>
                        <?php if ($log_date !== $previous_date): ?>
                            <div class="text-white text-center my-3">
                                <strong><?php echo date('d/m/Y', strtotime($log['created_at'])); ?></strong>
                            </div>
                            <?php $previous_date = $log_date; ?>
                        <?php endif; ?>
                        <div class="timeline-item <?php echo $badge_class; ?>">
                            <div class="timeline-header">
                                <div class="timeline-user">
                                    <i class="fas fa-user-circle text-secondary"></i>
                                    <?php echo htmlspecialchars($log['nom'] . ' ' . $log['prenom']); ?>
                                </div>
                                <div class="timeline-date">
                                    <i class="fas fa-clock"></i>
                                    <?php echo date('H:i', strtotime($log['created_at'])); ?>
                                    <?php if ($index > 0): ?>
                                        <span class="duration-badge">
                                            <?php echo calculateDuration($logs[count($logs) - $index]['created_at'], $log['created_at']); ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="status-transition">
                                <span class="badge bg-danger status-badge">
                                    <?php echo getStatusDisplayName($log['from_statut']); ?>
                                </span>
                                <i class="fas fa-arrow-right transition-arrow"></i>
                                <span class="badge bg-<?php echo $badge_class; ?> status-badge">
                                    <?php echo getStatusDisplayName($log['to_statut']); ?>
                                </span>
                            </div>
                            <?php if (!empty($log['commentaire'])): ?>
                                <div class="commentaire">
                                    <i class="fas fa-comment me-2"></i>
                                    <strong>Commentaire:</strong>
                                    <div class="mt-2"><?php echo nl2br(htmlspecialchars($log['commentaire'])); ?></div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-history"></i>
                    <h3>Aucun historique disponible</h3>
                    <p>Il n'y a encore aucun changement de statut enregistré pour cet état de besoin.</p>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
<!-- Bootstrap JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Add smooth scrolling
    const timelineItems = document.querySelectorAll('.timeline-item');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateX(0)';
            }
        });
    }, { threshold: 0.1 });
    timelineItems.forEach(item => {
        item.style.opacity = '0';
        item.style.transform = 'translateX(-20px)';
        item.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        observer.observe(item);
    });
    // Add click animation to timeline items
    timelineItems.forEach(item => {
        item.addEventListener('click', function() {
            this.style.transform = 'scale(0.98)';
            setTimeout(() => {
                this.style.transform = 'translateX(5px)';
            }, 150);
        });
    });
});
// Auto-refresh every 30 seconds if page is visible
document.addEventListener('visibilitychange', function() {
    if (!document.hidden) {
        setTimeout(() => {
            location.reload();
        }, 30000);
    }
});
</script>
</body>
</html>