<?php
// settings.php — Configuration du Dashboard Directeur Général
require_once '../Config/session.php';
require_once '../modules/permission.php';
// Vérifie que l'utilisateur est connecté et possède le rôle "directeur_general"
AuthMiddleware::requireRole('directeur_general');
// Paramètres par défaut
$config = [
    'app_name'       => 'Gestion Acquisition du matériel',
    'dashboard_name' => 'Directeur Général',
    'theme'          => 'light',  // ou 'dark'
    'items_per_page' => 10
];
// Chargement des paramètres depuis la base de données (optionnel)
require_once '../Config/db.php';
try {
    $pdo = Database::getInstance()->getConnection();
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM app_settings");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $config[$row['setting_key']] = $row['setting_value'];
    }
} catch (PDOException $e) {
    error_log("Erreur chargement paramètres: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Paramètres - DG Dashboard</title>
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .settings-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        h1 {
            font-size: 1.8rem;
            margin-bottom: 20px;
            color: #343a40;
        }
    </style>
</head>
<body>
<div class="settings-container">
    <h1>⚙️ Paramètres - Tableau de Bord DG</h1>
    <p>Bienvenue, <strong><?php echo htmlspecialchars($_SESSION['nom_complet']); ?></strong>.<br>
    Rôle : Directeur Général</p>
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success" role="alert">
            ✅ Paramètres mis à jour avec succès !
        </div>
    <?php endif; ?>
    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-danger" role="alert">
            ❌ Erreur lors de la mise à jour des paramètres.
        </div>
    <?php endif; ?>
    <form method="post" action="update_settings.php">
        <div class="mb-3">
            <label for="items_per_page" class="form-label">Éléments par page</label>
            <input type="number" id="items_per_page" name="items_per_page" class="form-control"
                   value="<?php echo htmlspecialchars($config['items_per_page']); ?>" min="5" max="50">
        </div>
        <div class="mb-3">
            <label for="theme" class="form-label">Thème du Dashboard</label>
            <select id="theme" name="theme" class="form-select">
                <option value="light" <?php echo $config['theme'] === 'light' ? 'selected' : ''; ?>>Clair</option>
                <option value="dark" <?php echo $config['theme'] === 'dark' ? 'selected' : ''; ?>>Sombre</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">💾 Enregistrer</button>
    </form>
</div>
</body>
</html>
