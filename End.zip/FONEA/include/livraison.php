livraison.php
<?php
require_once '../Config/db.php';
require_login();
$pdo = db(); // Using the same db() function as in your other file
$errors = [];
$success = "";
// Récupérer la liste des commandes
$commandes = $pdo->query("SELECT c.id_commande, f.nom AS fournisseur, m.nom AS materiel, c.quantite AS quantite_commandee
                          FROM Commande c
                          JOIN Fournisseur f ON c.id_fournisseur = f.id_fournisseur
                          JOIN Materiel m ON c.id_materiel = m.id_materiel
                          ORDER BY c.id_commande DESC")->fetchAll(PDO::FETCH_ASSOC);
// Traitement de l'ajout d'une livraison
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_commande = $_POST['id_commande'] ?? '';
    $quantite_livree = $_POST['quantite_livree'] ?? '';
    $date_livraison = $_POST['date_livraison'] ?? '';
    // Validation simple
    if (empty($id_commande)) $errors[] = "La commande est requise.";
    if (empty($quantite_livree) || !is_numeric($quantite_livree) || $quantite_livree <= 0) $errors[] = "Quantité livrée invalide.";
    if (empty($date_livraison)) $errors[] = "La date de livraison est requise.";
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO Livraison (id_commande, quantite_livree, date_livraison) 
                                   VALUES (:id_commande, :quantite_livree, :date_livraison)");
            $stmt->execute([
                ':id_commande' => $id_commande,
                ':quantite_livree' => $quantite_livree,
                ':date_livraison' => $date_livraison
            ]);
            $success = "Livraison ajoutée avec succès.";
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de l'ajout de la livraison : " . $e->getMessage();
        }
    }
}
// Récupérer la liste des livraisons
$livraisons = $pdo->query("SELECT l.id_livraison, c.id_commande, f.nom AS fournisseur, m.nom AS materiel, 
                           l.quantite_livree, l.date_livraison
                           FROM Livraison l
                           JOIN Commande c ON l.id_commande = c.id_commande
                           JOIN Fournisseur f ON c.id_fournisseur = f.id_fournisseur
                           JOIN Materiel m ON c.id_materiel = m.id_materiel
                           ORDER BY l.id_livraison DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Livraisons</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 90%; margin-top: 20px; }
        th, td { border: 1px solid #333; padding: 8px; text-align: center; }
        th { background-color: #f4f4f4; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        form { margin-top: 30px; width: 400px; }
        select, input[type="number"], input[type="date"] { width: 100%; padding: 8px; margin: 5px 0; }
        input[type="submit"] { padding: 10px 15px; background-color: #2196F3; color: white; border: none; cursor: pointer; }
        .error { color: red; }
        .success { color: green; }
        h1, h2 { color: #333; }
    </style>
</head>
<body>
    <h1>Liste des Livraisons</h1>
    <?php if ($success): ?>
        <p class='success'><?= htmlspecialchars($success) ?></p>
    <?php endif; ?>
    <?php if (!empty($errors)): ?>
        <p class='error'><?= htmlspecialchars(implode(' ', $errors)) ?></p>
    <?php endif; ?>
    <?php if (!empty($livraisons)): ?>
        <table>
            <tr>
                <th>ID Livraison</th>
                <th>ID Commande</th>
                <th>Fournisseur</th>
                <th>Matériel</th>
                <th>Quantité Livrée</th>
                <th>Date de Livraison</th>
            </tr>
            <?php foreach ($livraisons as $l): ?>
                <tr>
                    <td><?= htmlspecialchars($l['id_livraison']) ?></td>
                    <td><?= htmlspecialchars($l['id_commande']) ?></td>
                    <td><?= htmlspecialchars($l['fournisseur']) ?></td>
                    <td><?= htmlspecialchars($l['materiel']) ?></td>
                    <td><?= htmlspecialchars($l['quantite_livree']) ?></td>
                    <td><?= htmlspecialchars($l['date_livraison']) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>Aucune livraison enregistrée pour le moment.</p>
    <?php endif; ?>
    <h2>Ajouter une Livraison</h2>
    <form method="POST" action="">
        <label for="id_commande">Commande:</label>
        <select id="id_commande" name="id_commande" required>
            <option value="">-- Sélectionner une commande --</option>
            <?php foreach ($commandes as $c): ?>
                <option value="<?= htmlspecialchars($c['id_commande']) ?>">
                    Commande #<?= htmlspecialchars($c['id_commande']) ?> - <?= htmlspecialchars($c['materiel']) ?> (<?= htmlspecialchars($c['fournisseur']) ?>) - Qté: <?= htmlspecialchars($c['quantite_commandee']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <label for="quantite_livree">Quantité Livrée:</label>
        <input type="number" id="quantite_livree" name="quantite_livree" min="1" required>
        <label for="date_livraison">Date de Livraison:</label>
        <input type="date" id="date_livraison" name="date_livraison" required>
        <input type="submit" value="Ajouter">
    </form>
</body>
</html>