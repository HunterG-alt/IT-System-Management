<?php
require_once '../Config/session.php';
require_once __DIR__ . '/../public/user.php';
// Check if user is logged in and has Agent/Demandeur role
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['agent', 'demandeur'])) {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit();
}
// Get user info
$user = User::getById($_SESSION['user_id']);
$user_name = $user ? $user['nom_complet'] : 'Agent';
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Centre d'Aide - FONEA Agent</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #ffffff;
            color: #1a1a1a;
            overflow-x: hidden;
        }
        /* Sidebar - Purple/Indigo Theme */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, #6366f1 0%, #4f46e5 100%);
            z-index: 1000;
            transition: all 0.3s ease;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
        }
        .sidebar-header {
            padding: 30px 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .sidebar-logo {
            color: #ffffff;
            font-size: 24px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .sidebar-logo i {
            background: linear-gradient(135deg, #8b5cf6, #7c3aed);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-size: 28px;
        }
        .sidebar-nav {
            padding: 20px 0;
        }
        .nav-item {
            margin: 8px 20px;
        }
        .nav-link {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            color: #cbd5e1;
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
            gap: 15px;
        }
        .nav-link:hover {
            background: rgba(139, 92, 246, 0.1);
            color: #8b5cf6;
            transform: translateX(5px);
        }
        .nav-link.active {
            background: linear-gradient(135deg, #8b5cf6, #7c3aed);
            color: #ffffff;
            box-shadow: 0 4px 15px rgba(139, 92, 246, 0.3);
        }
        .nav-link i {
            font-size: 18px;
            width: 20px;
        }
        /* Main Content */
        .main-content {
            margin-left: 280px;
            min-height: 100vh;
            background: #ffffff;
        }
        /* Top Header */
        .top-header {
            background: #ffffff;
            padding: 20px 40px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        .header-title {
            font-size: 24px;
            font-weight: 700;
            color: #4c1d95;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .back-btn {
            background: #f8fafc;
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        .back-btn:hover {
            background: #8b5cf6;
            color: #ffffff;
            transform: translateX(-2px);
        }
        /* Help Section */
        .help-section {
            padding: 40px;
        }
        .help-hero {
            text-align: center;
            padding: 60px 0;
            background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);
            border-radius: 20px;
            margin-bottom: 40px;
        }
        .help-hero h1 {
            font-size: 42px;
            font-weight: 700;
            color: #4c1d95;
            margin-bottom: 16px;
        }
        .help-hero p {
            font-size: 18px;
            color: #6366f1;
            max-width: 600px;
            margin: 0 auto;
        }
        .search-help {
            max-width: 500px;
            margin: 30px auto 0;
            position: relative;
        }
        .search-input {
            width: 100%;
            padding: 16px 20px 16px 50px;
            border: 2px solid #e2e8f0;
            border-radius: 25px;
            background: #ffffff;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        .search-input:focus {
            outline: none;
            border-color: #8b5cf6;
            box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.1);
        }
        .search-icon {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 18px;
        }
        /* Help Categories */
        .help-categories {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 50px;
        }
        .help-category {
            background: #ffffff;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid #e2e8f0;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .help-category:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
        }
        .category-icon {
            width: 70px;
            height: 70px;
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            color: #ffffff;
            margin-bottom: 20px;
        }
        .category-title {
            font-size: 20px;
            font-weight: 600;
            color: #4c1d95;
            margin-bottom: 10px;
        }
        .category-description {
            font-size: 14px;
            color: #6366f1;
            margin-bottom: 20px;
            line-height: 1.6;
        }
        .category-items {
            list-style: none;
            padding: 0;
        }
        .category-items li {
            padding: 8px 0;
            color: #64748b;
            font-size: 14px;
            border-bottom: 1px solid #f1f5f9;
            cursor: pointer;
            transition: color 0.3s ease;
        }
        .category-items li:hover {
            color: #8b5cf6;
        }
        .category-items li:last-child {
            border-bottom: none;
        }
        /* FAQ Section */
        .faq-section {
            background: #ffffff;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid #e2e8f0;
            margin-bottom: 30px;
        }
        .faq-title {
            font-size: 24px;
            font-weight: 700;
            color: #4c1d95;
            margin-bottom: 30px;
            text-align: center;
        }
        .faq-item {
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            margin-bottom: 15px;
            overflow: hidden;
        }
        .faq-question {
            padding: 20px;
            background: #f8fafc;
            cursor: pointer;
            font-weight: 500;
            color: #4c1d95;
            transition: background 0.3s ease;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .faq-question:hover {
            background: #e2e8f0;
        }
        .faq-answer {
            padding: 0 20px;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
            color: #64748b;
            line-height: 1.6;
        }
        .faq-answer.active {
            padding: 20px;
            max-height: 300px;
        }
        .faq-icon {
            transition: transform 0.3s ease;
        }
        .faq-icon.active {
            transform: rotate(180deg);
        }
        /* Contact Support */
        .support-section {
            background: linear-gradient(135deg, #8b5cf6, #7c3aed);
            border-radius: 20px;
            padding: 40px;
            color: #ffffff;
            text-align: center;
        }
        .support-title {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 16px;
        }
        .support-description {
            font-size: 16px;
            margin-bottom: 30px;
            opacity: 0.9;
        }
        .support-methods {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        .support-method {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 25px;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .support-method:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-3px);
        }
        .method-icon {
            font-size: 32px;
            margin-bottom: 15px;
        }
        .method-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 8px;
        }
        .method-info {
            font-size: 14px;
            opacity: 0.8;
        }
        /* Category Colors */
        .cat-getting-started .category-icon { background: linear-gradient(135deg, #8b5cf6, #7c3aed); }
        .cat-requests .category-icon { background: linear-gradient(135deg, #a855f7, #8b5cf6); }
        .cat-tracking .category-icon { background: linear-gradient(135deg, #c084fc, #a855f7); }
        .cat-profile .category-icon { background: linear-gradient(135deg, #6366f1, #4f46e5); }
        .cat-notifications .category-icon { background: linear-gradient(135deg, #f59e0b, #d97706); }
        .cat-troubleshooting .category-icon { background: linear-gradient(135deg, #ef4444, #dc2626); }
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .main-content {
                margin-left: 0;
            }
            .top-header {
                padding: 15px 20px;
            }
            .help-section {
                padding: 20px;
            }
            .help-categories {
                grid-template-columns: 1fr;
            }
            .support-methods {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-user"></i>
                FONEA Agent
            </div>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-item">
                <a href="dashboard_agent.php" class="nav-link">
                    <i class="fas fa-chart-pie"></i>
                    Dashboard
                </a>
            </div>
            <div class="nav-item">
                <a href="../show/my_requests.php" class="nav-link">
                    <i class="fas fa-file-alt"></i>
                    Mes Demandes
                </a>
            </div>
            <div class="nav-item">
                <a href="../show/create_request.php" class="nav-link">
                    <i class="fas fa-plus-circle"></i>
                    Nouvelle Demande
                </a>
            </div>
            <div class="nav-item">
                <a href="../show/request_status.php" class="nav-link">
                    <i class="fas fa-clock"></i>
                    Suivi Statut
                </a>
            </div>
            <div class="nav-item">
                <a href="../show/request_history.php" class="nav-link">
                    <i class="fas fa-history"></i>
                    Historique
                </a>
            </div>
            <div class="nav-item">
                <a href="../show/profile.php" class="nav-link">
                    <i class="fas fa-user-cog"></i>
                    Mon Profil
                </a>
            </div>
            <div class="nav-item">
                <a href="../show/notifications.php" class="nav-link">
                    <i class="fas fa-bell"></i>
                    Notifications
                </a>
            </div>
            <div class="nav-item">
                <a href="#" class="nav-link active">
                    <i class="fas fa-question-circle"></i>
                    Aide
                </a>
            </div>
        </nav>
    </div>
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <div class="header-title">
                <a href="dashboard_agent.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i>
                </a>
                Centre d'Aide
            </div>
        </div>
        <!-- Help Section -->
        <div class="help-section">
            <!-- Help Hero -->
            <div class="help-hero">
                <h1>Comment pouvons-nous vous aider ?</h1>
                <p>Trouvez des réponses à vos questions sur l'utilisation du système FONEA et la gestion de vos demandes d'équipement.</p>
                <div class="search-help">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" class="search-input" placeholder="Rechercher dans l'aide..." id="helpSearch">
                </div>
            </div>
            <!-- Help Categories -->
            <div class="help-categories">
                <div class="help-category cat-getting-started" onclick="showCategoryDetails('getting-started')">
                    <div class="category-icon">
                        <i class="fas fa-rocket"></i>
                    </div>
                    <h3 class="category-title">Guide de Démarrage</h3>
                    <p class="category-description">Apprenez les bases du système FONEA et comment commencer à utiliser la plateforme.</p>
                    <ul class="category-items">
                        <li>Première connexion</li>
                        <li>Navigation dans l'interface</li>
                        <li>Configuration du profil</li>
                        <li>Comprendre les statuts</li>
                    </ul>
                </div>
                <div class="help-category cat-requests" onclick="showCategoryDetails('requests')">
                    <div class="category-icon">
                        <i class="fas fa-file-plus"></i>
                    </div>
                    <h3 class="category-title">Créer des Demandes</h3>
                    <p class="category-description">Tout ce que vous devez savoir sur la création et la soumission de demandes d'équipement.</p>
                    <ul class="category-items">
                        <li>Nouvelle demande</li>
                        <li>Remplir les formulaires</li>
                        <li>Joindre des documents</li>
                        <li>Modifier une demande</li>
                    </ul>
                </div>
                <div class="help-category cat-tracking" onclick="showCategoryDetails('tracking')">
                    <div class="category-icon">
                        <i class="fas fa-search-location"></i>
                    </div>
                    <h3 class="category-title">Suivi des Demandes</h3>
                    <p class="category-description">Apprenez à suivre l'état de vos demandes et comprendre les différentes étapes.</p>
                    <ul class="category-items">
                        <li>Statuts des demandes</li>
                        <li>Historique détaillé</li>
                        <li>Notifications automatiques</li>
                        <li>Délais de traitement</li>
                    </ul>
                </div>
                <div class="help-category cat-profile" onclick="showCategoryDetails('profile')">
                    <div class="category-icon">
                        <i class="fas fa-user-edit"></i>
                    </div>
                    <h3 class="category-title">Gestion du Profil</h3>
                    <p class="category-description">Gérez vos informations personnelles et personnalisez votre expérience utilisateur.</p>
                    <ul class="category-items">
                        <li>Modifier les informations</li>
                        <li>Changer le mot de passe</li>
                        <li>Préférences de notification</li>
                        <li>Paramètres de confidentialité</li>
                    </ul>
                </div>
                <div class="help-category cat-notifications" onclick="showCategoryDetails('notifications')">
                    <div class="category-icon">
                        <i class="fas fa-bell-slash"></i>
                    </div>
                    <h3 class="category-title">Notifications</h3>
                    <p class="category-description">Configurez et gérez vos notifications pour rester informé des mises à jour importantes.</p>
                    <ul class="category-items">
                        <li>Types de notifications</li>
                        <li>Paramètres d'alerte</li>
                        <li>Notifications par email</li>
                        <li>Historique des notifications</li>
                    </ul>
                </div>
                <div class="help-category cat-troubleshooting" onclick="showCategoryDetails('troubleshooting')">
                    <div class="category-icon">
                        <i class="fas fa-tools"></i>
                    </div>
                    <h3 class="category-title">Dépannage</h3>
                    <p class="category-description">Solutions aux problèmes courants et conseils pour résoudre les difficultés techniques.</p>
                    <ul class="category-items">
                        <li>Problèmes de connexion</li>
                        <li>Erreurs de formulaire</li>
                        <li>Fichiers non supportés</li>
                        <li>Problèmes d'affichage</li>
                    </ul>
                </div>
            </div>
            <!-- FAQ Section -->
            <div class="faq-section">
                <h2 class="faq-title">Questions Fréquemment Posées</h2>
                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFAQ(this)">
                        <span>Comment créer ma première demande d'équipement ?</span>
                        <i class="fas fa-chevron-down faq-icon"></i>
                    </div>
                    <div class="faq-answer">
                        Pour créer votre première demande, cliquez sur "Nouvelle Demande" dans le menu de gauche, puis remplissez le formulaire avec les détails de l'équipement souhaité. Assurez-vous de fournir toutes les informations requises et de joindre les documents justificatifs si nécessaire.
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFAQ(this)">
                        <span>Combien de temps faut-il pour traiter une demande ?</span>
                        <i class="fas fa-chevron-down faq-icon"></i>
                    </div>
                    <div class="faq-answer">
                        Le délai de traitement varie selon le type d'équipement et la complexité de la demande. En général, les demandes sont traitées dans un délai de 5 à 15 jours ouvrables. Vous recevrez des notifications automatiques à chaque étape du processus.
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFAQ(this)">
                        <span>Puis-je modifier une demande après l'avoir soumise ?</span>
                        <i class="fas fa-chevron-down faq-icon"></i>
                    </div>
                    <div class="faq-answer">
                        Vous pouvez modifier une demande uniquement si elle n'a pas encore été validée par votre supérieur hiérarchique. Une fois validée, toute modification nécessitera la création d'une nouvelle demande ou un contact direct avec le service administratif.
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFAQ(this)">
                        <span>Comment puis-je suivre l'état d'avancement de mes demandes ?</span>
                        <i class="fas fa-chevron-down faq-icon"></i>
                    </div>
                    <div class="faq-answer">
                        Rendez-vous dans la section "Suivi Statut" pour voir l'état en temps réel de toutes vos demandes. Vous pouvez également consulter l'historique détaillé dans la section "Historique" pour voir toutes les actions effectuées sur vos demandes.
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFAQ(this)">
                        <span>Que faire si ma demande est refusée ?</span>
                        <i class="fas fa-chevron-down faq-icon"></i>
                    </div>
                    <div class="faq-answer">
                        Si votre demande est refusée, vous recevrez une notification avec les raisons du refus. Vous pouvez soit modifier votre demande pour corriger les points soulevés, soit contacter votre supérieur hiérarchique pour discuter des alternatives possibles.
                    </div>
                </div>
            </div>
            <!-- Contact Support -->
            <div class="support-section">
                <h2 class="support-title">Besoin d'aide supplémentaire ?</h2>
                <p class="support-description">Notre équipe de support est là pour vous aider. Contactez-nous par l'un des moyens suivants :</p>
                <div class="support-methods">
                    <div class="support-method" onclick="contactSupport('email')">
                        <div class="method-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <h4 class="method-title">Support Email</h4>
                        <p class="method-info">support@fonea.cg<br>Réponse sous 24h</p>
                    </div>
                    <div class="support-method" onclick="contactSupport('phone')">
                        <div class="method-icon">
                            <i class="fas fa-phone"></i>
                        </div>
                        <h4 class="method-title">Support Téléphonique</h4>
                        <p class="method-info">+242 05 123 456<br>Lun-Ven 8h-17h</p>
                    </div>
                    <div class="support-method" onclick="contactSupport('ticket')">
                        <div class="method-icon">
                            <i class="fas fa-ticket-alt"></i>
                        </div>
                        <h4 class="method-title">Créer un Ticket</h4>
                        <p class="method-info">Support prioritaire<br>Suivi personnalisé</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Search functionality
        document.getElementById('helpSearch').addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const categories = document.querySelectorAll('.help-category');
            categories.forEach(category => {
                const title = category.querySelector('.category-title').textContent.toLowerCase();
                const description = category.querySelector('.category-description').textContent.toLowerCase();
                const items = Array.from(category.querySelectorAll('.category-items li')).map(item => item.textContent.toLowerCase());
                const matches = title.includes(searchTerm) || 
                               description.includes(searchTerm) || 
                               items.some(item => item.includes(searchTerm));
                if (searchTerm === '' || matches) {
                    category.style.display = 'block';
                } else {
                    category.style.display = 'none';
                }
            });
        });
        // FAQ Toggle
        function toggleFAQ(questionElement) {
            const answer = questionElement.nextElementSibling;
            const icon = questionElement.querySelector('.faq-icon');
            // Close all other FAQs
            document.querySelectorAll('.faq-answer').forEach(ans => {
                if (ans !== answer) {
                    ans.classList.remove('active');
                }
            });
            document.querySelectorAll('.faq-icon').forEach(ic => {
                if (ic !== icon) {
                    ic.classList.remove('active');
                }
            });
            // Toggle current FAQ
            answer.classList.toggle('active');
            icon.classList.toggle('active');
        }
        // Category details
        function showCategoryDetails(category) {
            console.log('Showing details for category:', category);
            // Here you would typically show a detailed view or navigate to a specific help page
            alert(`Affichage des détails pour la catégorie: ${category}`);
        }
        // Contact support
        function contactSupport(method) {
            switch(method) {
                case 'email':
                    window.location.href = 'mailto:support@fonea.cg?subject=Demande d\'aide - Agent';
                    break;
                case 'phone':
                    alert('Numéro de téléphone: +242 05 123 456\nDisponible du Lundi au Vendredi de 8h à 17h');
                    break;
                case 'ticket':
                    // Navigate to ticket creation page
                    console.log('Creating support ticket...');
                    alert('Redirection vers la création d\'un ticket de support...');
                    break;
            }
        }
        // Add smooth scrolling for internal links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const targetId = this.getAttribute('href').substring(1);
                const targetElement = document.getElementById(targetId);
                if (targetElement) {
                    targetElement.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    </script>
</body>
</html>