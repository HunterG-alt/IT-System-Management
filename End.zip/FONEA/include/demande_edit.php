<?php
require_once '../Config/db.php';
require_login();
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    die("ID invalide.");
}
$user = current_user();
$userRole = $user['role'] ?? '';
// Vérifier que l'utilisateur a le droit de modifier
if ($userRole !== 'agent_demandeur') {
    die("Accès refusé.");
}
// Charger la demande
$st = db()->prepare("SELECT * FROM etat_de_besoin WHERE id_besoin = ?");
$st->execute([$id_besoin]);
$demande = $st->fetch();
// Update query
$st = db()->prepare("
    UPDATE etat_de_besoin
    SET designation_materiel = ?, justification = ?
    WHERE id_besoin = ?
");
$st->execute([$designation_materiel, $justification, $id_besoin]);
if (!$demande) {
    die("Demande introuvable.");
}
// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $designation_materiel = trim($_POST['designation'] ?? '');
    $id_besoin = trim($_POST['besoin'] ?? '');
    $justification = trim($_POST['justification'] ?? '');
    if ($designation_materiel && $id_besoin) {
        $st = db()->prepare("
            UPDATE etat_de_besoin
            SET designation = ?, besoin = ?, justification = ?
            WHERE id = ?
        ");
        $st->execute([$designation_materiel, $justification, $id_besoin, $id]);
        header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/demande.php?success=1");
        exit;
    } else {
        $error = "Veuillez remplir tous les champs obligatoires.";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Modifier la Demande</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light p-4">
<div class="container bg-white p-4 rounded shadow">
  <h2 class="mb-3">Modifier la Demande #<?= htmlspecialchars($demande['id']) ?></h2>
  <?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>
  <form method="post">
    <div class="mb-3">
      <label class="form-label">Désignation</label>
      <input type="text" name="designation" class="form-control" value="<?= htmlspecialchars($demande['designation']) ?>" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Besoin</label>
      <textarea name="besoin" class="form-control" required><?= htmlspecialchars($demande['besoin']) ?></textarea>
    </div>
    <div class="mb-3">
      <label class="form-label">Justification</label>
      <textarea name="justification" class="form-control"><?= htmlspecialchars($demande['justification']) ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Enregistrer</button>
    <a href="demande.php" class="btn btn-secondary">Annuler</a>
  </form>
</div>
</body>
</html>
