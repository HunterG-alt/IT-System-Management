<?php 
include '../show/navigations.php';
require_once __DIR__ . 'config/db.php';
require_once __DIR__ . '/../Lib/csrf.php';
// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['avis'])) {
    if (!csrf_check()) {
        $error = "Erreur de sécurité. Veuillez réessayer.";
    } else {
        $id_etat = filter_var($_POST['id_etat'], FILTER_VALIDATE_INT);
        $avis = filter_input(INPUT_POST, 'avis', FILTER_SANITIZE_STRING);
        if ($id_etat && in_array($avis, ['favorable', 'defavorable'])) {
            try {
                $pdo = Database::getInstance()->getConnection();
                $new_status = ($avis === 'favorable') ? 'valide_service' : 'rejete';
                $stmt = $pdo->prepare("UPDATE etat_de_besoin SET statut = ? WHERE id = ?");
                $stmt->execute([$new_status, $id_etat]);
                $success = "État de besoin mis à jour avec succès.";
            } catch (PDOException $e) {
                $error = "Erreur lors de la mise à jour: " . $e->getMessage();
            }
        } else {
            $error = "Données invalides.";
        }
    }
}
// Get filter parameters
$status_filter = filter_input(INPUT_GET, 'status', FILTER_SANITIZE_STRING) ?? '';
$search = filter_input(INPUT_GET, 'search', FILTER_SANITIZE_STRING) ?? '';
// Pagination
$page = filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT) ?: 1;
$limit = 10;
$offset = ($page - 1) * $limit;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des États de Besoin</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #fff;
            padding: 20px;
            min-height: 100vh;
        }
        h1 { 
            text-align: center; 
            margin-bottom: 30px; 
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .glass-container {
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px) saturate(180%);
            -webkit-backdrop-filter: blur(10px) saturate(180%);
            border-radius: 15px;
            border: 1px solid rgba(255,255,255,0.2);
            padding: 25px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
            margin-bottom: 20px;
        }
        .filters-section {
            background: rgba(255,255,255,0.05);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        table th, table td { 
            color: #fff; 
            border-color: rgba(255,255,255,0.2) !important;
        }
        .table-hover tbody tr:hover td {
            background-color: rgba(255,255,255,0.1);
        }
        .btn-glass {
            background: rgba(255,255,255,0.15);
            border: 1px solid rgba(255,255,255,0.3);
            color: #fff;
            transition: all 0.3s ease;
            margin: 2px;
        }
        .btn-glass:hover {
            background: rgba(255,255,255,0.25);
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            color: #fff;
        }
        .btn-success-glass {
            background: rgba(40, 167, 69, 0.3);
            border: 1px solid rgba(40, 167, 69, 0.5);
            color: #fff;
        }
        .btn-success-glass:hover {
            background: rgba(40, 167, 69, 0.5);
            color: #fff;
        }
        .btn-danger-glass {
            background: rgba(220, 53, 69, 0.3);
            border: 1px solid rgba(220, 53, 69, 0.5);
            color: #fff;
        }
        .btn-danger-glass:hover {
            background: rgba(220, 53, 69, 0.5);
            color: #fff;
        }
        .status-badge {
            padding: 6px 12px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .status-pending { 
            background: linear-gradient(45deg, #ffa500, #ff8c00);
            color: #fff;
            box-shadow: 0 2px 4px rgba(255,165,0,0.3);
        }
        .status-approved { 
            background: linear-gradient(45deg, #28a745, #20c997);
            color: #fff;
            box-shadow: 0 2px 4px rgba(40,167,69,0.3);
        }
        .status-rejected { 
            background: linear-gradient(45deg, #dc3545, #c82333);
            color: #fff;
            box-shadow: 0 2px 4px rgba(220,53,69,0.3);
        }
        .alert-glass {
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            color: #fff;
            backdrop-filter: blur(5px);
        }
        .form-control-glass {
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            color: #fff;
            border-radius: 8px;
        }
        .form-control-glass:focus {
            background: rgba(255,255,255,0.15);
            border-color: rgba(255,255,255,0.4);
            color: #fff;
            box-shadow: 0 0 0 0.25rem rgba(255,255,255,0.1);
        }
        .form-control-glass::placeholder {
            color: rgba(255,255,255,0.7);
        }
        .pagination .page-link {
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            color: #fff;
        }
        .pagination .page-link:hover {
            background: rgba(255,255,255,0.2);
            color: #fff;
        }
        .pagination .page-item.active .page-link {
            background: rgba(255,255,255,0.3);
            border-color: rgba(255,255,255,0.4);
        }
        .empty-state {
            text-align: center;
            padding: 50px 20px;
            opacity: 0.7;
        }
        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.5;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <h1><i class="fas fa-clipboard-list me-3"></i>Liste des États de Besoin</h1>
    <?php if (isset($success)): ?>
        <div class="alert alert-success alert-glass alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if (isset($error)): ?>
        <div class="alert alert-danger alert-glass alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i><?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <!-- Filters Section -->
    <div class="glass-container">
        <div class="filters-section">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <label for="search" class="form-label">
                        <i class="fas fa-search me-2"></i>Rechercher
                    </label>
                    <input type="text" 
                           class="form-control form-control-glass" 
                           id="search" 
                           name="search" 
                           placeholder="Nom, prénom ou désignation..."
                           value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-3">
                    <label for="status" class="form-label">
                        <i class="fas fa-filter me-2"></i>Statut
                    </label>
                    <select class="form-select form-control-glass" id="status" name="status">
                        <option value="">Tous les statuts</option>
                        <option value="soumis" <?php echo $status_filter === 'soumis' ? 'selected' : ''; ?>>Soumis</option>
                        <option value="valide_service" <?php echo $status_filter === 'valide_service' ? 'selected' : ''; ?>>Validé</option>
                        <option value="rejete" <?php echo $status_filter === 'rejete' ? 'selected' : ''; ?>>Rejeté</option>
                    </select>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-glass me-2">
                        <i class="fas fa-search me-1"></i>Filtrer
                    </button>
                    <a href="?" class="btn btn-glass">
                        <i class="fas fa-undo me-1"></i>Reset
                    </a>
                </div>
            </form>
        </div>
        <?php
        try {
            $pdo = Database::getInstance()->getConnection();
            // Build query with filters
            $where_conditions = [];
            $params = [];
            if ($search) {
                $where_conditions[] = "(u.nom LIKE ? OR u.prenom LIKE ? OR e.designation LIKE ?)";
                $search_param = "%$search%";
                $params[] = $search_param;
                $params[] = $search_param;
                $params[] = $search_param;
            }
            if ($status_filter) {
                $where_conditions[] = "e.statut = ?";
                $params[] = $status_filter;
            }
            $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
            // Count total records
            $count_stmt = $pdo->prepare("
                SELECT COUNT(*) as total
                FROM etat_de_besoin e
                JOIN agents a ON e.agent_id = a.id
                JOIN users u ON a.user_id = u.id
                $where_clause
            ");
            $count_stmt->execute($params);
            $total_records = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
            $total_pages = ceil($total_records / $limit);
            // Get paginated records
            $stmt = $pdo->prepare("
                SELECT e.id, e.designation, u.nom, u.prenom, e.statut, e.created_at
                FROM etat_de_besoin e
                JOIN agents a ON e.agent_id = a.id
                JOIN users u ON a.user_id = u.id
                $where_clause
                ORDER BY e.created_at DESC
                LIMIT ? OFFSET ?
            ");
            $execute_params = array_merge($params, [$limit, $offset]);
            $stmt->execute($execute_params);
            $besoins = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            echo '<div class="alert alert-danger alert-glass">Erreur lors du chargement des données: ' . htmlspecialchars($e->getMessage()) . '</div>';
            $besoins = [];
            $total_records = 0;
            $total_pages = 0;
        }
        ?>
        <!-- Results Info -->
        <div class="d-flex justify-content-between align-items-center mb-3">
            <span class="text-muted">
                <i class="fas fa-info-circle me-2"></i>
                <?php echo $total_records; ?> résultat(s) trouvé(s)
                <?php if ($page > 1): ?>
                    - Page <?php echo $page; ?> sur <?php echo $total_pages; ?>
                <?php endif; ?>
            </span>
        </div>
        <?php if (empty($besoins)): ?>
            <div class="empty-state">
                <i class="fas fa-inbox"></i>
                <h3>Aucun état de besoin trouvé</h3>
                <p class="text-muted">
                    <?php if ($search || $status_filter): ?>
                        Essayez de modifier vos critères de recherche.
                    <?php else: ?>
                        Il n'y a aucun état de besoin enregistré pour le moment.
                    <?php endif; ?>
                </p>
            </div>
        <?php else: ?>
            <!-- Table -->
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th><i class="fas fa-hashtag me-2"></i>ID</th>
                            <th><i class="fas fa-file-alt me-2"></i>Désignation</th>
                            <th><i class="fas fa-user me-2"></i>Agent</th>
                            <th><i class="fas fa-flag me-2"></i>Statut</th>
                            <th><i class="fas fa-cogs me-2"></i>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($besoins as $b):
                            $statusClass = match($b['statut']) {
                                'soumis' => 'status-pending',
                                'valide_service' => 'status-approved',
                                'rejete' => 'status-rejected',
                                default => 'status-pending'
                            };
                            $statusText = match($b['statut']) {
                                'soumis' => 'En attente',
                                'valide_service' => 'Validé',
                                'rejete' => 'Rejeté',
                                default => $b['statut']
                            };
                        ?>
                        <tr>
                            <td><strong>#<?php echo htmlspecialchars($b['id']); ?></strong></td>
                            <td>
                                <div class="fw-bold"><?php echo htmlspecialchars($b['designation']); ?></div>
                                <?php if (isset($b['created_at'])): ?>
                                    <small class="text-muted">
                                        <i class="fas fa-calendar-alt me-1"></i>
                                        <?php echo date('d/m/Y H:i', strtotime($b['created_at'])); ?>
                                    </small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="avatar-circle me-2">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <?php echo htmlspecialchars($b['prenom'] . ' ' . $b['nom']); ?>
                                </div>
                            </td>
                            <td>
                                <span class="status-badge <?php echo $statusClass; ?>">
                                    <?php echo htmlspecialchars($statusText); ?>
                                </span>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <?php if ($b['statut'] === 'soumis'): ?>
                                        <form method="POST" style="display:inline-block;" class="me-1">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id_etat" value="<?php echo htmlspecialchars($b['id']); ?>">
                                            <button type="submit" 
                                                    name="avis" 
                                                    value="favorable" 
                                                    class="btn btn-success-glass btn-sm"
                                                    onclick="return confirm('Confirmer la validation de cet état de besoin ?');">
                                                <i class="fas fa-check me-1"></i>Valider
                                            </button>
                                        </form>
                                        <form method="POST" style="display:inline-block;" class="me-1">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id_etat" value="<?php echo htmlspecialchars($b['id']); ?>">
                                            <button type="submit" 
                                                    name="avis" 
                                                    value="defavorable" 
                                                    class="btn btn-danger-glass btn-sm"
                                                    onclick="return confirm('Confirmer le rejet de cet état de besoin ?');">
                                                <i class="fas fa-times me-1"></i>Rejeter
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    <a href="view.php?id=<?php echo htmlspecialchars($b['id']); ?>" 
                                       class="btn btn-glass btn-sm me-1"
                                       title="Voir les détails">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="Delete.php?id=<?php echo htmlspecialchars($b['id']); ?>" 
                                       onclick="return confirm('Voulez-vous vraiment supprimer cet enregistrement ? Cette action est irréversible.');" 
                                       class="btn btn-danger btn-sm"
                                       title="Supprimer">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <nav aria-label="Navigation des pages" class="mt-4">
                    <ul class="pagination justify-content-center">
                        <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo ($page-1); ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>">
                                    <i class="fas fa-chevron-left"></i>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                            <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>">
                                    <?php echo $i; ?>
                                </a>
                            </li>
                        <?php endfor; ?>
                        <?php if ($page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo ($page+1); ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>">
                                    <i class="fas fa-chevron-right"></i>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<!-- Bootstrap JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<script>
// Auto-hide alerts after 5 seconds
document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            if (alert && alert.classList.contains('show')) {
                alert.classList.remove('show');
                alert.classList.add('fade');
                setTimeout(() => alert.remove(), 300);
            }
        }, 5000);
    });
});
// Add loading states to buttons
document.querySelectorAll('button[type="submit"]').forEach(button => {
    button.addEventListener('click', function() {
        const icon = this.querySelector('i');
        const originalClass = icon.className;
        icon.className = 'fas fa-spinner fa-spin';
        setTimeout(() => {
            icon.className = originalClass;
        }, 2000);
    });
});
</script>
</body>
</html>