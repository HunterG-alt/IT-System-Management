<?php
require_once __DIR__ . '/../Config/session.php';
define('USER_BYPASS_GUARD', true);
require_once __DIR__ . '/../public/user.php';
// Get error type from URL parameter
$error_type = $_GET['error'] ?? 'general';
// Define error messages and details
$errors = [
    'unauthorized' => [
        'title' => 'Accès non autorisé',
        'message' => 'Vous n\'avez pas les permissions nécessaires pour accéder à cette page.',
        'description' => 'Cette section est réservée aux utilisateurs ayant des privilèges spécifiques. Veuillez contacter votre administrateur si vous pensez que c\'est une erreur.',
        'icon' => 'fas fa-shield-alt',
        'color' => 'warning',
        'code' => '403'
    ],
    'not_found' => [
        'title' => 'Page introuvable',
        'message' => 'La page que vous recherchez n\'existe pas.',
        'description' => 'Il est possible que le lien soit incorrect ou que la page ait été supprimée. Vérifiez l\'URL ou retournez à l\'accueil.',
        'icon' => 'fas fa-search',
        'color' => 'primary',
        'code' => '404'
    ],
    'session_expired' => [
        'title' => 'Session expirée',
        'message' => 'Votre session a expiré pour des raisons de sécurité.',
        'description' => 'Veuillez vous reconnecter pour continuer à utiliser l\'application.',
        'icon' => 'fas fa-clock',
        'color' => 'info',
        'code' => '401'
    ],
    'server_error' => [
        'title' => 'Erreur serveur',
        'message' => 'Une erreur interne s\'est produite.',
        'description' => 'Nous rencontrons actuellement des difficultés techniques. Veuillez réessayer dans quelques instants.',
        'icon' => 'fas fa-server',
        'color' => 'danger',
        'code' => '500'
    ],
    'database_error' => [
        'title' => 'Erreur de base de données',
        'message' => 'Impossible de se connecter à la base de données.',
        'description' => 'Un problème de connexion à la base de données est survenu. L\'équipe technique a été notifiée.',
        'icon' => 'fas fa-database',
        'color' => 'danger',
        'code' => '503'
    ],
    'maintenance' => [
        'title' => 'Maintenance en cours',
        'message' => 'Le système est temporairement indisponible.',
        'description' => 'Nous effectuons une maintenance programmée. Le service sera rétabli sous peu.',
        'icon' => 'fas fa-tools',
        'color' => 'secondary',
        'code' => '503'
    ],
    'general' => [
        'title' => 'Une erreur est survenue',
        'message' => 'Quelque chose s\'est mal passé.',
        'description' => 'Une erreur inattendue s\'est produite. Veuillez réessayer ou contacter le support technique.',
        'icon' => 'fas fa-exclamation-triangle',
        'color' => 'warning',
        'code' => '500'
    ]
];
// Get current error or default to general
$current_error = $errors[$error_type] ?? $errors['general'];
// Set HTTP response code if not already set
if (!headers_sent()) {
    http_response_code((int)$current_error['code']);
}
// Check if user is logged in for navigation
$user = null;
if (isset($_SESSION['user_id'])) {
    try {
        $user = User::getById($_SESSION['user_id']);
    } catch (Exception $e) {
        // Ignore error, user will be null
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($current_error['title']) ?> - FONEA</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh; 
            font-family: 'Segoe UI', Tahoma, sans-serif; 
        }
        .error-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem 0;
        }
        .error-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            overflow: hidden;
            max-width: 600px;
            width: 90%;
        }
        .error-header {
            padding: 3rem 2rem 2rem;
            text-align: center;
            position: relative;
        }
        .error-icon {
            font-size: 4rem;
            margin-bottom: 1rem;
            opacity: 0.8;
        }
        .error-code {
            position: absolute;
            top: 1rem;
            right: 1.5rem;
            font-size: 1.5rem;
            font-weight: 700;
            opacity: 0.3;
        }
        .error-title {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: #333;
        }
        .error-message {
            font-size: 1.1rem;
            color: #666;
            margin-bottom: 1rem;
        }
        .error-description {
            color: #777;
            font-size: 0.95rem;
            line-height: 1.6;
        }
        .error-actions {
            padding: 2rem;
            background: rgba(248, 249, 250, 0.5);
            text-align: center;
        }
        .btn-error {
            margin: 0.25rem;
            min-width: 120px;
            border-radius: 25px;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .btn-error:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .system-info {
            padding: 1rem 2rem;
            background: rgba(248, 249, 250, 0.8);
            border-top: 1px solid rgba(0,0,0,0.05);
            font-size: 0.8rem;
            color: #666;
            text-align: center;
        }
        @media (max-width: 576px) {
            .error-header { padding: 2rem 1.5rem 1.5rem; }
            .error-title { font-size: 1.5rem; }
            .error-icon { font-size: 3rem; }
            .btn-error { min-width: auto; width: 100%; margin: 0.25rem 0; }
        }
    </style>
</head>
<body>
    <div class="error-container">
        <div class="error-card">
            <div class="error-header">
                <div class="error-code"><?= $current_error['code'] ?></div>
                <div class="error-icon text-<?= $current_error['color'] ?>">
                    <i class="<?= $current_error['icon'] ?>"></i>
                </div>
                <h1 class="error-title"><?= htmlspecialchars($current_error['title']) ?></h1>
                <p class="error-message"><?= htmlspecialchars($current_error['message']) ?></p>
                <p class="error-description"><?= htmlspecialchars($current_error['description']) ?></p>
            </div>
            <div class="error-actions">
                <?php if ($error_type === 'unauthorized'): ?>
                    <?php if ($user): ?>
                        <a href="index.php" class="btn btn-primary btn-error">
                            <i class="fas fa-home me-2"></i>Retour à l'accueil
                        </a>
                        <a href="javascript:history.back()" class="btn btn-outline-secondary btn-error">
                            <i class="fas fa-arrow-left me-2"></i>Page précédente
                        </a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-primary btn-error">
                            <i class="fas fa-sign-in-alt me-2"></i>Se connecter
                        </a>
                    <?php endif; ?>
                <?php elseif ($error_type === 'session_expired'): ?>
                    <a href="login.php" class="btn btn-primary btn-error">
                        <i class="fas fa-sign-in-alt me-2"></i>Se reconnecter
                    </a>
                <?php else: ?>
                    <a href="index.php" class="btn btn-primary btn-error">
                        <i class="fas fa-home me-2"></i>Accueil
                    </a>
                    <button onclick="location.reload()" class="btn btn-outline-success btn-error">
                        <i class="fas fa-redo me-2"></i>Réessayer
                    </button>
                    <a href="javascript:history.back()" class="btn btn-outline-secondary btn-error">
                        <i class="fas fa-arrow-left me-2"></i>Retour
                    </a>
                <?php endif; ?>
            </div>
            <div class="system-info">
                <i class="fas fa-info-circle me-1"></i>
                Erreur survenue le <?= date('d/m/Y à H:i:s') ?>
                <?php if (defined('APP_VERSION')): ?>
                    | Version <?= APP_VERSION ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-redirect for certain error types after delay
        <?php if ($error_type === 'session_expired'): ?>
        setTimeout(function() {
            if (confirm('Redirection automatique vers la page de connexion dans 5 secondes. Continuer ?')) {
                window.location.href = 'login.php';
            }
        }, 5000);
        <?php endif; ?>
        // Log error to console for debugging (development only)
        console.log('Error Page Info:', {
            type: '<?= $error_type ?>',
            code: '<?= $current_error['code'] ?>',
            timestamp: '<?= date('c') ?>',
            user_agent: navigator.userAgent,
            referrer: document.referrer || 'Direct access'
        });
    </script>
</body>
</html>