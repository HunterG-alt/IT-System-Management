<?php
require_once '../Config/session.php';
require_once '../modules/permission.php';
require_once '../modules/WorkflowManager.php';

require login();
// Ensure proper authentication and authorization
AuthMiddleware::requireRole('chef_service');
// Initialize workflow manager
$workflowManager = new WorkflowManager();
$bulkMsg = '';
$message = '';
$error = '';
// === MIGRATED: Session-based statistics ===
if (!isset($_SESSION['validation_stats'])) {
    $_SESSION['validation_stats'] = ['valide' => 0, 'rejete' => 0];
}
// === MIGRATED: Reset stats functionality ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_stats'])) {
    // CSRF protection
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        $error = 'Token CSRF invalide';
    } else {
        $_SESSION['validation_stats'] = ['valide' => 0, 'rejete' => 0];
        $message = 'Statistiques remises à zéro avec succès.';
    }
}
// === MIGRATED: Enhanced pagination ===
$limit = 20;
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $limit;
// === Handle Bulk Actions ===
if (isset($_GET['action']) && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = filter_input(INPUT_GET, 'action', FILTER_SANITIZE_STRING);
    // CSRF protection for bulk actions
    if (!isset($_GET['token']) || $_GET['token'] !== $_SESSION['csrf_token']) {
        $error = "Token de sécurité invalide.";
    } else {
        $db = db(); // Ensure db() returns your PDO instance
        try {
            $db->beginTransaction();
            switch ($action) {
                case 'mark_all_favorable':
                    $stmt = $db->prepare("UPDATE etat_de_besoin SET statut = 'pre_validee', date_pre_validation = NOW(), chef_service_id = ? WHERE statut = 'en_attente' LIMIT 100");
                    $stmt->execute([$_SESSION['user_id']]);
                    $affectedRows = $stmt->rowCount();
                    $_SESSION['validation_stats']['valide'] += $affectedRows; // MIGRATED: Update session stats
                    $bulkMsg = "$affectedRows demande(s) en attente ont été marquées comme favorables.";
                    break;
                case 'mark_all_defavorable':
                    $stmt = $db->prepare("UPDATE etat_de_besoin SET statut = 'refusee_chef', date_pre_validation = NOW(), chef_service_id = ? WHERE statut = 'en_attente' LIMIT 100");
                    $stmt->execute([$_SESSION['user_id']]);
                    $affectedRows = $stmt->rowCount();
                    $_SESSION['validation_stats']['rejete'] += $affectedRows; // MIGRATED: Update session stats
                    $bulkMsg = "$affectedRows demande(s) en attente ont été marquées comme défavorables.";
                    break;
                case 'delete_all':
                    $stmt = $db->prepare("SELECT COUNT(*) FROM etat_de_besoin WHERE statut = 'en_attente'");
                    $stmt->execute();
                    $count = $stmt->fetchColumn();
                    $stmt = $db->prepare("DELETE FROM etat_de_besoin WHERE statut = 'en_attente'");
                    $stmt->execute();
                    $bulkMsg = "$count pré-validation(s) en attente ont été supprimées.";
                    break;
                default:
                    $error = "Action non reconnue.";
            }
            $db->commit();
            // Redirect to prevent form resubmission
            if (empty($error)) {
                header("Location: pre_validation.php?bulk_success=" . urlencode($bulkMsg));
                exit();
            }
        } catch (Exception $e) {
            $db->rollBack();
            $error = "Erreur lors de l'opération: " . $e->getMessage();
            error_log("Bulk action error: " . $e->getMessage());
        }
    }
}
// === Handle Individual Actions ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // CSRF protection
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = 'Token de sécurité invalide.';
    } else {
        $besoin_id = filter_input(INPUT_POST, 'besoin_id', FILTER_VALIDATE_INT);
        $action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);
        $commentaire = trim(filter_input(INPUT_POST, 'commentaire', FILTER_SANITIZE_STRING) ?? '');
        // MIGRATED: Enhanced input validation
        if (!$besoin_id || !in_array($action, ['approve', 'reject'])) {
            $error = 'Données invalides.';
        } elseif (strlen($commentaire) > 500) {
            $error = "Commentaire trop long (max 500 caractères)";
        } else {
            try {
                $success = $workflowManager->preValidateByChef($besoin_id, $_SESSION['user_id'], $action, $commentaire);
                if ($success) {
                    // MIGRATED: Update session statistics
                    $_SESSION['validation_stats'][$action === 'approve' ? 'valide' : 'rejete']++;
                    $message = $action === 'approve' ? 'Demande pré-validée avec succès' : 'Demande refusée avec succès';
                    header("Location: pre_validation.php?success=" . urlencode($message));
                    exit();
                } else {
                    $error = 'Erreur lors du traitement de la demande';
                }
            } catch (Exception $e) {
                $error = 'Erreur système: ' . $e->getMessage();
                error_log("Pre-validation error: " . $e->getMessage());
            }
        }
    }
}
// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
// === MIGRATED: Enhanced pending requests with pagination ===
try {
    $db = db();
    // Count total for pagination
    $stmt = $db->query("SELECT COUNT(*) FROM etat_de_besoin WHERE statut = 'en_attente'");
    $total_besoins = $stmt->fetchColumn();
    $total_pages = ceil($total_besoins / $limit);
    // Get paginated results
    $pending_requests = $workflowManager->getPendingRequestsPaginated('chef_service', $limit, $offset);
} catch (Exception $e) {
    $error = 'Erreur lors de la récupération des demandes.';
    $pending_requests = [];
    $total_besoins = 0;
    $total_pages = 0;
    error_log("Get pending requests error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pré-Validation - Chef de Service</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    .validation-card { 
      border-left: 4px solid #10b981; 
      transition: all 0.3s ease;
      border-radius: 8px;
    }
    .validation-card:hover { 
      transform: translateY(-2px); 
      box-shadow: 0 4px 15px rgba(0,0,0,0.1); 
    }
    .btn-approve { 
      background: linear-gradient(135deg, #10b981, #059669); 
      border: none; 
      color: #fff;
      transition: all 0.3s ease;
    }
    .btn-approve:hover { 
      background: linear-gradient(135deg, #059669, #047857);
      color: #fff;
      transform: translateY(-1px);
    }
    .btn-reject { 
      background: linear-gradient(135deg, #ef4444, #dc2626); 
      border: none; 
      color: #fff;
      transition: all 0.3s ease;
    }
    .btn-reject:hover { 
      background: linear-gradient(135deg, #dc2626, #b91c1c);
      color: #fff;
      transform: translateY(-1px);
    }
    .status-badge { 
      font-size: 0.8rem; 
      padding: 0.4rem 0.8rem;
      border-radius: 20px;
    }
    .bulk-actions {
      background: #f8f9fa;
      padding: 1rem;
      border-radius: 8px;
      border: 1px solid #e9ecef;
    }
    /* MIGRATED: Enhanced stats card styling */
    .stats-card {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border-radius: 15px;
      padding: 20px;
      margin-bottom: 20px;
    }
    .card-stats {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border-radius: 15px;
    }
    /* MIGRATED: Pagination styling */
    .pagination-wrapper {
      display: flex;
      justify-content: center;
      margin-top: 20px;
    }
  </style>
</head>
<body class="bg-light">
<div class="container-fluid py-4">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <div>
      <h2 class="text-primary mb-0">
        <i class="fas fa-check-circle me-2"></i>Pré-Validation des États de Besoin
      </h2>
      <small class="text-muted">Gérer les demandes en attente de pré-validation</small>
    </div>
    <a href="../show/dashboard_chef.php" class="btn btn-outline-primary">
      <i class="fas fa-arrow-left me-2"></i>Retour au Tableau de Bord
    </a>
  </div>
  <!-- MIGRATED: Enhanced Statistics Card with Reset functionality -->
  <div class="stats-card">
    <div class="d-flex align-items-center justify-content-between">
      <div>
        <h5><i class="fas fa-chart-bar me-2"></i>Statistiques de session</h5>
        <div class="row">
          <div class="col-md-3">
            <strong>Validés :</strong> <span class="badge bg-success"><?php echo $_SESSION['validation_stats']['valide'] ?></span>
          </div>
          <div class="col-md-3">
            <strong>Rejetés :</strong> <span class="badge bg-danger"><?php echo $_SESSION['validation_stats']['rejete'] ?></span>
          </div>
          <div class="col-md-3">
            <strong>En Attente :</strong> <span class="badge bg-warning text-dark"><?php echo $total_besoins ?></span>
          </div>
          <div class="col-md-3">
            <strong>Total Traités :</strong> <span class="badge bg-light text-dark"><?php echo $_SESSION['validation_stats']['valide'] + $_SESSION['validation_stats']['rejete'] ?></span>
          </div>
        </div>
      </div>
      <form method="POST" class="d-inline">
        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token'] ?>">
        <button type="submit" name="reset_stats" class="btn btn-warning btn-sm" 
                onclick="return confirm('Êtes-vous sûr de vouloir remettre à zéro les statistiques ?')">
          <i class="fas fa-undo me-1"></i>Reset Stats
        </button>
      </form>
    </div>
  </div>
  <!-- Alert Messages -->
  <?php if (isset($_GET['bulk_success'])): ?>
    <div class="alert alert-success alert-dismissible fade show">
      <i class="fas fa-check-circle me-2"></i>
      <?= htmlspecialchars($_GET['bulk_success'], ENT_QUOTES, 'UTF-8') ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>
  <?php if (isset($_GET['success']) || !empty($message)): ?>
    <div class="alert alert-success alert-dismissible fade show">
      <i class="fas fa-check-circle me-2"></i>
      <?= htmlspecialchars($_GET['success'] ?? $message, ENT_QUOTES, 'UTF-8') ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>
  <?php if (!empty($error)): ?>
    <div class="alert alert-danger alert-dismissible fade show">
      <i class="fas fa-exclamation-circle me-2"></i>
      <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>
  <!-- Bulk Actions -->
  <?php if (!empty($pending_requests)): ?>
  <div class="bulk-actions mb-4">
    <h6 class="mb-3"><i class="fas fa-tasks me-2"></i>Actions Groupées</h6>
    <div class="d-flex flex-wrap gap-2">
      <a href="?action=mark_all_favorable&token=<?= $_SESSION['csrf_token'] ?>" 
         class="btn btn-success btn-sm"
         onclick="return confirm('Êtes-vous sûr de vouloir marquer toutes les demandes comme favorables ?')">
        <i class="fas fa-thumbs-up me-1"></i>Marquer tout favorable
      </a>
      <a href="?action=mark_all_defavorable&token=<?= $_SESSION['csrf_token'] ?>" 
         class="btn btn-warning btn-sm"
         onclick="return confirm('Êtes-vous sûr de vouloir marquer toutes les demandes comme défavorables ?')">
        <i class="fas fa-thumbs-down me-1"></i>Marquer tout défavorable
      </a>
      <a href="?action=delete_all&token=<?= $_SESSION['csrf_token'] ?>" 
         class="btn btn-danger btn-sm"
         onclick="return confirm('ATTENTION: Cette action supprimera définitivement toutes les demandes en attente. Continuer ?')">
        <i class="fas fa-trash me-1"></i>Supprimer tout
      </a>
    </div>
  </div>
  <?php endif; ?>
  <!-- MIGRATED: Pagination info -->
  <?php if ($total_pages > 1): ?>
  <div class="d-flex justify-content-between align-items-center mb-3">
    <small class="text-muted">
      Page <?php echo $page ?> sur <?php echo $total_pages ?> 
      (<?php echo $total_besoins ?> demande<?php echo $total_besoins > 1 ? 's' : '' ?> au total)
    </small>
  </div>
  <?php endif; ?>
  <!-- Requests Grid -->
  <div class="row">
    <?php if (empty($pending_requests)): ?>
      <div class="col-12">
        <div class="card text-center py-5">
          <div class="card-body">
            <i class="fas fa-inbox fa-4x text-muted mb-3"></i>
            <h5 class="text-muted">Aucune demande en attente</h5>
            <p class="text-muted">Toutes les demandes ont été traitées ou il n'y a pas de nouvelles demandes.</p>
            <a href="dashboard_chef.php" class="btn btn-primary">
              <i class="fas fa-arrow-left me-2"></i>Retour au Tableau de Bord
            </a>
          </div>
        </div>
      </div>
    <?php else: ?>
      <?php foreach ($pending_requests as $request): ?>
        <div class="col-md-6 col-lg-4 mb-4">
          <div class="card validation-card h-100">
            <div class="card-header bg-white border-0">
              <div class="d-flex justify-content-between align-items-center">
                <span class="badge bg-warning status-badge">
                  <i class="fas fa-clock me-1"></i>En Attente
                </span>
                <small class="text-muted">
                  <i class="fas fa-calendar me-1"></i>
                  <?= date('d/m/Y H:i', strtotime($request['date_soumission'])) ?>
                </small>
              </div>
            </div>
            <div class="card-body">
              <h6 class="text-primary mb-2">
                <i class="fas fa-box me-1"></i>
                <?= htmlspecialchars($request['designation_materiel'], ENT_QUOTES, 'UTF-8') ?>
              </h6>
              <div class="mb-2">
                <small class="text-muted">
                  <i class="fas fa-user me-1"></i><strong>Demandeur:</strong>
                </small>
                <small class="d-block">
                  <?= htmlspecialchars($request['prenom'].' '.$request['nom'], ENT_QUOTES, 'UTF-8') ?>
                </small>
              </div>
              <?php if (!empty($request['justification'])): ?>
              <div class="mb-2">
                <small class="text-muted">
                  <i class="fas fa-comment me-1"></i><strong>Justification:</strong>
                </small>
                <p class="small mb-0">
                  <?= htmlspecialchars(
                    strlen($request['justification']) > 100 
                      ? substr($request['justification'], 0, 100) . '...' 
                      : $request['justification'], 
                    ENT_QUOTES, 'UTF-8'
                  ) ?>
                </p>
              </div>
              <?php endif; ?>
              <?php if (isset($request['quantite'])): ?>
              <div class="mb-2">
                <small class="text-muted">
                  <i class="fas fa-hashtag me-1"></i><strong>Quantité:</strong>
                  <?= htmlspecialchars($request['quantite'], ENT_QUOTES, 'UTF-8') ?>
                </small>
              </div>
              <?php endif; ?>
            </div>
            <div class="card-footer bg-white border-0 d-grid gap-2">
              <button class="btn btn-approve" 
                      data-bs-toggle="modal" 
                      data-bs-target="#validationModal"
                      data-besoin-id="<?= $request['id_besoin'] ?>" 
                      data-action="approve"
                      data-title="<?= htmlspecialchars($request['designation_materiel'], ENT_QUOTES, 'UTF-8') ?>">
                <i class="fas fa-check me-2"></i>Pré-Valider
              </button>
              <button class="btn btn-reject" 
                      data-bs-toggle="modal" 
                      data-bs-target="#validationModal"
                      data-besoin-id="<?= $request['id_besoin'] ?>" 
                      data-action="reject"
                      data-title="<?= htmlspecialchars($request['designation_materiel'], ENT_QUOTES, 'UTF-8') ?>">
                <i class="fas fa-times me-2"></i>Refuser
              </button>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
  <!-- MIGRATED: Enhanced Pagination -->
  <?php if ($total_pages > 1): ?>
  <div class="pagination-wrapper">
    <nav aria-label="Navigation des pages">
      <ul class="pagination">
        <?php if ($page > 1): ?>
          <li class="page-item">
            <a class="page-link" href="?page=<?php echo $page - 1 ?>">
              <i class="fas fa-chevron-left me-1"></i>Précédent
            </a>
          </li>
        <?php endif; ?>
        <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
          <li class="page-item <?php echo $i === $page ? 'active' : '' ?>">
            <a class="page-link" href="?page=<?php echo $i ?>"><?php echo $i ?></a>
          </li>
        <?php endfor; ?>
        <?php if ($page < $total_pages): ?>
          <li class="page-item">
            <a class="page-link" href="?page=<?php echo $page + 1 ?>">
              Suivant<i class="fas fa-chevron-right ms-1"></i>
            </a>
          </li>
        <?php endif; ?>
      </ul>
    </nav>
  </div>
  <?php endif; ?>
</div>
<!-- MIGRATED: Enhanced Validation Modal with character counter -->
<div class="modal fade" id="validationModal" tabindex="-1" aria-labelledby="modalTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalTitle">Confirmer l'action</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
      </div>
      <form method="POST" novalidate>
        <div class="modal-body">
          <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
          <input type="hidden" name="besoin_id" id="modalBesoinId">
          <input type="hidden" name="action" id="modalAction">
          <div class="mb-3">
            <label for="commentaire" class="form-label">
              <i class="fas fa-comment me-1"></i>Commentaire (optionnel)
            </label>
            <textarea class="form-control" 
                      id="commentaire" 
                      name="commentaire" 
                      rows="3" 
                      maxlength="500"
                      placeholder="Ajoutez un commentaire pour expliquer votre décision..."></textarea>
            <div class="form-text char-counter">Maximum 500 caractères</div>
          </div>
          <div class="alert alert-info mb-0">
            <i class="fas fa-info-circle me-2"></i>
            <span id="modalMessage"></span>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
            <i class="fas fa-times me-1"></i>Annuler
          </button>
          <button type="submit" class="btn" id="modalSubmitBtn">
            <i class="fas fa-check me-1"></i>Confirmer
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Modal event handler
document.getElementById('validationModal').addEventListener('show.bs.modal', function (event) {
    const button = event.relatedTarget;
    const besoinId = button.getAttribute('data-besoin-id');
    const action = button.getAttribute('data-action');
    const title = button.getAttribute('data-title');
    // Set form values
    document.getElementById('modalBesoinId').value = besoinId;
    document.getElementById('modalAction').value = action;
    // Update modal content
    const modalTitle = document.getElementById('modalTitle');
    const submitBtn = document.getElementById('modalSubmitBtn');
    const message = document.getElementById('modalMessage');
    const commentaire = document.getElementById('commentaire');
    if (action === 'approve') {
        modalTitle.textContent = 'Pré-Valider la Demande';
        submitBtn.className = 'btn btn-approve';
        submitBtn.innerHTML = '<i class="fas fa-check me-2"></i>Pré-Valider';
        message.textContent = 'Cette demande sera transmise au Directeur pour validation finale.';
        commentaire.placeholder = 'Commentaire de pré-validation (optionnel)...';
    } else {
        modalTitle.textContent = 'Refuser la Demande';
        submitBtn.className = 'btn btn-reject';
        submitBtn.innerHTML = '<i class="fas fa-times me-2"></i>Refuser';
        message.textContent = 'Cette demande sera refusée et le demandeur sera notifié.';
        commentaire.placeholder = 'Motif du refus (recommandé)...';
    }
    // Clear previous comment
    commentaire.value = '';
    // Reset character counter
    document.querySelector('.char-counter').textContent = 'Maximum 500 caractères';
    document.querySelector('.char-counter').className = 'form-text text-muted char-counter';
});
// MIGRATED: Enhanced character counter for textarea
document.getElementById('commentaire').addEventListener('input', function() {
    const maxLength = 500;
    const currentLength = this.value.length;
    const counter = document.querySelector('.char-counter');
    counter.textContent = `${currentLength}/${maxLength} caractères`;
    if (currentLength > maxLength * 0.9) {
        counter.className = 'form-text text-warning char-counter';
    } else if (currentLength === maxLength) {
        counter.className = 'form-text text-danger char-counter';
    } else {
        counter.className = 'form-text text-muted char-counter';
    }
});
// MIGRATED: Confirmation for validation actions
document.querySelectorAll('.btn-approve, .btn-reject').forEach(btn => {
    btn.addEventListener('click', function(e) {
        // This is handled by the modal, but we can add extra validation here
        const action = this.dataset.action;
        if (action === 'reject') {
            // Could add special handling for reject actions
        }
    });
});
// Auto-dismiss alerts after 5 seconds
document.querySelectorAll('.alert').forEach(function(alert) {
    if (alert.querySelector('.btn-close')) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    }
});
// MIGRATED: Form validation before submit
document.querySelector('form').addEventListener('submit', function(e) {
    const commentaire = document.getElementById('commentaire').value.trim();
    const action = document.getElementById('modalAction').value;
    if (action === 'reject' && !commentaire) {
        const confirmMsg = 'Vous allez rejeter cette demande sans commentaire. Il est recommandé d\'ajouter une justification. Continuer quand même ?';
        if (!confirm(confirmMsg)) {
            e.preventDefault();
            document.getElementById('commentaire').focus();
        }
    }
});
</script>
</body>
</html>