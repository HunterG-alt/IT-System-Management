<?php
$dir = __DIR__ . '/documents';

if(isset($_GET['file'])){
    $file = basename($_GET['file']); // prevent directory traversal
    $filepath = $dir . '/' . $file;

    if(file_exists($filepath)){
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $file . '"');
        header('Content-Length: ' . filesize($filepath));
        readfile($filepath);
        exit;
    } else {
        echo "File not found!";
    }
} else {
    echo "No file specified!";
}
?>