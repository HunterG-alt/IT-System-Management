<?php
require_once '../Config/session.php';
require_once '../Config/db.php';
require_login();

try {
    $pdo = Database::getInstance()->getConnection();
    
    // Enhanced query with material details
    $stmt = $pdo->prepare("
        SELECT 
            s.id_stock, 
            s.id_materiel, 
            s.quantite,
            m.reference,
            m.nom,
            m.marque,
            m.statut,
            c.nom as categorie
        FROM Stock s
        LEFT JOIN Materiel m ON s.id_materiel = m.id_materiel
        LEFT JOIN Categorie c ON m.id_categorie = c.id_categorie
        ORDER BY s.id_stock DESC
    ");
    $stmt->execute();
    $stock = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate statistics
    $total_items = count($stock);
    $total_quantity = array_sum(array_column($stock, 'quantite'));
    $low_stock = array_filter($stock, function($item) {
        return $item['quantite'] < 5;
    });
    $low_stock_count = count($low_stock);
    
} catch (PDOException $e) {
    die("Erreur lors de la récupération du stock : " . $e->getMessage());
}

// Get user info
$user_name = $_SESSION['nom'] ?? 'Utilisateur';
$user_role = $_SESSION['role'] ?? 'agent';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion du Stock - FONEA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }

        /* Animated background circles */
        body::before,
        body::after {
            content: '';
            position: fixed;
            border-radius: 50%;
            filter: blur(60px);
            opacity: 0.3;
            animation: float 20s infinite ease-in-out;
        }

        body::before {
            width: 400px;
            height: 400px;
            background: rgba(255, 255, 255, 0.3);
            top: -100px;
            right: -100px;
            animation-delay: 0s;
        }

        body::after {
            width: 350px;
            height: 350px;
            background: rgba(102, 126, 234, 0.4);
            bottom: -100px;
            left: -100px;
            animation-delay: 10s;
        }

        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
        }

        .container-main {
            max-width: 1600px;
            margin: 0 auto;
            position: relative;
            z-index: 1;
        }

        /* Glass Header */
        .glass-header {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            animation: slideDown 0.6s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .glass-header h1 {
            color: white;
            font-size: 2.5rem;
            font-weight: 700;
            margin: 0;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
        }

        .user-info {
            color: rgba(255, 255, 255, 0.95);
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-badge {
            background: rgba(255, 255, 255, 0.2);
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: 500;
        }

        /* Statistics Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            animation: fadeInUp 0.6s ease-out;
            animation-fill-mode: both;
        }

        .stat-card:nth-child(1) { animation-delay: 0.1s; }
        .stat-card:nth-child(2) { animation-delay: 0.2s; }
        .stat-card:nth-child(3) { animation-delay: 0.3s; }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.2);
            background: rgba(255, 255, 255, 0.2);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            margin-bottom: 15px;
        }

        .stat-icon.primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .stat-icon.success {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
        }

        .stat-icon.warning {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
        }

        .stat-value {
            font-size: 2.5rem;
            font-weight: 700;
            color: white;
            margin: 10px 0;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
        }

        .stat-label {
            color: rgba(255, 255, 255, 0.9);
            font-size: 1rem;
            font-weight: 500;
        }

        /* Glass Table Container */
        .glass-table-container {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 24px;
            padding: 30px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            animation: fadeIn 0.8s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .table-header h2 {
            color: white;
            font-size: 1.8rem;
            font-weight: 600;
            margin: 0;
        }

        .search-box {
            position: relative;
            width: 300px;
        }

        .search-box input {
            width: 100%;
            padding: 12px 45px 12px 20px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-radius: 50px;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            font-size: 0.95rem;
            transition: all 0.3s ease;
        }

        .search-box input::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        .search-box input:focus {
            outline: none;
            border-color: rgba(255, 255, 255, 0.5);
            background: rgba(255, 255, 255, 0.15);
        }

        .search-box i {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.7);
        }

        /* Table Styles */
        .table-responsive {
            border-radius: 16px;
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }

        thead {
            background: rgba(255, 255, 255, 0.2);
        }

        th {
            padding: 18px 20px;
            text-align: left;
            font-weight: 600;
            color: white;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 1px;
        }

        tbody tr {
            background: rgba(255, 255, 255, 0.08);
            transition: all 0.3s ease;
        }

        tbody tr:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: scale(1.01);
        }

        td {
            padding: 18px 20px;
            color: white;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            font-size: 0.95rem;
        }

        /* Badges */
        .badge-quantity {
            display: inline-block;
            padding: 6px 14px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .badge-high {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
        }

        .badge-medium {
            background: linear-gradient(135deg, #ffd89b 0%, #19547b 100%);
            color: white;
        }

        .badge-low {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
        }

        .status-badge {
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-block;
        }

        .status-disponible {
            background: rgba(16, 185, 129, 0.3);
            color: #10b981;
            border: 1px solid rgba(16, 185, 129, 0.5);
        }

        .status-en-utilisation {
            background: rgba(59, 130, 246, 0.3);
            color: #3b82f6;
            border: 1px solid rgba(59, 130, 246, 0.5);
        }

        .status-en-maintenance {
            background: rgba(245, 158, 11, 0.3);
            color: #f59e0b;
            border: 1px solid rgba(245, 158, 11, 0.5);
        }

        .status-hors-service {
            background: rgba(239, 68, 68, 0.3);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.5);
        }

        /* Action Buttons */
        .btn-glass {
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            padding: 8px 12px;
            border-radius: 10px;
            transition: all 0.3s ease;
            cursor: pointer;
            margin: 0 3px;
        }

        .btn-glass:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }

        .btn-back {
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            padding: 12px 24px;
            border-radius: 50px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            font-weight: 600;
            transition: all 0.3s ease;
            margin-bottom: 20px;
        }

        .btn-back:hover {
            background: rgba(255, 255, 255, 0.3);
            color: white;
            transform: translateX(-5px);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 80px 20px;
            color: white;
        }

        .empty-state i {
            font-size: 5rem;
            margin-bottom: 25px;
            opacity: 0.6;
        }

        .empty-state h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .empty-state p {
            opacity: 0.8;
            font-size: 1.1rem;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .glass-header h1 {
                font-size: 1.8rem;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .table-header {
                flex-direction: column;
                gap: 15px;
                align-items: stretch;
            }

            .search-box {
                width: 100%;
            }

            table {
                font-size: 0.85rem;
            }

            th, td {
                padding: 12px 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container-main">
        <a href="mini_dashboard.php" class="btn-back">
            <i class="fas fa-arrow-left"></i>
            Retour au Dashboard
        </a>

        <div class="glass-header">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                <div>
                    <h1><i class="fas fa-boxes me-3"></i>Gestion du Stock</h1>
                </div>
                <div class="user-info">
                    <i class="fas fa-user-circle"></i>
                    <span><?= htmlspecialchars($user_name) ?></span>
                    <span class="user-badge"><?= htmlspecialchars($user_role) ?></span>
                </div>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon primary">
                    <i class="fas fa-layer-group"></i>
                </div>
                <div class="stat-value"><?= $total_items ?></div>
                <div class="stat-label">Articles en Stock</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon success">
                    <i class="fas fa-cubes"></i>
                </div>
                <div class="stat-value"><?= $total_quantity ?></div>
                <div class="stat-label">Quantité Totale</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon warning">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div class="stat-value"><?= $low_stock_count ?></div>
                <div class="stat-label">Stock Faible</div>
            </div>
        </div>

        <div class="glass-table-container">
            <div class="table-header">
                <h2><i class="fas fa-inventory me-2"></i>Inventaire</h2>
                <div class="search-box">
                    <input type="text" id="searchInput" placeholder="Rechercher un article...">
                    <i class="fas fa-search"></i>
                </div>
            </div>

            <?php if (!empty($stock)): ?>
                <div class="table-responsive">
                    <table id="stockTable">
                        <thead>
                            <tr>
                                <th><i class="fas fa-hashtag me-2"></i>ID</th>
                                <th><i class="fas fa-barcode me-2"></i>Référence</th>
                                <th><i class="fas fa-box me-2"></i>Désignation</th>
                                <th><i class="fas fa-tag me-2"></i>Marque</th>
                                <th><i class="fas fa-folder me-2"></i>Catégorie</th>
                                <th><i class="fas fa-sort-numeric-up me-2"></i>Quantité</th>
                                <th><i class="fas fa-info-circle me-2"></i>Statut</th>
                                <th><i class="fas fa-cog me-2"></i>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($stock as $s): ?>
                                <tr>
                                    <td><strong>#<?= htmlspecialchars($s['id_stock']) ?></strong></td>
                                    <td><?= htmlspecialchars($s['reference'] ?? 'N/A') ?></td>
                                    <td><?= htmlspecialchars($s['nom'] ?? 'N/A') ?></td>
                                    <td><?= htmlspecialchars($s['marque'] ?? '-') ?></td>
                                    <td><?= htmlspecialchars($s['categorie'] ?? 'Non catégorisé') ?></td>
                                    <td>
                                        <?php 
                                            $qty = $s['quantite'];
                                            $badgeClass = 'badge-high';
                                            if ($qty < 5) $badgeClass = 'badge-low';
                                            elseif ($qty < 10) $badgeClass = 'badge-medium';
                                        ?>
                                        <span class="badge-quantity <?= $badgeClass ?>">
                                            <?= $qty ?> unités
                                        </span>
                                    </td>
                                    <td>
                                        <?php 
                                            $statut = strtolower(str_replace([' ', 'é'], ['-', 'e'], $s['statut'] ?? 'disponible'));
                                        ?>
                                        <span class="status-badge status-<?= $statut ?>">
                                            <?= htmlspecialchars($s['statut'] ?? 'Disponible') ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn-glass" title="Voir détails">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn-glass" title="Modifier">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-box-open"></i>
                    <h3>Aucun Stock Disponible</h3>
                    <p>Le stock est actuellement vide. Ajoutez des articles pour commencer.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function() {
            const searchValue = this.value.toLowerCase();
            const tableRows = document.querySelectorAll('#stockTable tbody tr');
            
            tableRows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchValue) ? '' : 'none';
            });
        });

        // Add smooth entrance animation to table rows
        document.addEventListener('DOMContentLoaded', function() {
            const rows = document.querySelectorAll('tbody tr');
            rows.forEach((row, index) => {
                row.style.animation = `fadeInUp 0.5s ease-out ${index * 0.05}s both`;
            });
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>