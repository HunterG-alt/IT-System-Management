<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications - FONEA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            color: #1a1a1a;
            min-height: 100vh;
        }
        .container-fluid {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }
        /* Header */
        .page-header {
            background: #ffffff;
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid #e2e8f0;
        }
        .page-title {
            font-size: 32px;
            font-weight: 700;
            color: #4c1d95;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .page-subtitle {
            font-size: 16px;
            color: #6366f1;
            margin: 0;
        }
        .header-actions {
            display: flex;
            gap: 15px;
            align-items: center;
        }
        .btn-mark-all {
            background: linear-gradient(135deg, #8b5cf6, #7c3aed);
            border: none;
            color: #ffffff;
            padding: 12px 24px;
            border-radius: 12px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        .btn-mark-all:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(139, 92, 246, 0.3);
            color: #ffffff;
        }
        .btn-back {
            background: #f8fafc;
            border: 2px solid #e2e8f0;
            color: #64748b;
            padding: 12px 24px;
            border-radius: 12px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        .btn-back:hover {
            background: #e2e8f0;
            color: #4c1d95;
            text-decoration: none;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: #ffffff;
            border-radius: 16px;
            padding: 25px;
            text-align: center;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid #e2e8f0;
            transition: all 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
        }
        .stat-value {
            font-size: 28px;
            font-weight: 700;
            color: #4c1d95;
            margin-bottom: 5px;
        }
        .stat-label {
            font-size: 14px;
            color: #6366f1;
            font-weight: 500;
        }
        .stat-unread .stat-value { color: #3b82f6; }
        .stat-read .stat-value { color: #10b981; }
        .stat-today .stat-value { color: #f59e0b; }
        /* Notifications List */
        .notifications-container {
            background: #ffffff;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid #e2e8f0;
        }
        .notifications-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f1f5f9;
        }
        .notifications-title {
            font-size: 20px;
            font-weight: 600;
            color: #4c1d95;
        }
        .notification-item {
            display: flex;
            align-items: flex-start;
            gap: 20px;
            padding: 20px;
            border-radius: 16px;
            margin-bottom: 15px;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }
        .notification-item:hover {
            background: #f8fafc;
            transform: translateX(5px);
        }
        .notification-item.unread {
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            border-color: #bae6fd;
        }
        .notification-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            font-size: 18px;
            flex-shrink: 0;
        }
        .notification-content {
            flex: 1;
        }
        .notification-type {
            font-size: 16px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 5px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .notification-message {
            color: #64748b;
            margin-bottom: 8px;
            line-height: 1.5;
        }
        .notification-time {
            font-size: 12px;
            color: #94a3b8;
            font-weight: 500;
        }
        .notification-actions {
            display: flex;
            flex-direction: column;
            gap: 8px;
            align-items: flex-end;
        }
        .badge-unread {
            background: linear-gradient(135deg, #3b82f6, #1d4ed8);
            color: #ffffff;
            font-size: 11px;
            padding: 4px 8px;
            border-radius: 6px;
            font-weight: 600;
        }
        .btn-mark-read {
            background: linear-gradient(135deg, #10b981, #059669);
            border: none;
            color: #ffffff;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn-mark-read:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
            color: #ffffff;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #64748b;
        }
        .empty-icon {
            font-size: 64px;
            color: #cbd5e1;
            margin-bottom: 20px;
        }
        .empty-title {
            font-size: 20px;
            font-weight: 600;
            color: #475569;
            margin-bottom: 8px;
        }
        .empty-text {
            color: #64748b;
        }
        
        .alert {
            border: none;
            border-radius: 12px;
            padding: 16px 20px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        .alert-success {
            background: linear-gradient(135deg, #d1fae5, #a7f3d0);
            color: #065f46;
        }
        .alert-danger {
            background: linear-gradient(135deg, #fee2e2, #fecaca);
            color: #991b1b;
        }
        /* Responsive */
        @media (max-width: 768px) {
            .container-fluid {
                padding: 20px 15px;
            }
            .page-header {
                padding: 20px;
            }
            .page-title {
                font-size: 24px;
            }
            .header-actions {
                flex-direction: column;
                align-items: stretch;
                gap: 10px;
            }
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .notification-item {
                flex-direction: column;
                text-align: center;
            }
            .notification-actions {
                align-items: center;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        
        <div class="page-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="page-title">
                        <i class="fas fa-bell"></i>
                        Mes Notifications
                    </h1>
                    <p class="page-subtitle">Bonjour <?= htmlspecialchars($user_name ?? 'Utilisateur') ?>, voici vos dernières notifications</p>
                </div>
                <div class="header-actions">
                    <?php if (!empty($notifications) && ($stats['unread'] ?? 0) > 0): ?>
                    <form method="post" style="margin: 0;">
                        <input type="hidden" name="action" value="mark_all_read">
                        <button type="submit" class="btn-mark-all">
                            <i class="fas fa-check-double me-2"></i>
                            Tout marquer comme lu
                        </button>
                    </form>
                    <?php endif; ?>
                    <a href="<?= htmlspecialchars($dashboard_page ?? 'dashboard.php') ?>" class="btn-back">
                        <i class="fas fa-arrow-left me-2"></i>
                        Retour
                    </a>
                </div>
            </div>
        </div>
        <!-- Alert Messages -->
        <?php if (isset($_GET['success'])): ?>
            <?php if ($_GET['success'] === 'all_read'): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i>
                    Toutes les notifications ont été marquées comme lues.
                </div>
            <?php elseif ($_GET['success'] === 'marked_read'): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check me-2"></i>
                    Notification marquée comme lue.
                </div>
            <?php endif; ?>
        <?php endif; ?>
        <?php if (isset($_GET['error']) && $_GET['error'] === 'mark_failed'): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i>
                Erreur lors du marquage de la notification.
            </div>
        <?php endif; ?>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value"><?= (int)($stats['total'] ?? count($notifications ?? [])) ?></div>
                <div class="stat-label">Total</div>
            </div>
            <div class="stat-card stat-unread">
                <div class="stat-value"><?= (int)($stats['unread'] ?? 0) ?></div>
                <div class="stat-label">Non lues</div>
            </div>
            <div class="stat-card stat-read">
                <div class="stat-value"><?= (int)($stats['read'] ?? 0) ?></div>
                <div class="stat-label">Lues</div>
            </div>
            <div class="stat-card stat-today">
                <div class="stat-value"><?= (int)($stats['today'] ?? 0) ?></div>
                <div class="stat-label">Aujourd'hui</div>
            </div>
        </div>
        
        <div class="notifications-container">
            <div class="notifications-header">
                <h3 class="notifications-title">
                    <i class="fas fa-list me-2"></i>
                    Liste des notifications
                </h3>
            </div>
            <?php if (empty($notifications)): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-bell-slash"></i>
                    </div>
                    <h4 class="empty-title">Aucune notification</h4>
                    <p class="empty-text">Vous n'avez aucune notification pour le moment.</p>
                </div>
            <?php else: ?>
                <?php foreach ($notifications as $notification): ?>
                    <div class="notification-item <?= (int)$notification['is_read'] === 0 ? 'unread' : '' ?>">
                        <div class="notification-icon" style="background: <?= getNotificationColor($notification['type']) ?>;">
                            <i class="<?= getNotificationIcon($notification['type']) ?>"></i>
                        </div>
                        <div class="notification-content">
                            <div class="notification-type">
                                <?= formatNotificationType($notification['type']) ?>
                                <?php if ((int)$notification['is_read'] === 0): ?>
                                    <span class="badge-unread">Nouveau</span>
                                <?php endif; ?>
                            </div>
                            <div class="notification-message">
                                <?= htmlspecialchars($notification['message']) ?>
                            </div>
                            <div class="notification-time">
                                <i class="fas fa-clock me-1"></i>
                                <?= date('d/m/Y à H:i', strtotime($notification['created_at'])) ?>
                            </div>
                        </div>
                        <?php if ((int)$notification['is_read'] === 0): ?>
                        <div class="notification-actions">
                            <form method="post" style="margin: 0;">
                                <input type="hidden" name="action" value="mark_read">
                                <input type="hidden" name="id" value="<?= (int)$notification['id'] ?>">
                                <button type="submit" class="btn-mark-read">
                                    <i class="fas fa-check me-1"></i>
                                    Marquer comme lu
                                </button>
                            </form>
                        </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.opacity = '0';
                    setTimeout(() => {
                        alert.remove();
                    }, 300);
                }, 3000);
            });
        });
        
        document.querySelectorAll('form button').forEach(button => {
            button.addEventListener('click', function() {
                this.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Chargement...';
                this.disabled = true;
            });
        });
    </script>
</body>
</html>