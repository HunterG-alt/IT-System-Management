<?php
require_once '../Config/db.php';
// Note: require_login() function needs to be defined somewhere
// require_once '../modules/auth.php'; // Uncomment if you have an auth module
// Initialize variables
$errors = [];
$success = "";
$pdo = null;
try {
    // Get database connection
    if (class_exists('Database')) {
        $pdo = Database::getInstance()->getConnection();
    } else {
        // Fallback to global $pdo if Database class doesn't exist
        global $pdo;
        if (!$pdo) {
            throw new Exception("Database connection not available");
        }
    }
} catch (Exception $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}
// Authentication check - implement based on your auth system
function checkAuth() {
    if (!isset($_SESSION['user_id']) && !isset($_SESSION['logged_in'])) {
        header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
        exit();
    }
}
checkAuth();
// Get current user info
$current_user = $_SESSION['user_id'] ?? 1; // Default fallback
// Retrieve suppliers
$fournisseurs = [];
try {
    $stmt = $pdo->query("SELECT * FROM fournisseur ORDER BY nom ASC");
    $fournisseurs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = "Erreur lors du chargement des fournisseurs : " . $e->getMessage();
}
// Retrieve materials
$materiels = [];
try {
    $stmt = $pdo->query("SELECT * FROM materiel ORDER BY nom ASC");
    $materiels = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = "Erreur lors du chargement des matériels : " . $e->getMessage();
}
// Handle order addition
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $id_fournisseur = trim($_POST['id_fournisseur'] ?? '');
    $id_materiel = trim($_POST['id_materiel'] ?? '');
    $quantite = trim($_POST['quantite'] ?? '');
    $date_commande = trim($_POST['date_commande'] ?? '');
    $prix_unitaire = trim($_POST['prix_unitaire'] ?? '0');
    $statut = 'en_attente'; // Default status
    // Validation
    if (empty($id_fournisseur) || !is_numeric($id_fournisseur)) {
        $errors[] = "Veuillez sélectionner un fournisseur valide.";
    }
    if (empty($id_materiel) || !is_numeric($id_materiel)) {
        $errors[] = "Veuillez sélectionner un matériel valide.";
    }
    if (empty($quantite) || !is_numeric($quantite) || $quantite <= 0) {
        $errors[] = "La quantité doit être un nombre positif.";
    }
    if (empty($date_commande)) {
        $errors[] = "La date de commande est requise.";
    }
    if (!empty($prix_unitaire) && (!is_numeric($prix_unitaire) || $prix_unitaire < 0)) {
        $errors[] = "Le prix unitaire doit être un nombre positif.";
    }
    // Verify that supplier and material exist
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM fournisseur WHERE id = :id");
            $stmt->execute([':id' => $id_fournisseur]);
            if ($stmt->fetchColumn() == 0) {
                $errors[] = "Fournisseur introuvable.";
            }
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM materiel WHERE id = :id");
            $stmt->execute([':id' => $id_materiel]);
            if ($stmt->fetchColumn() == 0) {
                $errors[] = "Matériel introuvable.";
            }
        } catch (PDOException $e) {
            $errors[] = "Erreur de validation : " . $e->getMessage();
        }
    }
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("
                INSERT INTO commande (id_fournisseur, id_materiel, quantite, prix_unitaire, date_commande, statut, created_by, created_at) 
                VALUES (:fournisseur, :materiel, :quantite, :prix_unitaire, :date_commande, :statut, :created_by, NOW())
            ");
            $result = $stmt->execute([
                ':fournisseur' => $id_fournisseur,
                ':materiel' => $id_materiel,
                ':quantite' => $quantite,
                ':prix_unitaire' => $prix_unitaire,
                ':date_commande' => $date_commande,
                ':statut' => $statut,
                ':created_by' => $current_user
            ]);
            if ($result) {
                $pdo->commit();
                $_SESSION['message'] = "Commande ajoutée avec succès.";
                $_SESSION['message_type'] = "success";
                header('Location: ' . $_SERVER['PHP_SELF']);
                exit();
            } else {
                throw new Exception("Erreur lors de l'insertion");
            }
        } catch (PDOException $e) {
            $pdo->rollBack();
            $errors[] = "Erreur lors de l'ajout de la commande : " . $e->getMessage();
        }
    }
}
// Handle order deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $id_commande = (int)($_POST['id_commande'] ?? 0);
    if ($id_commande > 0) {
        try {
            $stmt = $pdo->prepare("DELETE FROM commande WHERE id = :id");
            $result = $stmt->execute([':id' => $id_commande]);
            if ($result) {
                $_SESSION['message'] = "Commande supprimée avec succès.";
                $_SESSION['message_type'] = "success";
            } else {
                $_SESSION['message'] = "Erreur lors de la suppression.";
                $_SESSION['message_type'] = "danger";
            }
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit();
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de la suppression : " . $e->getMessage();
        }
    }
}
// Retrieve orders with pagination
$page = (int)($_GET['page'] ?? 1);
$limit = 10;
$offset = ($page - 1) * $limit;
$commandes = [];
$total_commandes = 0;
try {
    // Get total count
    $stmt = $pdo->query("SELECT COUNT(*) FROM commande");
    $total_commandes = $stmt->fetchColumn();
    // Get orders with details
    $stmt = $pdo->prepare("
        SELECT c.id, c.quantite, c.prix_unitaire, c.date_commande, c.statut,
               f.nom AS fournisseur, f.email AS fournisseur_email,
               m.nom AS materiel, m.description AS materiel_description
        FROM commande c
        LEFT JOIN fournisseur f ON c.id_fournisseur = f.id
        LEFT JOIN materiel m ON c.id_materiel = m.id
        ORDER BY c.id DESC 
        LIMIT :limit OFFSET :offset
    ");
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $commandes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = "Erreur lors du chargement des commandes : " . $e->getMessage();
}
$total_pages = ceil($total_commandes / $limit);
// Get session messages
if (isset($_SESSION['message'])) {
    $success = $_SESSION['message'];
    $message_type = $_SESSION['message_type'] ?? 'info';
    unset($_SESSION['message'], $_SESSION['message_type']);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Commandes</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card {
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .form-section {
            background: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 30px;
        }
        .status-badge {
            font-size: 0.85em;
        }
        .table th {
            background: #f8f9fa;
            border-top: none;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1><i class="fas fa-shopping-cart"></i> Gestion des Commandes</h1>
            <a href="../dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left"></i> Retour
            </a>
        </div>
        <!-- Messages -->
        <?php if (!empty($success)): ?>
            <div class="alert alert-<?= $message_type ?? 'success' ?> alert-dismissible fade show" role="alert">
                <?= htmlspecialchars($success) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?= implode('<br>', array_map('htmlspecialchars', $errors)) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <!-- Add Order Form -->
        <div class="form-section">
            <h4 class="mb-3"><i class="fas fa-plus-circle"></i> Nouvelle Commande</h4>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="add">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="id_fournisseur" class="form-label">Fournisseur *</label>
                        <select id="id_fournisseur" name="id_fournisseur" class="form-select" required>
                            <option value="">-- Sélectionner un fournisseur --</option>
                            <?php foreach ($fournisseurs as $f): ?>
                                <option value="<?= $f['id'] ?>" <?= (isset($_POST['id_fournisseur']) && $_POST['id_fournisseur'] == $f['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($f['nom']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback">Veuillez sélectionner un fournisseur.</div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="id_materiel" class="form-label">Matériel *</label>
                        <select id="id_materiel" name="id_materiel" class="form-select" required>
                            <option value="">-- Sélectionner un matériel --</option>
                            <?php foreach ($materiels as $m): ?>
                                <option value="<?= $m['id'] ?>" <?= (isset($_POST['id_materiel']) && $_POST['id_materiel'] == $m['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($m['nom']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback">Veuillez sélectionner un matériel.</div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label for="quantite" class="form-label">Quantité *</label>
                        <input type="number" id="quantite" name="quantite" class="form-control" 
                               min="1" step="1" value="<?= htmlspecialchars($_POST['quantite'] ?? '') ?>" required>
                        <div class="invalid-feedback">Veuillez saisir une quantité valide.</div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="prix_unitaire" class="form-label">Prix unitaire (€)</label>
                        <input type="number" id="prix_unitaire" name="prix_unitaire" class="form-control" 
                               min="0" step="0.01" value="<?= htmlspecialchars($_POST['prix_unitaire'] ?? '') ?>" 
                               placeholder="0.00">
                        <div class="form-text">Optionnel</div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="date_commande" class="form-label">Date de commande *</label>
                        <input type="date" id="date_commande" name="date_commande" class="form-control" 
                               value="<?= htmlspecialchars($_POST['date_commande'] ?? date('Y-m-d')) ?>" required>
                        <div class="invalid-feedback">Veuillez saisir une date valide.</div>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Ajouter la Commande
                    </button>
                    <button type="reset" class="btn btn-outline-secondary">
                        <i class="fas fa-undo"></i> Réinitialiser
                    </button>
                </div>
            </form>
        </div>
        <!-- Orders List -->
        <div class="card">
            <div class="card-header bg-light">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-list"></i> Liste des Commandes</h5>
                    <span class="badge bg-primary"><?= $total_commandes ?> commande(s)</span>
                </div>
            </div>
            <div class="card-body">
                <?php if (empty($commandes)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-shopping-cart fa-3x text-muted mb-3"></i>
                        <p class="text-muted">Aucune commande enregistrée pour le moment.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover align-middle">
                            <thead class="table-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Fournisseur</th>
                                    <th>Matériel</th>
                                    <th>Quantité</th>
                                    <th>Prix unitaire</th>
                                    <th>Total</th>
                                    <th>Date</th>
                                    <th>Statut</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($commandes as $c): ?>
                                    <?php $total = $c['quantite'] * ($c['prix_unitaire'] ?? 0); ?>
                                    <tr>
                                        <td><strong><?= $c['id'] ?></strong></td>
                                        <td>
                                            <div>
                                                <strong><?= htmlspecialchars($c['fournisseur'] ?? 'N/A') ?></strong>
                                                <?php if (!empty($c['fournisseur_email'])): ?>
                                                    <br><small class="text-muted"><?= htmlspecialchars($c['fournisseur_email']) ?></small>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div>
                                                <strong><?= htmlspecialchars($c['materiel'] ?? 'N/A') ?></strong>
                                                <?php if (!empty($c['materiel_description'])): ?>
                                                    <br><small class="text-muted"><?= htmlspecialchars(substr($c['materiel_description'], 0, 50)) ?>...</small>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td><span class="badge bg-info"><?= $c['quantite'] ?></span></td>
                                        <td><?= $c['prix_unitaire'] ? number_format($c['prix_unitaire'], 2) . ' €' : '-' ?></td>
                                        <td><strong><?= $total > 0 ? number_format($total, 2) . ' €' : '-' ?></strong></td>
                                        <td><?= date("d/m/Y", strtotime($c['date_commande'])) ?></td>
                                        <td>
                                            <?php
                                            $status_class = match($c['statut']) {
                                                'en_attente' => 'bg-warning text-dark',
                                                'confirmee' => 'bg-info',
                                                'livree' => 'bg-success',
                                                'annulee' => 'bg-danger',
                                                default => 'bg-secondary'
                                            };
                                            ?>
                                            <span class="badge status-badge <?= $status_class ?>">
                                                <?= ucfirst($c['statut']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <button type="button" class="btn btn-sm btn-outline-primary" 
                                                        onclick="editCommande(<?= $c['id'] ?>)" title="Modifier">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button type="button" class="btn btn-sm btn-outline-danger" 
                                                        onclick="deleteCommande(<?= $c['id'] ?>, '<?= htmlspecialchars($c['materiel']) ?>')" 
                                                        title="Supprimer">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <nav class="mt-4">
                            <ul class="pagination justify-content-center">
                                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                                    <a class="page-link" href="?page=<?= $page - 1 ?>">Précédent</a>
                                </li>
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                        <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                                    </li>
                                <?php endfor; ?>
                                <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
                                    <a class="page-link" href="?page=<?= $page + 1 ?>">Suivant</a>
                                </li>
                            </ul>
                        </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
   // Updated JavaScript functions for commande.php
<script>
    // Form validation
    (function() {
        'use strict';
        window.addEventListener('load', function() {
            var forms = document.getElementsByClassName('needs-validation');
            Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();
    // Edit order function - Updated to redirect to edit page
    function editCommande(id) {
        window.location.href = 'edit_commande.php?id=' + id;
    }
    // Delete order function - Updated to redirect to delete confirmation page
    function deleteCommande(id, materiel) {
        if (confirm('Êtes-vous sûr de vouloir supprimer la commande #' + id + ' (' + materiel + ') ?\n\nCette action vous dirigera vers une page de confirmation.')) {
            window.location.href = 'delete_commande.php?id=' + id;
        }
    }
    // Quick delete function for immediate deletion (alternative approach)
    function quickDeleteCommande(id, materiel) {
        if (confirm('SUPPRESSION RAPIDE: Êtes-vous sûr de vouloir supprimer immédiatement la commande #' + id + ' (' + materiel + ') ?\n\nCette action est irréversible !')) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'delete';
            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'id_commande';
            idInput.value = id;
            form.appendChild(actionInput);
            form.appendChild(idInput);
            document.body.appendChild(form);
            form.submit();
        }
    }
    // Status update function (for quick status changes)
    function updateStatus(id, currentStatus) {
        const statuses = {
            'en_attente': 'En attente',
            'confirmee': 'Confirmée', 
            'livree': 'Livrée',
            'annulee': 'Annulée'
        };
        let options = '';
        for (let [key, label] of Object.entries(statuses)) {
            const selected = key === currentStatus ? ' selected' : '';
            options += `<option value="${key}"${selected}>${label}</option>`;
        }
        const newStatus = prompt(`Changer le statut de la commande #${id}:\n\nChoisissez un nouveau statut:\n- en_attente (En attente)\n- confirmee (Confirmée)\n- livree (Livrée)\n- annulee (Annulée)\n\nEntrez le code du statut:`, currentStatus);
        if (newStatus && newStatus !== currentStatus && statuses[newStatus]) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'update_status';
            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'id_commande';
            idInput.value = id;
            const statusInput = document.createElement('input');
            statusInput.type = 'hidden';
            statusInput.name = 'new_status';
            statusInput.value = newStatus;
            form.appendChild(actionInput);
            form.appendChild(idInput);
            form.appendChild(statusInput);
            document.body.appendChild(form);
            form.submit();
        }
    }
    // Add keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl+N for new order (focus on supplier select)
        if (e.ctrlKey && e.key === 'n') {
            e.preventDefault();
            document.getElementById('id_fournisseur').focus();
        }
        // Escape to clear form
        if (e.key === 'Escape') {
            const form = document.querySelector('form[method="POST"]');
            if (form && confirm('Effacer le formulaire ?')) {
                form.reset();
                document.getElementById('id_fournisseur').focus();
            }
        }
    });
    // Auto-calculate total when price or quantity changes
    function calculateTotal() {
        const quantite = parseFloat(document.getElementById('quantite').value) || 0;
        const prixUnitaire = parseFloat(document.getElementById('prix_unitaire').value) || 0;
        const total = quantite * prixUnitaire;
        // Display total if both values are present
        let totalDisplay = document.getElementById('total-display');
        if (!totalDisplay) {
            totalDisplay = document.createElement('div');
            totalDisplay.id = 'total-display';
            totalDisplay.className = 'mt-2 text-info';
            document.getElementById('prix_unitaire').parentNode.appendChild(totalDisplay);
        }
        if (total > 0) {
            totalDisplay.innerHTML = `<small><i class="fas fa-calculator"></i> Total estimé: <strong>${total.toFixed(2)} €</strong></small>`;
        } else {
            totalDisplay.innerHTML = '';
        }
    }
    // Add event listeners for auto-calculation
    window.addEventListener('load', function() {
        const quantiteInput = document.getElementById('quantite');
        const prixInput = document.getElementById('prix_unitaire');
        if (quantiteInput && prixInput) {
            quantiteInput.addEventListener('input', calculateTotal);
            prixInput.addEventListener('input', calculateTotal);
            // Calculate on page load if values are present
            calculateTotal();
        }
    });
</script>
</body>
</html>