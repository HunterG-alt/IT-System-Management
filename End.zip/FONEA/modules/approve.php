<?php
require_once __DIR__ . '/../Config/session.php';
require_login();
if ($_SESSION['role'] !== ROLE_DIRECTEUR) die('Accès refusé');
$pdo = Database::getInstance()->getConnection();
$success = $error = '';
// --- Compteurs en session ---
if (!isset($_SESSION['stats'])) {
    $_SESSION['stats'] = ['valide' => 0, 'rejete' => 0];
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_stats'])) {
    $_SESSION['stats'] = ['valide' => 0, 'rejete' => 0];
    $success = "Statistiques remises à zéro.";
}
// Traitement POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_besoin'], $_POST['statut_validation'])) {
    $id_besoin = (int) $_POST['id_besoin'];
    $statut = $_POST['statut_validation'] === 'valider' ? 'valider' : 'rejeter';
    $commentaire = trim($_POST['commentaire'] ?? '');
    try {
        $pdo->beginTransaction();
        // Vérifier que le besoin existe et est au bon statut
        $stmt = $pdo->prepare("SELECT statut FROM etat_de_besoin WHERE id_besoin = ?");
        $stmt->execute([$id_besoin]);
        $current_status = $stmt->fetchColumn();
        if (!$current_status) {
            throw new Exception("État de besoin introuvable.");
        }
        if ($current_status !== 'pre_validee') {
            throw new Exception("Ce besoin ne peut pas être traité dans son état actuel.");
        }
        // Déterminer nouveau statut selon le schéma de la DB
        $new_statut = $statut === 'valider' ? 'validee_directeur' : 'refusee_directeur';
        // Mise à jour statut dans etat_de_besoin
        $stmt = $pdo->prepare("UPDATE etat_de_besoin SET statut = ?, date_maj = NOW() WHERE id_besoin = ?");
        $stmt->execute([$new_statut, $id_besoin]);
        // Enregistrer dans validation_direction
        $stmt = $pdo->prepare("
            INSERT INTO validation_direction (id_besoin, id_directeur, statut_validation, commentaire) 
            VALUES (?, ?, ?, ?)
        ");
        $validation_status = $statut === 'valider' ? 'valide' : 'refuse';
        $stmt->execute([$id_besoin, $_SESSION['user_id'], $validation_status, $commentaire]);
        // Récupérer l'agent demandeur pour notification
        $stmt = $pdo->prepare("SELECT id_agent FROM etat_de_besoin WHERE id_besoin = ?");
        $stmt->execute([$id_besoin]);
        $agent_id = $stmt->fetchColumn();
        // Créer notification pour l'agent demandeur
        if ($agent_id) {
            $message = $statut === 'valider' 
                ? "Votre demande a été approuvée par la direction" 
                : "Votre demande a été rejetée par la direction";
            if ($commentaire) {
                $message .= ". Commentaire: " . $commentaire;
            }
            $stmt = $pdo->prepare("
                INSERT INTO notifications (id_agent, id_besoin, message) 
                VALUES (?, ?, ?)
            ");
            $stmt->execute([$agent_id, $id_besoin, $message]);
        }
        $pdo->commit();
        $success = "Décision enregistrée avec succès.";
        // Mettre à jour les statistiques
        $_SESSION['stats'][$statut === 'valider' ? 'valide' : 'rejete']++;
    } catch (Exception $e) {
        $pdo->rollback();
        $error = "Erreur : " . $e->getMessage();
    }
}
// Lister les besoins à valider (statut 'pre_validee')
$stmt = $pdo->query("
    SELECT eb.*, a.nom, a.prenom
    FROM etat_de_besoin eb
    JOIN agents a ON eb.id_agent = a.id_agent
    WHERE eb.statut = 'pre_validee'
    ORDER BY eb.date_soumission ASC
");
$besoins = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Fonction pour badge
function badgeClass($statut) {
    return match($statut) {
        'validee_directeur' => 'success',
        'refusee_directeur' => 'danger',
        'pre_validee' => 'warning',
        'en_attente' => 'secondary',
        'en_analyse_technique' => 'info',
        'en_acquisition' => 'primary',
        default => 'secondary',
    };
}
// Fonction pour libellé du statut
function getStatusLabel($statut) {
    return match($statut) {
        'pre_validee' => 'Pré-validé',
        'validee_directeur' => 'Validé Directeur',
        'refusee_directeur' => 'Refusé Directeur',
        'en_attente' => 'En Attente',
        'en_analyse_technique' => 'Analyse Technique',
        'en_acquisition' => 'En Acquisition',
        default => ucfirst(str_replace('_', ' ', $statut)),
    };
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Approbation États de Besoin</title>
<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
<style>
.card { 
    margin-bottom: 20px; 
    transition: box-shadow 0.2s ease;
}
.card:hover {
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}
.card-body { 
    display: flex; 
    flex-direction: column; 
    gap: 15px; 
}
.actions { 
    display: flex; 
    gap: 10px; 
    flex-wrap: wrap; 
    align-items: flex-start;
}
.actions textarea { 
    flex: 1; 
    min-width: 300px;
}
.actions .btn-group {
    flex-shrink: 0;
}
.stats-card {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border: none;
}
.info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 10px;
    margin-bottom: 15px;
}
.info-item {
    padding: 8px;
    background-color: #f8f9fa;
    border-radius: 4px;
    border-left: 3px solid #007bff;
}
</style>
</head>
<body>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-check-circle me-2"></i>Approbation États de Besoin</h2>
        <div class="badge bg-primary fs-6"><?php echo count($besoins); ?> en attente</div>
    </div>
    <!-- Statistiques -->
    <div class="card stats-card mb-4">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex gap-4">
                    <div class="text-center">
                        <div class="h4 text-success mb-0"><?php echo $_SESSION['stats']['valide']; ?></div>
                        <small class="text-muted">Validés</small>
                    </div>
                    <div class="text-center">
                        <div class="h4 text-danger mb-0"><?php echo $_SESSION['stats']['rejete']; ?></div>
                        <small class="text-muted">Rejetés</small>
                    </div>
                    <div class="text-center">
                        <div class="h4 text-primary mb-0"><?php echo $_SESSION['stats']['valide'] + $_SESSION['stats']['rejete']; ?></div>
                        <small class="text-muted">Total traités</small>
                    </div>
                </div>
                <form method="POST" style="margin: 0;">
                    <button type="submit" name="reset_stats" class="btn btn-outline-warning btn-sm" 
                            onclick="return confirm('Remettre les statistiques à zéro ?')">
                        <i class="fas fa-redo me-1"></i>Reset
                    </button>
                </form>
            </div>
        </div>
    </div>
    <!-- Messages -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <!-- Liste des besoins -->
    <?php if (empty($besoins)): ?>
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">Aucun état de besoin en attente d'approbation</h5>
                <p class="text-muted">Tous les états de besoin ont été traités ou aucune demande n'a été pré-validée.</p>
            </div>
        </div>
    <?php else: ?>
        <?php foreach ($besoins as $besoin): ?>
            <div class="card shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-0"><?php echo htmlspecialchars($besoin['designation_materiel']); ?></h6>
                        <small class="text-muted">ID: <?php echo $besoin['id_besoin']; ?></small>
                    </div>
                    <span class="badge bg-<?php echo badgeClass($besoin['statut']); ?>">
                        <?php echo getStatusLabel($besoin['statut']); ?>
                    </span>
                </div>
                <div class="card-body">
                    <div class="info-grid">
                        <div class="info-item">
                            <strong>Agent:</strong><br>
                            <?php echo htmlspecialchars($besoin['prenom'] . ' ' . $besoin['nom']); ?>
                        </div>
                        <div class="info-item">
                            <strong>Date demande:</strong><br>
                            <?php echo date('d/m/Y H:i', strtotime($besoin['date_soumission'])); ?>
                        </div>
                        <?php if ($besoin['date_limite']): ?>
                        <div class="info-item">
                            <strong>Date limite:</strong><br>
                            <?php echo date('d/m/Y', strtotime($besoin['date_limite'])); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <strong>Justification:</strong>
                        <p class="mt-2 p-3 bg-light rounded"><?php echo nl2br(htmlspecialchars($besoin['justification'])); ?></p>
                    </div>
                    <form method="POST" class="actions">
                        <input type="hidden" name="id_besoin" value="<?php echo $besoin['id_besoin']; ?>">
                        <textarea name="commentaire" class="form-control" 
                                  placeholder="Commentaire de validation (optionnel)" 
                                  rows="3"></textarea>
                        <div class="btn-group-vertical">
                            <button type="submit" name="statut_validation" value="valider" 
                                    class="btn btn-success"
                                    onclick="return confirm('Confirmer l\'approbation de cette demande ?')">
                                <i class="fas fa-check me-2"></i>Approuver
                            </button>
                            <button type="submit" name="statut_validation" value="rejeter" 
                                    class="btn btn-danger"
                                    onclick="return confirm('Confirmer le rejet de cette demande ?')">
                                <i class="fas fa-times me-2"></i>Rejeter
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
<script src="../../assets/js/bootstrap.bundle.min.js"></script>
<script>
// Auto-dismiss alerts after 5 seconds
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert-dismissible');
        alerts.forEach(alert => {
            const closeButton = alert.querySelector('.btn-close');
            if (closeButton) {
                closeButton.click();
            }
        });
    }, 5000);
});
</script>
</body>
</html>