<?php
// finalize.php
session_start();
require_once '../Config/db.php'; // Connexion PDO dans ce fichier
// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit;
}
// Vérifier si la requête est valide
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requestId = $_POST['request_id'] ?? null;
    if ($requestId) {
        try {
            // Mise à jour du statut
            $stmt = $pdo->prepare("UPDATE requests SET status = 'Finalisé', updated_at = NOW() WHERE id = :id");
            $stmt->execute(['id' => $requestId]);
            // Redirection après finalisation
            header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/my_requests.php?msg=finalize_success");
            exit;
        } catch (PDOException $e) {
            die("Erreur lors de la finalisation : " . $e->getMessage());
        }
    } else {
        echo "<p>Aucune demande spécifiée.</p>";
    }
} else {
    echo "<p>Méthode de requête invalide.</p>";
}
?>
