<?php
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../Lib/csrf.php';
// Start session and security checks
session_start();
// Security constants (define if not already defined)
if (!defined('ROLE_AGENT')) {
    define('ROLE_AGENT', 'agent');
}
// Enhanced security check
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit();
}
if ($_SESSION['role'] !== ROLE_AGENT) {
    http_response_code(403);
    die('Accès refusé - Rôle agent requis');
}
// Initialize variables
$success = $error = '';
$etat = null;
$id_etat = null;
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_etat'])) {
    // CSRF protection
    if (!csrf_check()) {
        $error = "Erreur de sécurité. Veuillez réessayer.";
    } else {
        // Input validation and sanitization
        $id_etat = filter_var($_POST['id_etat'], FILTER_VALIDATE_INT);
        $designation = filter_var($_POST['designation'], FILTER_SANITIZE_STRING);
        $besoin = filter_var($_POST['besoin'], FILTER_SANITIZE_STRING);
        $justification = filter_var($_POST['justification'], FILTER_SANITIZE_STRING);
        // Validate required fields
        if (!$id_etat || empty(trim($designation)) || empty(trim($besoin)) || empty(trim($justification))) {
            $error = "Tous les champs sont obligatoires et doivent être valides.";
        } else {
            try {
                $pdo = Database::getInstance()->getConnection();
                // Check if the requirement exists and belongs to the current user
                $stmt = $pdo->prepare("
                    SELECT e.*, u.nom, u.prenom 
                    FROM etat_de_besoin e
                    JOIN agents a ON e.agent_id = a.id
                    JOIN users u ON a.user_id = u.id
                    WHERE e.id = ? AND a.user_id = ?
                ");
                $stmt->execute([$id_etat, $_SESSION['user_id']]);
                $current_etat = $stmt->fetch(PDO::FETCH_ASSOC);
                if (!$current_etat) {
                    $error = "État de besoin introuvable ou vous n'êtes pas autorisé à le modifier.";
                } elseif (!in_array($current_etat['statut'], ['soumis', 'rejete_service', 'rejete'])) {
                    $error = "Vous ne pouvez modifier cet état de besoin qu'aux statuts 'soumis' ou 'rejeté'.";
                } else {
                    // Begin transaction
                    $pdo->beginTransaction();
                    try {
                        // Update the requirement
                        $stmt = $pdo->prepare("
                            UPDATE etat_de_besoin 
                            SET designation = ?, besoin = ?, justification = ?, statut = 'soumis', updated_at = NOW()
                            WHERE id = ?
                        ");
                        $stmt->execute([$designation, $besoin, $justification, $id_etat]);
                        // Log the workflow change if Workflow class exists
                        if (class_exists('Workflow')) {
                            Workflow::logStatusChange(
                                $id_etat, 
                                $current_etat['statut'], 
                                'soumis', 
                                $_SESSION['user_id'], 
                                'Modification et resoumission de l\'état de besoin'
                            );
                        }
                        // Send notification if Notification class exists
                        if (class_exists('Notification')) {
                            Notification::send(
                                $_SESSION['user_id'], 
                                $id_etat, 
                                'modification', 
                                'État de besoin modifié et resoumis'
                            );
                        }
                        $pdo->commit();
                        $success = "État de besoin mis à jour et resoumis avec succès !";
                        // Refresh the data to show updated values
                        $etat = array_merge($current_etat, [
                            'designation' => $designation,
                            'besoin' => $besoin,
                            'justification' => $justification,
                            'statut' => 'soumis'
                        ]);
                    } catch (Exception $e) {
                        $pdo->rollBack();
                        throw $e;
                    }
                }
            } catch (PDOException $e) {
                $error = "Erreur de base de données : " . $e->getMessage();
                error_log("Update requirement error: " . $e->getMessage());
            } catch (Exception $e) {
                $error = "Erreur : " . $e->getMessage();
                error_log("General update error: " . $e->getMessage());
            }
        }
    }
}
// Load requirement data for display/editing
if (isset($_GET['id']) && !$etat) {
    $id_etat = filter_var($_GET['id'], FILTER_VALIDATE_INT);
    if (!$id_etat) {
        http_response_code(400);
        die("ID de l'état de besoin invalide.");
    }
    try {
        $pdo = Database::getInstance()->getConnection();
        $stmt = $pdo->prepare("
            SELECT e.*, u.nom, u.prenom, s.nom as service_nom
            FROM etat_de_besoin e
            JOIN agents a ON e.agent_id = a.id
            JOIN users u ON a.user_id = u.id
            LEFT JOIN services s ON a.service_id = s.id
            WHERE e.id = ? AND a.user_id = ?
        ");
        $stmt->execute([$id_etat, $_SESSION['user_id']]);
        $etat = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$etat) {
            http_response_code(404);
            die("État de besoin introuvable ou vous n'êtes pas autorisé à le modifier.");
        }
    } catch (PDOException $e) {
        $error = "Erreur lors du chargement des données : " . $e->getMessage();
        error_log("Load requirement error: " . $e->getMessage());
    }
} elseif (!isset($_GET['id']) && !$etat) {
    http_response_code(400);
    die("ID de l'état de besoin requis.");
}
// Status display function
function getStatusDisplay($status) {
    $statuses = [
        'soumis' => ['label' => 'Soumis', 'class' => 'warning', 'icon' => 'clock'],
        'rejete_service' => ['label' => 'Rejeté par le service', 'class' => 'danger', 'icon' => 'times-circle'],
        'rejete' => ['label' => 'Rejeté', 'class' => 'danger', 'icon' => 'times-circle'],
        'valide_service' => ['label' => 'Validé par le service', 'class' => 'success', 'icon' => 'check-circle'],
        'approuve' => ['label' => 'Approuvé', 'class' => 'success', 'icon' => 'check-circle']
    ];
    return $statuses[$status] ?? ['label' => ucfirst($status), 'class' => 'secondary', 'icon' => 'info-circle'];
}
$statusInfo = $etat ? getStatusDisplay($etat['statut']) : null;
$canEdit = $etat && in_array($etat['statut'], ['soumis', 'rejete_service', 'rejete']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un État de Besoin #<?php echo $etat ? htmlspecialchars($etat['id']) : 'N/A'; ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            padding: 20px 0;
        }
        .glass-container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px) saturate(180%);
            -webkit-backdrop-filter: blur(10px) saturate(180%);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            padding: 30px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            margin-bottom: 30px;
        }
        .page-header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }
        .form-container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
        }
        .info-card {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
            color: white;
        }
        .status-badge {
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .form-label {
            font-weight: 600;
            color: #495057;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .form-control, .form-select {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 12px 15px;
            transition: all 0.3s ease;
            font-size: 1rem;
        }
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.25rem rgba(102, 126, 234, 0.15);
        }
        .btn-primary {
            background: linear-gradient(45deg, #667eea, #764ba2);
            border: none;
            border-radius: 10px;
            padding: 12px 30px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        .btn-secondary {
            background: rgba(108, 117, 125, 0.8);
            border: none;
            border-radius: 10px;
            padding: 12px 30px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .btn-secondary:hover {
            background: rgba(108, 117, 125, 1);
            transform: translateY(-1px);
        }
        .alert {
            border: none;
            border-radius: 12px;
            padding: 15px 20px;
            margin-bottom: 25px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert-success {
            background: rgba(40, 167, 69, 0.1);
            color: #155724;
            border-left: 4px solid #28a745;
        }
        .alert-danger {
            background: rgba(220, 53, 69, 0.1);
            color: #721c24;
            border-left: 4px solid #dc3545;
        }
        .alert-warning {
            background: rgba(255, 193, 7, 0.1);
            color: #856404;
            border-left: 4px solid #ffc107;
        }
        .char-counter {
            font-size: 0.8rem;
            color: #6c757d;
            text-align: right;
            margin-top: 5px;
        }
        .char-counter.warning {
            color: #ffc107;
        }
        .char-counter.danger {
            color: #dc3545;
        }
        .back-btn {
            background: rgba(255, 255, 255, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            border-radius: 10px;
            padding: 10px 20px;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 20px;
        }
        .back-btn:hover {
            background: rgba(255, 255, 255, 0.25);
            color: white;
            transform: translateY(-2px);
            text-decoration: none;
        }
        .timeline-info {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
            color: white;
        }
        .disabled-overlay {
            position: relative;
        }
        .disabled-overlay::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.7);
            border-radius: 15px;
            z-index: 10;
        }
        .disabled-message {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 11;
            text-align: center;
            background: rgba(220, 53, 69, 0.9);
            color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
        }
        @media (max-width: 768px) {
            .glass-container {
                padding: 20px;
                margin: 10px;
            }
            .form-container {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <!-- Back Button -->
    <a href="List.php" class="back-btn">
        <i class="fas fa-arrow-left"></i>
        Retour à la liste
    </a>
    <!-- Page Header -->
    <div class="page-header">
        <h1><i class="fas fa-edit me-3"></i>Modifier un État de Besoin</h1>
        <?php if ($etat): ?>
            <p class="lead">État de Besoin #<?php echo htmlspecialchars($etat['id']); ?></p>
        <?php endif; ?>
    </div>
    <!-- Alerts -->
    <?php if ($success): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i>
            <?php echo htmlspecialchars($success); ?>
        </div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle"></i>
            <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>
    <?php if ($etat): ?>
        <!-- Current Status Info -->
        <div class="glass-container">
            <div class="info-card">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <h5 class="mb-3">
                            <i class="fas fa-info-circle me-2"></i>
                            Informations de l'État de Besoin
                        </h5>
                        <p><strong>Demandeur:</strong> <?php echo htmlspecialchars($etat['prenom'] . ' ' . $etat['nom']); ?></p>
                        <p><strong>Service:</strong> <?php echo htmlspecialchars($etat['service_nom'] ?? 'Non spécifié'); ?></p>
                        <p><strong>Date de création:</strong> <?php echo date('d/m/Y H:i', strtotime($etat['created_at'])); ?></p>
                        <?php if (isset($etat['updated_at']) && $etat['updated_at']): ?>
                            <p><strong>Dernière modification:</strong> <?php echo date('d/m/Y H:i', strtotime($etat['updated_at'])); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 text-md-end">
                        <div class="mb-3">
                            <strong>Statut actuel:</strong><br>
                            <span class="status-badge bg-<?php echo $statusInfo['class']; ?> mt-2">
                                <i class="fas fa-<?php echo $statusInfo['icon']; ?>"></i>
                                <?php echo $statusInfo['label']; ?>
                            </span>
                        </div>
                    </div>
                </div>
                <?php if (!$canEdit): ?>
                    <div class="timeline-info">
                        <div class="alert alert-warning">
                            <i class="fas fa-info-circle"></i>
                            <strong>Information:</strong> Cet état de besoin ne peut pas être modifié dans son statut actuel. 
                            Seuls les états "Soumis" ou "Rejeté" peuvent être modifiés.
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- Form Container -->
        <div class="glass-container">
            <div class="form-container <?php echo !$canEdit ? 'disabled-overlay' : ''; ?>">
                <?php if (!$canEdit): ?>
                    <div class="disabled-message">
                        <i class="fas fa-lock fa-2x mb-2"></i>
                        <h5>Modification non autorisée</h5>
                        <p>Cet état de besoin ne peut pas être modifié dans son statut actuel.</p>
                    </div>
                <?php endif; ?>
                <form method="POST" id="updateForm" <?php echo !$canEdit ? 'style="pointer-events: none;"' : ''; ?>>
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id_etat" value="<?php echo htmlspecialchars($etat['id']); ?>">
                    <div class="row">
                        <div class="col-md-12 mb-4">
                            <label for="designation" class="form-label">
                                <i class="fas fa-tag"></i>
                                Désignation globale *
                            </label>
                            <input type="text" 
                                   id="designation" 
                                   name="designation" 
                                   class="form-control" 
                                   value="<?php echo htmlspecialchars($etat['designation']); ?>" 
                                   required
                                   maxlength="255"
                                   placeholder="Entrez la désignation de votre besoin">
                            <div class="char-counter" id="designationCounter">0/255 caractères</div>
                        </div>
                        <div class="col-md-12 mb-4">
                            <label for="besoin" class="form-label">
                                <i class="fas fa-list"></i>
                                Description du besoin *
                            </label>
                            <input type="text" 
                                   id="besoin" 
                                   name="besoin" 
                                   class="form-control" 
                                   value="<?php echo htmlspecialchars($etat['besoin']); ?>" 
                                   required
                                   maxlength="500"
                                   placeholder="Décrivez précisément votre besoin">
                            <div class="char-counter" id="besoinCounter">0/500 caractères</div>
                        </div>
                        <div class="col-md-12 mb-4">
                            <label for="justification" class="form-label">
                                <i class="fas fa-clipboard-list"></i>
                                Justification *
                            </label>
                            <textarea id="justification" 
                                      name="justification" 
                                      class="form-control" 
                                      rows="6" 
                                      required
                                      maxlength="1000"
                                      placeholder="Expliquez les raisons de votre demande et son impact sur votre travail"><?php echo htmlspecialchars($etat['justification']); ?></textarea>
                            <div class="char-counter" id="justificationCounter">0/1000 caractères</div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="d-flex gap-3 flex-wrap">
                                <?php if ($canEdit): ?>
                                    <button type="submit" class="btn btn-primary" id="submitBtn">
                                        <i class="fas fa-save me-2"></i>
                                        Mettre à jour et resoumettre
                                    </button>
                                <?php endif; ?>
                                <a href="List.php" class="btn btn-secondary">
                                    <i class="fas fa-times me-2"></i>
                                    Annuler
                                </a>
                                <a href="logique.php?etat_id=<?php echo $etat['id']; ?>" class="btn btn-info">
                                    <i class="fas fa-history me-2"></i>
                                    Voir l'historique
                                </a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>
</div>
<!-- Bootstrap JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Character counters
    const fields = [
        { id: 'designation', max: 255, counter: 'designationCounter' },
        { id: 'besoin', max: 500, counter: 'besoinCounter' },
        { id: 'justification', max: 1000, counter: 'justificationCounter' }
    ];
    fields.forEach(field => {
        const element = document.getElementById(field.id);
        const counter = document.getElementById(field.counter);
        if (element && counter) {
            function updateCounter() {
                const length = element.value.length;
                counter.textContent = `${length}/${field.max} caractères`;
                counter.classList.remove('warning', 'danger');
                if (length > field.max * 0.8) {
                    counter.classList.add('warning');
                }
                if (length > field.max * 0.95) {
                    counter.classList.add('danger');
                }
            }
            // Initial update
            updateCounter();
            // Update on input
            element.addEventListener('input', updateCounter);
        }
    });
    // Form validation
    const form = document.getElementById('updateForm');
    const submitBtn = document.getElementById('submitBtn');
    if (form && submitBtn) {
        form.addEventListener('submit', function(e) {
            // Disable submit button to prevent double submission
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Mise à jour en cours...';
            // Validate fields
            let isValid = true;
            const requiredFields = ['designation', 'besoin', 'justification'];
            requiredFields.forEach(fieldName => {
                const field = document.getElementById(fieldName);
                if (field && !field.value.trim()) {
                    isValid = false;
                    field.classList.add('is-invalid');
                } else if (field) {
                    field.classList.remove('is-invalid');
                }
            });
            if (!isValid) {
                e.preventDefault();
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fas fa-save me-2"></i>Mettre à jour et resoumettre';
                alert('Veuillez remplir tous les champs obligatoires.');
            }
        });
        // Auto-save draft functionality (optional)
        let autoSaveTimer;
        fields.forEach(field => {
            const element = document.getElementById(field.id);
            if (element) {
                element.addEventListener('input', function() {
                    clearTimeout(autoSaveTimer);
                    autoSaveTimer = setTimeout(() => {
                        // Save to localStorage as draft
                        const draftData = {
                            designation: document.getElementById('designation').value,
                            besoin: document.getElementById('besoin').value,
                            justification: document.getElementById('justification').value,
                            timestamp: new Date().getTime()
                        };
                        localStorage.setItem('draft_update_<?php echo $etat['id']; ?>', JSON.stringify(draftData));
                    }, 2000);
                });
            }
        });
        // Load draft on page load (if exists and recent)
        const draftKey = 'draft_update_<?php echo $etat['id']; ?>';
        const draft = localStorage.getItem(draftKey);
        if (draft) {
            try {
                const draftData = JSON.parse(draft);
                const now = new Date().getTime();
                // Load draft if it's less than 1 hour old
                if (now - draftData.timestamp < 3600000) {
                    if (confirm('Un brouillon récent a été trouvé. Voulez-vous le charger ?')) {
                        document.getElementById('designation').value = draftData.designation;
                        document.getElementById('besoin').value = draftData.besoin;
                        document.getElementById('justification').value = draftData.justification;
                        // Update counters
                        fields.forEach(field => {
                            const element = document.getElementById(field.id);
                            const counter = document.getElementById(field.counter);
                            if (element && counter) {
                                const event = new Event('input');
                                element.dispatchEvent(event);
                            }
                        });
                    }
                } else {
                    // Remove old draft
                    localStorage.removeItem(draftKey);
                }
            } catch (e) {
                localStorage.removeItem(draftKey);
            }
        }
    }
    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert-success');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            alert.style.transition = 'opacity 0.5s ease';
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });
});
// Clear draft on successful submission
<?php if ($success): ?>
localStorage.removeItem('draft_update_<?php echo $etat['id']; ?>');
<?php endif; ?>
</script>
</body>
</html>