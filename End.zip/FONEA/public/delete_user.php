<?php
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Lib/csrf.php';
require_once __DIR__ . '/../public/userClass.php';


if (!isset($_SESSION['user'])) {
    header("Location: /FONEA/public/login.php");
    exit;
}

$currentUser = $_SESSION['user'];

if (!isset($currentUser['role']) || strtolower($currentUser['role']) !== 'directeur général') {
    http_response_code(403);
    die("Accès refusé : seul le Directeur Général peut supprimer les utilisateurs.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validate();

    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;

    if ($id > 0) {
        if (User::delete($id)) {
            
            header("Location: /FONEA/public/user.php");
            exit;
        } else {
            die("Erreur : impossible de supprimer cet utilisateur.");
        }
    } else {
        die("ID utilisateur invalide.");
    }
} else {
    die("Requête invalide.");
}

?>

<button class="delete-btn" data-id="<?= $user['id'] ?>" data-name="<?= $user['name'] ?>"> Supprimé </button>

<div id="confirmModal" class="modal">
  <div class="modal-content">
    <h3>Confirm Deletion</h3>
    <p id="confirmText"></p>
    <div class="modal-actions">
      <button id="confirmYes" class="confirm-btn danger"> Oui, Supprimé </button>
      <button id="confirmNo" class="confirm-btn"> Annulé </button>
    </div>
  </div>
</div>

<style>

.modal {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.65);
    justify-content: center;
    align-items: center;
    z-index: 9999;
}
.modal-content {
    background: #fff;
    padding: 30px;
    border-radius: 8px;
    max-width: 420px;
    width: 90%;
    text-align: center;
    box-shadow: 0 15px 40px rgba(0,0,0,0.3);
}
.modal-content h3 {
    color: #0f172a;
    margin-bottom: 10px;
}
.modal-content p {
    color: #475569;
    margin-bottom: 20px;
}
.modal-actions {
    display: flex;
    justify-content: center;
    gap: 15px;
}
.confirm-btn {
    padding: 10px 18px;
    border: none;
    border-radius: 6px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}
.confirm-btn:hover {
    transform: translateY(-2px);
}
.confirm-btn.danger {
    background: #ef4444;
    color: #fff;
}
.confirm-btn.danger:hover {
    background: #dc2626;
}
.confirm-btn:not(.danger) {
    background: #e2e8f0;
    color: #1e293b;
}
</style>

<script>

const modal = document.getElementById('confirmModal');
const confirmText = document.getElementById('confirmText');
let selectedId = null;

document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        selectedId = btn.dataset.id;
        confirmText.textContent = `Are you sure you want to delete agent "${btn.dataset.name}"? This action cannot be undone.`;
        modal.style.display = 'flex';
    });
});

document.getElementById('confirmNo').addEventListener('click', () => {
    modal.style.display = 'none';
    selectedId = null;
});

document.getElementById('confirmYes').addEventListener('click', () => {
    if (!selectedId) return;

    fetch('delete_agent.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id=' + encodeURIComponent(selectedId)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert('Agent Supprimé avec succès.');
            location.reload(); 
        } else {
            alert('Echec lors de la suppression de agent: ' + (data.message || 'Unknown error'));
        }
        modal.style.display = 'none';
    })
    .catch(err => {
        alert('Server error: ' + err);
        modal.style.display = 'none';
    });
});
</script>
