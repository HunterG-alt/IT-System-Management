<?php
// session.php
// Prevent double inclusion
if (defined('SESSION_LOADED')) return;
define('SESSION_LOADED', true);

require_once __DIR__ . '/db.php';

if (!defined('ROLE_AGENT')) define('ROLE_AGENT', 'agent_demandeur');
if (!defined('ROLE_DEMANDEUR')) define('ROLE_DEMANDEUR', 'demandeur');
if (!defined('ROLE_CHEF')) define('ROLE_CHEF', 'chef_service');
if (!defined('ROLE_INFORMATIQUE')) define('ROLE_INFORMATIQUE', 'informatique');
if (!defined('ROLE_MOYEN_GENERAUX')) define('ROLE_MOYEN_GENERAUX', 'moyens_generaux');
if (!defined('ROLE_DIRECTEUR')) define('ROLE_DIRECTEUR', 'directeur');
if (!defined('ROLE_DIRECTEUR_GENERAL')) define('ROLE_DIRECTEUR_GENERAL', 'directeur_general');

// Hiérarchie des rôles (valeurs numériques pour comparaisons)
if (!defined('ROLE_HIERARCHY')) {
    define('ROLE_HIERARCHY', [
        'demandeur' => 1,
        'agent' => 1,
        'chef_service' => 2,
        'informatique' => 3,
        'moyens_generaux' => 3,
        'directeur' => 4,
        'directeur_general' => 5
    ]);
}

class SessionConfig {
    const DEFAULT_TIMEOUT = 1800; // 30 minutes
    const REMEMBER_ME_TIMEOUT = 2592000; // 30 days
    const SESSION_NAME = 'FONEA_SESSION';
    const CSRF_TOKEN_LENGTH = 32;

    public static function initialize(): void {
        // Configure session security settings
        if (session_status() === PHP_SESSION_NONE) {
            // Basic hardening
            ini_set('session.use_only_cookies', 1);
            ini_set('session.use_strict_mode', 1);

            // cookie_httponly
            ini_set('session.cookie_httponly', 1);

            // secure flag only when HTTPS
            $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
            ini_set('session.cookie_secure', $isHttps ? 1 : 0);

            // Session name
            session_name(self::SESSION_NAME);

            // Domain: avoid setting domain for 'localhost' or raw IPs (browsers reject it)
            $domain = self::getSessionDomain();

            $cookieParams = [
                'lifetime' => 0,
                'path' => '/',
                'domain' => $domain,
                'secure' => $isHttps,
                'httponly' => true,
                'samesite' => 'Strict'
            ];

            // Set cookie params in a compatible way
            if (PHP_VERSION_ID >= 70300) {
                session_set_cookie_params($cookieParams);
            } else {
                // For older PHP versions, set cookie without samesite
                session_set_cookie_params(
                    $cookieParams['lifetime'],
                    $cookieParams['path'],
                    $cookieParams['domain'],
                    $cookieParams['secure'],
                    $cookieParams['httponly']
                );
            }

            // Start session
            session_start();

            // Regenerate id on first load or periodically
            if (!isset($_SESSION['session_regenerated'])) {
                session_regenerate_id(true);
                $_SESSION['session_regenerated'] = time();
            } elseif (isset($_SESSION['session_regenerated']) && (time() - $_SESSION['session_regenerated'] > 300)) {
                // Regenerate periodically (every 5 minutes)
                session_regenerate_id(true);
                $_SESSION['session_regenerated'] = time();
            }
        }

        // Initialize structures
        if (!isset($_SESSION['security'])) {
            $_SESSION['security'] = [
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
                'created_at' => time(),
                'last_activity' => time()
            ];
        }
        if (!isset($_SESSION['flash'])) {
            $_SESSION['flash'] = [];
        }
        if (!isset($_SESSION['csrf_tokens'])) {
            $_SESSION['csrf_tokens'] = [];
        }

        // Validate timeout immediately
        self::checkSessionTimeout();
    }

    private static function getSessionDomain(): string {
        $host = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? '';
        // Sanitize hostname more carefully
        $host = filter_var($host, FILTER_SANITIZE_URL);
        $host = preg_replace('/[^a-zA-Z0-9\.\-:]/', '', $host);
        
        // Remove port if present
        if (strpos($host, ':') !== false) {
            $host = explode(':', $host)[0];
        }
        
        // Avoid setting cookie domain for localhost or IPs
        if ($host === 'localhost' || filter_var($host, FILTER_VALIDATE_IP)) {
            return '';
        }
        return $host;
    }

    private static function checkSessionTimeout(): void {
        $timeout = isset($_SESSION['remember_me']) && $_SESSION['remember_me'] ? self::REMEMBER_ME_TIMEOUT : self::DEFAULT_TIMEOUT;
        if (isset($_SESSION['security']['last_activity']) &&
            (time() - $_SESSION['security']['last_activity']) > $timeout) {
            // Log and logout
            if (isset($_SESSION['user_id'])) {
                self::logSecurityEvent('session_timeout', $_SESSION['user_id']);
            }
            SessionAuth::logout();
            FlashMessage::set('warning', 'Votre session a expiré. Veuillez vous reconnecter.');
            $redirect_url = self::getBaseUrl() . '/public/login.php?expired=1';
            if (!headers_sent()) {
                header("Location: " . $redirect_url);
                exit();
            } else {
                echo "<script>window.location.href='" . htmlspecialchars($redirect_url, ENT_QUOTES, 'UTF-8') . "';</script>";
                exit();
            }
        }

        // Update last activity
        if (isset($_SESSION['security'])) {
            $_SESSION['security']['last_activity'] = time();
        }

        // Integrity validation
        self::validateSessionIntegrity();
    }

    private static function validateSessionIntegrity(): void {
        // Ensure the IP/user agent are OK; more tolerant in development
        $current_ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $current_ua = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

        if (isset($_SESSION['security']['ip_address']) && $_SESSION['security']['ip_address'] !== $current_ip) {
            self::logSecurityEvent('ip_change', $_SESSION['user_id'] ?? null, [
                'old_ip' => $_SESSION['security']['ip_address'],
                'new_ip' => $current_ip
            ]);
            if (self::isProductionEnvironment()) {
                // In production, be more strict about IP changes
                SessionAuth::logout();
                FlashMessage::set('danger', 'Activité suspecte détectée. Veuillez vous reconnecter.');
                $redirect_url = self::getBaseUrl() . '/public/login.php?security=1';
                if (!headers_sent()) {
                    header("Location: " . $redirect_url);
                    exit();
                } else {
                    echo "<script>window.location.href='" . htmlspecialchars($redirect_url, ENT_QUOTES, 'UTF-8') . "';</script>";
                    exit();
                }
            } else {
                // Development: update IP to avoid false positives
                $_SESSION['security']['ip_address'] = $current_ip;
            }
        }

        if (isset($_SESSION['security']['user_agent']) && $_SESSION['security']['user_agent'] !== $current_ua) {
            self::logSecurityEvent('user_agent_change', $_SESSION['user_id'] ?? null);
            // Update agent to avoid false positives in dev/test
            $_SESSION['security']['user_agent'] = $current_ua;
        }
    }

    private static function isProductionEnvironment(): bool {
        $server = $_SERVER['SERVER_NAME'] ?? ($_SERVER['HTTP_HOST'] ?? '');
        return !in_array($server, ['localhost', '127.0.0.1', '::1']) && !str_contains($server, '.local');
    }

    // Dynamic base URL: remove trailing /public if present, return project base
    public static function getBaseUrl(): string {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $scriptPath = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
        $base = rtrim($scheme . "://" . $host . $scriptPath, '/');
        // If path ends with /public (case-insensitive), remove it to get project root
        if (preg_match('#/public$#i', $scriptPath)) {
            $base = preg_replace('#/public$#i', '', $base);
        }
        return $base;
    }

    public static function logSecurityEvent(string $event, $user_id = null, array $data = []): void {
        try {
            if (class_exists('DatabaseUtils') && method_exists('DatabaseUtils', 'insert')) {
                $log_data = [
                    'event' => $event,
                    'user_id' => $user_id,
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
                    'timestamp' => date('Y-m-d H:i:s'),
                    'data' => json_encode($data)
                ];
                DatabaseUtils::insert('security_log', $log_data);
            } else {
                // Fallback to file logging (ensure logs directory exists and is writable)
                $logDir = __DIR__ . '/../logs';
                if (!is_dir($logDir)) {
                    @mkdir($logDir, 0755, true);
                }
                $log_message = sprintf(
                    "[%s] %s - User: %s, IP: %s, Data: %s\n",
                    date('Y-m-d H:i:s'),
                    $event,
                    $user_id ?? 'anonymous',
                    $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                    json_encode($data)
                );
                @error_log($log_message, 3, $logDir . '/security.log');
            }
        } catch (Throwable $e) {
            // Best-effort logging to PHP error log
            error_log("Failed to log security event: " . $e->getMessage());
        }
    }
}

class SessionAuth {
    public static function isLoggedIn(): bool {
        return isset($_SESSION['user_id']) &&
               isset($_SESSION['logged_in']) &&
               $_SESSION['logged_in'] === true &&
               !empty($_SESSION['role']);
    }

    public static function requireLogin(): void {
        if (!self::isLoggedIn()) {
            $redirect = $_SERVER['REQUEST_URI'] ?? '';
            $base_url = SessionConfig::getBaseUrl();
            $login_url = $base_url . '/public/login.php';
            if (!empty($redirect) && $redirect !== '/') {
                $login_url .= '?redirect=' . urlencode($redirect);
            }
            if (!headers_sent()) {
                header("Location: " . $login_url);
                exit();
            } else {
                echo "<script>window.location.href='" . htmlspecialchars($login_url, ENT_QUOTES, 'UTF-8') . "';</script>";
                exit();
            }
        }
    }

    public static function login(array $user_data, bool $remember_me = false): bool {
        try {
            if (!isset($user_data['id']) || !isset($user_data['role'])) {
                throw new Exception('Données utilisateur incomplètes');
            }

            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$user_data['id'];
            $_SESSION['logged_in'] = true;
            $_SESSION['role'] = $user_data['role'];
            $_SESSION['nom_complet'] = trim(($user_data['prenom'] ?? '') . ' ' . ($user_data['nom'] ?? ''));
            $_SESSION['email'] = $user_data['email'] ?? '';
            $_SESSION['remember_me'] = $remember_me;
            $_SESSION['security']['login_time'] = time();
            $_SESSION['security']['ip_address'] = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
            $_SESSION['security']['user_agent'] = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
            $_SESSION['security']['last_activity'] = time();

            self::updateLastLogin((int)$user_data['id']);
            SessionConfig::logSecurityEvent('login_success', (int)$user_data['id']);
            return true;
        } catch (Throwable $e) {
            error_log("Login error: " . $e->getMessage());
            return false;
        }
    }

    public static function logout(): void {
        $user_id = $_SESSION['user_id'] ?? null;
        if ($user_id) {
            SessionConfig::logSecurityEvent('logout', $user_id);
        }

        // Clear session array
        $_SESSION = [];

        // Remove cookie
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 3600,
                $params["path"],
                $params["domain"] ?? '',
                $params["secure"] ?? false,
                $params["httponly"] ?? true
            );
        }

        // Destroy session and restart fresh one
        @session_destroy();
        session_start();
    }

    public static function hasRole(string $role): bool {
        return self::isLoggedIn() && ($_SESSION['role'] ?? '') === $role;
    }

    public static function hasAnyRole(array $roles): bool {
        return self::isLoggedIn() && in_array($_SESSION['role'] ?? '', $roles, true);
    }

    public static function hasMinimumRole(string $minimum_role): bool {
        if (!self::isLoggedIn()) return false;
        $hierarchy = constant('ROLE_HIERARCHY');
        $user_level = $hierarchy[$_SESSION['role']] ?? 0;
        $required_level = $hierarchy[$minimum_role] ?? PHP_INT_MAX;
        return $user_level >= $required_level;
    }

    public static function requireRole(string $role): void {
        if (!self::hasRole($role)) {
            http_response_code(403);
            FlashMessage::set('danger', 'Accès interdit. Privilèges insuffisants.');
            $base_url = SessionConfig::getBaseUrl();
            $target = $base_url . '/public/access-denied.php';
            if (!headers_sent()) {
                header("Location: " . $target);
                exit();
            } else {
                echo "<script>window.location.href='" . htmlspecialchars($target, ENT_QUOTES, 'UTF-8') . "';</script>";
                exit();
            }
        }
    }

    public static function requireAnyRole(array $roles): void {
        if (!self::hasAnyRole($roles)) {
            http_response_code(403);
            FlashMessage::set('danger', 'Accès interdit. Privilèges insuffisants.');
            $base_url = SessionConfig::getBaseUrl();
            $target = $base_url . '/public/access-denied.php';
            if (!headers_sent()) {
                header("Location: " . $target);
                exit();
            } else {
                echo "<script>window.location.href='" . htmlspecialchars($target, ENT_QUOTES, 'UTF-8') . "';</script>";
                exit();
            }
        }
    }

    public static function getCurrentUser(): ?array {
        static $cached_user = null;
        static $cache_time = 0;
        if (!self::isLoggedIn()) return null;
        if ($cached_user !== null && (time() - $cache_time) < 300) {
            return $cached_user;
        }
        try {
            if (class_exists('DatabaseUtils') && method_exists('DatabaseUtils', 'fetchOne')) {
                $user = DatabaseUtils::fetchOne(
                    "SELECT id, nom, prenom, email, role, created_at, last_login, active,
                            CONCAT(COALESCE(prenom, ''), ' ', COALESCE(nom, '')) as nom_complet
                     FROM users 
                     WHERE id = ? AND active = 1",
                    [$_SESSION['user_id']]
                );
                if ($user) {
                    $cached_user = $user;
                    $cache_time = time();
                } else {
                    self::logout();
                    return null;
                }
                return $user;
            } else {
                // Fallback to session-stored data
                return [
                    'id' => $_SESSION['user_id'] ?? null,
                    'role' => $_SESSION['role'] ?? null,
                    'email' => $_SESSION['email'] ?? '',
                    'nom_complet' => $_SESSION['nom_complet'] ?? '',
                    'prenom' => explode(' ', $_SESSION['nom_complet'] ?? '')[0] ?? '',
                    'nom' => explode(' ', $_SESSION['nom_complet'] ?? '')[1] ?? ''
                ];
            }
        } catch (Throwable $e) {
            error_log("Error fetching current user: " . $e->getMessage());
            return null;
        }
    }

    private static function updateLastLogin(int $user_id): void {
        try {
            if (class_exists('DatabaseUtils') && method_exists('DatabaseUtils', 'update')) {
                DatabaseUtils::update(
                    'users',
                    ['last_login' => date('Y-m-d H:i:s')],
                    'id = ?',
                    [$user_id]
                );
            }
        } catch (Throwable $e) {
            error_log("Error updating last login: " . $e->getMessage());
        }
    }

    // Wrapper for SessionConfig logging
    public static function logSecurityEvent(string $event, $user_id = null, array $data = []): void {
        SessionConfig::logSecurityEvent($event, $user_id, $data);
    }
}

class CSRFProtection {
    public static function generateToken(): string {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(SessionConfig::CSRF_TOKEN_LENGTH));
        }
        return $_SESSION['csrf_token'];
    }

    public static function generateTokenFor(string $form_name): string {
        $token = bin2hex(random_bytes(SessionConfig::CSRF_TOKEN_LENGTH));
        $_SESSION['csrf_tokens'][$form_name] = [
            'token' => $token,
            'created' => time()
        ];
        self::cleanOldTokens();
        return $token;
    }

    public static function verifyToken(?string $token): bool {
        return isset($_SESSION['csrf_token']) &&
               !empty($token) &&
               hash_equals($_SESSION['csrf_token'], $token);
    }

    public static function verifyTokenFor(string $form_name, ?string $token): bool {
        if (!isset($_SESSION['csrf_tokens'][$form_name]) || empty($token)) {
            return false;
        }
        $stored_token = $_SESSION['csrf_tokens'][$form_name];
        if (time() - $stored_token['created'] > 3600) {
            unset($_SESSION['csrf_tokens'][$form_name]);
            return false;
        }
        $valid = hash_equals($stored_token['token'], $token);
        if ($valid) {
            unset($_SESSION['csrf_tokens'][$form_name]);
        }
        return $valid;
    }

    public static function getInputField(?string $form_name = null): string {
        $token = $form_name ? self::generateTokenFor($form_name) : self::generateToken();
        $field_name = $form_name ? "csrf_token_{$form_name}" : 'csrf_token';
        return "<input type='hidden' name='" . htmlspecialchars($field_name, ENT_QUOTES, 'UTF-8') . "' value='" . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . "'>";
    }

    private static function cleanOldTokens(): void {
        if (!isset($_SESSION['csrf_tokens']) || !is_array($_SESSION['csrf_tokens'])) return;
        $current_time = time();
        foreach ($_SESSION['csrf_tokens'] as $form_name => $token_data) {
            if (!is_array($token_data) || !isset($token_data['created'])) {
                unset($_SESSION['csrf_tokens'][$form_name]);
                continue;
            }
            if ($current_time - $token_data['created'] > 3600) {
                unset($_SESSION['csrf_tokens'][$form_name]);
            }
        }
    }

    public static function requireToken(?string $form_name = null): void {
        $field_name = $form_name ? "csrf_token_{$form_name}" : 'csrf_token';
        $token = $_POST[$field_name] ?? $_GET[$field_name] ?? null;
        $valid = $form_name ? self::verifyTokenFor($form_name, $token) : self::verifyToken($token);
        if (!$valid) {
            http_response_code(403);
            FlashMessage::set('danger', 'Token de sécurité invalide. Veuillez réessayer.');
            if (!headers_sent()) {
                $referer = $_SERVER['HTTP_REFERER'] ?? SessionConfig::getBaseUrl() . '/public/index.php';
                header("Location: " . $referer);
                exit();
            } else {
                echo "<script>history.back();</script>";
                exit();
            }
        }
    }
}

class FlashMessage {
    const TYPE_SUCCESS = 'success';
    const TYPE_ERROR = 'error';
    const TYPE_DANGER = 'danger';
    const TYPE_WARNING = 'warning';
    const TYPE_INFO = 'info';

    public static function set(string $type, string $message): void {
        if (!isset($_SESSION['flash'])) $_SESSION['flash'] = [];
        $_SESSION['flash'][$type] = $message;
    }

    public static function add(string $type, string $message): void {
        if (!isset($_SESSION['flash'])) $_SESSION['flash'] = [];
        if (!isset($_SESSION['flash'][$type])) {
            $_SESSION['flash'][$type] = [];
        } elseif (!is_array($_SESSION['flash'][$type])) {
            $_SESSION['flash'][$type] = [$_SESSION['flash'][$type]];
        }
        $_SESSION['flash'][$type][] = $message;
    }

    public static function get(?string $type = null): array {
        if (!isset($_SESSION['flash'])) return [];
        if ($type !== null) {
            $messages = $_SESSION['flash'][$type] ?? [];
            return is_array($messages) ? $messages : [$messages];
        }
        return $_SESSION['flash'];
    }

    public static function display(?string $type = null): void {
        if (!isset($_SESSION['flash']) || !is_array($_SESSION['flash'])) return;
        $messages = $type ? [$type => ($_SESSION['flash'][$type] ?? [])] : $_SESSION['flash'];
        foreach ($messages as $msg_type => $message) {
            if (empty($message)) continue;
            $alert_class = self::getAlertClass($msg_type);
            $icon = self::getIcon($msg_type);
            if (is_array($message)) {
                foreach ($message as $msg) {
                    if (!empty($msg)) self::renderMessage($alert_class, $icon, $msg);
                }
            } else {
                self::renderMessage($alert_class, $icon, $message);
            }
        }
        if ($type !== null) {
            unset($_SESSION['flash'][$type]);
        } else {
            unset($_SESSION['flash']);
        }
    }

    public static function clear(?string $type = null): void {
        if (!isset($_SESSION['flash'])) return;
        if ($type !== null) {
            unset($_SESSION['flash'][$type]);
        } else {
            $_SESSION['flash'] = [];
        }
    }

    public static function hasMessages(?string $type = null): bool {
        if (!isset($_SESSION['flash'])) return false;
        if ($type !== null) {
            return isset($_SESSION['flash'][$type]) && !empty($_SESSION['flash'][$type]);
        }
        return !empty($_SESSION['flash']);
    }

    private static function getAlertClass(string $type): string {
        return match($type) {
            self::TYPE_SUCCESS => 'alert-success',
            self::TYPE_DANGER, self::TYPE_ERROR => 'alert-danger',
            self::TYPE_WARNING => 'alert-warning',
            self::TYPE_INFO => 'alert-info',
            default => 'alert-secondary',
        };
    }

    private static function getIcon(string $type): string {
        return match($type) {
            self::TYPE_SUCCESS => 'fas fa-check-circle',
            self::TYPE_DANGER, self::TYPE_ERROR => 'fas fa-exclamation-triangle',
            self::TYPE_WARNING => 'fas fa-exclamation-circle',
            self::TYPE_INFO => 'fas fa-info-circle',
            default => 'fas fa-bell',
        };
    }

    private static function renderMessage(string $alert_class, string $icon, string $message): void {
        echo "<div class='alert {$alert_class} alert-dismissible fade show' role='alert'>
                <i class='{$icon} me-2'></i>"
                . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') .
              "<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
              </div>";
    }
}

// Initialize session configuration (start session, checks)
SessionConfig::initialize();

// Backward-compatibility helper functions (kept for existing code)
if (!function_exists('is_logged_in')) {
    function is_logged_in(): bool { return SessionAuth::isLoggedIn(); }
}
if (!function_exists('require_login')) {
    function require_login(): void { SessionAuth::requireLogin(); }
}
if (!function_exists('user_has_role')) {
    function user_has_role(string $role): bool { return SessionAuth::hasRole($role); }
}
if (!function_exists('user_has_any_role')) {
    function user_has_any_role(array $roles): bool { return SessionAuth::hasAnyRole($roles); }
}
if (!function_exists('user_logout')) {
    function user_logout(): void { SessionAuth::logout(); }
}
if (!function_exists('csrf_token')) {
    function csrf_token(): string { return CSRFProtection::generateToken(); }
}
if (!function_exists('csrf_verify')) {
    function csrf_verify(?string $token): bool { return CSRFProtection::verifyToken($token); }
}
if (!function_exists('set_flash_message')) {
    function set_flash_message(string $type, string $message): void { FlashMessage::set($type, $message); }
}
if (!function_exists('display_flash_messages')) {
    function display_flash_messages(): void { FlashMessage::display(); }
}
if (!function_exists('get_current_user_data')) {
    function get_current_user_data(): ?array { return SessionAuth::getCurrentUser(); }
}
if (!function_exists('getBaseUrl')) {
    function getBaseUrl(): string {
        return SessionConfig::getBaseUrl();
    }
}
