<?php
require_once '../Config/session.php';
require_login();
require_once '../Config/db.php';
require_once __DIR__ . '/../modules/permission.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    die('ID de demande manquant.');
}

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'informatique') {
    http_response_code(403);
    die('Accès refusé.');
}

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    CSRFProtection::requireToken('spec_update');
    $infoTech = trim($_POST['info_tech'] ?? '');
    if ($infoTech === '') {
        $error = "Le champ des spécifications techniques ne peut pas être vide.";
    } else {
        $pdo = Database::getInstance()->getConnection();
        
        $stmt = $pdo->prepare("UPDATE etat_de_besoin SET info_tech = ? , date_maj = NOW() WHERE id_besoin = ?");
        $stmt->execute([$infoTech, $id]);
        
        if (function_exists('notifications_send')) {
            notifications_send($_SESSION['user_id'], $id, 'info_tech', "Spécifications techniques ajoutées");
        }
        $success = "Spécifications techniques enregistrées avec succès.";
    }
}
// Récupérer les données existantes
$pdo = Database::getInstance()->getConnection();
$stmt = $pdo->prepare("SELECT info_tech FROM etat_de_besoin WHERE id_besoin = ?");
$stmt->execute([$id]);
$existingData = $stmt->fetch(PDO::FETCH_ASSOC);
$currentInfoTech = $existingData['info_tech'] ?? '';
?>
<div class="container mt-4">
    <h2>Spécifications techniques de Demande #<?= (int)$id ?></h2>
    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post" action="">
        <?= CSRFProtection::getInputField('spec_update') ?>
        <div class="mb-3">
            <label for="infoTech" class="form-label">Détails techniques</label>
            <textarea id="infoTech" name="info_tech" class="form-control" rows="6" placeholder="Saisir les spécifications techniques..."><?= htmlspecialchars($_POST['info_tech'] ?? $currentInfoTech) ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-save"></i> Enregistrer et Notifier le Service des Moyens Généraux
        </button>
    </form>
</div>