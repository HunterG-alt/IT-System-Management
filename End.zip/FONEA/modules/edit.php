<?php

require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Lib/csrf.php';
// Start session and check authentication
require_login();
// Check user permissions (only certain roles can edit)
$allowed_roles = [ROLE_DIRECTEUR, ROLE_INFORMATIQUE, ROLE_MOYENS_GENERAUX];
if (!in_array($_SESSION['role'], $allowed_roles)) {
    die('Accès refusé - Vous n\'avez pas les permissions pour modifier des éléments');
}
$pdo = Database::getInstance()->getConnection();
$success = $error = '';
// Check what entity to edit (besoin or materiel)
$entity_type = $_GET['type'] ?? 'materiel';
$allowed_types = ['besoin', 'materiel'];
if (!in_array($entity_type, $allowed_types)) {
    die("Type d'entité invalide.");
}
// Verify ID parameter
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: list_' . $entity_type . '.php?error=missing_id');
    exit;
}
$id = (int) $_GET['id'];
// Get existing record
try {
    if ($entity_type === 'materiel') {
        $stmt = $pdo->prepare("
            SELECT m.*, tm.libelle as type_libelle, eb.designation_materiel as besoin_designation
            FROM materiel m
            LEFT JOIN type_materiel tm ON m.id_type = tm.id_type
            LEFT JOIN etat_de_besoin eb ON m.id_etat = eb.id_besoin
            WHERE m.id_materiel = ?
        ");
        $stmt->execute([$id]);
        $entity = $stmt->fetch(PDO::FETCH_ASSOC);
    } else { // besoin
        $stmt = $pdo->prepare("
            SELECT eb.*, a.nom as agent_nom, a.prenom as agent_prenom
            FROM etat_de_besoin eb
            JOIN agents a ON eb.id_agent = a.id_agent
            WHERE eb.id_besoin = ?
        ");
        $stmt->execute([$id]);
        $entity = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    if (!$entity) {
        header('Location: list_' . $entity_type . '.php?error=not_found');
        exit;
    }
} catch (Exception $e) {
    die("Erreur lors de la récupération des données : " . $e->getMessage());
}
// Get dropdown data
$types_materiel = [];
$agents = [];
if ($entity_type === 'materiel') {
    // Get material types
    $stmt = $pdo->query("SELECT id_type, libelle FROM type_materiel ORDER BY libelle");
    $types_materiel = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // Get available besoins
    $stmt = $pdo->query("
        SELECT id_besoin, designation_materiel 
        FROM etat_de_besoin 
        WHERE statut IN ('validee_directeur', 'en_analyse_technique', 'en_acquisition')
        ORDER BY designation_materiel
    ");
    $besoins = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    // Get agents for besoin editing
    $stmt = $pdo->query("SELECT id_agent, nom, prenom FROM agents ORDER BY nom, prenom");
    $agents = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF verification
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = "Token CSRF invalide. Veuillez recharger la page.";
    } else {
        try {
            $pdo->beginTransaction();
            if ($entity_type === 'materiel') {
                // Validate material data
                $required_fields = ['reference', 'designation', 'marque', 'modele', 'quantite'];
                foreach ($required_fields as $field) {
                    if (empty(trim($_POST[$field] ?? ''))) {
                        throw new Exception("Le champ '$field' est obligatoire.");
                    }
                }
                $quantite = (int) $_POST['quantite'];
                if ($quantite <= 0) {
                    throw new Exception("La quantité doit être supérieure à zéro.");
                }
                // Update material
                $stmt = $pdo->prepare("
                    UPDATE materiel SET 
                        id_etat = ?, 
                        quantite = ?, 
                        id_type = ?, 
                        reference = ?, 
                        designation = ?, 
                        marque = ?, 
                        modele = ?, 
                        categorie = ?, 
                        caracteristique = ?,
                        statut = ?
                    WHERE id_materiel = ?
                ");
                $stmt->execute([
                    (int) $_POST['id_etat'],
                    $quantite,
                    (int) $_POST['id_type'],
                    trim($_POST['reference']),
                    trim($_POST['designation']),
                    trim($_POST['marque']),
                    trim($_POST['modele']),
                    $_POST['categorie'],
                    trim($_POST['caracteristique']),
                    trim($_POST['statut']),
                    $id
                ]);
                // Update characteristics if provided
                if (!empty($_POST['caracteristiques'])) {
                    // Delete existing characteristics
                    $stmt = $pdo->prepare("DELETE FROM caracteristique WHERE id_materiel = ?");
                    $stmt->execute([$id]);
                    // Insert new characteristics
                    $stmt_carac = $pdo->prepare("
                        INSERT INTO caracteristique (id_materiel, id_type_carac, valeur_acquise) 
                        VALUES (?, ?, ?)
                    ");
                    foreach ($_POST['caracteristiques'] as $id_type_carac => $valeur) {
                        if (!empty(trim($valeur))) {
                            $stmt_carac->execute([$id, $id_type_carac, trim($valeur)]);
                        }
                    }
                }
                $success = "Matériel mis à jour avec succès.";
            } else { // besoin
                // Validate besoin data
                if (empty(trim($_POST['designation_materiel']))) {
                    throw new Exception("La désignation du matériel est obligatoire.");
                }
                if (empty(trim($_POST['justification']))) {
                    throw new Exception("La justification est obligatoire.");
                }
                // Check if status change is allowed
                $new_status = $_POST['statut'];
                $old_status = $entity['statut'];
                $allowed_transitions = [
                    'en_attente' => ['pre_validee', 'refusee_chef'],
                    'pre_validee' => ['validee_directeur', 'refusee_directeur'],
                    'validee_directeur' => ['en_analyse_technique'],
                    'en_analyse_technique' => ['en_acquisition'],
                    'en_acquisition' => ['attribuee'],
                    'attribuee' => ['cloturee']
                ];
                if ($new_status !== $old_status && 
                    !in_array($new_status, $allowed_transitions[$old_status] ?? [])) {
                    throw new Exception("Transition de statut non autorisée.");
                }
                // Update besoin
                $stmt = $pdo->prepare("
                    UPDATE etat_de_besoin SET 
                        designation_materiel = ?, 
                        justification = ?, 
                        statut = ?,
                        date_limite = ?,
                        date_maj = NOW()
                    WHERE id_besoin = ?
                ");
                $date_limite = !empty($_POST['date_limite']) ? $_POST['date_limite'] : null;
                $stmt->execute([
                    trim($_POST['designation_materiel']),
                    trim($_POST['justification']),
                    $new_status,
                    $date_limite,
                    $id
                ]);
                $success = "État de besoin mis à jour avec succès.";
            }
            // Log activity
            $stmt = $pdo->prepare("
                INSERT INTO activity_log (user_id, action, entity_type, entity_id, description) 
                VALUES (?, 'UPDATE', ?, ?, ?)
            ");
            $stmt->execute([
                $_SESSION['user_id'],
                $entity_type,
                $id,
                "Modification de " . ($entity_type === 'materiel' ? 'matériel' : 'état de besoin') . " #$id"
            ]);
            $pdo->commit();
            // Refresh entity data
            if ($entity_type === 'materiel') {
                $stmt = $pdo->prepare("
                    SELECT m.*, tm.libelle as type_libelle, eb.designation_materiel as besoin_designation
                    FROM materiel m
                    LEFT JOIN type_materiel tm ON m.id_type = tm.id_type
                    LEFT JOIN etat_de_besoin eb ON m.id_etat = eb.id_besoin
                    WHERE m.id_materiel = ?
                ");
            } else {
                $stmt = $pdo->prepare("
                    SELECT eb.*, a.nom as agent_nom, a.prenom as agent_prenom
                    FROM etat_de_besoin eb
                    JOIN agents a ON eb.id_agent = a.id_agent
                    WHERE eb.id_besoin = ?
                ");
            }
            $stmt->execute([$id]);
            $entity = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            $pdo->rollback();
            $error = "Erreur : " . $e->getMessage();
        }
    }
}
// Get characteristics for material type if editing material
$caracteristiques_type = [];
if ($entity_type === 'materiel' && !empty($entity['id_type'])) {
    $stmt = $pdo->prepare("
        SELECT tc.id_type_carac, tc.libelle, c.valeur_acquise
        FROM type_caracteristique tc
        LEFT JOIN caracteristique c ON tc.id_type_carac = c.id_type_carac AND c.id_materiel = ?
        WHERE tc.id_type = ?
        ORDER BY tc.libelle
    ");
    $stmt->execute([$id, $entity['id_type']]);
    $caracteristiques_type = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
// Generate CSRF token
$csrf_token = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Éditer <?php echo ucfirst($entity_type); ?> - FONEA</title>
    <link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .card {
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            border: none;
        }
        .card-header {
            background: linear-gradient(135deg, #007bff, #0056b3);
            color: white;
        }
        .form-section {
            background: #f8f9fa;
            border-left: 4px solid #007bff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 0 8px 8px 0;
        }
        .required-field::after {
            content: " *";
            color: red;
        }
        .readonly-field {
            background-color: #f8f9fa;
            border: 1px solid #e9ecef;
        }
    </style>
</head>
<body>
<div class="container mt-4">
    <div class="row">
        <div class="col-lg-10 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">
                        <i class="fas fa-edit me-2"></i>
                        Éditer <?php echo $entity_type === 'materiel' ? 'Matériel' : 'État de Besoin'; ?>
                        <span class="badge bg-light text-dark ms-2">#<?php echo $id; ?></span>
                    </h4>
                </div>
                <div class="card-body">
                    <!-- Messages -->
                    <?php if ($success): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle me-2"></i>
                            <?php echo htmlspecialchars($success); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?php echo htmlspecialchars($error); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    <form method="POST" id="edit-form">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <?php if ($entity_type === 'materiel'): ?>
                            <!-- Material Form -->
                            <div class="form-section">
                                <h5 class="mb-3"><i class="fas fa-cog me-2"></i>Informations Matériel</h5>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label required-field">Référence</label>
                                        <input type="text" name="reference" class="form-control" 
                                               value="<?php echo htmlspecialchars($entity['reference']); ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label required-field">Quantité</label>
                                        <input type="number" name="quantite" class="form-control" 
                                               value="<?php echo htmlspecialchars($entity['quantite']); ?>" 
                                               min="1" required>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label required-field">Désignation</label>
                                    <input type="text" name="designation" class="form-control" 
                                           value="<?php echo htmlspecialchars($entity['designation']); ?>" required>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label required-field">Marque</label>
                                        <input type="text" name="marque" class="form-control" 
                                               value="<?php echo htmlspecialchars($entity['marque']); ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label required-field">Modèle</label>
                                        <input type="text" name="modele" class="form-control" 
                                               value="<?php echo htmlspecialchars($entity['modele']); ?>" required>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Type</label>
                                        <select name="id_type" class="form-control">
                                            <option value="">-- Sélectionner --</option>
                                            <?php foreach ($types_materiel as $type): ?>
                                                <option value="<?php echo $type['id_type']; ?>" 
                                                        <?php echo ($entity['id_type'] == $type['id_type']) ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($type['libelle']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Catégorie</label>
                                        <select name="categorie" class="form-control">
                                            <option value="Ordinateur" <?php echo ($entity['categorie'] === 'Ordinateur') ? 'selected' : ''; ?>>Ordinateur</option>
                                            <option value="Ram" <?php echo ($entity['categorie'] === 'Ram') ? 'selected' : ''; ?>>Ram</option>
                                            <option value="Alimentation Central" <?php echo ($entity['categorie'] === 'Alimentation Central') ? 'selected' : ''; ?>>Alimentation Central</option>
                                            <option value="Disque dur" <?php echo ($entity['categorie'] === 'Disque dur') ? 'selected' : ''; ?>>Disque dur</option>
                                            <option value="Autres" <?php echo ($entity['categorie'] === 'Autres') ? 'selected' : ''; ?>>Autres</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Statut</label>
                                        <input type="text" name="statut" class="form-control" 
                                               value="<?php echo htmlspecialchars($entity['statut']); ?>">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">État de besoin associé</label>
                                    <select name="id_etat" class="form-control">
                                        <option value="">-- Aucun --</option>
                                        <?php foreach ($besoins as $besoin): ?>
                                            <option value="<?php echo $besoin['id_besoin']; ?>" 
                                                    <?php echo ($entity['id_etat'] == $besoin['id_besoin']) ? 'selected' : ''; ?>>
                                                #<?php echo $besoin['id_besoin']; ?> - <?php echo htmlspecialchars($besoin['designation_materiel']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Caractéristiques générales</label>
                                    <textarea name="caracteristique" class="form-control" rows="3"><?php echo htmlspecialchars($entity['caracteristique']); ?></textarea>
                                </div>
                                <!-- Specific characteristics -->
                                <?php if (!empty($caracteristiques_type)): ?>
                                    <h6 class="mt-4 mb-3">Caractéristiques spécifiques</h6>
                                    <?php foreach ($caracteristiques_type as $carac): ?>
                                        <div class="mb-3">
                                            <label class="form-label"><?php echo htmlspecialchars($carac['libelle']); ?></label>
                                            <input type="text" 
                                                   name="caracteristiques[<?php echo $carac['id_type_carac']; ?>]" 
                                                   class="form-control" 
                                                   value="<?php echo htmlspecialchars($carac['valeur_acquise'] ?? ''); ?>">
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <!-- Besoin Form -->
                            <div class="form-section">
                                <h5 class="mb-3"><i class="fas fa-clipboard-list me-2"></i>Informations État de Besoin</h5>
                                <div class="row">
                                    <div class="col-md-8 mb-3">
                                        <label class="form-label required-field">Désignation du matériel</label>
                                        <input type="text" name="designation_materiel" class="form-control" 
                                               value="<?php echo htmlspecialchars($entity['designation_materiel']); ?>" required>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Date limite</label>
                                        <input type="date" name="date_limite" class="form-control" 
                                               value="<?php echo $entity['date_limite']; ?>">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label required-field">Justification</label>
                                    <textarea name="justification" class="form-control" rows="4" required><?php echo htmlspecialchars($entity['justification']); ?></textarea>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Demandeur</label>
                                        <input type="text" class="form-control readonly-field" 
                                               value="<?php echo htmlspecialchars($entity['agent_prenom'] . ' ' . $entity['agent_nom']); ?>" 
                                               readonly>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Statut</label>
                                        <select name="statut" class="form-control">
                                            <option value="en_attente" <?php echo ($entity['statut'] === 'en_attente') ? 'selected' : ''; ?>>En attente</option>
                                            <option value="pre_validee" <?php echo ($entity['statut'] === 'pre_validee') ? 'selected' : ''; ?>>Pré-validé</option>
                                            <option value="refusee_chef" <?php echo ($entity['statut'] === 'refusee_chef') ? 'selected' : ''; ?>>Refusé chef</option>
                                            <option value="en_attente_validation" <?php echo ($entity['statut'] === 'en_attente_validation') ? 'selected' : ''; ?>>En attente validation</option>
                                            <option value="validee_directeur" <?php echo ($entity['statut'] === 'validee_directeur') ? 'selected' : ''; ?>>Validé directeur</option>
                                            <option value="refusee_directeur" <?php echo ($entity['statut'] === 'refusee_directeur') ? 'selected' : ''; ?>>Refusé directeur</option>
                                            <option value="en_analyse_technique" <?php echo ($entity['statut'] === 'en_analyse_technique') ? 'selected' : ''; ?>>En analyse technique</option>
                                            <option value="en_acquisition" <?php echo ($entity['statut'] === 'en_acquisition') ? 'selected' : ''; ?>>En acquisition</option>
                                            <option value="attribuee" <?php echo ($entity['statut'] === 'attribuee') ? 'selected' : ''; ?>>Attribuée</option>
                                            <option value="cloturee" <?php echo ($entity['statut'] === 'cloturee') ? 'selected' : ''; ?>>Clôturée</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <!-- Action buttons -->
                        <div class="text-end">
                            <a href="list_<?php echo $entity_type; ?>.php" class="btn btn-outline-secondary me-2">
                                <i class="fas fa-times me-2"></i>Annuler
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Mettre à jour
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../../assets/js/bootstrap.bundle.min.js"></script>
<script>
// Form validation
document.getElementById('edit-form').addEventListener('submit', function(e) {
    const requiredFields = this.querySelectorAll('[required]');
    let hasErrors = false;
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('is-invalid');
            hasErrors = true;
        } else {
            field.classList.remove('is-invalid');
        }
    });
    if (hasErrors) {
        e.preventDefault();
        alert('Veuillez remplir tous les champs obligatoires.');
        return false;
    }
    return confirm('Confirmer la mise à jour de cet élément ?');
});
// Auto-dismiss alerts
setTimeout(function() {
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(alert => {
        const closeBtn = alert.querySelector('.btn-close');
        if (closeBtn) closeBtn.click();
    });
}, 5000);
</script>
</body>
</html>