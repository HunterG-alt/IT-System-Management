<?php
// Security check
if (!defined('ROOT_PATH')) {
    require_once '../Config/db.php';
}

// Define roles and statuses if not already defined
if (!defined('ROLE_DEMANDEUR')) define('ROLE_DEMANDEUR', 'demandeur');
if (!defined('ROLE_AGENT')) define('ROLE_AGENT', 'agent');
if (!defined('ROLE_CHEF_SERVICE')) define('ROLE_CHEF_SERVICE', 'chef_service');
if (!defined('ROLE_DIRECTEUR')) define('ROLE_DIRECTEUR', 'directeur');
if (!defined('ROLE_DIRECTEUR_GENERAL')) define('ROLE_DIRECTEUR_GENERAL', 'directeur_general');
if (!defined('ROLE_INFORMATIQUE')) define('ROLE_INFORMATIQUE', 'informatique');
if (!defined('ROLE_MOYENS_GENERAUX')) define('ROLE_MOYENS_GENERAUX', 'moyens_generaux');

// Request statuses
if (!defined('STATUS_EN_ATTENTE')) define('STATUS_EN_ATTENTE', 'en_attente');
if (!defined('STATUS_PRE_VALIDEE')) define('STATUS_PRE_VALIDEE', 'pre_validee');
if (!defined('STATUS_REFUSEE_CHEF')) define('STATUS_REFUSEE_CHEF', 'refusee_chef');
if (!defined('STATUS_EN_ATTENTE_VALIDATION')) define('STATUS_EN_ATTENTE_VALIDATION', 'en_attente_validation');
if (!defined('STATUS_VALIDEE_DIRECTEUR')) define('STATUS_VALIDEE_DIRECTEUR', 'validee_directeur');
if (!defined('STATUS_REFUSEE_DIRECTEUR')) define('STATUS_REFUSEE_DIRECTEUR', 'refusee_directeur');
if (!defined('STATUS_EN_ANALYSE_TECHNIQUE')) define('STATUS_EN_ANALYSE_TECHNIQUE', 'en_analyse_technique');
if (!defined('STATUS_EN_ACQUISITION')) define('STATUS_EN_ACQUISITION', 'en_acquisition');
if (!defined('STATUS_ATTRIBUEE')) define('STATUS_ATTRIBUEE', 'attribuee');
if (!defined('STATUS_CLOTUREE')) define('STATUS_CLOTUREE', 'cloturee');

// Role hierarchy for permission escalation
if (!defined('ROLE_HIERARCHY')) {
    define('ROLE_HIERARCHY', serialize([
        'demandeur' => 1,
        'agent' => 1,
        'chef_service' => 2,
        'directeur' => 3,
        'informatique' => 4,
        'moyens_generaux' => 4,
        'directeur_general' => 5
    ]));
}
class PermissionManager {
    private static $instance = null;
    private $cache = [];
    private $cache_ttl = 300; // 5 minutes
    /**
     * Singleton pattern
     */
    public static function getInstance(): PermissionManager {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    private function __construct() {}
    /**
     * Define system permissions and their hierarchies
     */
    const PERMISSIONS = [
        // User Management
        'users.view' => ['chef_service','directeur', 'directeur_general', 'informatique'],
        'users.create' => ['directeur','directeur_general', 'informatique'],
        'users.edit' => ['directeur','directeur_general', 'informatique'],
        'users.delete' => ['directeur_general', 'informatique'],
        'users.view_all' => ['directeur_general', 'informatique'],
        // Request Management - Updated workflow permissions
        'requests.create' => ['demandeur', 'chef_service','directeur', 'directeur_general', 'informatique', 'moyens_generaux'],
        'requests.view_own' => ['demandeur', 'chef_service','directeur', 'directeur_general', 'informatique', 'moyens_generaux'],
        'requests.view_department' => ['chef_service', 'directeur', 'directeur_general', 'informatique', 'moyens_generaux'],
        'requests.view_all' => ['directeur','directeur_general', 'informatique'],
        'requests.pre_approve' => ['chef_service'], // Chef service pre-validation
        'requests.approve' => ['directeur'], // Director validation
        'requests.reject' => ['chef_service', 'directeur'], // Pre-validation or validation rejection
        'requests.assign' => ['moyens_generaux', 'directeur_general'], // MG assigns after approval
        'requests.process' => ['moyens_generaux'], // MG processes approved requests
        'requests.complete' => ['moyens_generaux'], // MG marks as completed
        'requests.cancel' => ['directeur_general'], // Only DG can cancel
        'requests.edit' => ['demandeur', 'chef_service','directeur'], // Can't edit after submission to DG
        'requests.delete' => ['directeur_general'],
        'requests.track' => ['moyens_generaux'], // MG tracks procurement progress
        // Technical Analysis
        'analysis.create' => ['informatique'], // IT creates technical analysis
        'analysis.view' => ['informatique', 'moyens_generaux', 'directeur', 'directeur_general'],
        'analysis.edit' => ['informatique'],
        // Procurement specific permissions
        'procurement.initiate' => ['moyens_generaux'], // Start procurement process
        'procurement.vendor_select' => ['moyens_generaux'], // Select vendors
        'procurement.purchase' => ['moyens_generaux'], // Execute purchase
        'procurement.receive' => ['moyens_generaux'], // Receive goods
        'procurement.report' => ['moyens_generaux', 'directeur_general'], // Procurement reports
        // Asset Management
        'assets.view' => ['chef_service','directeur', 'directeur_general', 'informatique', 'moyens_generaux'],
        'assets.create' => ['informatique', 'moyens_generaux', 'directeur_general'],
        'assets.edit' => ['informatique', 'moyens_generaux', 'directeur_general'],
        'assets.delete' => ['directeur_general', 'informatique'],
        'assets.assign' => ['moyens_generaux', 'directeur_general'],
        'assets.maintenance' => ['informatique', 'moyens_generaux'],
        // Reports and Analytics
        'reports.view_basic' => ['chef_service','directeur', 'directeur_general', 'informatique', 'moyens_generaux'],
        'reports.view_advanced' => ['directeur_general', 'informatique'],
        'reports.export' => ['chef_service','directeur', 'directeur_general', 'informatique', 'moyens_generaux'],
        'reports.dashboard' => ['chef_service','directeur', 'directeur_general', 'informatique', 'moyens_generaux'],
        // System Administration
        'system.settings' => ['directeur_general', 'informatique'],
        'system.maintenance' => ['informatique'],
        'system.backup' => ['informatique'],
        'system.logs' => ['directeur_general', 'informatique'],
        'system.health' => ['informatique'],
        // Workflow Management
        'workflow.view' => ['chef_service','directeur', 'directeur_general', 'informatique', 'moyens_generaux'],
        'workflow.modify' => ['directeur_general', 'informatique'],
        'workflow.approve_final' => ['directeur_general'], // Final approval level
        'workflow.assign_tasks' => ['moyens_generaux', 'directeur_general'],
        // Notifications
        'notifications.send' => ['chef_service','directeur', 'directeur_general', 'informatique', 'moyens_generaux'],
        'notifications.broadcast' => ['directeur_general', 'informatique'],
        'notifications.manage' => ['informatique'],
        // Department specific
        'department.manage_own' => ['chef_service','directeur'],
        'department.view_all' => ['directeur_general', 'informatique'],
        'department.statistics' => ['chef_service','directeur', 'directeur_general', 'informatique']
    ];
    /**
     * Resource-specific permissions
     */
    const RESOURCE_PERMISSIONS = [
        'requests' => [
            'create' => 'requests.create',
            'view' => 'requests.view_own',
            'edit' => 'requests.edit',
            'delete' => 'requests.delete',
            'pre_approve' => 'requests.pre_approve',
            'approve' => 'requests.approve',
            'reject' => 'requests.reject',
            'process' => 'requests.process',
            'assign' => 'requests.assign'
        ],
        'users' => [
            'create' => 'users.create',
            'view' => 'users.view',
            'edit' => 'users.edit',
            'delete' => 'users.delete'
        ],
        'assets' => [
            'create' => 'assets.create',
            'view' => 'assets.view',
            'edit' => 'assets.edit',
            'delete' => 'assets.delete'
        ],
        'procurement' => [
            'initiate' => 'procurement.initiate',
            'vendor_select' => 'procurement.vendor_select',
            'purchase' => 'procurement.purchase',
            'receive' => 'procurement.receive',
            'report' => 'procurement.report'
        ],
        'analysis' => [
            'create' => 'analysis.create',
            'view' => 'analysis.view',
            'edit' => 'analysis.edit'
        ]
    ];
    /**
     * Check if current user has specific permission
     */
    public function hasPermission(string $permission, ?int $user_id = null): bool {
        $user_data = $this->getUserData($user_id);
        if (!$user_data) {
            return false;
        }
        $user_role = $user_data['role'];
        $cache_key = "perm_{$permission}_{$user_role}";
        // Check cache first
        if (isset($this->cache[$cache_key])) {
            $cached = $this->cache[$cache_key];
            if (time() - $cached['time'] < $this->cache_ttl) {
                return $cached['result'];
            }
        }
        $has_permission = $this->checkPermission($permission, $user_role, $user_data);
        // Cache result
        $this->cache[$cache_key] = [
            'result' => $has_permission,
            'time' => time()
        ];
        return $has_permission;
    }
    /**
     * Internal permission checking logic
     */
    private function checkPermission(string $permission, string $user_role, array $user_data): bool {
        // Check if permission exists
        if (!isset(self::PERMISSIONS[$permission])) {
            error_log("Unknown permission requested: {$permission}");
            return false;
        }
        $allowed_roles = self::PERMISSIONS[$permission];
        // Direct role check
        if (in_array($user_role, $allowed_roles)) {
            return true;
        }
        // Check role hierarchy for elevated permissions
        return $this->checkRoleHierarchy($user_role, $allowed_roles);
    }
    /**
     * Check if user role meets minimum requirement through hierarchy
     */
    private function checkRoleHierarchy(string $user_role, array $allowed_roles): bool {
        $user_level = ROLE_HIERARCHY[$user_role] ?? 0;
        foreach ($allowed_roles as $allowed_role) {
            $allowed_level = ROLE_HIERARCHY[$allowed_role] ?? 999;
            if ($user_level >= $allowed_level) {
                return true;
            }
        }
        return false;
    }
    /**
     * Check resource-specific permission
     */
    public function hasResourcePermission(string $resource_type, string $action, $resource_id = null, ?int $user_id = null): bool {
        $user_data = $this->getUserData($user_id);
        if (!$user_data) {
            return false;
        }
        // Get base permission
        $permission_map = self::RESOURCE_PERMISSIONS[$resource_type] ?? [];
        $base_permission = $permission_map[$action] ?? null;
        if (!$base_permission) {
            return false;
        }
        // Check base permission first
        if (!$this->hasPermission($base_permission, $user_data['id_agent'])) {
            return false;
        }
        // Additional resource-specific checks
        return $this->checkResourceOwnership($resource_type, $action, $resource_id, $user_data);
    }
    /**
     * Check resource ownership and department restrictions
     */
    private function checkResourceOwnership(string $resource_type, string $action, $resource_id, array $user_data): bool {
        if (!$resource_id) {
            return true; // No specific resource to check
        }
        $user_role = $user_data['role'];
        $user_id = $user_data['id_agent'];
        try {
            switch ($resource_type) {
                case 'requests':
                    return $this->checkRequestAccess($action, $resource_id, $user_id, $user_role);
                case 'users':
                    return $this->checkUserAccess($action, $resource_id, $user_id, $user_role);
                case 'assets':
                    return $this->checkAssetAccess($action, $resource_id, $user_id, $user_role);
                default:
                    return true;
            }
        } catch (Exception $e) {
            error_log("Error checking resource ownership: " . $e->getMessage());
            return false;
        }
    } 
    private function checkRequestAccess(string $action, int $request_id, int $user_id, string $user_role): bool {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM etat_de_besoin WHERE id_besoin = ?");
        $stmt->execute([$request_id]);
        $request = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$request) {
            return false;
        }
        switch ($action) {
            case 'view':
                // Agents can only view their own requests
                if ($user_role === ROLE_DEMANDEUR) {
                    return $request['id_agent'] == $user_id;
                }
                // Others can view based on their role permissions
                return true;
            case 'edit':
                // Own requests or higher authority
                if ($request['id_agent'] == $user_id) {
                    return in_array($request['statut'], [STATUS_EN_ATTENTE, STATUS_REFUSEE_CHEF]);
                }
                return in_array($user_role, [ROLE_CHEF_SERVICE, ROLE_DIRECTEUR]);
            case 'pre_approve':
                // Chef service can pre-validate
                if ($user_role !== ROLE_CHEF_SERVICE) {
                    return false;
                }
                // Cannot approve own requests
                if ($request['id_agent'] == $user_id) {
                    return false;
                }
                return $request['statut'] === STATUS_EN_ATTENTE;
            case 'approve':
                // Directors can validate after pre-validation
                if ($user_role !== ROLE_DIRECTEUR) {
                    return false;
                }
                // Cannot approve own requests
                if ($request['id_agent'] == $user_id) {
                    return false;
                }
                return $request['statut'] === STATUS_PRE_VALIDEE;
            case 'reject':
                // Chef service or Director can reject
                if (!in_array($user_role, [ROLE_CHEF_SERVICE, ROLE_DIRECTEUR])) {
                    return false;
                }
                // Cannot reject own requests
                if ($request['id_agent'] == $user_id) {
                    return false;
                }
                // Chef can reject during pre-validation, Director during validation
                if ($user_role === ROLE_CHEF_SERVICE) {
                    return $request['statut'] === STATUS_EN_ATTENTE;
                } elseif ($user_role === ROLE_DIRECTEUR) {
                    return $request['statut'] === STATUS_PRE_VALIDEE;
                }
                return false;
            case 'process':
            case 'assign':
                // Only Moyens Généraux can process after director validation
                if ($user_role !== ROLE_MOYENS_GENERAUX) {
                    return false;
                }
                // Can only process approved requests
                return $request['statut'] === STATUS_VALIDEE_DIRECTEUR;
            case 'complete':
                // Only Moyens Généraux can mark as complete
                return $user_role === ROLE_MOYENS_GENERAUX && 
                       in_array($request['statut'], [STATUS_EN_ACQUISITION, STATUS_ATTRIBUEE]);
            default:
                return true;
        }
    }
    /**
     * Check user-specific access permissions
     * 
     * @param string $action
     * @param int $target_user_id
     * @param int $user_id
     * @param string $user_role
     * @return bool
     */
    private function checkUserAccess(string $action, int $target_user_id, int $user_id, string $user_role): bool {
        // Can't modify self in certain contexts
        if ($action === 'delete' && $target_user_id == $user_id) {
            return false;
        }
        // Only directors and IT can manage users
        return in_array($user_role, [ROLE_DIRECTEUR, ROLE_INFORMATIQUE]);
    }
    /**
     * Check asset-specific access permissions
     * 
     * @param string $action
     * @param int $asset_id
     * @param int $user_id
     * @param string $user_role
     * @return bool
     */
    private function checkAssetAccess(string $action, int $asset_id, int $user_id, string $user_role): bool {
        // Basic role-based access for assets
        $allowed_roles = [ROLE_DIRECTEUR, ROLE_INFORMATIQUE, ROLE_MOYENS_GENERAUX];
        if ($action === 'view') {
            $allowed_roles[] = ROLE_CHEF_SERVICE;
        }
        return in_array($user_role, $allowed_roles);
    }
    /**
     * Get user data (with caching)
     * 
     * @param int|null $user_id
     * @return array|null
     */
    private function getUserData(?int $user_id = null): ?array {
        if ($user_id === null && isset($_SESSION['user_data'])) {
            return $_SESSION['user_data'];
        }
        if ($user_id === null) {
            return null;
        }
        $cache_key = "user_{$user_id}";
        if (isset($this->cache[$cache_key])) {
            $cached = $this->cache[$cache_key];
            if (time() - $cached['time'] < $this->cache_ttl) {
                return $cached['result'];
            }
        }
        try {
            global $pdo;
            $stmt = $pdo->prepare("SELECT * FROM agents WHERE id_agent = ?");
            $stmt->execute([$user_id]);
            $user_data = $stmt->fetch(PDO::FETCH_ASSOC);
            $this->cache[$cache_key] = [
                'result' => $user_data,
                'time' => time()
            ];
            return $user_data;
        } catch (Exception $e) {
            error_log("Error fetching user data: " . $e->getMessage());
            return null;
        }
    }
    /**
     * Get all permissions for a role
     * 
     * @param string $role
     * @return array
     */
    public function getRolePermissions(string $role): array {
        $permissions = [];
        foreach (self::PERMISSIONS as $permission => $allowed_roles) {
            if (in_array($role, $allowed_roles)) {
                $permissions[] = $permission;
            }
        }
        return $permissions;
    }
    /**
     * Clear permission cache
     */
    public function clearCache(): void {
        $this->cache = [];
    }
    /**
     * Log permission denial for security audit
     * 
     * @param string $permission
     * @param int|null $user_id
     * @param array $context
     */
    private function logPermissionDenial(string $permission, ?int $user_id, array $context = []): void {
        $user_data = $this->getUserData($user_id);
        $log_data = [
            'permission' => $permission,
            'user_id' => $user_id,
            'user_role' => $user_data['role'] ?? 'unknown',
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
            'timestamp' => date('c'),
            'context' => $context
        ];
        error_log("Permission denied: " . json_encode($log_data));
    }
}
/**
 * Authorization middleware functions
 */
class AuthMiddleware {
    /**
     * Require login - redirect if not authenticated
     * 
     * @param string $redirect_url
     */
    public static function requireLogin(string $redirect_url = '/login.php'): void {
        if (!isset($_SESSION['user_data'])) {
            $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
            header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/{$redirect_url}");
            exit;
        }
    }
    /**
     * Require specific permission - show 403 if denied
     * 
     * @param string $permission
     * @param string $error_message
     */
    public static function requirePermission(string $permission, string $error_message = null): void {
        self::requireLogin();
        $pm = PermissionManager::getInstance();
        if (!$pm->hasPermission($permission)) {
            http_response_code(403);
            $error_message = $error_message ?: "Vous n'avez pas l'autorisation d'accéder à cette ressource.";
            if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
                // AJAX request
                header('Content-Type: application/json');
                echo json_encode(['error' => $error_message, 'code' => 403]);
            } else {
                // Regular request
                include_once 'errors/403.php';
            }
            exit;
        }
    }
    /**
     * Require specific role
     * 
     * @param string $role
     * @param string $error_message
     */
    public static function requireRole(string $role, string $error_message = null): void {
        self::requireLogin();
        $user_data = $_SESSION['user_data'] ?? null;
        if (!$user_data || $user_data['role'] !== $role) {
            http_response_code(403);
            $error_message = $error_message ?: "Accès réservé aux {$role}.";
            if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
                header('Content-Type: application/json');
                echo json_encode(['error' => $error_message, 'code' => 403]);
            } else {
                include_once 'errors/403.php';
            }
            exit;
        }
    }
    /**
     * Require minimum role level
     * 
     * @param string $minimum_role
     * @param string $error_message
     */
    public static function requireMinimumRole(string $minimum_role, string $error_message = null): void {
        self::requireLogin();
        $user_data = $_SESSION['user_data'] ?? null;
        if (!$user_data) {
            http_response_code(403);
            exit;
        }
        $user_level = ROLE_HIERARCHY[$user_data['role']] ?? 0;
        $min_level = ROLE_HIERARCHY[$minimum_role] ?? 999;
        if ($user_level < $min_level) {
            http_response_code(403);
            $error_message = $error_message ?: "Niveau d'autorisation insuffisant.";
            if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
                header('Content-Type: application/json');
                echo json_encode(['error' => $error_message, 'code' => 403]);
            } else {
                include_once 'errors/403.php';
            }
            exit;
        }
    }
}
/**
 * Helper functions for templates
 */
/**
 * Check if current user has permission (template helper)
 * 
 * @param string $permission
 * @return bool
 */
function can(string $permission): bool {
    return PermissionManager::getInstance()->hasPermission($permission);
}
/**
 * Check if current user has resource permission (template helper)
 * 
 * @param string $resource_type
 * @param string $action
 * @param mixed $resource_id
 * @return bool
 */
function can_access(string $resource_type, string $action, $resource_id = null): bool {
    return PermissionManager::getInstance()->hasResourcePermission($resource_type, $action, $resource_id);
}
/**
 * Check if current user has specific role (template helper)
 * 
 * @param string $role
 * @return bool
 */
function is_role(string $role): bool {
    $user_data = $_SESSION['user_data'] ?? null;
    return $user_data && $user_data['role'] === $role;
}
/**
 * Check if current user has minimum role level (template helper)
 * 
 * @param string $minimum_role
 * @return bool
 */
function has_min_role(string $minimum_role): bool {
    $user_data = $_SESSION['user_data'] ?? null;
    if (!$user_data) {
        return false;
    }
    $user_level = ROLE_HIERARCHY[$user_data['role']] ?? 0;
    $min_level = ROLE_HIERARCHY[$minimum_role] ?? 999;
    return $user_level >= $min_level;
}
/**
 * Get current user role label (template helper)
 * 
 * @return string
 */
function current_role_label(): string {
    $user_data = $_SESSION['user_data'] ?? null;
    if (!$user_data) {
        return 'Non connecté';
    }
    $role_labels = [
        'demandeur' => 'Demandeur',
        'chef_service' => 'Chef de Service',
        'directeur' => 'Directeur',
        'directeur_general' => 'Directeur Général',
        'informatique' => 'Informatique',
        'moyens_generaux' => 'Moyens Généraux'
    ];
    return $role_labels[$user_data['role']] ?? $user_data['role'];
}
/**
 * Legacy compatibility functions
 */
/**
 * @deprecated Use PermissionManager::getInstance()->hasPermission() instead
 */
function check_permission(string $permission): bool {
    return PermissionManager::getInstance()->hasPermission($permission);
}
/**
 * @deprecated Use AuthMiddleware::requirePermission() instead
 */
function require_permission(string $permission): void {
    AuthMiddleware::requirePermission($permission);
}
/**
 * @deprecated Use AuthMiddleware::requireRole() instead
 */
function require_role(string $role): void {
    AuthMiddleware::requireRole($role);
}
?>
