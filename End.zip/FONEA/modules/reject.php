<?php
require_once '../Config/db.php'; // connexion à ta base de données
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requestId = $_POST['request_id'] ?? null;
    if ($requestId) {
        // Met à jour le statut de la demande
        $stmt = $pdo->prepare("UPDATE requests SET status = 'Rejeté' WHERE id = :id");
        $stmt->execute(['id' => $requestId]);
        // Redirige vers la liste avec un message de confirmation
        header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/Show/my_requests.php?msg=rejet");
        exit;
    } else {
        echo "Aucune demande spécifiée.";
    }
}
?>
