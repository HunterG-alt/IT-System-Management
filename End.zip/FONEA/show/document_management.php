<?php
require_once __DIR__ . '/../Config/session.php';
require_login();
require_once __DIR__ . '/../Config/db.php';
$user_role = $_SESSION['user']['role'] ?? '';
$user_id = $_SESSION['user']['id'] ?? 0;
$pdo = Database::getInstance()->getConnection();
// Handle file upload
if ($_POST['action'] ?? '' === 'upload_file') {
    $upload_dir = __DIR__ . '/../uploads/documents/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    if (isset($_FILES['document']) && $_FILES['document']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['document'];
        $allowed_types = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'jpeg', 'png', 'txt'];
        $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (in_array($file_extension, $allowed_types)) {
            $file_name = uniqid() . '_' . basename($file['name']);
            $file_path = $upload_dir . $file_name;
            if (move_uploaded_file($file['tmp_name'], $file_path)) {
                // Save to database
                $stmt = $pdo->prepare("
                    INSERT INTO documents (filename, original_name, file_path, file_size, file_type, uploaded_by, related_id, related_type, description, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                ");
                $stmt->execute([
                    $file_name,
                    $file['name'],
                    $file_path,
                    $file['size'],
                    $file_extension,
                    $user_id,
                    $_POST['related_id'] ?? null,
                    $_POST['related_type'] ?? 'general',
                    $_POST['description'] ?? '',
                ]);
                $success_message = "Document uploadé avec succès!";
            } else {
                $error_message = "Erreur lors de l'upload du fichier.";
            }
        } else {
            $error_message = "Type de fichier non autorisé.";
        }
    } else {
        $error_message = "Aucun fichier sélectionné ou erreur d'upload.";
    }
}
// Handle file deletion
if ($_POST['action'] ?? '' === 'delete_file') {
    $file_id = (int)$_POST['file_id'];
    // Get file info
    $stmt = $pdo->prepare("SELECT file_path FROM documents WHERE id = ? AND uploaded_by = ?");
    $stmt->execute([$file_id, $user_id]);
    $file_info = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($file_info) {
        // Delete physical file
        if (file_exists($file_info['file_path'])) {
            unlink($file_info['file_path']);
        }
        // Delete from database
        $stmt = $pdo->prepare("DELETE FROM documents WHERE id = ? AND uploaded_by = ?");
        $stmt->execute([$file_id, $user_id]);
        $success_message = "Document supprimé avec succès!";
    } else {
        $error_message = "Document non trouvé ou accès refusé.";
    }
}
// Get documents with filters
$filter_type = $_GET['type'] ?? '';
$search_term = $_GET['search'] ?? '';
$sort_by = $_GET['sort'] ?? 'created_at';
$sort_order = $_GET['order'] ?? 'DESC';
$where_conditions = [];
$params = [];
if (!empty($filter_type)) {
    $where_conditions[] = "file_type = ?";
    $params[] = $filter_type;
}
if (!empty($search_term)) {
    $where_conditions[] = "(original_name LIKE ? OR description LIKE ?)";
    $search_param = '%' . $search_term . '%';
    $params[] = $search_param;
    $params[] = $search_param;
}
$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
$documents_sql = "
    SELECT d.*, CONCAT(a.prenom, ' ', a.nom) as uploader_name
    FROM documents d
    LEFT JOIN agents a ON d.uploaded_by = a.id_agent
    $where_clause
    ORDER BY d.$sort_by $sort_order
";
$documents_stmt = $pdo->prepare($documents_sql);
$documents_stmt->execute($params);
$documents = $documents_stmt->fetchAll(PDO::FETCH_ASSOC);
// Get file type statistics
$stats = [
    'total_files' => $pdo->query("SELECT COUNT(*) FROM documents")->fetchColumn(),
    'total_size' => $pdo->query("SELECT SUM(file_size) FROM documents")->fetchColumn(),
    'pdf_count' => $pdo->query("SELECT COUNT(*) FROM documents WHERE file_type = 'pdf'")->fetchColumn(),
    'image_count' => $pdo->query("SELECT COUNT(*) FROM documents WHERE file_type IN ('jpg', 'jpeg', 'png')")->fetchColumn()
];
// Get file types for filter
$file_types = $pdo->query("SELECT DISTINCT file_type FROM documents ORDER BY file_type")->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Documents - FONEA</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="../Design/assets/style.css" rel="stylesheet">
    <style>
        .document-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 30px 30px;
        }
        .upload-zone {
            border: 3px dashed #d1d5db;
            border-radius: 20px;
            padding: 3rem;
            text-align: center;
            background: #f9fafb;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .upload-zone:hover,
        .upload-zone.dragover {
            border-color: #667eea;
            background: #f0f4ff;
            transform: translateY(-2px);
        }
        .upload-zone.dragover {
            border-color: #4f46e5;
            background: #eef2ff;
        }
        .document-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            border-left: 4px solid #e5e7eb;
        }
        .document-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            border-left-color: #667eea;
        }
        .file-icon {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            margin-right: 1rem;
        }
        .file-pdf { background: linear-gradient(135deg, #ef4444, #dc2626); }
        .file-doc, .file-docx { background: linear-gradient(135deg, #3b82f6, #1d4ed8); }
        .file-xls, .file-xlsx { background: linear-gradient(135deg, #10b981, #059669); }
        .file-jpg, .file-jpeg, .file-png { background: linear-gradient(135deg, #f59e0b, #d97706); }
        .file-txt { background: linear-gradient(135deg, #6b7280, #4b5563); }
        .file-default { background: linear-gradient(135deg, #8b5cf6, #7c3aed); }
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
        }
        .stat-card.files::before { background: linear-gradient(90deg, #667eea, #764ba2); }
        .stat-card.size::before { background: linear-gradient(90deg, #10b981, #059669); }
        .stat-card.pdf::before { background: linear-gradient(90deg, #ef4444, #dc2626); }
        .stat-card.images::before { background: linear-gradient(90deg, #f59e0b, #d97706); }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.12);
        }
        .filter-section {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        .upload-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
            font-size: 1.5rem;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
            transition: all 0.3s ease;
            z-index: 1000;
        }
        .upload-btn:hover {
            transform: scale(1.1);
            box-shadow: 0 15px 40px rgba(102, 126, 234, 0.4);
        }
        .progress-bar-custom {
            height: 8px;
            border-radius: 4px;
            background: #e5e7eb;
            overflow: hidden;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #667eea, #764ba2);
            border-radius: 4px;
            transition: width 0.3s ease;
        }
        .file-preview {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 10px;
            border: 2px solid #e5e7eb;
        }
        @media (max-width: 768px) {
            .upload-zone {
                padding: 2rem 1rem;
            }
            .upload-btn {
                bottom: 20px;
                right: 20px;
                width: 50px;
                height: 50px;
                font-size: 1.2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
        <div class="container">
            <a class="navbar-brand fw-bold" href="../show/enhanced_dashboard.php">
                <i class="fas fa-building me-2"></i>FONEA
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../show/enhanced_dashboard.php"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../show/content.php"><i class="fas fa-list me-2"></i>Demandes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#"><i class="fas fa-folder me-2"></i>Documents</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../public/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Déconnexion</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Header -->
    <div class="document-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="display-5 fw-bold mb-0">
                        <i class="fas fa-folder-open me-3"></i>Gestion des Documents
                    </h1>
                    <p class="lead opacity-75 mb-0">Stockage et organisation centralisée des fichiers</p>
                </div>
                <div class="col-md-4 text-end">
                    <div class="d-none d-md-block">
                        <i class="fas fa-cloud-upload-alt" style="font-size: 4rem; opacity: 0.2;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <!-- Statistics -->
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="stat-card files text-center">
                    <div class="mb-3">
                        <i class="fas fa-file text-primary" style="font-size: 2.5rem;"></i>
                    </div>
                    <h3 class="fw-bold"><?= number_format($stats['total_files']) ?></h3>
                    <p class="text-muted mb-0">Fichiers Total</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="stat-card size text-center">
                    <div class="mb-3">
                        <i class="fas fa-hdd text-success" style="font-size: 2.5rem;"></i>
                    </div>
                    <h3 class="fw-bold"><?= formatBytes($stats['total_size']) ?></h3>
                    <p class="text-muted mb-0">Espace Utilisé</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="stat-card pdf text-center">
                    <div class="mb-3">
                        <i class="fas fa-file-pdf text-danger" style="font-size: 2.5rem;"></i>
                    </div>
                    <h3 class="fw-bold"><?= $stats['pdf_count'] ?></h3>
                    <p class="text-muted mb-0">Documents PDF</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="stat-card images text-center">
                    <div class="mb-3">
                        <i class="fas fa-image text-warning" style="font-size: 2.5rem;"></i>
                    </div>
                    <h3 class="fw-bold"><?= $stats['image_count'] ?></h3>
                    <p class="text-muted mb-0">Images</p>
                </div>
            </div>
        </div>
        <!-- Upload Zone -->
        <div class="upload-zone" id="uploadZone" onclick="document.getElementById('fileInput').click()">
            <div class="mb-3">
                <i class="fas fa-cloud-upload-alt text-primary" style="font-size: 3rem;"></i>
            </div>
            <h4 class="fw-bold text-primary">Glissez vos fichiers ici</h4>
            <p class="text-muted mb-3">ou cliquez pour sélectionner des fichiers</p>
            <small class="text-muted">
                Formats supportés: PDF, DOC, DOCX, XLS, XLSX, JPG, JPEG, PNG, TXT<br>
                Taille maximale: 10 MB par fichier
            </small>
            <input type="file" id="fileInput" multiple style="display: none;" accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png,.txt">
        </div>
        <!-- Upload Progress -->
        <div id="uploadProgress" style="display: none;" class="mb-4">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Upload en cours...</h6>
                    <div class="progress-bar-custom">
                        <div class="progress-fill" id="progressFill" style="width: 0%"></div>
                    </div>
                    <small class="text-muted mt-2 d-block" id="progressText">0%</small>
                </div>
            </div>
        </div>
        <!-- Filters -->
        <div class="filter-section">
            <form method="GET" class="row align-items-end">
                <div class="col-md-4">
                    <label class="form-label fw-bold">Rechercher</label>
                    <input type="text" name="search" class="form-control" placeholder="Nom de fichier ou description..." value="<?= htmlspecialchars($search_term) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold">Type de fichier</label>
                    <select name="type" class="form-select">
                        <option value="">Tous les types</option>
                        <?php foreach ($file_types as $type): ?>
                            <option value="<?= htmlspecialchars($type) ?>" <?= $filter_type === $type ? 'selected' : '' ?>>
                                <?= strtoupper($type) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold">Trier par</label>
                    <select name="sort" class="form-select">
                        <option value="created_at" <?= $sort_by === 'created_at' ? 'selected' : '' ?>>Date d'ajout</option>
                        <option value="original_name" <?= $sort_by === 'original_name' ? 'selected' : '' ?>>Nom</option>
                        <option value="file_size" <?= $sort_by === 'file_size' ? 'selected' : '' ?>>Taille</option>
                        <option value="file_type" <?= $sort_by === 'file_type' ? 'selected' : '' ?>>Type</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-2"></i>Filtrer
                    </button>
                </div>
            </form>
        </div>
        <!-- Documents List -->
        <div class="row">
            <?php foreach ($documents as $doc): ?>
                <div class="col-lg-6 col-xl-4">
                    <div class="document-card">
                        <div class="d-flex align-items-start">
                            <div class="file-icon file-<?= $doc['file_type'] ?>">
                                <?php
                                $icon_map = [
                                    'pdf' => 'fa-file-pdf',
                                    'doc' => 'fa-file-word', 'docx' => 'fa-file-word',
                                    'xls' => 'fa-file-excel', 'xlsx' => 'fa-file-excel',
                                    'jpg' => 'fa-file-image', 'jpeg' => 'fa-file-image', 'png' => 'fa-file-image',
                                    'txt' => 'fa-file-alt'
                                ];
                                $icon = $icon_map[$doc['file_type']] ?? 'fa-file';
                                ?>
                                <i class="fas <?= $icon ?>"></i>
                            </div>
                            <div class="flex-grow-1">
                                <h6 class="fw-bold mb-1"><?= htmlspecialchars($doc['original_name']) ?></h6>
                                <?php if (!empty($doc['description'])): ?>
                                    <p class="text-muted small mb-2"><?= htmlspecialchars($doc['description']) ?></p>
                                <?php endif; ?>
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <small class="text-muted"><?= formatBytes($doc['file_size']) ?></small>
                                    <small class="text-muted"><?= date('d/m/Y H:i', strtotime($doc['created_at'])) ?></small>
                                </div>
                                <small class="text-muted">
                                    <i class="fas fa-user me-1"></i>
                                    <?= htmlspecialchars($doc['uploader_name']) ?>
                                </small>
                            </div>
                        </div>
                        <div class="mt-3 d-flex gap-2">
                            <a href="download.php?id=<?= $doc['id'] ?>" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-download me-1"></i>Télécharger
                            </a>
                            <?php if ($doc['uploaded_by'] == $user_id || in_array($user_role, ['directeur', 'directeur_general'])): ?>
                                <button class="btn btn-sm btn-outline-danger" onclick="deleteDocument(<?= $doc['id'] ?>)">
                                    <i class="fas fa-trash me-1"></i>Supprimer
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php if (empty($documents)): ?>
            <div class="text-center py-5">
                <i class="fas fa-folder-open text-muted" style="font-size: 4rem;"></i>
                <h4 class="mt-3 text-muted">Aucun document trouvé</h4>
                <p class="text-muted">Commencez par uploader vos premiers documents</p>
            </div>
        <?php endif; ?>
    </div>
    <!-- Upload Button -->
    <button class="upload-btn" data-bs-toggle="modal" data-bs-target="#uploadModal">
        <i class="fas fa-plus"></i>
    </button>
    <!-- Upload Modal -->
    <div class="modal fade" id="uploadModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-upload me-2"></i>Uploader un Document
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="upload_file">
                        <div class="mb-3">
                            <label class="form-label">Fichier *</label>
                            <input type="file" name="document" class="form-control" required accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png,.txt">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description" class="form-control" rows="3" placeholder="Description du document..."></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Lié à une demande</label>
                            <select name="related_id" class="form-select">
                                <option value="">Aucune demande spécifique</option>
                                <!-- Add options for existing requests -->
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-upload me-2"></i>Uploader
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script>
        // Drag and drop functionality
        const uploadZone = document.getElementById('uploadZone');
        const fileInput = document.getElementById('fileInput');
        uploadZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadZone.classList.add('dragover');
        });
        uploadZone.addEventListener('dragleave', () => {
            uploadZone.classList.remove('dragover');
        });
        uploadZone.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadZone.classList.remove('dragover');
            const files = e.dataTransfer.files;
            handleFiles(files);
        });
        fileInput.addEventListener('change', (e) => {
            handleFiles(e.target.files);
        });
        function handleFiles(files) {
            if (files.length > 0) {
                // Show upload progress
                document.getElementById('uploadProgress').style.display = 'block';
                // Simulate upload progress (replace with actual upload logic)
                let progress = 0;
                const interval = setInterval(() => {
                    progress += 10;
                    document.getElementById('progressFill').style.width = progress + '%';
                    document.getElementById('progressText').textContent = progress + '%';
                    if (progress >= 100) {
                        clearInterval(interval);
                        setTimeout(() => {
                            document.getElementById('uploadProgress').style.display = 'none';
                            alert('Upload terminé!');
                        }, 500);
                    }
                }, 200);
            }
        }
        function deleteDocument(id) {
            if (confirm('Êtes-vous sûr de vouloir supprimer ce document ?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="delete_file">
                    <input type="hidden" name="file_id" value="${id}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
        // Success/Error message handling
        <?php if (isset($success_message)): ?>
            alert('<?= $success_message ?>');
        <?php endif; ?>
        <?php if (isset($error_message)): ?>
            alert('<?= $error_message ?>');
        <?php endif; ?>
    </script>
</body>
</html>
<?php
function formatBytes($size, $precision = 2) {
    $base = log($size, 1024);
    $suffixes = array('B', 'KB', 'MB', 'GB', 'TB');
    return round(pow(1024, $base - floor($base)), $precision) . ' ' . $suffixes[floor($base)];
}
?>
