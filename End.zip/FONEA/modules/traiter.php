<?php
require_once '../Config/db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requestId = $_POST['request_id'] ?? null;
    if ($requestId) {
        $stmt = $pdo->prepare("UPDATE requests SET status='En cours de traitement' WHERE id=:id");
        $stmt->execute(['id' => $requestId]);
        header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/Show/my_requests.php?msg=traiter");
        exit;
    } else {
        echo "Aucune demande spécifiée.";
    }
}
?>
