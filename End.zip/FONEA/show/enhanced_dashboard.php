<?php
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../include/besoin.php';
require_once __DIR__ . '/../public/user.php';
require_once __DIR__ . '/../include/materiel.php';
// Check user role
$user_role = $_SESSION['user']['role'] ?? '';
$user_id = $_SESSION['user']['id'] ?? 0;
$pdo = Database::getInstance()->getConnection();
// Get comprehensive statistics
$stats = [
    'total_requests' => $pdo->query("SELECT COUNT(*) FROM etat_de_besoin")->fetchColumn(),
    'pending_requests' => $pdo->query("SELECT COUNT(*) FROM etat_de_besoin WHERE statut='en_attente'")->fetchColumn(),
    'approved_requests' => $pdo->query("SELECT COUNT(*) FROM etat_de_besoin WHERE statut='validee_directeur'")->fetchColumn(),
    'rejected_requests' => $pdo->query("SELECT COUNT(*) FROM etat_de_besoin WHERE statut='refusee_directeur'")->fetchColumn(),
    'total_equipment' => $pdo->query("SELECT COUNT(*) FROM materiel")->fetchColumn(),
    'total_users' => $pdo->query("SELECT COUNT(*) FROM agents")->fetchColumn(),
    'acquisitions' => $pdo->query("SELECT COUNT(*) FROM acquisition")->fetchColumn()
];
// Get monthly statistics for charts
$monthly_stats = $pdo->query("
    SELECT 
        MONTH(date_soumission) as month,
        YEAR(date_soumission) as year,
        COUNT(*) as count,
        statut
    FROM etat_de_besoin 
    WHERE date_soumission >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
    GROUP BY YEAR(date_soumission), MONTH(date_soumission), statut
    ORDER BY year, month
")->fetchAll(PDO::FETCH_ASSOC);
// Get recent activities
$recent_activities = $pdo->query("
    SELECT 
        b.id_besoin,
        b.designation_materiel,
        b.statut,
        b.date_soumission,
        CONCAT(a.prenom, ' ', a.nom) as agent_name
    FROM etat_de_besoin b
    JOIN agents a ON b.id_agent = a.id_agent
    ORDER BY b.date_soumission DESC
    LIMIT 10
")->fetchAll(PDO::FETCH_ASSOC);
// Get equipment categories
$equipment_categories = $pdo->query("
    SELECT 
        categorie,
        COUNT(*) as count
    FROM materiel 
    GROUP BY categorie
    ORDER BY count DESC
")->fetchAll(PDO::FETCH_ASSOC);
// Get notifications (placeholder for now)
$notifications = [];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Avancé - FONEA</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="../Design/assets/style.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --success-gradient: linear-gradient(135deg, #4ade80 0%, #16a34a 100%);
            --warning-gradient: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%);
            --danger-gradient: linear-gradient(135deg, #f87171 0%, #ef4444 100%);
            --info-gradient: linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%);
            --dark-gradient: linear-gradient(135deg, #374151 0%, #1f2937 100%);
        }
        body {
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            font-family: 'Inter', 'Segoe UI', sans-serif;
            min-height: 100vh;
        }
        .dashboard-header {
            background: var(--primary-gradient);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 30px 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            border: 1px solid rgba(255,255,255,0.2);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--primary-gradient);
        }
        .stat-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.12);
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: 800;
            margin: 0.5rem 0;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            margin-bottom: 1rem;
        }
        .chart-container {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            height: 400px;
        }
        .activity-item {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            border-left: 4px solid;
            transition: all 0.3s ease;
        }
        .activity-item:hover {
            transform: translateX(5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        .status-pending { border-left-color: #fbbf24; }
        .status-approved { border-left-color: #10b981; }
        .status-rejected { border-left-color: #ef4444; }
        .quick-action-btn {
            background: white;
            border: 2px solid #e5e7eb;
            border-radius: 15px;
            padding: 1.5rem;
            text-decoration: none;
            color: #374151;
            display: block;
            transition: all 0.3s ease;
            margin-bottom: 1rem;
        }
        .quick-action-btn:hover {
            border-color: #667eea;
            color: #667eea;
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.15);
        }
        .notification-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: #ef4444;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .progress-ring {
            width: 120px;
            height: 120px;
            margin: 0 auto;
        }
        .progress-ring-circle {
            stroke: #e5e7eb;
            stroke-width: 8;
            fill: transparent;
            r: 52;
            cx: 60;
            cy: 60;
        }
        .progress-ring-progress {
            stroke: #667eea;
            stroke-width: 8;
            stroke-linecap: round;
            fill: transparent;
            r: 52;
            cx: 60;
            cy: 60;
            stroke-dasharray: 326.73;
            stroke-dashoffset: 326.73;
            transform: rotate(-90deg);
            transform-origin: 60px 60px;
            transition: stroke-dashoffset 1s ease-in-out;
        }
        @media (max-width: 768px) {
            .dashboard-header {
                padding: 1.5rem 0;
            }
            .stat-card {
                padding: 1.5rem;
            }
            .chart-container {
                height: 300px;
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark" style="background: var(--primary-gradient);">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">
                <i class="fas fa-building me-2"></i>FONEA
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="../show/dashboard_dg.php"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../include/demande.php"><i class="fas fa-list me-2"></i>Demandes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../show/equipement.php"><i class="fas fa-boxes me-2"></i>Équipements</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle position-relative" href="#" id="notificationDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-bell"></i>
                            <?php if(count($notifications) > 0): ?>
                                <span class="notification-badge"><?= count($notifications) ?></span>
                            <?php endif; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php if(empty($notifications)): ?>
                                <li><span class="dropdown-item text-muted">Aucune notification</span></li>
                            <?php else: ?>
                                <?php foreach($notifications as $notif): ?>
                                    <li><a class="dropdown-item" href="#"><?= htmlspecialchars($notif['message']) ?></a></li>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../public/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Déconnexion</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Header -->
    <div class="dashboard-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="display-5 fw-bold mb-0">
                        <i class="fas fa-chart-line me-3"></i>Dashboard Avancé
                    </h1>
                    <p class="lead opacity-75 mb-0">Vue d'ensemble complète du système FONEA</p>
                </div>
                <div class="col-md-4 text-end">
                    <div class="d-none d-md-block">
                        <i class="fas fa-analytics" style="font-size: 4rem; opacity: 0.2;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <!-- Statistics Overview -->
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="stat-card text-center">
                    <div class="stat-icon mx-auto" style="background: var(--primary-gradient);">
                        <i class="fas fa-clipboard-list"></i>
                    </div>
                    <h6 class="text-muted text-uppercase fw-bold">Total Demandes</h6>
                    <div class="stat-number"><?= $stats['total_requests'] ?></div>
                    <small class="text-muted">Toutes les demandes</small>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="stat-card text-center">
                    <div class="stat-icon mx-auto" style="background: var(--warning-gradient);">
                        <i class="fas fa-clock"></i>
                    </div>
                    <h6 class="text-muted text-uppercase fw-bold">En Attente</h6>
                    <div class="stat-number"><?= $stats['pending_requests'] ?></div>
                    <small class="text-muted">À traiter</small>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="stat-card text-center">
                    <div class="stat-icon mx-auto" style="background: var(--success-gradient);">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <h6 class="text-muted text-uppercase fw-bold">Approuvées</h6>
                    <div class="stat-number"><?= $stats['approved_requests'] ?></div>
                    <small class="text-muted">Validées</small>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="stat-card text-center">
                    <div class="stat-icon mx-auto" style="background: var(--info-gradient);">
                        <i class="fas fa-laptop"></i>
                    </div>
                    <h6 class="text-muted text-uppercase fw-bold">Équipements</h6>
                    <div class="stat-number"><?= $stats['total_equipment'] ?></div>
                    <small class="text-muted">En stock</small>
                </div>
            </div>
        </div>
        <!-- Charts Row -->
        <div class="row">
            <div class="col-lg-8">
                <div class="chart-container">
                    <h5 class="fw-bold mb-4">
                        <i class="fas fa-chart-bar text-primary me-2"></i>
                        Évolution des Demandes (12 derniers mois)
                    </h5>
                    <canvas id="requestsChart"></canvas>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="chart-container">
                    <h5 class="fw-bold mb-4">
                        <i class="fas fa-pie-chart text-primary me-2"></i>
                        Répartition par Statut
                    </h5>
                    <canvas id="statusChart"></canvas>
                </div>
            </div>
        </div>
        <!-- Activity and Actions Row -->
        <div class="row">
            <div class="col-lg-8">
                <div class="chart-container">
                    <h5 class="fw-bold mb-4">
                        <i class="fas fa-history text-primary me-2"></i>
                        Activités Récentes
                    </h5>
                    <div class="activity-list" style="max-height: 300px; overflow-y: auto;">
                        <?php foreach($recent_activities as $activity): ?>
                            <div class="activity-item status-<?= $activity['statut'] === 'en_attente' ? 'pending' : ($activity['statut'] === 'validee_directeur' ? 'approved' : 'rejected') ?>">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1 fw-bold"><?= htmlspecialchars($activity['designation_materiel']) ?></h6>
                                        <small class="text-muted">Par <?= htmlspecialchars($activity['agent_name']) ?></small>
                                    </div>
                                    <div class="text-end">
                                        <span class="badge bg-<?= $activity['statut'] === 'en_attente' ? 'warning' : ($activity['statut'] === 'validee_directeur' ? 'success' : 'danger') ?>">
                                            <?= ucfirst(str_replace('_', ' ', $activity['statut'])) ?>
                                        </span>
                                        <br>
                                        <small class="text-muted"><?= date('d/m/Y H:i', strtotime($activity['date_soumission'])) ?></small>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="chart-container">
                    <h5 class="fw-bold mb-4">
                        <i class="fas fa-rocket text-primary me-2"></i>
                        Actions Rapides
                    </h5>
                    <div class="quick-actions">
                        <a href="../public/create.php" class="quick-action-btn">
                            <div class="d-flex align-items-center">
                                <div class="stat-icon me-3" style="background: var(--success-gradient); width: 50px; height: 50px;">
                                    <i class="fas fa-plus"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">Nouvelle Demande</h6>
                                    <small class="text-muted">Créer un état de besoin</small>
                                </div>
                            </div>
                        </a>
                        <a href="../show/content.php" class="quick-action-btn">
                            <div class="d-flex align-items-center">
                                <div class="stat-icon me-3" style="background: var(--info-gradient); width: 50px; height: 50px;">
                                    <i class="fas fa-list"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">Voir Demandes</h6>
                                    <small class="text-muted">Consulter toutes les demandes</small>
                                </div>
                            </div>
                        </a>
                        <a href="#" class="quick-action-btn">
                            <div class="d-flex align-items-center">
                                <div class="stat-icon me-3" style="background: var(--warning-gradient); width: 50px; height: 50px;">
                                    <i class="fas fa-chart-line"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">Rapports</h6>
                                    <small class="text-muted">Générer des rapports</small>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script>
        // Requests Evolution Chart
        const ctx1 = document.getElementById('requestsChart').getContext('2d');
        const requestsChart = new Chart(ctx1, {
            type: 'line',
            data: {
                labels: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'],
                datasets: [{
                    label: 'Demandes soumises',
                    data: [12, 19, 3, 5, 2, 3, 10, 15, 8, 12, 6, 9],
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0,0,0,0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        // Status Distribution Chart
        const ctx2 = document.getElementById('statusChart').getContext('2d');
        const statusChart = new Chart(ctx2, {
            type: 'doughnut',
            data: {
                labels: ['En Attente', 'Approuvées', 'Rejetées'],
                datasets: [{
                    data: [<?= $stats['pending_requests'] ?>, <?= $stats['approved_requests'] ?>, <?= $stats['rejected_requests'] ?>],
                    backgroundColor: ['#fbbf24', '#10b981', '#ef4444'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                }
            }
        });
        // Add hover effects and animations
        document.addEventListener('DOMContentLoaded', function() {
            // Animate stat cards on scroll
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, observerOptions);
            document.querySelectorAll('.stat-card').forEach(card => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'all 0.6s ease';
                observer.observe(card);
            });
            // Auto-refresh data every 5 minutes
            setInterval(() => {
                if (!document.hidden) {
                    location.reload();
                }
            }, 300000);
        });
    </script>
</body>
</html>
