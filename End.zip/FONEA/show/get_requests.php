<?php
// Set proper headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // For CORS if needed
try {
    // Sample data - replace with database query in production
    $requests = [
        [
            "name" => "Ordinateur Portable",
            "status" => "En attente",
            "submitted" => "2025-09-13 09:00:00",
            "icon" => "fas fa-laptop"
        ],
        [
            "name" => "Imprimante Bureau",
            "status" => "Approuvée",
            "submitted" => "2025-09-08 10:00:00",
            "icon" => "fas fa-print"
        ],
        [
            "name" => "Chaise Ergonomique",
            "status" => "Livrée",
            "submitted" => "2025-08-31 14:00:00",
            "icon" => "fas fa-chair"
        ]
    ];
    // In production, you might fetch from database like this:
    /*
    try {
        $pdo = new PDO("mysql:host=localhost;dbname=yourdb;charset=utf8", "user", "pass", [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
        $stmt = $pdo->prepare("
            SELECT name, status, submitted, icon 
            FROM requests 
            WHERE user_id = ? 
            ORDER BY submitted DESC
        ");
        $stmt->execute([$_SESSION['user_id'] ?? 1]);
        $requests = $stmt->fetchAll();
    } catch (PDOException $e) {
        throw new Exception("Database error occurred");
    }
    */
    // Validate data structure
    foreach ($requests as &$request) {
        // Ensure all required fields exist
        if (!isset($request['name']) || !isset($request['status']) || 
            !isset($request['submitted']) || !isset($request['icon'])) {
            throw new Exception("Invalid request data structure");
        }
        // Sanitize data
        $request['name'] = htmlspecialchars($request['name'], ENT_QUOTES, 'UTF-8');
        $request['status'] = htmlspecialchars($request['status'], ENT_QUOTES, 'UTF-8');
        $request['icon'] = htmlspecialchars($request['icon'], ENT_QUOTES, 'UTF-8');
        // Validate date format
        if (!strtotime($request['submitted'])) {
            $request['submitted'] = date('Y-m-d H:i:s'); // fallback to current time
        }
    }
    // Return successful response
    echo json_encode($requests, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
} catch (Exception $e) {
    // Log error for debugging (in production)
    error_log("Error in get_requests.php: " . $e->getMessage());
    // Return error response
    http_response_code(500);
    echo json_encode([
        'error' => 'An error occurred while fetching requests',
        'message' => $e->getMessage() // Remove this in production for security
    ], JSON_UNESCAPED_UNICODE);
}
?>