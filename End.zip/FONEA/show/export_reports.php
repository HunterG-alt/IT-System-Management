<?php
require_once __DIR__ . '/../Config/session.php';
require_login();
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../Lib/pdf.php';
$user_role = $_SESSION['user']['role'] ?? '';
$user_id = $_SESSION['user']['id'] ?? 0;
$pdo = Database::getInstance()->getConnection();
// Handle export requests
if ($_POST['action'] ?? '' === 'export') {
    $export_type = $_POST['export_type'] ?? 'pdf';
    $report_type = $_POST['report_type'] ?? 'requests';
    $date_from = $_POST['date_from'] ?? '';
    $date_to = $_POST['date_to'] ?? '';
    switch ($report_type) {
        case 'requests':
            exportRequestsReport($export_type, $date_from, $date_to);
            break;
        case 'inventory':
            exportInventoryReport($export_type);
            break;
        case 'analytics':
            exportAnalyticsReport($export_type, $date_from, $date_to);
            break;
    }
}
function exportRequestsReport($type, $date_from, $date_to) {
    global $pdo;
    $where_clause = '';
    $params = [];
    if ($date_from && $date_to) {
        $where_clause = 'WHERE DATE(b.date_soumission) BETWEEN ? AND ?';
        $params = [$date_from, $date_to];
    }
    $sql = "
        SELECT 
            b.id_besoin,
            b.designation_materiel,
            b.justification,
            b.statut,
            b.date_soumission,
            CONCAT(a.prenom, ' ', a.nom) as agent_name
        FROM etat_de_besoin b
        JOIN agents a ON b.id_agent = a.id_agent
        $where_clause
        ORDER BY b.date_soumission DESC
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if ($type === 'csv') {
        exportToCSV($data, 'rapport_demandes_' . date('Y-m-d') . '.csv');
    } else {
        exportToPDF($data, 'Rapport des Demandes', 'rapport_demandes_' . date('Y-m-d') . '.pdf');
    }
}
function exportToCSV($data, $filename) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);
    $output = fopen('php://output', 'w');
    if (!empty($data)) {
        fputcsv($output, array_keys($data[0]));
        foreach ($data as $row) {
            fputcsv($output, $row);
        }
    }
    fclose($output);
    exit;
}
function exportToPDF($data, $title, $filename) {
    // Basic PDF generation - you can enhance this with a proper PDF library
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename=' . $filename);
    // Simple PDF content (replace with proper PDF library implementation)
    echo "PDF Report: $title\n\n";
    foreach ($data as $row) {
        foreach ($row as $key => $value) {
            echo "$key: $value\n";
        }
        echo "\n---\n\n";
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Export de Rapports - FONEA</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="../Design/assets/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
        <div class="container">
            <a class="navbar-brand fw-bold" href="../show/enhanced_dashboard.php">
                <i class="fas fa-building me-2"></i>FONEA
            </a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../show/enhanced_dashboard.php"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#"><i class="fas fa-download me-2"></i>Export</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-4">
        <h1 class="display-6 fw-bold mb-4">
            <i class="fas fa-file-export text-primary me-3"></i>Export de Rapports
        </h1>
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="action" value="export">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Type de rapport</label>
                                <select name="report_type" class="form-select" required>
                                    <option value="requests">Rapport des demandes</option>
                                    <option value="inventory">Rapport d'inventaire</option>
                                    <option value="analytics">Rapport analytique</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Format d'export</label>
                                <select name="export_type" class="form-select" required>
                                    <option value="pdf">PDF</option>
                                    <option value="csv">CSV (Excel)</option>
                                </select>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Date de début</label>
                                        <input type="date" name="date_from" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Date de fin</label>
                                        <input type="date" name="date_to" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-download me-2"></i>Générer et Télécharger
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
