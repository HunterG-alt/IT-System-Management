<?php
// equipement_etat.php
require_once '../Config/db.php'; // PDO connection
// Fetch equipment state counts
try {
    $stmt = $pdo->query("
        SELECT statut, COUNT(*) AS count
        FROM materiel
        GROUP BY statut
    ");
    $equipmentData = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $labels = [];
    $counts = [];
    foreach ($equipmentData as $row) {
        $labels[] = ucfirst($row['statut']);
        $counts[] = $row['count'];
    }
} catch (PDOException $e) {
    die("Erreur SQL : " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>État des Équipements</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: linear-gradient(135deg, #e0f7ff, #ffffff);
        }
        .side-panel {
            background: rgba(255, 255, 255, 0.25);
            border-radius: 15px;
            padding: 20px;
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 0 auto;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .side-panel:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
        }
        .panel-title {
            font-size: 20px;
            color: #0d47a1;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }
        .panel-title i {
            margin-right: 10px;
            color: #42a5f5;
        }
        canvas {
            width: 100% !important;
            height: 250px !important;
        }
    </style>
</head>
<body>
    <div class="side-panel">
        <h4 class="panel-title"><i class="fas fa-chart-pie"></i> État des Équipements</h4>
        <canvas id="equipmentChart"></canvas>
    </div>
    <script>
        const ctx = document.getElementById('equipmentChart').getContext('2d');
        const equipmentChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: <?= json_encode($labels) ?>,
                datasets: [{
                    label: 'État des équipements',
                    data: <?= json_encode($counts) ?>,
                    backgroundColor: [
                        '#42a5f5', // sky blue
                        '#66bb6a', // green
                        '#ffa726', // orange
                        '#ef5350', // red
                        '#ab47bc'  // purple
                    ],
                    borderColor: '#fff',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#0d47a1',
                            font: { size: 14, weight: 'bold' }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.label + ': ' + context.raw;
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
