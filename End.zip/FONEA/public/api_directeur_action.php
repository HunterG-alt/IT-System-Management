<?php
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../modules/WorkflowManager.php';
header('Content-Type: application/json');
if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['error' => 'Non authentifié']);
    exit;
}
$role = $_SESSION['role'] ?? '';
if ($role !== 'directeur') {
    http_response_code(403);
    echo json_encode(['error' => 'Accès refusé']);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Méthode non autorisée']);
    exit;
}
// CSRF token for form 'dir_request_action'
if (!CSRFProtection::verifyTokenFor('dir_request_action', $_POST['csrf_token_dir_request_action'] ?? null)) {
    http_response_code(403);
    echo json_encode(['error' => 'Token CSRF invalide']);
    exit;
}
$id_besoin = (int)($_POST['id_besoin'] ?? 0);
$action = $_POST['action'] ?? '';
$commentaire = trim($_POST['commentaire'] ?? '');
if ($id_besoin <= 0 || !in_array($action, ['approve', 'reject'], true)) {
    http_response_code(400);
    echo json_encode(['error' => 'Paramètres invalides']);
    exit;
}
try {
    $manager = new WorkflowManager();
    $ok = $manager->validateByDirecteur($id_besoin, (int)$_SESSION['user_id'], $action, $commentaire);
    if (!$ok) {
        throw new Exception('Échec de la mise à jour');
    }
    // If approved, next status is en_attente_permission_dg per workflow
    $newStatus = $action === 'approve' ? 'en_attente_permission_dg' : 'refusee_directeur';
    echo json_encode(['success' => true, 'new_status' => $newStatus]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur serveur']);
}
?>
