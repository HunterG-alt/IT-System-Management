<?php
require_once __DIR__ . '/../Config/session.php';
require_login();
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../include/materiel.php';
$user_role = $_SESSION['user']['role'] ?? '';
$user_id = $_SESSION['user']['id'] ?? 0;
$pdo = Database::getInstance()->getConnection();
// Handle actions
if ($_POST['action'] ?? '' === 'add_equipment') {
    $result = Materiel::create([
        'designation' => $_POST['designation'],
        'categorie' => $_POST['categorie'],
        'quantite_stock' => $_POST['quantite_stock'],
        'prix_unitaire' => $_POST['prix_unitaire'],
        'fournisseur' => $_POST['fournisseur'],
        'date_acquisition' => $_POST['date_acquisition'],
        'garantie_mois' => $_POST['garantie_mois'],
        'etat' => $_POST['etat'],
        'localisation' => $_POST['localisation'],
        'description' => $_POST['description']
    ]);
    if ($result) {
        $success_message = "Équipement ajouté avec succès!";
    } else {
        $error_message = "Erreur lors de l'ajout de l'équipement.";
    }
}
// Get inventory statistics
$stats = [
    'total_equipment' => $pdo->query("SELECT COUNT(*) FROM materiel")->fetchColumn(),
    'total_value' => $pdo->query("SELECT SUM(quantite_stock * prix_unitaire) FROM materiel")->fetchColumn(),
    'low_stock' => $pdo->query("SELECT COUNT(*) FROM materiel WHERE quantite_stock < seuil_alerte")->fetchColumn(),
    'categories' => $pdo->query("SELECT COUNT(DISTINCT categorie) FROM materiel")->fetchColumn()
];
// Get equipment list with filters
$filter_category = $_GET['category'] ?? '';
$filter_status = $_GET['status'] ?? '';
$search_term = $_GET['search'] ?? '';
$where_conditions = [];
$params = [];
if (!empty($filter_category)) {
    $where_conditions[] = "categorie = ?";
    $params[] = $filter_category;
}
if (!empty($filter_status)) {
    $where_conditions[] = "etat = ?";
    $params[] = $filter_status;
}
if (!empty($search_term)) {
    $where_conditions[] = "(designation LIKE ? OR description LIKE ?)";
    $search_param = '%' . $search_term . '%';
    $params[] = $search_param;
    $params[] = $search_param;
}
$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
$equipment_sql = "
    SELECT * FROM materiel 
    $where_clause 
    ORDER BY designation ASC
";
$equipment_stmt = $pdo->prepare($equipment_sql);
$equipment_stmt->execute($params);
$equipment_list = $equipment_stmt->fetchAll(PDO::FETCH_ASSOC);
// Get categories for filter
$categories = $pdo->query("SELECT DISTINCT categorie FROM materiel ORDER BY categorie")->fetchAll(PDO::FETCH_COLUMN);
// Get low stock alerts
$low_stock_items = $pdo->query("
    SELECT designation, quantite_stock, seuil_alerte 
    FROM materiel 
    WHERE quantite_stock < seuil_alerte 
    ORDER BY (quantite_stock / seuil_alerte) ASC
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion d'Inventaire - FONEA</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="../Design/assets/style.css" rel="stylesheet">
    <style>
        .inventory-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 30px 30px;
        }
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
        }
        .stat-card.total::before { background: linear-gradient(90deg, #667eea, #764ba2); }
        .stat-card.value::before { background: linear-gradient(90deg, #10b981, #059669); }
        .stat-card.alerts::before { background: linear-gradient(90deg, #f59e0b, #d97706); }
        .stat-card.categories::before { background: linear-gradient(90deg, #8b5cf6, #7c3aed); }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.12);
        }
        .equipment-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            border-left: 4px solid #e5e7eb;
        }
        .equipment-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            border-left-color: #667eea;
        }
        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 25px;
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        .status-neuf { background: #d1fae5; color: #065f46; }
        .status-bon { background: #dbeafe; color: #1e40af; }
        .status-moyen { background: #fef3c7; color: #92400e; }
        .status-mauvais { background: #fee2e2; color: #dc2626; }
        .stock-indicator {
            width: 100%;
            height: 8px;
            background: #e5e7eb;
            border-radius: 4px;
            overflow: hidden;
        }
        .stock-bar {
            height: 100%;
            border-radius: 4px;
            transition: width 0.3s ease;
        }
        .stock-high { background: #10b981; }
        .stock-medium { background: #f59e0b; }
        .stock-low { background: #ef4444; }
        .add-equipment-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
            font-size: 1.5rem;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
            transition: all 0.3s ease;
            z-index: 1000;
        }
        .add-equipment-btn:hover {
            transform: scale(1.1);
            box-shadow: 0 15px 40px rgba(102, 126, 234, 0.4);
        }
        .alert-card {
            background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            border-left: 4px solid #f59e0b;
        }
        .filter-section {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        .category-tag {
            display: inline-block;
            background: #f3f4f6;
            color: #374151;
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-right: 0.5rem;
        }
        @media (max-width: 768px) {
            .add-equipment-btn {
                bottom: 20px;
                right: 20px;
                width: 50px;
                height: 50px;
                font-size: 1.2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
        <div class="container">
            <a class="navbar-brand fw-bold" href="../show/enhanced_dashboard.php">
                <i class="fas fa-building me-2"></i>FONEA
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../show/enhanced_dashboard.php"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../show/content.php"><i class="fas fa-list me-2"></i>Demandes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#"><i class="fas fa-boxes me-2"></i>Inventaire</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../public/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Déconnexion</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Header -->
    <div class="inventory-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="display-5 fw-bold mb-0">
                        <i class="fas fa-warehouse me-3"></i>Gestion d'Inventaire
                    </h1>
                    <p class="lead opacity-75 mb-0">Suivi et gestion des équipements en temps réel</p>
                </div>
                <div class="col-md-4 text-end">
                    <div class="d-none d-md-block">
                        <i class="fas fa-chart-pie" style="font-size: 4rem; opacity: 0.2;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <!-- Statistics -->
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="stat-card total text-center">
                    <div class="mb-3">
                        <i class="fas fa-boxes text-primary" style="font-size: 2.5rem;"></i>
                    </div>
                    <h3 class="fw-bold"><?= number_format($stats['total_equipment']) ?></h3>
                    <p class="text-muted mb-0">Équipements Total</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="stat-card value text-center">
                    <div class="mb-3">
                        <i class="fas fa-euro-sign text-success" style="font-size: 2.5rem;"></i>
                    </div>
                    <h3 class="fw-bold"><?= number_format($stats['total_value'], 0, ',', ' ') ?> €</h3>
                    <p class="text-muted mb-0">Valeur Totale</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="stat-card alerts text-center">
                    <div class="mb-3">
                        <i class="fas fa-exclamation-triangle text-warning" style="font-size: 2.5rem;"></i>
                    </div>
                    <h3 class="fw-bold"><?= $stats['low_stock'] ?></h3>
                    <p class="text-muted mb-0">Alertes Stock</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="stat-card categories text-center">
                    <div class="mb-3">
                        <i class="fas fa-tags text-purple" style="font-size: 2.5rem;"></i>
                    </div>
                    <h3 class="fw-bold"><?= $stats['categories'] ?></h3>
                    <p class="text-muted mb-0">Catégories</p>
                </div>
            </div>
        </div>
        <!-- Low Stock Alerts -->
        <?php if (!empty($low_stock_items)): ?>
            <div class="alert-card">
                <h5 class="fw-bold mb-3">
                    <i class="fas fa-exclamation-triangle text-warning me-2"></i>
                    Alertes Stock Faible
                </h5>
                <div class="row">
                    <?php foreach ($low_stock_items as $item): ?>
                        <div class="col-md-6 col-lg-4 mb-2">
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="fw-bold"><?= htmlspecialchars($item['designation']) ?></span>
                                <span class="badge bg-warning">
                                    <?= $item['quantite_stock'] ?>/<?= $item['seuil_alerte'] ?>
                                </span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
        <!-- Filters -->
        <div class="filter-section">
            <form method="GET" class="row align-items-end">
                <div class="col-md-4">
                    <label class="form-label fw-bold">Rechercher</label>
                    <input type="text" name="search" class="form-control" placeholder="Nom ou description..." value="<?= htmlspecialchars($search_term) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold">Catégorie</label>
                    <select name="category" class="form-select">
                        <option value="">Toutes les catégories</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?= htmlspecialchars($category) ?>" <?= $filter_category === $category ? 'selected' : '' ?>>
                                <?= htmlspecialchars($category) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold">État</label>
                    <select name="status" class="form-select">
                        <option value="">Tous les états</option>
                        <option value="neuf" <?= $filter_status === 'neuf' ? 'selected' : '' ?>>Neuf</option>
                        <option value="bon" <?= $filter_status === 'bon' ? 'selected' : '' ?>>Bon</option>
                        <option value="moyen" <?= $filter_status === 'moyen' ? 'selected' : '' ?>>Moyen</option>
                        <option value="mauvais" <?= $filter_status === 'mauvais' ? 'selected' : '' ?>>Mauvais</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-2"></i>Filtrer
                    </button>
                </div>
            </form>
        </div>
        <!-- Equipment List -->
        <div class="row">
            <?php foreach ($equipment_list as $equipment): ?>
                <div class="col-lg-6 col-xl-4">
                    <div class="equipment-card">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <h5 class="fw-bold mb-0"><?= htmlspecialchars($equipment['designation']) ?></h5>
                            <span class="status-badge status-<?= $equipment['etat'] ?>">
                                <?= ucfirst($equipment['etat']) ?>
                            </span>
                        </div>
                        <div class="mb-3">
                            <span class="category-tag"><?= htmlspecialchars($equipment['categorie']) ?></span>
                        </div>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <small class="text-muted">Stock</small>
                                <small class="fw-bold"><?= $equipment['quantite_stock'] ?> unités</small>
                            </div>
                            <?php 
                            $stock_percentage = $equipment['seuil_alerte'] > 0 ? ($equipment['quantite_stock'] / $equipment['seuil_alerte']) * 100 : 100;
                            $stock_class = $stock_percentage > 100 ? 'stock-high' : ($stock_percentage > 50 ? 'stock-medium' : 'stock-low');
                            ?>
                            <div class="stock-indicator">
                                <div class="stock-bar <?= $stock_class ?>" style="width: <?= min(100, $stock_percentage) ?>%"></div>
                            </div>
                        </div>
                        <div class="row text-center">
                            <div class="col-6">
                                <small class="text-muted d-block">Prix unitaire</small>
                                <strong><?= number_format($equipment['prix_unitaire'], 2) ?> €</strong>
                            </div>
                            <div class="col-6">
                                <small class="text-muted d-block">Valeur totale</small>
                                <strong><?= number_format($equipment['quantite_stock'] * $equipment['prix_unitaire'], 2) ?> €</strong>
                            </div>
                        </div>
                        <?php if (!empty($equipment['localisation'])): ?>
                            <div class="mt-2">
                                <small class="text-muted">
                                    <i class="fas fa-map-marker-alt me-1"></i>
                                    <?= htmlspecialchars($equipment['localisation']) ?>
                                </small>
                            </div>
                        <?php endif; ?>
                        <div class="mt-3">
                            <button class="btn btn-sm btn-outline-primary me-2" onclick="editEquipment(<?= $equipment['id_materiel'] ?>)">
                                <i class="fas fa-edit me-1"></i>Modifier
                            </button>
                            <button class="btn btn-sm btn-outline-info" onclick="viewHistory(<?= $equipment['id_materiel'] ?>)">
                                <i class="fas fa-history me-1"></i>Historique
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php if (empty($equipment_list)): ?>
            <div class="text-center py-5">
                <i class="fas fa-boxes text-muted" style="font-size: 4rem;"></i>
                <h4 class="mt-3 text-muted">Aucun équipement trouvé</h4>
                <p class="text-muted">Commencez par ajouter des équipements à votre inventaire</p>
            </div>
        <?php endif; ?>
    </div>
    <!-- Add Equipment Button -->
    <button class="add-equipment-btn" data-bs-toggle="modal" data-bs-target="#addEquipmentModal">
        <i class="fas fa-plus"></i>
    </button>
    <!-- Add Equipment Modal -->
    <div class="modal fade" id="addEquipmentModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-plus-circle me-2"></i>Ajouter un Équipement
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add_equipment">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Désignation *</label>
                                    <input type="text" name="designation" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Catégorie *</label>
                                    <input type="text" name="categorie" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Quantité en stock *</label>
                                    <input type="number" name="quantite_stock" class="form-control" min="0" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Prix unitaire (€) *</label>
                                    <input type="number" name="prix_unitaire" class="form-control" step="0.01" min="0" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Fournisseur</label>
                                    <input type="text" name="fournisseur" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Date d'acquisition</label>
                                    <input type="date" name="date_acquisition" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Garantie (mois)</label>
                                    <input type="number" name="garantie_mois" class="form-control" min="0">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">État *</label>
                                    <select name="etat" class="form-select" required>
                                        <option value="neuf">Neuf</option>
                                        <option value="bon">Bon</option>
                                        <option value="moyen">Moyen</option>
                                        <option value="mauvais">Mauvais</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="mb-3">
                                    <label class="form-label">Localisation</label>
                                    <input type="text" name="localisation" class="form-control" placeholder="Bureau, Salle, Étage...">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="mb-3">
                                    <label class="form-label">Description</label>
                                    <textarea name="description" class="form-control" rows="3"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Ajouter
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script>
        function editEquipment(id) {
            // Implementation for editing equipment
            alert('Fonction de modification en cours de développement');
        }
        function viewHistory(id) {
            // Implementation for viewing equipment history
            alert('Historique de l\'équipement ID: ' + id);
        }
        // Auto-refresh every 5 minutes
        setInterval(() => {
            if (!document.hidden) {
                location.reload();
            }
        }, 300000);
        // Success/Error message handling
        <?php if (isset($success_message)): ?>
            alert('<?= $success_message ?>');
        <?php endif; ?>
        <?php if (isset($error_message)): ?>
            alert('<?= $error_message ?>');
        <?php endif; ?>
    </script>
</body>
</html>
