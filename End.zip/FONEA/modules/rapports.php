<?php
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../public/user.php';
require_once __DIR__ . '/../include/materiel.php';
require_once __DIR__ . '/../include/caracteristique.php';
require_once __DIR__ . '/../include/type_materiel.php';
session_start();
require_login();
if (!defined('ROLE_DIRECTEUR_GENERAL')) {
    throw new Exception('Role constants not defined');
}
if ($_SESSION['role'] !== ROLE_DIRECTEUR_GENERAL) {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/error.php?error=unauthorized");
    exit;
}
// CSRF token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
try {
    $user = User::getById($_SESSION['user_id']);
    if (!$user) {
        throw new Exception('Utilisateur introuvable');
    }
    // Statistiques principales
    $stats = [
        'total_type_materiel' => Type_materiel::count(),
        'total_caracteristique' => Caracteristique::count(),
        'total_materiel' => Materiel::count(),
        'materiel_mois' => Materiel::countThisMonth(),
        'montant_total' => Materiel::getTotalAmount(),
        'montant_mois' => Materiel::getAmountThisMonth()
    ];
    // Rapports détaillés - Fixed variable names to match display
    $recent_factures = Materiel::getRecent(10); // Assuming this returns recent material orders as "factures"
    $top_materiels = Materiel::getTopSelling(5); // Fixed method call
    $agents_actifs = User::getMostActiveAgents(5); // Fixed to get active agents/users
    // Alternative data sources if the above methods don't exist
    // $recent_factures = Materiel::getRecentOrders(10);
    // $top_materiels = Materiel::getTopByQuantity(5);
    // $agents_actifs = User::getActiveUsers(5);
} catch (Exception $e) {
    error_log($e->getMessage());
    $error_message = "Erreur lors du chargement des rapports.";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Rapports - FONEAr</title>
  <link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <style>
    body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, sans-serif; }
    .report-header {
        background: linear-gradient(135deg, #0d6efd 0%, #20c997 100%);
        color: white; padding: 2rem 0; margin-bottom: 2rem; border-radius: 0 0 20px 20px;
    }
    .metric-card {
        background: white; border-radius: 15px; padding: 1.5rem; margin-bottom: 20px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        transition: all 0.3s ease; border-left: 4px solid #0d6efd;
    }
    .metric-card:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(0,0,0,0.12); }
    .metric-number { font-size: 2rem; font-weight: 700; color: #0d6efd; }
    .metric-label { font-size: 0.9rem; color: #6c757d; text-transform: uppercase; font-weight: 600; }
    .section-title { font-size: 1.25rem; font-weight: 700; color: #333; margin-bottom: 1rem; border-left: 4px solid #0d6efd; padding-left: 10px; }
    .list-group-item { border: none; border-bottom: 1px solid #e9ecef; }
    .list-group-item:last-child { border-bottom: none; }
  </style>
</head>
<body>
  <div class="report-header text-center">
    <h1 class="mb-0"><i class="fas fa-chart-line me-3"></i>Rapports Généraux</h1>
    <p class="mb-0 mt-2 opacity-75">Vue d'ensemble des performances et données clés</p>
  </div>
  <div class="container">
    <?php if (isset($error_message)): ?>
      <div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i><?= htmlspecialchars($error_message) ?></div>
    <?php endif; ?>
    <!-- Statistiques clés -->
    <div class="row">
      <div class="col-12 col-md-4">
        <div class="metric-card text-center">
          <div class="metric-number"><?= $stats['total_type_materiel'] ?? 0 ?></div>
          <div class="metric-label">Types de Matériel</div>
        </div>
      </div>
      <div class="col-12 col-md-4">
        <div class="metric-card text-center">
          <div class="metric-number"><?= $stats['total_materiel'] ?? 0 ?></div>
          <div class="metric-label">Matériels</div>
        </div>
      </div>
      <div class="col-12 col-md-4">
        <div class="metric-card text-center">
          <div class="metric-number"><?= $stats['total_caracteristique'] ?? 0 ?></div>
          <div class="metric-label">Caractéristiques</div>
        </div>
      </div>
    </div>
    <!-- Montants -->
    <div class="row mt-3">
      <div class="col-12 col-md-6">
        <div class="metric-card text-center">
          <div class="metric-number"><?= number_format($stats['montant_total'] ?? 0, 0, ',', ' ') ?> FCFA</div>
          <div class="metric-label">Montant total</div>
        </div>
      </div>
      <div class="col-12 col-md-6">
        <div class="metric-card text-center">
          <div class="metric-number"><?= number_format($stats['montant_mois'] ?? 0, 0, ',', ' ') ?> FCFA</div>
          <div class="metric-label">Ce mois-ci</div>
        </div>
      </div>
    </div>
    <!-- Rapports détaillés -->
    <div class="row mt-4">
      <div class="col-12 col-lg-6">
        <div class="card">
          <div class="card-body">
            <h3 class="section-title">📑 Commandes récentes</h3>
            <ul class="list-group list-group-flush">
              <?php if (!empty($recent_factures)): ?>
                <?php foreach ($recent_factures as $facture): ?>
                  <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                    <div>
                      <strong><?= htmlspecialchars($facture['nom'] ?? $facture['numero'] ?? 'N/A') ?></strong>
                      <small class="text-muted d-block"><?= isset($facture['date_creation']) ? date('d/m/Y', strtotime($facture['date_creation'])) : 'Date inconnue' ?></small>
                    </div>
                    <span class="badge bg-success rounded-pill"><?= number_format($facture['montant'] ?? $facture['prix'] ?? 0, 0, ',', ' ') ?> FCFA</span>
                  </li>
                <?php endforeach; ?>
              <?php else: ?>
                <li class="list-group-item text-muted text-center px-0">Aucune commande récente</li>
              <?php endif; ?>
            </ul>
          </div>
        </div>
      </div>
      <div class="col-12 col-lg-6">
        <div class="card">
          <div class="card-body">
            <h3 class="section-title">🏆 Top Matériels</h3>
            <ul class="list-group list-group-flush">
              <?php if (!empty($top_materiels)): ?>
                <?php foreach ($top_materiels as $mat): ?>
                  <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                    <div>
                      <strong><?= htmlspecialchars($mat['nom'] ?? 'Matériel') ?></strong>
                      <small class="text-muted d-block"><?= htmlspecialchars($mat['description'] ?? '') ?></small>
                    </div>
                    <span class="badge bg-primary rounded-pill"><?= $mat['quantite'] ?? $mat['acheter'] ?? 0 ?> unités</span>
                  </li>
                <?php endforeach; ?>
              <?php else: ?>
                <li class="list-group-item text-muted text-center px-0">Aucun matériel trouvé</li>
              <?php endif; ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!-- Agents actifs -->
    <div class="row mt-4">
      <div class="col-12">
        <div class="card">
          <div class="card-body">
            <h3 class="section-title">👥 Utilisateurs les plus actifs</h3>
            <ul class="list-group list-group-flush">
              <?php if (!empty($agents_actifs)): ?>
                <?php foreach ($agents_actifs as $agent): ?>
                  <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                    <div>
                      <strong><?= htmlspecialchars($agent['nom'] ?? $agent['username'] ?? 'Utilisateur') ?></strong>
                      <small class="text-muted d-block"><?= htmlspecialchars($agent['email'] ?? '') ?></small>
                    </div>
                    <span class="badge bg-info rounded-pill"><?= $agent['commandes'] ?? $agent['activite'] ?? 0 ?> actions</span>
                  </li>
                <?php endforeach; ?>
              <?php else: ?>
                <li class="list-group-item text-muted text-center px-0">Aucun utilisateur actif</li>
              <?php endif; ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!-- Actions -->
    <div class="text-center mt-4 mb-5">
      <a href="export_pdf.php" class="btn btn-success btn-lg">
        <i class="fas fa-file-pdf me-2"></i>Exporter en PDF
      </a>
    </div>
  </div>
  <script src="../../assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>