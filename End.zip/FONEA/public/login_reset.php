<?php
// config.php should contain PDO connection as $pdo
require_once '../Config/config.php';
session_start();
// LOGIN + REMEMBER ME
// LOGIN + REMEMBER ME
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']);
    // Fetch user info including role
    $stmt = $pdo->prepare("SELECT id, password, role FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $user['role']; // store the role in session
        // Remember me
        if ($remember) {
            $token = bin2hex(random_bytes(32));
            setcookie('remember_token', $token, time() + (86400*30), "/", "", false, true);
            $pdo->prepare("UPDATE users SET remember_token = :token WHERE id = :id")
                ->execute(['token' => $token, 'id' => $user['id']]);
        }
        // Redirect by role
        switch (strtolower($user['role'])) {
            case 'dg':
                header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/show/dashboard_dg.php");
                break;
            case 'directeur':
                header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/show/dashboard_directeur.php");
                break;
            case 'chef de service':
                header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/show/dashboard_chef.php");
                break;
            case 'informatique':
                header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/show/dashboard_informatique.php");
                break;
            case 'moyen generaux':
                header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/show/dashboard_moyens_generaux.php");
                break;
            case 'agent':
            case'demandeur':    
                header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/show/dashboard_agent.php");
                break;
            default:
                // fallback if role is unknown
                header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/Public/Mini_dashboard.php");
                break;
        }
        exit;
    } else {
        $error = "Invalid email or password.";
    }
}
if (!isset($_SESSION['user_id']) && isset($_COOKIE['remember_token'])) {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE remember_token = :token");
    $stmt->execute(['token' => $_COOKIE['remember_token']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        $_SESSION['user_id'] = $user['id'];
    }
}
// FORGOT PASSWORD
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['forgot'])) {
    $email = trim($_POST['email']);
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    if ($stmt->fetch()) {
        $reset_token = bin2hex(random_bytes(32));
        $pdo->prepare("UPDATE users SET reset_token = :token, reset_expires = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE email = :email")
            ->execute(['token' => $reset_token, 'email' => $email]);
        $reset_link = "https://loussig.42web.io/reset_password.php?token=$reset_token";
        mail($email, "Password Reset", "Click here to reset: $reset_link");
        $msg = "A reset link has been sent to your email.";
    } else {
        $error = "Email not found.";
    }
}
// RESET PASSWORD HANDLER
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['token'])) {
    $token = $_GET['token'];
    $stmt = $pdo->prepare("SELECT id, reset_expires FROM users WHERE reset_token = :token");
    $stmt->execute(['token' => $token]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user && strtotime($user['reset_expires']) > time()) {
        $_SESSION['reset_user_id'] = $user['id'];
    } else {
        die("Invalid or expired token.");
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_password'])) {
    if (!isset($_SESSION['reset_user_id'])) {
        die("Session expired. Request a new reset link.");
    }
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    if ($new_password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (strlen($new_password) < 8) {
        $error = "Password must be at least 8 characters.";
    } else {
        $hashed = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password = :password, reset_token = NULL, reset_expires = NULL WHERE id = :id");
        $stmt->execute(['password' => $hashed, 'id' => $_SESSION['reset_user_id']]);
        unset($_SESSION['reset_user_id']);
        $msg = "Password updated successfully. You can now log in.";
    }
}
?>
<!-- LOGIN FORM -->
<form method="POST">
    <input type="email" name="email" placeholder="Email" required><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <label><input type="checkbox" name="remember"> Remember Me</label><br>
    <button type="submit" name="login">Connexion</button>
</form>
<form method="POST">
    <h3>Forgot Password?</h3>
    <input type="email" name="email" placeholder="Enter your email" required><br>
    <button type="submit" name="forgot">Envoyer le lien réinitialiser</button>
</form>
<!-- RESET PASSWORD FORM -->
<?php if (isset($_SESSION['reset_user_id'])): ?>
<form method="POST">
    <h3>Reset Password</h3>
    <?php if (isset($error)) echo "<p style='color:red'>$error</p>"; ?>
    <input type="password" name="new_password" placeholder="New Password" required><br>
    <input type="password" name="confirm_password" placeholder="Confirm Password" required><br>
    <button type="submit" name="reset_password">Mot de passe modifier</button>
</form>
<?php endif; ?>
<?php if (isset($msg)) echo "<p style='color:green'>$msg</p>"; ?>
