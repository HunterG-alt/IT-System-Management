<?php
require_once __DIR__ . '/../Config/db.php';

class Notification {
    private static function pdo() {
        return Database::getInstance()->getConnection();
    }
    public static function getForUser($user_id, $only_unread = false, $limit = 100) {
        $sql = "SELECT * FROM notifications WHERE user_id = :user_id";
        if ($only_unread) {
            $sql .= " AND is_read = 0";
        }
        $sql .= " ORDER BY created_at DESC LIMIT :limit";
        $stmt = self::pdo()->prepare($sql);
        $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    public static function markAllAsRead($user_id) {
        $sql = "UPDATE notifications SET is_read = 1, read_at = NOW() WHERE user_id = :user_id AND is_read = 0";
        $stmt = self::pdo()->prepare($sql);
        $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
    }
    public static function markAsRead($notification_id, $user_id) {
        $sql = "UPDATE notifications SET is_read = 1, read_at = NOW() WHERE id = :id AND user_id = :user_id";
        $stmt = self::pdo()->prepare($sql);
        $stmt->bindValue(':id', $notification_id, PDO::PARAM_INT);
        $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->rowCount() > 0;
    }
    public static function getStats($user_id) {
        $sql = "SELECT COUNT(*) as total, SUM(CASE WHEN is_read = 0 THEN 1 ELSE 0 END) as unread FROM notifications WHERE user_id = :user_id";
        $stmt = self::pdo()->prepare($sql);
        $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return [
            'total' => (int)($row['total'] ?? 0),
            'unread' => (int)($row['unread'] ?? 0)
        ];
    }
}

// Helper function to format notification type
function formatNotificationType($type) {
    $types = [
        'request_created' => 'Demande créée',
        'request_approved' => 'Demande approuvée',
        'request_rejected' => 'Demande rejetée',
        'request_updated' => 'Demande mise à jour',
        'system_alert' => 'Alerte système',
        'reminder' => 'Rappel'
    ];
    return $types[$type] ?? ucfirst(str_replace('_', ' ', $type));
}
// Helper function to get icon for notification type
function getNotificationIcon($type) {
    $icons = [
        'request_created' => 'fas fa-plus-circle',
        'request_approved' => 'fas fa-check-circle',
        'request_rejected' => 'fas fa-times-circle',
        'request_updated' => 'fas fa-edit',
        'system_alert' => 'fas fa-exclamation-triangle',
        'reminder' => 'fas fa-clock'
    ];
    return $icons[$type] ?? 'fas fa-bell';
}

function getNotificationColor($type) {
    $colors = [
        'request_created' => '#3b82f6',
        'request_approved' => '#10b981',
        'request_rejected' => '#ef4444',
        'request_updated' => '#f59e0b',
        'system_alert' => '#ef4444',
        'reminder' => '#8b5cf6'
    ];
    return $colors[$type] ?? '#6366f1';
}
?>