<?php
require_once '../Config/session.php';
require_once __DIR__ . '/../public/userClass.php';
require_once '../include/besoin.php';
require_once __DIR__ . '/../public/notifications.php';
require_once __DIR__ . '/../Config/titles.php'; 

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'directeur_general') {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit();
}

$user = User::getById($_SESSION['user_id']);
$user_name = $user ? $user['nom_complet'] : 'Directeur Général';

$total_users = User::count();
$pending_requests = Besoin::countByStatut('EN_ATTENTE');
$approved_requests = Besoin::countByStatut('APPROUVE');
$stats = Notification::getStats($_SESSION['user_id']);
$total_notifications = $stats['unread'] ?? 0;

$currentPage = basename(__FILE__);
$pageTitle = $pageTitles[$currentPage] ?? 'Dashboard - FONEA';

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
   <style>
        .btn-accueil {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 90%;
            margin: 30px auto 20px auto;
            padding: 14px 0;
            border-radius: 30px;
            font-size: 1.1rem;
            font-weight: bold;
            background: linear-gradient(135deg, #1e293b, #3b82f6);
            color: #fff !important;
            box-shadow: 0 4px 16px rgba(59,130,246,0.15);
            border: none;
            transition: background 0.3s, transform 0.2s;
            text-decoration: none !important;
        }
        .btn-accueil i {
            margin-right: 10px;
            font-size: 1.2em;
        }
        .btn-accueil:hover {
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: #fff !important;
            transform: translateY(-2px) scale(1.03);
            text-decoration: none !important;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #ffffff;
            color: #1a1a1a;
            overflow-x: hidden;
        }
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 240px;
            height: 100vh;
            background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
            z-index: 1000;
            transition: all 0.3s ease;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
        }
        .sidebar-header {
            padding: 30px 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .sidebar-logo {
            color: #ffffff;
            font-size: 24px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .sidebar-logo i {
            color: #ffffff;
            font-size: 28px;
        }
        .sidebar-nav {
            padding: 20px 0;
            padding-bottom: 180px;
        }
        .nav-item {
            margin: 8px 20px;
        }
        .nav-link {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
            gap: 15px;
        }
        .nav-link:hover {
            background: rgba(255, 255, 255, 0.1);
            color: #ffffff;
            transform: translateX(5px);
            text-decoration: none;
        }
        .nav-link.active {
            background: rgba(255, 255, 255, 0.2);
            color: #ffffff;
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
        }
        .nav-link i {
            font-size: 18px;
            width: 20px;
        }
        /* Main Content */
        .main-content {
            margin-left: 240px;
            min-height: 100vh;
            background: #ffffff;
        }
        /* Top Header */
        .top-header {
            background: #ffffff;
            padding: 20px 40px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        .search-bar {
            flex: 1;
            max-width: 400px;
            margin: 0 30px;
            position: relative;
        }
        .search-input {
            width: 100%;
            padding: 12px 20px 12px 45px;
            border: 2px solid #e2e8f0;
            border-radius: 25px;
            background: #f8fafc;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        .search-input:focus {
            outline: none;
            border-color: #3b82f6;
            background: #ffffff;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
        }
        .header-actions {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .notification-btn {
            position: relative;
            background: #f8fafc;
            border: none;
            width: 45px;
            height: 45px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .notification-btn:hover {
            background: #3b82f6;
            color: #ffffff;
            transform: translateY(-2px);
        }
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #ef4444;
            color: #ffffff;
            font-size: 11px;
            padding: 2px 6px;
            border-radius: 10px;
            font-weight: 600;
        }
        .profile-section {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 16px;
            background: #f8fafc;
            border-radius: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            color: inherit;
        }
        .profile-section:hover {
            background: #e2e8f0;
            text-decoration: none;
            color: inherit;
        }
        .profile-avatar {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            font-weight: 600;
            font-size: 16px;
        }
        .profile-info h6 {
            margin: 0;
            font-size: 14px;
            font-weight: 600;
            color: #1e293b;
        }
        .profile-info p {
            margin: 0;
            font-size: 12px;
            color: #64748b;
        }
        /* Welcome Section */
        .welcome-section {
            padding: 40px;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            position: relative;
        }
        .welcome-title {
            font-size: 32px;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 8px;
        }
        .welcome-subtitle {
            font-size: 16px;
            color: #64748b;
            margin-bottom: 0;
        }
        /* ADDED: Advanced Dashboard Button */
        .advanced-dashboard-btn {
            position: absolute;
            top: 40px;
            right: 40px;
            background: linear-gradient(135deg, #8b5cf6, #7c3aed);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(139, 92, 246, 0.3);
        }
        .advanced-dashboard-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(139, 92, 246, 0.4);
            color: white;
            text-decoration: none;
        }
        /* Dashboard Cards */
        .dashboard-section {
            padding: 40px;
        }
        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        .dg-dashboard-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 25px;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            border: 1px solid #e2e8f0;
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-decoration: none !important;
            color: inherit;
        }
        .dg-dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(59, 130, 246, 0.2);
        }
        .card-icon {
            width: 60px;
            height: 60px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: #ffffff;
            margin-bottom: 20px;
        }
        .card-title {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 8px;
        }
        .card-description {
            font-size: 14px;
            color: #64748b;
            margin-bottom: 15px;
            line-height: 1.5;
        }
        .card-metric {
            font-size: 28px;
            font-weight: 700;
            color: #1e293b;
        }
        /* Card Colors */
        .card-users .card-icon { background: linear-gradient(135deg, #3b82f6, #1d4ed8); }
        .card-requests .card-icon { background: linear-gradient(135deg, #8b5cf6, #7c3aed); }
        .card-reports .card-icon { background: linear-gradient(135deg, #06b6d4, #0891b2); }
        .card-workflow .card-icon { background: linear-gradient(135deg, #10b981, #059669); }
        .card-assets .card-icon { background: linear-gradient(135deg, #f59e0b, #d97706); }
        .card-procurement .card-icon { background: linear-gradient(135deg, #ef4444, #dc2626); }
        .card-notifications .card-icon { background: linear-gradient(135deg, #8b5cf6, #7c3aed); }
        .card-settings .card-icon { background: linear-gradient(135deg, #64748b, #475569); }
        /* Side Panels */
        .side-panels {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
            margin-top: 30px;
        }
        .dashboard-card,
        .dg-side-panel {
            background: #ffffff;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            border: 1px solid #e2e8f0;
        }
        .panel-title {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .document-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 0;
            border-bottom: 1px solid #f1f5f9;
        }
        .document-item:last-child {
            border-bottom: none;
        }
        .document-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: #f1f5f9;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
        }
        .document-info h6 {
            margin: 0;
            font-size: 14px;
            font-weight: 500;
            color: #1e293b;
        }
        .document-info p {
            margin: 0;
            font-size: 12px;
            color: #64748b;
        }
        #quickStatsChart {
            width: 100% !important;
            max-width: 100% !important;
            height: 220px !important;
            display: block !important;
            margin: 0 auto !important;
        }
        .logout-btn {
            position: fixed;
            bottom: 30px;
            left: 20px;
            width: 200px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #ffffff;
            padding: 12px 20px;
            border-radius: 12px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
        }
        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            color: #ffffff;
            text-decoration: none;
        }
        .chart-container {
            position: relative;
            height: 220px;
            width: 100%;
        }
        .btn-action {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            margin: 3px;
            min-width: 90px;
            justify-content: center;
        }
        .actions-cell {
            text-align: center;
            white-space: nowrap;
        }
        .actions-cell .btn-action {
            margin: 0 4px 4px 0;
        }
        a, a:hover, a:focus, a:active {
            text-decoration: none !important;
            outline: none;
        }
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .main-content {
                margin-left: 0;
            }
            .top-header {
                padding: 15px 20px;
            }
            .dashboard-section {
                padding: 20px;
            }
            .cards-grid {
                grid-template-columns: 1fr;
            }
            .side-panels {
                grid-template-columns: 1fr;
            }
            .advanced-dashboard-btn {
                position: static;
                margin-top: 20px;
                align-self: flex-start;
            }
            .welcome-section {
                padding: 20px;
            }
        }
    </style>

</head>
<body class="dashboard-dg">
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-building"></i>
                FONEA DG
            </div>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-item">
                <a href="#" class="nav-link active">
                    <i class="fas fa-chart-pie"></i>
                    Dashboard
                </a>
            </div>
            <div class="nav-item">
                <a href="content.php#requests" class="nav-link">
                    <i class="fas fa-file-alt"></i>
                    Demandes
                </a>
            </div>
            <div class="nav-item">
                <a href="export_reports.php" class="nav-link">
                    <i class="fas fa-chart-bar"></i>
                    Rapports
                </a>
            </div>
            <div class="nav-item">
                <a href="content.php" class="nav-link">
                    <i class="fas fa-project-diagram"></i>
                    Workflow
                </a>
            </div>
            <div class="nav-item">
                <a href="document_management.php" class="nav-link">
                    <i class="fas fa-boxes"></i>
                    Actifs
                </a>
            </div>
            <div class="nav-item">
                <a href="content.php#procurement" class="nav-link">
                    <i class="fas fa-shopping-cart"></i>
                    Approvisionnement
                </a>
            </div>
            <div class="nav-item">
                <a href="../public/notifications.php" class="nav-link">
                    <i class="fas fa-bell"></i>
                    Notifications
                </a>
            </div>
            <div class="nav-item">
                <a href="settings.php" class="nav-link">
                    <i class="fas fa-cog"></i>
                    Paramètres
                </a>
            </div>
        </nav>
        <a href="../layout/header.php" class="btn-accueil"><i class="fas fa-home"></i>Accueil</a>
    </div>
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <div class="search-bar position-relative">
                <i class="fas fa-search search-icon"></i>
                <input type="text" class="search-input" placeholder="Rechercher...">
            </div>
            <div class="header-actions">
                <button class="notification-btn">
                    <i class="fas fa-bell"></i>
                    <?php if ($total_notifications > 0): ?>
                        <span class="notification-badge"><?= $total_notifications ?></span>
                    <?php endif; ?>
                </button>
                <div class="profile-section">
                    <div class="profile-avatar">
                        <?= strtoupper(substr($user_name, 0, 2)) ?>
                    </div>
                    <div class="profile-info">
                        <h6><?= htmlspecialchars($user_name) ?></h6>
                        <p>Directeur Général</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Welcome Section -->
        <div class="welcome-section">
            <h1 class="welcome-title">Bienvenue Directeur Général, <?= htmlspecialchars($user_name) ?></h1>
            <p class="welcome-subtitle">Tableau de bord exécutif - Vue d'ensemble des opérations FONEA</p>
            <!-- ADDED: Advanced Dashboard Button -->
            <a href="enhanced_dashboard.php" class="advanced-dashboard-btn">
                <i class="fas fa-chart-line"></i>
                Dashboard Avancé
            </a>
        </div>
        <!-- Dashboard Section -->
        <div class="dashboard-section">
            <div class="cards-grid">
                <a href="content.php#requests" class="dg-dashboard-card card-requests">
                    <div class="card-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <h3 class="card-title">Demandes</h3>
                    <p class="card-description">Suivi et validation des demandes d'équipement</p>
                    <div class="card-metric"><?= $pending_requests ?></div>
                </a>
                <a href="export_reports.php" class="dg-dashboard-card card-reports">
                    <div class="card-icon">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <h3 class="card-title">Rapports</h3>
                    <p class="card-description">Analyses statistiques et rapports de performance</p>
                    <div class="card-metric"><?= $approved_requests ?></div>
                </a>
                <a href="content.php" class="dg-dashboard-card card-workflow">
                    <div class="card-icon">
                        <i class="fas fa-project-diagram"></i>
                    </div>
                    <h3 class="card-title">Workflow</h3>
                    <p class="card-description">Gestion des processus et flux de validation</p>
                    <div class="card-metric">Active</div>
                </a>
                <a href="document_management.php" class="dg-dashboard-card card-assets">
                    <div class="card-icon">
                        <i class="fas fa-boxes"></i>
                    </div>
                    <h3 class="card-title">Actifs</h3>
                    <p class="card-description">Inventaire et gestion du matériel organisationnel</p>
                    <div class="card-metric">Suivi</div>
                </a>
                <a href="procurement_mg.php" class="dg-dashboard-card card-procurement">
                    <div class="card-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <h3 class="card-title">Approvisionnement</h3>
                    <p class="card-description">Gestion des achats et acquisitions d'équipement</p>
                    <div class="card-metric">En cours</div>
                </a>
                <a href="../public/notifications.php" class="dg-dashboard-card card-notifications">
                    <div class="card-icon">
                        <i class="fas fa-bell"></i>
                    </div>
                    <h3 class="card-title">Notifications</h3>
                    <p class="card-description">Alertes système et notifications importantes</p>
                    <div class="card-metric"><?= $total_notifications ?></div>
                </a>
                <a href="settings.php" class="dg-dashboard-card card-settings">
                    <div class="card-icon">
                        <i class="fas fa-cog"></i>
                    </div>
                    <h3 class="card-title">Paramètres</h3>
                    <p class="card-description">Configuration système et historique des actions</p>
                    <div class="card-metric">Config</div>
                </a>
            </div>
            <!-- Side Panels -->
            <div class="side-panels">
                <div class="dg-side-panel">
                    <h4 class="panel-title">
                        <i class="fas fa-file-pdf"></i>
                        Documents Récents
                    </h4>
                    <div class="document-item">
                        <div class="document-icon">
                            <i class="fas fa-file-pdf"></i>
                        </div>
                        <div class="document-info">
                            <h6>Rapport Mensuel.pdf</h6>
                            <p class="modified-date"></p>
                        </div>
                    </div>
                    <div class="document-item">
                        <div class="document-icon">
                            <i class="fas fa-file-excel"></i>
                        </div>
                        <div class="document-info">
                            <h6>Demandes Q4.xlsx</h6>
                            <p class="modified-date"></p>
                        </div>
                    </div>
                    <div class="document-item">
                        <div class="document-icon">
                            <i class="fas fa-file-word"></i>
                        </div>
                        <div class="document-info">
                            <h6>Politique Achat.docx</h6>
                            <p class="modified-date"></p>
                        </div>
                    </div>
                </div>
                <div class="dg-side-panel">
                    <h4 class="panel-title">
                        <i class="fas fa-chart-line"></i>
                       <a href="dashboard_stats.php" style="text-decoration:none; color:inherit; cursor:pointer;">
                             Statistiques Rapides
                       </a>
                    </h4>
                    <canvas id="quickStatsChart"></canvas>
                </div>
            </div>
            <!-- Pending Requests for DG -->
            <div class="mt-4">
                <div class="dg-side-panel" style="max-width:100%">
                    <h4 class="panel-title"><i class="fas fa-inbox"></i> Demandes en attente d'autorisation DG</h4>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Demandeur</th>
                                    <th>Désignation</th>
                                    <th>Statut</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="dgPendingTable">
                                <?php if (empty($pending_list)): ?>
                                    <tr><td colspan="5" class="text-center text-muted">Aucune demande en attente</td></tr>
                                <?php else: foreach ($pending_list as $row): ?>
                                    <tr data-id="<?= (int)$row['id_besoin'] ?>">
                                        <td><?= (int)$row['id_besoin'] ?></td>
                                        <td><?= htmlspecialchars($row['prenom'] . ' ' . $row['nom']) ?></td>
                                        <td><?= htmlspecialchars($row['designation_materiel'] ?? '') ?></td>
                                        <td><span class="status-badge <?= htmlspecialchars($row['statut']) ?>"><?= htmlspecialchars($row['statut']) ?></span></td>
                                        <td class="actions-cell">
                                            <?php if ($_SESSION['role'] === 'directeur_general' && in_array($row['statut'], ['EN_ATTENTE', 'SOUS_VALIDATION_DG'])): ?>
                                                <button type="button" class="btn btn-sm btn-success btn-action" 
                                                    onclick="window.location.href='../modules/dg_approval.php?id=<?= (int)$row['id_besoin'] ?>'">
                                                    <i class="fas fa-check"></i> Autoriser
                                                </button>
                                                <button type="button" class="btn btn-sm btn-danger btn-action" 
                                                    onclick="window.location.href='../modules/reject.php?id=<?= (int)$row['id_besoin'] ?>'">
                                                    <i class="fas fa-times"></i> Rejeter
                                                </button>
                                                <span class="status-badge status-<?= strtolower(htmlspecialchars($row['statut'])) ?>">
                                                    <?= htmlspecialchars($row['statut']) ?>
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Quick Stats Chart
        const ctx = document.getElementById('quickStatsChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun'],
                datasets: [{
                    label: 'Demandes',
                    data: [12, 19, 15, 25, 22, 30],
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: '#f1f5f9'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        // Add click handlers to notification button
        document.querySelector('.notification-btn').addEventListener('click', function() {
            window.location.href = 'notifications.php';
        });
        const today = new Date();
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const formattedDate = today.toLocaleDateString('fr-FR', options);
        // Insert the date into each .modified-date element
        document.querySelectorAll('.modified-date').forEach(el => {
          el.textContent = `Modifié le ${formattedDate}`;
        });
    </script>
</body>
</html>