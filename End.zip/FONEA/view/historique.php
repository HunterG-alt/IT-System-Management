<?php
require_once '../Config/session.php';
require_once '../Config/db.php';
session_start();
require_login();
// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
try {
    $pdo = Database::getInstance()->getConnection();
    // Build query with filters
    $where_conditions = [];
    $params = [];
    // Filter by agent
    if (!empty($_GET['agent'])) {
        $where_conditions[] = "utilisateur LIKE :agent";
        $params['agent'] = '%' . $_GET['agent'] . '%';
    }
    // Filter by status
    if (!empty($_GET['statut'])) {
        $where_conditions[] = "action LIKE :statut";
        $params['statut'] = '%' . $_GET['statut'] . '%';
    }
    // Filter by date range
    if (!empty($_GET['date_debut'])) {
        $where_conditions[] = "created_at >= :date_debut";
        $params['date_debut'] = $_GET['date_debut'];
    }
    if (!empty($_GET['date_fin'])) {
        $where_conditions[] = "created_at <= :date_fin";
        $params['date_fin'] = $_GET['date_fin'] . ' 23:59:59';
    }
    // Build final query
    $sql = "SELECT h.*, u.prenom, u.nom 
            FROM historique h 
            LEFT JOIN users u ON h.user_id = u.id";
    if (!empty($where_conditions)) {
        $sql .= " WHERE " . implode(' AND ', $where_conditions);
    }
    $sql .= " ORDER BY h.created_at DESC LIMIT 100";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $historique = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // Get total count for pagination
    $count_sql = "SELECT COUNT(*) FROM historique h";
    if (!empty($where_conditions)) {
        $count_sql .= " WHERE " . implode(' AND ', $where_conditions);
    }
    $count_stmt = $pdo->prepare($count_sql);
    $count_stmt->execute($params);
    $total_records = $count_stmt->fetchColumn();
} catch (Exception $e) {
    error_log("Historique Error: " . $e->getMessage());
    $historique = [];
    $total_records = 0;
    $error_message = "Une erreur s'est produite lors du chargement de l'historique.";
}
// Status mapping for better display
$status_labels = [
    'en attente de prévalidation' => ['label' => 'En attente', 'class' => 'warning'],
    'pré-validee' => ['label' => 'Pré-validée', 'class' => 'info'],
    'refusée_chef' => ['label' => 'Refusée (Chef)', 'class' => 'danger'],
    'en attente de validation de la direction' => ['label' => 'Attente Direction', 'class' => 'warning'],
    'validee_directeur' => ['label' => 'Validée', 'class' => 'success'],
    'refusée_directeur' => ['label' => 'Refusée (Direction)', 'class' => 'danger'],
    'en acquisition' => ['label' => 'En acquisition', 'class' => 'primary'],
    'attribuée' => ['label' => 'Attribuée', 'class' => 'success'],
    'cloturée' => ['label' => 'Clôturée', 'class' => 'secondary']
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historique des Actions - FONEA</title>
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .main-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            margin: 2rem auto;
            padding: 0;
            overflow: hidden;
        }
        .header-section {
            background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
            color: white;
            padding: 2rem;
            position: relative;
            overflow: hidden;
        }
        .header-section::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -20%;
            width: 100%;
            height: 200%;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="2" fill="rgba(255,255,255,0.1)"/></svg>') repeat;
            animation: float 20s infinite linear;
        }
        @keyframes float {
            0% { transform: translateX(0) translateY(0); }
            100% { transform: translateX(-100px) translateY(-100px); }
        }
        .header-content {
            position: relative;
            z-index: 2;
        }
        .filter-section {
            background: #f8f9fa;
            padding: 2rem;
            border-bottom: 3px solid #e9ecef;
        }
        .filter-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            border: 1px solid rgba(0,0,0,0.05);
        }
        .table-section {
            padding: 2rem;
        }
        .custom-table {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none;
        }
        .custom-table thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .custom-table th {
            border: none;
            padding: 1rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.85rem;
        }
        .custom-table td {
            border: none;
            padding: 1rem;
            vertical-align: middle;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }
        .custom-table tbody tr {
            transition: all 0.3s ease;
        }
        .custom-table tbody tr:hover {
            background: rgba(102, 126, 234, 0.05);
            transform: translateX(5px);
        }
        .status-badge {
            padding: 0.4rem 0.8rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .action-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-right: 0.5rem;
            font-size: 1rem;
        }
        .form-control, .form-select {
            border-radius: 10px;
            border: 2px solid #e9ecef;
            padding: 0.75rem 1rem;
            transition: all 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        .btn-custom {
            border-radius: 10px;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            border: none;
        }
        .btn-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 1rem;
        }
        .stats-number {
            font-size: 2rem;
            font-weight: 700;
            color: #667eea;
        }
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            color: #6c757d;
        }
        .empty-state i {
            font-size: 4rem;
            margin-bottom: 1rem;
            opacity: 0.3;
        }
        .pagination-wrapper {
            display: flex;
            justify-content: center;
            margin-top: 2rem;
        }
        .export-section {
            background: #f8f9fa;
            padding: 1.5rem;
            border-top: 3px solid #e9ecef;
        }
        @media (max-width: 768px) {
            .main-container {
                margin: 1rem;
            }
            .header-section {
                padding: 1.5rem;
            }
            .filter-section, .table-section {
                padding: 1rem;
            }
            .custom-table {
                font-size: 0.85rem;
            }
            .custom-table th, .custom-table td {
                padding: 0.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="main-container">
            <!-- Header Section -->
            <div class="header-section">
                <div class="header-content">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h1 class="mb-2">
                                <i class="fas fa-history me-3"></i>
                                Historique des Actions
                            </h1>
                            <p class="mb-0 opacity-75">
                                Suivi complet des activités du système FONEA
                            </p>
                        </div>
                        <div class="col-md-4 text-end">
                            <div class="stats-card d-inline-block">
                                <div class="stats-number"><?php echo number_format($total_records); ?></div>
                                <div class="text-muted">Total d'entrées</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Filter Section -->
            <div class="filter-section">
                <div class="filter-card">
                    <h5 class="mb-3">
                        <i class="fas fa-filter me-2 text-primary"></i>
                        Filtres de recherche
                    </h5>
                    <form method="get" class="row g-3">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        <div class="col-md-3">
                            <label class="form-label">
                                <i class="fas fa-user me-1"></i>Agent
                            </label>
                            <input type="text" 
                                   class="form-control" 
                                   name="agent" 
                                   placeholder="Rechercher par nom d'agent"
                                   value="<?php echo htmlspecialchars($_GET['agent'] ?? ''); ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">
                                <i class="fas fa-flag me-1"></i>Statut
                            </label>
                            <select class="form-select" name="statut">
                                <option value="">-- Tous les statuts --</option>
                                <?php foreach ($status_labels as $status => $info): ?>
                                    <option value="<?php echo $status; ?>" 
                                            <?php echo (isset($_GET['statut']) && $_GET['statut'] === $status) ? 'selected' : ''; ?>>
                                        <?php echo $info['label']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">
                                <i class="fas fa-calendar-alt me-1"></i>Date début
                            </label>
                            <input type="date" 
                                   class="form-control" 
                                   name="date_debut"
                                   value="<?php echo htmlspecialchars($_GET['date_debut'] ?? ''); ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">
                                <i class="fas fa-calendar-alt me-1"></i>Date fin
                            </label>
                            <input type="date" 
                                   class="form-control" 
                                   name="date_fin"
                                   value="<?php echo htmlspecialchars($_GET['date_fin'] ?? ''); ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">&nbsp;</label>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary btn-custom">
                                    <i class="fas fa-search me-2"></i>Filtrer
                                </button>
                            </div>
                        </div>
                    </form>
                    <?php if (!empty($_GET)): ?>
                        <div class="mt-3">
                            <a href="historique.php" class="btn btn-outline-secondary btn-sm">
                                <i class="fas fa-times me-1"></i>Réinitialiser
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <!-- Table Section -->
            <div class="table-section">
                <?php if (isset($error_message)): ?>
                    <div class="alert alert-danger" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>
                <?php if (empty($historique)): ?>
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h4>Aucun historique trouvé</h4>
                        <p class="text-muted">
                            <?php if (!empty($_GET)): ?>
                                Aucun enregistrement ne correspond aux critères de recherche.
                            <?php else: ?>
                                L'historique des actions est vide pour le moment.
                            <?php endif; ?>
                        </p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table custom-table">
                            <thead>
                                <tr>
                                    <th><i class="fas fa-hashtag me-1"></i>ID</th>
                                    <th><i class="fas fa-cogs me-1"></i>Action</th>
                                    <th><i class="fas fa-user me-1"></i>Utilisateur</th>
                                    <th><i class="fas fa-calendar me-1"></i>Date</th>
                                    <th><i class="fas fa-info-circle me-1"></i>Détails</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($historique as $entry): ?>
                                <tr>
                                    <td>
                                        <span class="badge bg-light text-dark">
                                            #<?php echo str_pad($entry['id'], 4, '0', STR_PAD_LEFT); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php 
                                        $action = $entry['action'];
                                        $status_info = $status_labels[$action] ?? ['label' => $action, 'class' => 'secondary'];
                                        ?>
                                        <div class="d-flex align-items-center">
                                            <div class="action-icon bg-<?php echo $status_info['class']; ?> text-white">
                                                <i class="fas fa-<?php 
                                                    switch($status_info['class']) {
                                                        case 'success': echo 'check'; break;
                                                        case 'danger': echo 'times'; break;
                                                        case 'warning': echo 'clock'; break;
                                                        case 'info': echo 'info'; break;
                                                        case 'primary': echo 'shopping-cart'; break;
                                                        default: echo 'file';
                                                    }
                                                ?>"></i>
                                            </div>
                                            <div>
                                                <div class="fw-bold"><?php echo htmlspecialchars($status_info['label']); ?></div>
                                                <small class="text-muted"><?php echo htmlspecialchars($action); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-circle bg-primary text-white me-2">
                                                <?php 
                                                $nom_complet = trim(($entry['prenom'] ?? '') . ' ' . ($entry['nom'] ?? '') ?: $entry['utilisateur']);
                                                echo strtoupper(substr($nom_complet, 0, 2)); 
                                                ?>
                                            </div>
                                            <div>
                                                <div class="fw-bold"><?php echo htmlspecialchars($nom_complet); ?></div>
                                                <?php if (!empty($entry['email'])): ?>
                                                    <small class="text-muted"><?php echo htmlspecialchars($entry['email']); ?></small>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php 
                                        $date = new DateTime($entry['created_at'] ?? $entry['date']);
                                        $now = new DateTime();
                                        $diff = $now->diff($date);
                                        if ($diff->days == 0) {
                                            $time_ago = "Aujourd'hui à " . $date->format('H:i');
                                        } elseif ($diff->days == 1) {
                                            $time_ago = "Hier à " . $date->format('H:i');
                                        } elseif ($diff->days < 7) {
                                            $time_ago = "Il y a " . $diff->days . " jour(s)";
                                        } else {
                                            $time_ago = $date->format('d/m/Y');
                                        }
                                        ?>
                                        <div class="fw-bold"><?php echo $time_ago; ?></div>
                                        <small class="text-muted"><?php echo $date->format('d/m/Y H:i:s'); ?></small>
                                    </td>
                                    <td>
                                        <button class="btn btn-outline-primary btn-sm" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#detailModal<?php echo $entry['id']; ?>">
                                            <i class="fas fa-eye me-1"></i>Voir
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
            <!-- Export Section -->
            <div class="export-section">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h6 class="mb-2">
                            <i class="fas fa-download me-2"></i>Export des données
                        </h6>
                        <p class="text-muted mb-0">
                            Exportez l'historique filtré au format PDF pour analyse externe.
                        </p>
                    </div>
                    <div class="col-md-4 text-end">
                        <form method="get" action="/export/historique.php" class="d-inline">
                            <?php foreach ($_GET as $key => $value): ?>
                                <input type="hidden" name="<?php echo htmlspecialchars($key); ?>" 
                                       value="<?php echo htmlspecialchars($value); ?>">
                            <?php endforeach; ?>
                            <button type="submit" class="btn btn-success btn-custom" onclick="window.location.href='../view/historique.php';">
                                <i class="fas fa-file-csv me-2"></i>Exporter PDF
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Detail Modals -->
    <?php foreach ($historique as $entry): ?>
    <div class="modal fade" id="detailModal<?php echo $entry['id']; ?>" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-info-circle me-2"></i>
                        Détail de l'action #<?php echo $entry['id']; ?>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <dl class="row">
                        <dt class="col-sm-4">Action :</dt>
                        <dd class="col-sm-8"><?php echo htmlspecialchars($entry['action']); ?></dd>
                        <dt class="col-sm-4">Utilisateur :</dt>
                        <dd class="col-sm-8"><?php echo htmlspecialchars($entry['utilisateur']); ?></dd>
                        <dt class="col-sm-4">Date :</dt>
                        <dd class="col-sm-8"><?php echo htmlspecialchars($entry['created_at'] ?? $entry['date']); ?></dd>
                        <?php if (!empty($entry['details'])): ?>
                        <dt class="col-sm-4">Détails :</dt>
                        <dd class="col-sm-8"><?php echo nl2br(htmlspecialchars($entry['details'])); ?></dd>
                        <?php endif; ?>
                        <?php if (!empty($entry['ip_address'])): ?>
                        <dt class="col-sm-4">Adresse IP :</dt>
                        <dd class="col-sm-8"><?php echo htmlspecialchars($entry['ip_address']); ?></dd>
                        <?php endif; ?>
                    </dl>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
    <!-- Scripts -->
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-refresh functionality
        let autoRefresh = setInterval(() => {
            if (document.hidden === false && !document.querySelector('.modal.show')) {
                location.reload();
            }
        }, 300000); // 5 minutes
        // Clear auto-refresh when modal is open
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('shown.bs.modal', () => clearInterval(autoRefresh));
            modal.addEventListener('hidden.bs.modal', () => {
                autoRefresh = setInterval(() => {
                    if (document.hidden === false) location.reload();
                }, 300000);
            });
        });
        // Enhanced table interactions
        document.querySelectorAll('.custom-table tbody tr').forEach(row => {
            row.addEventListener('click', function(e) {
                if (!e.target.closest('button')) {
                    const button = this.querySelector('[data-bs-toggle="modal"]');
                    if (button) button.click();
                }
            });
        });
    </script>
    <style>
        .avatar-circle {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            font-weight: 600;
        }
    </style>
</body>
</html>