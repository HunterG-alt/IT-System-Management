<?php
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Config/db.php';
require_login();
$user = get_current_user_data();
$userRole = $user['role'] ?? ($_SESSION['role'] ?? '');
$msg = $_GET['msg'] ?? '';
$success = $_GET['success'] ?? '';
// Pagination
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;
// PDO
$pdo = Database::getInstance()->getConnection();
// Statuts (DB uses lowercase); map display values separately
$allowedStatuses = ['en_attente','validee_directeur','refusee_directeur','pre_validee'];
$in = implode(',', array_fill(0, count($allowedStatuses), '?'));
$stmt = $pdo->prepare("
    SELECT b.id_besoin AS id,
           b.designation_materiel AS designation,
           b.justification,
           b.statut,
           a.nom, a.prenom
    FROM etat_de_besoin b
    JOIN agents a ON a.id_agent = b.id_agent
    WHERE b.statut IN ($in)
    ORDER BY b.id_besoin DESC
    LIMIT ? OFFSET ?
");
$params = array_merge($allowedStatuses, [$limit, $offset]);
$stmt->execute($params);
$demandes = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Total pour pagination
$st2 = $pdo->prepare("SELECT COUNT(*) as c FROM etat_de_besoin WHERE statut IN ($in)");
$st2->execute($allowedStatuses);
$total = (int)($st2->fetch()['c'] ?? 0);
$totalPages = ceil($total / $limit);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Liste des Demandes</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { font-family: Arial,sans-serif; background:#f4f6f9; padding:20px; }
.table-container { background:#fff; padding:20px; border-radius:10px; box-shadow:0 4px 12px rgba(0,0,0,0.1); }
.statut { padding:5px 10px; border-radius:6px; font-weight:bold; font-size:12px; color:#fff; }
.statut.EN_ATTENTE { background:#ffc107; }
.statut.APPROUVE { background:#28a745; }
.statut.REJETE { background:#dc3545; }
.search-box { margin-bottom:15px; }
.pagination { justify-content:center; }
</style>
</head>
<body>
<div class="container table-container">
<h1 class="mb-4">Liste des Demandes</h1>
<?php if($msg): ?>
    <div class="alert alert-info">
        <?= htmlspecialchars($msg) ?>
    </div>
<?php elseif($success): ?>
    <div class="alert alert-success">
        <?= htmlspecialchars($success) ?>
    </div>
<?php endif; ?>
<input type="text" id="search" class="form-control search-box" placeholder="Rechercher par désignation, besoin ou agent...">
<table class="table table-hover align-middle">
  <thead class="table-dark">
    <tr>
      <th>ID</th>
      <th>Désignation</th>
      <th>Besoin</th>
      <th>Justification</th>
      <th>Agent</th>
      <th>Statut</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody id="demandesTable">
  <?php foreach($demandes as $d): ?>
    <tr>
      <td><?= htmlspecialchars($d['id']) ?></td>
      <td><?= htmlspecialchars($d['designation']) ?></td>
      <td><?= htmlspecialchars($d['designation']) ?></td>
      <td><?= htmlspecialchars($d['justification']) ?></td>
      <td><?= htmlspecialchars($d['nom'].' '.$d['prenom']) ?></td>
      <?php $dispStat = strtoupper($d['statut']); ?>
      <td><span class="statut <?= htmlspecialchars($dispStat) ?> status-badge"><?= htmlspecialchars($dispStat) ?></span></td>
      <td>
  <a href="demande.php?id=<?= (int)$d['id'] ?>" class="btn btn-sm btn-primary">Voir</a>
  <?php if($userRole === 'demandeur' || $userRole === 'agent_demandeur'): ?>
    <a href="demande_edit.php?id=<?= (int)$d['id'] ?>" class="btn btn-sm btn-warning">Modifier</a>
  <?php endif; ?>
  <?php if($userRole === 'chef_service' && $d['statut'] === 'en_attente'): ?>
    <form method="post" action="demande_action.php" class="d-inline">
      <?= CSRFProtection::getInputField('chef_request_action') ?>
      <input type="hidden" name="id_besoin" value="<?= (int)$d['id'] ?>">
      <input type="hidden" name="action" value="approve">
      <button type="submit" class="btn btn-sm btn-success">pré-validation</button>
    </form>
    <form method="post" action="demande_action.php" class="d-inline ms-1">
      <?= CSRFProtection::getInputField('chef_request_action') ?>
      <input type="hidden" name="id_besoin" value="<?= (int)$d['id'] ?>">
      <input type="hidden" name="action" value="reject">
      <button type="submit" class="btn btn-sm btn-danger">Rejeter</button>
    </form>
  <?php endif; ?>
</td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php if ($totalPages > 1): ?>
<nav>
  <ul class="pagination">
    <?php for($p=1;$p<=$totalPages;$p++): ?>
      <li class="page-item <?= $p==$page?'active':'' ?>">
        <a class="page-link" href="?page=<?= $p ?>"><?= $p ?></a>
      </li>
    <?php endfor; ?>
  </ul>
</nav>
<?php endif; ?>
<?php if ($userRole === 'chef_service'): ?>
  <div class="mt-3">
    <?php 
    $bulkActions = [
        ['mark_all_favorable', 'btn-primary', 'Marquer toutes comme favorables'],
        ['mark_all_defavorable', 'btn-danger', 'Marquer toutes comme défavorables'],
        ['delete_all', 'btn-secondary', 'Supprimer toutes les pré-validations']
    ];
    foreach ($bulkActions as [$action, $class, $label]): ?>
      <form method="post" action="/pre-validation.php?action=<?= $action ?>" class="mb-2 d-inline">
        <?php csrfInput(); ?>
        <button class="btn <?= $class ?>" type="submit"><?= $label ?></button>
      </form>
    <?php endforeach; ?>
  </div>
  <form method="post" action="pre-validation.php?action=<?= $action ?>/delete_by_date" class="mt-3">
    <?php csrfInput(); ?>
    <div class="mb-3">
      <label for="date">Date limite pour supprimer les pré-validations</label> 
      <input type="date" name="date" class="form-control" id="date">
    </div>
    <button class="btn btn-danger" type="submit">Supprimer</button>
  </form>
<?php endif; ?>
</div>
<script>
const searchInput = document.getElementById('search');
searchInput.addEventListener('keyup', function(){
  const filter = searchInput.value.toLowerCase().trim();
  document.querySelectorAll('#demandesTable tr').forEach(tr=>{
    tr.style.display = Array.from(tr.cells).some(td => td.textContent.toLowerCase().includes(filter)) ? '' : 'none';
  });
});
</script>
</body>
</html>