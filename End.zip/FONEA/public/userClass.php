<?php
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../Lib/csrf.php';
class User {
    
    public static function authenticate(string $email, string $password): array|false {
        try {
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare("
                SELECT id_agent as id, nom, prenom, email, mot_de_passe, role, date_creation
                FROM agents 
                WHERE email = ?
            ");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($user) {
                // Check both SHA2 (from DB) and password_hash (for new users)
                $password_valid = false;
                // Try SHA2 first (legacy from database)
                if (strlen($user['mot_de_passe']) === 64) { // SHA2 produces 64-char hex
                    $password_valid = hash_equals($user['mot_de_passe'], hash('sha256', $password));
                }
                // Try password_verify for modern hashes
                if (!$password_valid) {
                    $password_valid = password_verify($password, $user['mot_de_passe']);
                }
                if ($password_valid) {
                    self::updateLastLogin((int)$user['id']);
                    unset($user['mot_de_passe']);
                    return $user;
                }
            }
            return false;
        } catch (Exception $e) {
            error_log("Authentication error: " . $e->getMessage());
            return false;
        }
    }
    
    public static function getById(int $id): ?array {
        try {
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare("
                SELECT id_agent as id, nom, prenom, email, role, date_creation,
                       CONCAT(prenom, ' ', nom) as nom_complet
                FROM agents 
                WHERE id_agent = ?
            ");
            $stmt->execute([$id]);
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (Exception $e) {
            error_log("Error fetching user by ID: " . $e->getMessage());
            return null;
        }
    }
    
    public static function create(array $data): int|false {
        try {
            $required = ['nom','prenom','email','password','role'];
            foreach ($required as $field) {
                if (empty($data[$field])) {
                    throw new Exception("Field '$field' is required");
                }
            }
            $valid_roles = ['demandeur','chef_service','directeur','directeur_general','informatique','moyens_generaux'];
            if (!in_array($data['role'], $valid_roles)) {
                throw new Exception("Invalid role specified");
            }
            $db = Database::getInstance()->getConnection();
            // Check if email exists
            $stmt = $db->prepare("SELECT COUNT(*) FROM agents WHERE email = ?");
            $stmt->execute([$data['email']]);
            if ($stmt->fetchColumn() > 0) {
                throw new Exception("Email already exists");
            }
            // Hash password securely
            $password_hash = password_hash($data['password'], PASSWORD_DEFAULT);
            $stmt = $db->prepare("
                INSERT INTO agents (nom, prenom, email, mot_de_passe, role) 
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([$data['nom'],$data['prenom'],$data['email'],$password_hash,$data['role']]);
            return (int)$db->lastInsertId();
        } catch (Exception $e) {
            error_log("Error creating user: " . $e->getMessage());
            return false;
        }
    }
    
    public static function update(int $id, array $data): bool {
        try {
            $db = Database::getInstance()->getConnection();
            $set = [];
            $params = [];
            $allowed_fields = ['nom','prenom','email','role'];
            foreach ($allowed_fields as $field) {
                if (isset($data[$field])) {
                    $set[] = "$field = ?";
                    $params[] = $data[$field];
                }
            }
            if (!empty($data['password'])) {
                $set[] = "mot_de_passe = ?";
                $params[] = password_hash($data['password'], PASSWORD_DEFAULT);
            }
            if (empty($set)) return false;
            $params[] = $id;
            $sql = "UPDATE agents SET " . implode(', ', $set) . " WHERE id_agent = ?";
            $stmt = $db->prepare($sql);
            return $stmt->execute($params);
        } catch (Exception $e) {
            error_log("Error updating user: " . $e->getMessage());
            return false;
        }
    }
    
public static function delete(int $id): bool {
    $db = Database::getInstance()->getConnection();

    try {
        
        $db->beginTransaction();

        $stmt = $db->prepare("DELETE FROM agents WHERE id_agent = ?");
        $stmt->execute([$id]);

        if ($stmt->rowCount() > 0) {
            
            $db->commit();
            return true;
        } else {
            
            $db->rollBack();
            error_log("Delete failed: No agent found with ID = " . $id);
            return false;
        }

    } catch (PDOException $e) {
        
        if ($db->inTransaction()) {
            $db->rollBack();
        }

        error_log("Database error deleting agent (ID: $id): " . $e->getMessage());
        return false;

    } catch (Exception $e) {
        
        if ($db->inTransaction()) {
            $db->rollBack();
        }

        error_log("Unexpected error deleting agent (ID: $id): " . $e->getMessage());
        return false;
    }
}

    public static function getAll(int $limit=20,int $offset=0): array {
        try {
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare("
                SELECT id_agent as id, nom, prenom, email, role, date_creation
                FROM agents 
                ORDER BY date_creation DESC 
                LIMIT ? OFFSET ?
            ");
            $stmt->execute([$limit,$offset]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error fetching users: " . $e->getMessage());
            return [];
        }
    }
    
    public static function count(): int {
        try {
            $db = Database::getInstance()->getConnection();
            $stmt = $db->query("SELECT COUNT(*) FROM agents");
            return (int)$stmt->fetchColumn();
        } catch (Exception $e) {
            error_log("Error counting users: " . $e->getMessage());
            return 0;
        }
    }
   
    private static function updateLastLogin(int $user_id): void {
        try {
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare("UPDATE agents SET last_login = NOW() WHERE id_agent = ?");
            $stmt->execute([$user_id]);
        } catch (Exception $e) {
            error_log("Error updating last login: " . $e->getMessage());
        }
    }
    
    public static function hasRole(int $user_id, string $role): bool {
        try {
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare("SELECT role FROM agents WHERE id_agent = ?");
            $stmt->execute([$user_id]);
            return $stmt->fetchColumn() === $role;
        } catch (Exception $e) {
            error_log("Error checking user role: " . $e->getMessage());
            return false;
        }
    }
    
    public static function getByRole(string $role): array {
        try {
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare("
                SELECT id_agent as id, nom, prenom, email, role, date_creation,
                       CONCAT(prenom, ' ', nom) as nom_complet
                FROM agents 
                WHERE role = ?
                ORDER BY nom, prenom
            ");
            $stmt->execute([$role]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error fetching users by role: " . $e->getMessage());
            return [];
        }
    }
}