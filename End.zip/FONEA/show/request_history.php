<?php
// request_history.php
session_start();
require_once '../Config/db.php'; 

if (!isset($_SESSION['user_id'])) {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit;
}
$userId = $_SESSION['user_id'];
$role = $_SESSION['role'] ?? '';

try {
    if ($role === 'DG' || $role === 'Directeur' || $role === 'Moyen Generaux') {
        
        $stmt = $pdo->query("SELECT id, title, status, created_at, updated_at FROM requests ORDER BY updated_at DESC");
    } else {
        
        $stmt = $pdo->prepare("SELECT id, title, status, created_at, updated_at FROM requests WHERE user_id = :uid ORDER BY updated_at DESC");
        $stmt->execute(['uid' => $userId]);
    }
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur lors de la récupération de l'historique : " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historique des Demandes</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #4facfe, #00f2fe);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }
        .card {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 20px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
            color: #fff;
            padding: 2rem;
        }
        h1 {
            color: #fff;
            text-align: center;
            margin-bottom: 2rem;
            text-shadow: 1px 1px 4px rgba(0,0,0,0.4);
        }
        table {
            color: #fff;
        }
        .btn-secondary {
            background-color: rgba(255,255,255,0.2);
            border: none;
            transition: 0.3s;
        }
        .btn-secondary:hover {
            background-color: rgba(255,255,255,0.35);
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Historique des Demandes</h1>
    <div class="card">
        <?php if (count($requests) > 0): ?>
            <table class="table table-hover table-borderless">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Titre</th>
                        <th>Statut</th>
                        <th>Date de création</th>
                        <th>Dernière mise à jour</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requests as $req): ?>
                        <tr>
                            <td><?= htmlspecialchars($req['id']) ?></td>
                            <td><?= htmlspecialchars($req['title']) ?></td>
                            <td>
                                <?php
                                $statusClass = match($req['status']) {
                                    'Clôturé' => 'text-success',
                                    'Rejeté' => 'text-danger',
                                    'En cours de traitement' => 'text-warning',
                                    default => 'text-light'
                                };
                                ?>
                                <span class="<?= $statusClass ?>"><?= htmlspecialchars($req['status']) ?></span>
                            </td>
                            <td><?= htmlspecialchars(date('d/m/Y H:i', strtotime($req['created_at']))) ?></td>
                            <td><?= htmlspecialchars(date('d/m/Y H:i', strtotime($req['updated_at']))) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="text-center">Aucune demande trouvée dans l'historique.</p>
        <?php endif; ?>
    </div>
    <div class="text-center mt-4">
        <a href="dashboard_agent.php" class="btn btn-secondary">Retour au Tableau de Bord</a>
        <a href="logout.php" class="btn btn-danger">Se Déconnecter</a>
    </div>
</div>
</body>
</html>
