<?php
/**
 * Materiel (Equipment/Material) Management Class for FONEA System
 * 
 * Handles equipment inventory, specifications, and stock management
 * 
 * @author Glory LOUSSI & Development Team
 * @version 2.0
 */
require_once __DIR__ . '/../Config/db.php';
class Materiel {
    /**
     * Get all materials with pagination
     * 
     * @param int $limit
     * @param int $offset
     * @return array
     */
    public static function getAll(int $limit = 20, int $offset = 0): array {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            $stmt = $pdo->prepare("
                SELECT m.*, t.libelle as type_libelle, s.quantite as stock_quantite
                FROM materiel m
                LEFT JOIN type_materiel t ON m.id_type = t.id_type
                LEFT JOIN stock s ON m.id_materiel = s.id_materiel
                ORDER BY m.date_materiel DESC 
                LIMIT ? OFFSET ?
            ");
            $stmt->execute([$limit, $offset]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error fetching materials: " . $e->getMessage());
            return [];
        }
    }
    /**
     * Get material by ID
     * 
     * @param int $id
     * @return array|null
     */
    public static function getById(int $id): ?array {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            $stmt = $pdo->prepare("
                SELECT m.*, t.libelle as type_libelle, s.quantite as stock_quantite,
                       b.designation_materiel as besoin_designation
                FROM materiel m
                LEFT JOIN type_materiel t ON m.id_type = t.id_type
                LEFT JOIN stock s ON m.id_materiel = s.id_materiel
                LEFT JOIN etat_de_besoin b ON m.id_etat = b.id_besoin
                WHERE m.id_materiel = ?
            ");
            $stmt->execute([$id]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result ?: null;
        } catch (Exception $e) {
            error_log("Error fetching material by ID: " . $e->getMessage());
            return null;
        }
    }
    /**
     * Create new material
     * 
     * @param array $data
     * @return int|false Material ID on success, false on failure
     */
    public static function create(array $data) {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            $stmt = $pdo->prepare("
                INSERT INTO materiel (id_etat, quantite, id_type, reference, designation, marque, modele, categorie, caracteristique, statut) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $data['id_etat'],
                $data['quantite'],
                $data['id_type'],
                $data['reference'],
                $data['designation'],
                $data['marque'],
                $data['modele'],
                $data['categorie'] ?? 'Autres',
                $data['caracteristique'] ?? null,
                $data['statut'] ?? 'disponible'
            ]);
            $material_id = $pdo->lastInsertId();
            // Add to stock if quantity > 0
            if ($data['quantite'] > 0) {
                self::addToStock($material_id, $data['quantite']);
            }
            return $material_id;
        } catch (Exception $e) {
            error_log("Error creating material: " . $e->getMessage());
            return false;
        }
    }
    /**
     * Update material
     * 
     * @param int $id
     * @param array $data
     * @return bool
     */
    public static function update(int $id, array $data): bool {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            $set_clauses = [];
            $params = [];
            $allowed_fields = ['quantite', 'reference', 'designation', 'marque', 'modele', 'categorie', 'caracteristique', 'statut'];
            foreach ($allowed_fields as $field) {
                if (isset($data[$field])) {
                    $set_clauses[] = "$field = ?";
                    $params[] = $data[$field];
                }
            }
            if (empty($set_clauses)) {
                return false;
            }
            $params[] = $id;
            $sql = "UPDATE materiel SET " . implode(', ', $set_clauses) . " WHERE id_materiel = ?";
            $stmt = $pdo->prepare($sql);
            return $stmt->execute($params);
        } catch (Exception $e) {
            error_log("Error updating material: " . $e->getMessage());
            return false;
        }
    }
    /**
     * Delete material
     * 
     * @param int $id
     * @return bool
     */
    public static function delete(int $id): bool {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            // Remove from stock first
            $stmt = $pdo->prepare("DELETE FROM stock WHERE id_materiel = ?");
            $stmt->execute([$id]);
            // Delete material
            $stmt = $pdo->prepare("DELETE FROM materiel WHERE id_materiel = ?");
            return $stmt->execute([$id]);
        } catch (Exception $e) {
            error_log("Error deleting material: " . $e->getMessage());
            return false;
        }
    }
    /**
     * Add material to stock
     * 
     * @param int $material_id
     * @param int $quantity
     * @return bool
     */
    public static function addToStock(int $material_id, int $quantity): bool {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            // Check if already in stock
            $stmt = $pdo->prepare("SELECT quantite FROM stock WHERE id_materiel = ?");
            $stmt->execute([$material_id]);
            $existing = $stmt->fetchColumn();
            if ($existing !== false) {
                // Update existing stock
                $stmt = $pdo->prepare("UPDATE stock SET quantite = quantite + ? WHERE id_materiel = ?");
                return $stmt->execute([$quantity, $material_id]);
            } else {
                // Add new stock entry
                $stmt = $pdo->prepare("INSERT INTO stock (id_materiel, quantite) VALUES (?, ?)");
                return $stmt->execute([$material_id, $quantity]);
            }
        } catch (Exception $e) {
            error_log("Error adding to stock: " . $e->getMessage());
            return false;
        }
    }
    /**
     * Remove material from stock
     * 
     * @param int $material_id
     * @param int $quantity
     * @return bool
     */
    public static function removeFromStock(int $material_id, int $quantity): bool {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            // Check current stock
            $stmt = $pdo->prepare("SELECT quantite FROM stock WHERE id_materiel = ?");
            $stmt->execute([$material_id]);
            $current_stock = $stmt->fetchColumn();
            if ($current_stock === false || $current_stock < $quantity) {
                return false; // Insufficient stock
            }
            $new_quantity = $current_stock - $quantity;
            if ($new_quantity <= 0) {
                // Remove from stock completely
                $stmt = $pdo->prepare("DELETE FROM stock WHERE id_materiel = ?");
                return $stmt->execute([$material_id]);
            } else {
                // Update stock quantity
                $stmt = $pdo->prepare("UPDATE stock SET quantite = ? WHERE id_materiel = ?");
                return $stmt->execute([$new_quantity, $material_id]);
            }
        } catch (Exception $e) {
            error_log("Error removing from stock: " . $e->getMessage());
            return false;
        }
    }
    /**
     * Get stock quantity for material
     * 
     * @param int $material_id
     * @return int
     */
    public static function getStockQuantity(int $material_id): int {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            $stmt = $pdo->prepare("SELECT quantite FROM stock WHERE id_materiel = ?");
            $stmt->execute([$material_id]);
            $quantity = $stmt->fetchColumn();
            return $quantity !== false ? (int) $quantity : 0;
        } catch (Exception $e) {
            error_log("Error getting stock quantity: " . $e->getMessage());
            return 0;
        }
    }
    /**
     * Get materials by category
     * 
     * @param string $category
     * @return array
     */
    public static function getByCategory(string $category): array {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            $stmt = $pdo->prepare("
                SELECT m.*, t.libelle as type_libelle, s.quantite as stock_quantite
                FROM materiel m
                LEFT JOIN type_materiel t ON m.id_type = t.id_type
                LEFT JOIN stock s ON m.id_materiel = s.id_materiel
                WHERE m.categorie = ?
                ORDER BY m.designation
            ");
            $stmt->execute([$category]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error fetching materials by category: " . $e->getMessage());
            return [];
        }
    }
    /**
     * Search materials
     * 
     * @param string $search_term
     * @return array
     */
    public static function search(string $search_term): array {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            $search_term = "%$search_term%";
            $stmt = $pdo->prepare("
                SELECT m.*, t.libelle as type_libelle, s.quantite as stock_quantite
                FROM materiel m
                LEFT JOIN type_materiel t ON m.id_type = t.id_type
                LEFT JOIN stock s ON m.id_materiel = s.id_materiel
                WHERE m.designation LIKE ? OR m.marque LIKE ? OR m.modele LIKE ? OR m.reference LIKE ?
                ORDER BY m.designation
            ");
            $stmt->execute([$search_term, $search_term, $search_term, $search_term]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error searching materials: " . $e->getMessage());
            return [];
        }
    }
    /**
     * Get low stock materials
     * 
     * @param int $threshold
     * @return array
     */
    public static function getLowStock(int $threshold = 5): array {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            $stmt = $pdo->prepare("
                SELECT m.*, t.libelle as type_libelle, s.quantite as stock_quantite
                FROM materiel m
                LEFT JOIN type_materiel t ON m.id_type = t.id_type
                LEFT JOIN stock s ON m.id_materiel = s.id_materiel
                WHERE s.quantite <= ? AND s.quantite > 0
                ORDER BY s.quantite ASC
            ");
            $stmt->execute([$threshold]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error fetching low stock materials: " . $e->getMessage());
            return [];
        }
    }
}
?>