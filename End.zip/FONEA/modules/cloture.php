<?php
require_once __DIR__ . '/../Config/db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requestId = $_POST['request_id'] ?? null;
    if ($requestId) {
        // Exemple de mise à jour du statut
        $stmt = $pdo->prepare("UPDATE requests SET status='Clôturé' WHERE id=:id");
        $stmt->execute(['id' => $requestId]);
        // Redirection après clôture
        header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/Show/my_requests.php?msg=cloture");
        exit;
    } else {
        echo "Aucune demande spécifiée.";
    }
}
