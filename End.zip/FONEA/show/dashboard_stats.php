<?php require_once __DIR__ . '/../Config/titles.php'; ?>
<?php
// dashboard_stats.php - Fichier à inclure dans votre dashboard
require_once '../Config/db.php'; 
function getDashboardStats($pdo) {
    $stats = [];
    try {
        // 1. Nouvelles demandes aujourd'hui
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as count 
            FROM demandes 
            WHERE DATE(date_creation) = CURDATE()
        ");
        $stmt->execute();
        $stats['nouvelles_aujourd_hui'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        // 2. Demandes validées cette semaine (7 derniers jours)
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as count 
            FROM demandes 
            WHERE statut = 'validee' 
            AND date_validation >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        ");
        $stmt->execute();
        $stats['validees_semaine'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        // 3. Demandes en attente d'approbation
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as count 
            FROM demandes 
            WHERE statut = 'en_attente_approbation' 
            OR statut = 'validee'
        ");
        $stmt->execute();
        $stats['en_attente_approbation'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        // 4. Statistiques générales (bonus)
        // Total des demandes
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM demandes");
        $stmt->execute();
        $stats['total_demandes'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        // Demandes en cours (non finalisées)
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as count 
            FROM demandes 
            WHERE statut NOT IN ('approuvee', 'rejetee')
        ");
        $stmt->execute();
        $stats['en_cours'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        // Demandes approuvées
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as count 
            FROM demandes 
            WHERE statut = 'approuvee'
        ");
        $stmt->execute();
        $stats['approuvees'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        // Demandes rejetées
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as count 
            FROM demandes 
            WHERE statut = 'rejetee'
        ");
        $stmt->execute();
        $stats['rejetees'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    } catch (PDOException $e) {
        // En cas d'erreur, retourner des valeurs par défaut
        error_log("Erreur dans getDashboardStats: " . $e->getMessage());
        $stats = [
            'nouvelles_aujourd_hui' => 0,
            'validees_semaine' => 0,
            'en_attente_approbation' => 0,
            'total_demandes' => 0,
            'en_cours' => 0,
            'approuvees' => 0,
            'rejetees' => 0
        ];
    }
    return $stats;
}
// Utilisation dans votre page dashboard
try {
    $stats = getDashboardStats($pdo);
} catch (Exception $e) {
    // Gérer l'erreur
    $stats = [
        'nouvelles_aujourd_hui' => 0,
        'validees_semaine' => 0,
        'en_attente_approbation' => 0,
        'total_demandes' => 0,
        'en_cours' => 0,
        'approuvees' => 0,
        'rejetees' => 0
    ];
}
?>
<!-- HTML pour afficher les statistiques dans votre dashboard -->
<div id="dashboard" class="page-content active">
    <h2><i class="fas fa-tachometer-alt"></i> Tableau de Bord</h2>
    <p>Vue d'ensemble des statistiques et activités récentes du système FONEA.</p>
    <div class="row">
        <div class="col-md-6">
            <div class="stats-card">
                <h4><i class="fas fa-chart-bar"></i> Statistiques Générales</h4>
                <ul class="stats-list">
                    <li>
                        <span class="stat-label">Nombre total de demandes:</span> 
                        <strong class="stat-number text-primary"><?= $stats['total_demandes'] ?></strong>
                    </li>
                    <li>
                        <span class="stat-label">Demandes en cours:</span> 
                        <strong class="stat-number text-warning"><?= $stats['en_cours'] ?></strong>
                    </li>
                    <li>
                        <span class="stat-label">Demandes approuvées:</span> 
                        <strong class="stat-number text-success"><?= $stats['approuvees'] ?></strong>
                    </li>
                    <li>
                        <span class="stat-label">Demandes rejetées:</span> 
                        <strong class="stat-number text-danger"><?= $stats['rejetees'] ?></strong>
                    </li>
                </ul>
            </div>
        </div>
        <div class="col-md-6">
            <div class="stats-card">
                <h4><i class="fas fa-clock"></i> Activités Récentes</h4>
                <ul class="activity-list">
                    <li class="activity-item <?= $stats['nouvelles_aujourd_hui'] > 0 ? 'has-activity' : '' ?>">
                        <i class="fas fa-plus-circle text-info"></i>
                        <span><?= $stats['nouvelles_aujourd_hui'] ?> nouvelle<?= $stats['nouvelles_aujourd_hui'] > 1 ? 's' : '' ?> demande<?= $stats['nouvelles_aujourd_hui'] > 1 ? 's' : '' ?> aujourd'hui</span>
                        <?php if($stats['nouvelles_aujourd_hui'] > 0): ?>
                            <span class="badge bg-info ms-2"><?= $stats['nouvelles_aujourd_hui'] ?></span>
                        <?php endif; ?>
                    </li>
                    <li class="activity-item <?= $stats['validees_semaine'] > 0 ? 'has-activity' : '' ?>">
                        <i class="fas fa-check-circle text-success"></i>
                        <span><?= $stats['validees_semaine'] ?> demande<?= $stats['validees_semaine'] > 1 ? 's' : '' ?> validée<?= $stats['validees_semaine'] > 1 ? 's' : '' ?> cette semaine</span>
                        <?php if($stats['validees_semaine'] > 0): ?>
                            <span class="badge bg-success ms-2"><?= $stats['validees_semaine'] ?></span>
                        <?php endif; ?>
                    </li>
                    <li class="activity-item <?= $stats['en_attente_approbation'] > 0 ? 'has-activity' : '' ?>">
                        <i class="fas fa-hourglass-half text-warning"></i>
                        <span><?= $stats['en_attente_approbation'] ?> demande<?= $stats['en_attente_approbation'] > 1 ? 's' : '' ?> en attente d'approbation</span>
                        <?php if($stats['en_attente_approbation'] > 0): ?>
                            <span class="badge bg-warning ms-2"><?= $stats['en_attente_approbation'] ?></span>
                            <?php if($stats['en_attente_approbation'] > 5): ?>
                                <span class="urgent-badge">URGENT</span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Alertes conditionnelles -->
    <?php if($stats['en_attente_approbation'] > 5): ?>
    <div class="alert alert-warning mt-3">
        <i class="fas fa-exclamation-triangle"></i>
        <strong>Attention:</strong> <?= $stats['en_attente_approbation'] ?> demandes nécessitent une validation urgente.
    </div>
    <?php endif; ?>
    <?php if($stats['nouvelles_aujourd_hui'] > 0): ?>
    <div class="alert alert-info mt-3">
        <i class="fas fa-info-circle"></i>
        <strong>Info:</strong> <?= $stats['nouvelles_aujourd_hui'] ?> nouvelle<?= $stats['nouvelles_aujourd_hui'] > 1 ? 's' : '' ?> demande<?= $stats['nouvelles_aujourd_hui'] > 1 ? 's' : '' ?> soumise<?= $stats['nouvelles_aujourd_hui'] > 1 ? 's' : '' ?> aujourd'hui.
    </div>
    <?php endif; ?>
</div>
<style>
/* Styles CSS additionnels pour les statistiques */
.stats-card {
    background: rgba(255,255,255,0.05);
    border-radius: 15px;
    padding: 20px;
    margin-bottom: 20px;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.1);
}
.stats-card h4 {
    color: #4CAF50;
    margin-bottom: 15px;
    font-size: 1.2rem;
}
.stats-list {
    list-style: none;
    padding: 0;
}
.stats-list li {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}
.stats-list li:last-child {
    border-bottom: none;
}
.stat-label {
    color: #ccc;
}
.stat-number {
    font-size: 1.2rem;
    font-weight: bold;
}
.activity-list {
    list-style: none;
    padding: 0;
}
.activity-item {
    display: flex;
    align-items: center;
    padding: 12px 0;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    color: #ccc;
    transition: all 0.3s ease;
}
.activity-item:last-child {
    border-bottom: none;
}
.activity-item.has-activity {
    color: white;
    background: rgba(255,255,255,0.05);
    border-radius: 8px;
    padding: 12px;
    margin: 5px 0;
}
.activity-item i {
    margin-right: 10px;
    font-size: 1.1rem;
}
.urgent-badge {
    background: #ff4757;
    color: white;
    font-size: 0.7rem;
    padding: 2px 6px;
    border-radius: 10px;
    margin-left: 8px;
    animation: pulse 2s infinite;
}
@keyframes pulse {
    0% { opacity: 1; }
    50% { opacity: 0.5; }
    100% { opacity: 1; }
}
.text-primary { color: #007bff !important; }
.text-success { color: #28a745 !important; }
.text-warning { color: #ffc107 !important; }
.text-danger { color: #dc3545 !important; }
.text-info { color: #17a2b8 !important; }
</style>
<?php
// Fonction utilitaire pour rafraîchir les stats via AJAX (optionnel)
if (isset($_GET['ajax']) && $_GET['ajax'] === 'refresh_stats') {
    header('Content-Type: application/json');
    echo json_encode(getDashboardStats($pdo));
    exit;
}
?>
<script>
// Script JavaScript pour rafraîchir les stats automatiquement (optionnel)
function refreshStats() {
    fetch('?ajax=refresh_stats')
        .then(response => response.json())
        .then(data => {
            // Mettre à jour les éléments avec les nouvelles données
            console.log('Stats refreshed:', data);
        })
        .catch(error => console.error('Erreur:', error));
}
// Rafraîchir les stats toutes les 5 minutes
// setInterval(refreshStats, 300000);
</script>