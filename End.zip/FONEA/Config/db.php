<?php
/**
 * Database Configuration File for FONEA System
 * 
 * This file contains database connection settings, role definitions,
 * and essential database utility functions.
 * 
 * @author Glory LOUSSI & Development Team
 * @version 2.0
 * @created 2025
 * Contact: gloryloudmith@gmail.com
 * License: All rights reserved
 *
 * Note: Unauthorized copying or modification is prohibited.
 */
// Security check to prevent direct access
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', true);
}
// Environment configuration
define('ENVIRONMENT', 'development'); // production, development, testing
// Role definitions with hierarchical structure
define('ROLE_AGENT', 'agent_demandeur');
define('ROLE_DEMANDEUR', 'demandeur');
define('ROLE_CHEF', 'chef_service');
define('ROLE_DIRECTEUR', 'directeur');
define('ROLE_DIRECTEUR_GENERAL', 'directeur_general');
define('ROLE_INFO', 'informatique');
define('ROLE_MG', 'moyens_generaux');
// Role hierarchy for permission checking
define('ROLE_HIERARCHY', [
    ROLE_AGENT => 1,
    ROLE_DEMANDEUR => 1,
    ROLE_CHEF => 2,
    ROLE_INFO => 2,
    ROLE_MG => 2,
    ROLE_DIRECTEUR => 3,
    ROLE_DIRECTEUR_GENERAL => 4 // highest level
]);
// Database status constants
define('STATUS_EN_ATTENTE', 'EN_ATTENTE');
define('STATUS_APPROUVE', 'APPROUVE');
define('STATUS_REJETE', 'REJETE');
define('STATUS_EN_COURS', 'EN_COURS');
define('STATUS_TERMINE', 'TERMINE');

class Database {
    private static $instance = null;
    private $connection = null;
    private $config = [];
    
    private function __construct() {
        $this->loadConfig();
        $this->connect();
    }
    /**
     * Get singleton instance of Database
     * 
     * @return Database
     */
    public static function getInstance(): Database {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function loadConfig(): void {
        switch (ENVIRONMENT) {
            case 'production':
                $this->config = [
                    'host' => $_ENV['DB_HOST'] ?? 'localhost',
                    'dbname' => $_ENV['DB_NAME'] ?? 'fonea_prod',
                    'username' => $_ENV['DB_USER'] ?? 'fonea_user',
                    'password' => $_ENV['DB_PASS'] ?? '',
                    'charset' => 'utf8mb4',
                    'options' => [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => false,
                        PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT => true
                    ]
                ];
                break;
            case 'testing':
                $this->config = [
                    'host' => 'localhost',
                    'dbname' => 'fonea_test',
                    'username' => 'root',
                    'password' => '',
                    'charset' => 'utf8mb4',
                    'options' => [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => false
                    ]
                ];
                break;
            default: // development
                $this->config = [
                    'host' => 'localhost',
                    'dbname' => 'fonea',
                    'username' => 'root',
                    'password' => '',
                    'charset' => 'utf8mb4',
                    'options' => [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => false,
                        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
                    ]
                ];
                break;
        }
    }
    /**
     * Establish database connection
     * 
     * @throws Exception
     */
    private function connect(): void {
        try {
            $dsn = sprintf(
                "mysql:host=%s;dbname=%s;charset=%s",
                $this->config['host'],
                $this->config['dbname'],
                $this->config['charset']
            );
            $this->connection = new PDO(
                $dsn,
                $this->config['username'],
                $this->config['password'],
                $this->config['options']
            );
            // Test the connection
            $this->connection->query('SELECT 1');
            // Log successful connection in development
            if (ENVIRONMENT === 'development') {
                error_log("Database connection established successfully to {$this->config['dbname']}");
            }
        } catch (PDOException $e) {
            $error_message = "Database connection failed: " . $e->getMessage();
            error_log($error_message);
            if (ENVIRONMENT === 'development') {
                throw new Exception($error_message);
            } else {
                throw new Exception("Database connection failed. Please try again later.");
            }
        }
    }
    /**
     * Get PDO connection instance
     * 
     * @return PDO
     * @throws Exception
     */
    public function getConnection(): PDO {
        if ($this->connection === null) {
            throw new Exception("Database connection not established");
        }
        // Check if connection is still alive
        try {
            $this->connection->query('SELECT 1');
        } catch (PDOException $e) {
            error_log("Database connection lost, reconnecting...");
            $this->connect();
        }
        return $this->connection;
    }
    /**
     * Get database configuration
     * 
     * @return array
     */
    public function getConfig(): array {
        return $this->config;
    }
    /**
     * Check database health
     * 
     * @return bool
     */
    public function isHealthy(): bool {
        try {
            $stmt = $this->connection->query('SELECT 1 as health_check');
            return $stmt !== false;
        } catch (PDOException $e) {
            error_log("Database health check failed: " . $e->getMessage());
            return false;
        }
    }
    
    public function beginTransaction(): void {
        $this->connection->beginTransaction();
    }
        public function commit(): void {
        $this->connection->commit();
    }
    
    public function rollback(): void {
        $this->connection->rollBack();
    }
    
    private function __clone() {}
    
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}

class UserUtils {
    /**
     * Get current user data from session
     * 
     * @return array|null
     */
    public static function getCurrentUserData(): ?array {
        if (!self::isLoggedIn()) {
            return null;
        }
        static $cached_user = null;
        static $cache_time = 0;
        // Cache user data for 5 minutes
        if ($cached_user !== null && (time() - $cache_time) < 300) {
            return $cached_user;
        }
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            $stmt = $pdo->prepare("
                SELECT id, nom, prenom, email, role, created_at, last_login,
                       CONCAT(prenom, ' ', nom) as nom_complet
                FROM users 
                WHERE id = ? AND active = 1
            ");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($user) {
                $cached_user = $user;
                $cache_time = time();
                // Update last activity
                self::updateLastActivity($_SESSION['user_id']);
            }
            return $user ?: null;
        } catch (PDOException $e) {
            error_log("Error fetching user data: " . $e->getMessage());
            return null;
        }
    }
    /**
     * Check if user is logged in
     * 
     * @return bool
     */
    public static function isLoggedIn(): bool {
        return isset($_SESSION['user_id']) && 
               isset($_SESSION['logged_in']) && 
               $_SESSION['logged_in'] === true;
    }
    /**
     * Check if user has required role
     * 
     * @param string $required_role
     * @param string|null $user_role
     * @return bool
     */
    public static function hasRole(string $required_role, ?string $user_role = null): bool {
        if (!self::isLoggedIn()) {
            return false;
        }
        if ($user_role === null) {
            $user_data = self::getCurrentUserData();
            $user_role = $user_data['role'] ?? null;
        }
        return $user_role === $required_role;
    }
    /**
     * Check if user has minimum role level
     * 
     * @param string $required_role
     * @param string|null $user_role
     * @return bool
     */
    public static function hasMinimumRole(string $required_role, ?string $user_role = null): bool {
        if (!self::isLoggedIn()) {
            return false;
        }
        if ($user_role === null) {
            $user_data = self::getCurrentUserData();
            $user_role = $user_data['role'] ?? null;
        }
        $user_level = ROLE_HIERARCHY[$user_role] ?? 0;
        $required_level = ROLE_HIERARCHY[$required_role] ?? 999;
        return $user_level >= $required_level;
    }
    /**
     * Update user's last activity
     * 
     * @param int $user_id
     */
    private static function updateLastActivity(int $user_id): void {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            $stmt = $pdo->prepare("
                UPDATE users 
                SET last_activity = NOW() 
                WHERE id = ?
            ");
            $stmt->execute([$user_id]);
        } catch (PDOException $e) {
            error_log("Error updating last activity: " . $e->getMessage());
        }
    }
    /**
     * Get user role label for display
     * 
     * @param string $role
     * @return string
     */
    public static function getRoleLabel(string $role): string {
        $labels = [
            ROLE_AGENT => 'Agent Demandeur',
            ROLE_CHEF => 'Chef de Service',
            ROLE_DIRECTEUR => 'Directeur',
            ROLE_DIRECTEUR_GENERAL => 'Directeur Général',
            ROLE_INFO => 'Service Informatique',
            ROLE_MG => 'Moyens Généraux'
        ];
        return $labels[$role] ?? ucfirst(str_replace('_', ' ', $role));
    }
}

class DatabaseUtils {
    /**
     * Execute a safe query with parameters
     * 
     * @param string $sql
     * @param array $params
     * @return PDOStatement
     * @throws Exception
     */
    public static function executeQuery(string $sql, array $params = []): PDOStatement {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            error_log("Database query error: " . $e->getMessage() . " SQL: " . $sql);
            throw new Exception("Database query failed");
        }
    }
    /**
     * Get single record
     * 
     * @param string $sql
     * @param array $params
     * @return array|null
     */
    public static function fetchOne(string $sql, array $params = []): ?array {
        $stmt = self::executeQuery($sql, $params);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ?: null;
    }
    /**
     * Get multiple records
     * 
     * @param string $sql
     * @param array $params
     * @return array
     */
    public static function fetchAll(string $sql, array $params = []): array {
        $stmt = self::executeQuery($sql, $params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    /**
     * Get count of records
     * 
     * @param string $table
     * @param string $where
     * @param array $params
     * @return int
     */
    public static function count(string $table, string $where = '', array $params = []): int {
        $sql = "SELECT COUNT(*) FROM `{$table}`";
        if ($where) {
            $sql .= " WHERE {$where}";
        }
        $stmt = self::executeQuery($sql, $params);
        return (int) $stmt->fetchColumn();
    }
    /**
     * Insert record and return last insert ID
     * 
     * @param string $table
     * @param array $data
     * @return string
     */
    public static function insert(string $table, array $data): string {
        $columns = implode('`, `', array_keys($data));
        $placeholders = ':' . implode(', :', array_keys($data));
        $sql = "INSERT INTO `{$table}` (`{$columns}`) VALUES ({$placeholders})";
        $db = Database::getInstance();
        $pdo = $db->getConnection();
        $stmt = $pdo->prepare($sql);
        $stmt->execute($data);
        return $pdo->lastInsertId();
    }
    /**
     * Update records
     * 
     * @param string $table
     * @param array $data
     * @param string $where
     * @param array $where_params
     * @return int Number of affected rows
     */
    public static function update(string $table, array $data, string $where, array $where_params = []): int {
        $set_clause = [];
        foreach (array_keys($data) as $column) {
            $set_clause[] = "`{$column}` = :{$column}";
        }
        $sql = "UPDATE `{$table}` SET " . implode(', ', $set_clause) . " WHERE {$where}";
        $params = array_merge($data, $where_params);
        $stmt = self::executeQuery($sql, $params);
        return $stmt->rowCount();
    }
    /**
     * Delete records
     * 
     * @param string $table
     * @param string $where
     * @param array $params
     * @return int Number of affected rows
     */
    public static function delete(string $table, string $where, array $params = []): int {
        $sql = "DELETE FROM `{$table}` WHERE {$where}";
        $stmt = self::executeQuery($sql, $params);
        return $stmt->rowCount();
    }
}
/**
 * Legacy support for global $pdo variable
 * @deprecated Use Database::getInstance()->getConnection() instead
 */
try {
    $pdo = Database::getInstance()->getConnection();
} catch (Exception $e) {
    error_log("Failed to initialize legacy PDO: " . $e->getMessage());
    $pdo = null;
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (ENVIRONMENT === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
    ini_set('display_errors', 0);
}

if (isset($_GET['health_check']) && $_GET['health_check'] === 'database') {
    header('Content-Type: application/json');
    try {
        $db = Database::getInstance();
        $healthy = $db->isHealthy();
        http_response_code($healthy ? 200 : 503);
        echo json_encode([
            'status' => $healthy ? 'healthy' : 'unhealthy',
            'timestamp' => date('c'),
            'environment' => ENVIRONMENT
        ]);
    } catch (Exception $e) {
        http_response_code(503);
        echo json_encode([
            'status' => 'error',
            'message' => 'Database connection failed',
            'timestamp' => date('c')
        ]);
    }
    exit;
}
?>