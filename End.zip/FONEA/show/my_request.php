<?php
require_once '../Config/db.php';
session_start();
// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit;
}
$userId = $_SESSION['user_id'];
// Fetch user requests
$stmt = $pdo->prepare("SELECT * FROM requests WHERE user_id = :user_id ORDER BY created_at DESC");
$stmt->execute(['user_id' => $userId]);
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
/**
 * Retourne une chaîne relative du type "il y a X jours/semaines" avec la date exacte
 * @param string $dateStr Date au format Y-m-d ou Y-m-d H:i:s
 * @return string
 */
function timeAgo($dateStr) {
    $now = new DateTime();
    $date = new DateTime($dateStr);
    $diff = $now->diff($date);
    if ($diff->y > 0) {
        $relative = $diff->y . ' an' . ($diff->y > 1 ? 's' : '');
    } elseif ($diff->m > 0) {
        $relative = $diff->m . ' mois';
    } elseif ($diff->d >= 7) {
        $weeks = floor($diff->d / 7);
        $relative = $weeks . ' semaine' . ($weeks > 1 ? 's' : '');
    } elseif ($diff->d > 0) {
        $relative = $diff->d . ' jour' . ($diff->d > 1 ? 's' : '');
    } elseif ($diff->h > 0) {
        $relative = $diff->h . ' heure' . ($diff->h > 1 ? 's' : '');
    } elseif ($diff->i > 0) {
        $relative = $diff->i . ' minute' . ($diff->i > 1 ? 's' : '');
    } else {
        $relative = 'quelques secondes';
    }
    return "Soumise il y a $relative (" . $date->format('Y-m-d') . ")";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Mes Demandes</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9fafb;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .header {
            background: #3b82f6;
            color: white;
            padding: 24px;
            text-align: center;
            border-radius: 8px 8px 0 0;
        }
        .header h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }
        .controls {
            padding: 20px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .refresh-btn {
            background-color: #3b82f6;
            color: white;
            border: none;
            padding: 10px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .refresh-btn:hover {
            background-color: #2563eb;
        }
        .content {
            padding: 20px;
        }
        .request-card {
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            padding: 16px;
            margin-bottom: 12px;
            background: #ffffff;
        }
        .request-card h4 {
            margin: 0 0 8px 0;
        }
        .request-card p {
            margin: 4px 0;
        }
        .request-card .status {
            font-weight: bold;
        }
        .status.pending {
            color: #f59e0b;
        }
        .status.approved {
            color: #10b981;
        }
        .status.rejected {
            color: #ef4444;
        }
        .empty-state {
            text-align: center;
            color: #6b7280;
            font-size: 18px;
            margin-top: 40px;
        }
        .empty-state i {
            font-size: 48px;
            margin-bottom: 16px;
        }
        .btn {
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            margin-right: 8px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn-primary {
            background-color: #3b82f6;
            color: white;
        }
        .btn-warning {
            background-color: #f59e0b;
            color: white;
        }
        .btn-success {
            background-color: #10b981;
            color: white;
        }
        .btn-sm {
            padding: 6px 10px;
            font-size: 12px;
        }
        .action-buttons {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Mes Demandes</h2>
        </div>
        <div class="controls">
            <a href="create_request.php" class="btn btn-primary">Créer une nouvelle demande</a>
            <button class="refresh-btn" onclick="loadRequests()">
                <i class="fas fa-sync-alt"></i> Refresh
            </button>
        </div>
        <div class="content">
            <div id="requests-container">
                <?php if ($requests): ?>
                    <?php foreach ($requests as $req): ?>
                        <div class="request-card">
                            <h4><?= htmlspecialchars($req['title']) ?></h4>
                            <p><?= htmlspecialchars($req['description']) ?></p>
                            <p>Status: <span class="status <?= strtolower(str_replace(' ', '-', $req['status'])) ?>"><?= htmlspecialchars($req['status']) ?></span></p>
                            <a href="request_status.php?id=<?= $req['id'] ?>">View Status</a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <p>Aucune demande trouvé.</p>
                    </div>
                <?php endif; ?>
            </div>
            <div class="action-buttons">
                
                <button type="button" class="btn btn-sm btn-primary" 
                        onclick="window.location.href='assigner.php'">
                    <i class="fas fa-tasks"></i> Assigner
                </button>
                
                <button type="button" class="btn btn-sm btn-warning" 
                        onclick="window.location.href='traiter.php'">
                    <i class="fas fa-cogs"></i> Traiter
                </button>
                <button type="button" class="btn btn-sm btn-warning" 
                        onclick="window.location.href='cloture.php'">
                    <i class="fas fa-cogs"></i> Cloturer
                </button>
                <?php if (isset($request)): ?>
                <form action="finalize.php" method="POST" style="display:inline;">
                    <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-success">
                        <i class="fas fa-check-circle"></i> Finaliser
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script>
        async function loadRequests() {
            const container = document.getElementById('requests-container');
            const refreshBtn = document.querySelector('.refresh-btn');
            refreshBtn.disabled = true;
            refreshBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
            try {
                const response = await fetch('api/get_requests.php');
                if (!response.ok) throw new Error('Network response was not ok');
                const data = await response.json();
                container.innerHTML = '';
                if (data.requests.length === 0) {
                    container.innerHTML = '<div class="empty-state"><i class="fas fa-inbox"></i><p>No requests found.</p></div>';
                } else {
                    data.requests.forEach(req => {
                        const reqDiv = document.createElement('div');
                        reqDiv.className = 'request-card';
                        reqDiv.innerHTML = `
                            <h4>${req.title}</h4>
                            <p>${req.description}</p>
                            <p>Status: <span class="status ${req.status.toLowerCase().replace(' ', '-')}">${req.status}</span></p>
                            <a href="request_status.php?id=${req.id}">View Status</a>
                        `;
                        container.appendChild(reqDiv);
                    });
                }
            } catch (error) {
                console.error('Error fetching requests:', error);
                container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><p>Error loading requests</p></div>';
            } finally {
                refreshBtn.disabled = false;
                refreshBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Refresh';
            }
        }
    </script>
</body>
</html>