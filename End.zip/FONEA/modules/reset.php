<?php
// If you're using sessions to store form data, clear them:
session_start();
$_SESSION = [];
session_destroy();
// Optionally clear GET/POST cache
header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/index.php");
exit;
