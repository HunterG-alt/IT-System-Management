<?php
require_once '../Config/db.php';
require_once '../Config/session.php';
require_once '../modules/permission.php';

// Set JSON header
header('Content-Type: application/json');

// Check if user is authenticated
if (!isset($_SESSION['user_data'])) {
    echo json_encode(['success' => false, 'message' => 'Non authentifié']);
    exit;
}

// Check permission to create requests
$pm = PermissionManager::getInstance();
if (!$pm->hasPermission('requests.create')) {
    echo json_encode(['success' => false, 'message' => 'Permission refusée']);
    exit;
}

// Validate request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

try {
    // Get form data
    $objet = trim($_POST['objet'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $quantite = intval($_POST['quantite'] ?? 1);
    $priorite = $_POST['priorite'] ?? 'normale';
    $user_data = $_SESSION['user_data'];
    $id_agent = $user_data['id_agent'];
    
    // Validate inputs
    if (empty($objet)) {
        throw new Exception('L\'objet de la demande est requis');
    }
    
    if (empty($description)) {
        throw new Exception('La description est requise');
    }
    
    if ($quantite < 1) {
        throw new Exception('La quantité doit être supérieure à 0');
    }
    
    if (!in_array($priorite, ['normale', 'urgente', 'critique'])) {
        throw new Exception('Priorité invalide');
    }
    
    // Get user's department
    $stmt = $pdo->prepare("SELECT id_departement FROM agents WHERE id_agent = ?");
    $stmt->execute([$id_agent]);
    $agent = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$agent) {
        throw new Exception('Agent introuvable');
    }
    
    $id_departement = $agent['id_departement'];
    
    // Begin transaction
    $pdo->beginTransaction();
    
    // Insert the request with initial status "en_attente" (waiting for chef de service pre-validation)
    $stmt = $pdo->prepare("
        INSERT INTO etat_de_besoin 
        (id_agent, id_departement, objet, description, quantite, priorite, statut, date_creation, date_modification) 
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    ");
    
    $stmt->execute([
        $id_agent,
        $id_departement,
        $objet,
        $description,
        $quantite,
        $priorite,
        STATUS_EN_ATTENTE // Waiting for Chef de Service
    ]);
    
    $request_id = $pdo->lastInsertId();
    
    // Log the creation in history
    $stmt = $pdo->prepare("
        INSERT INTO historique_besoin 
        (id_besoin, id_agent, action, commentaire, date_action) 
        VALUES (?, ?, ?, ?, NOW())
    ");
    
    $stmt->execute([
        $request_id,
        $id_agent,
        'creation',
        'Demande créée avec priorité: ' . $priorite
    ]);
    
    // ==========================================
    // STEP 1: Notify Chef de Service for PRE-VALIDATION
    // ==========================================
    
    // Get all Chef de Service in the same department
    $stmt = $pdo->prepare("
        SELECT id_agent, nom, prenom, email 
        FROM agents 
        WHERE role = ? AND id_departement = ? AND statut = 'actif'
    ");
    $stmt->execute([ROLE_CHEF_SERVICE, $id_departement]);
    $chefs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($chefs)) {
        // If no chef in department, notify all chefs
        $stmt = $pdo->prepare("
            SELECT id_agent, nom, prenom, email 
            FROM agents 
            WHERE role = ? AND statut = 'actif'
        ");
        $stmt->execute([ROLE_CHEF_SERVICE]);
        $chefs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Send notifications to Chef(s) de Service
    foreach ($chefs as $chef) {
        $message = sprintf(
            "Nouvelle demande à pré-valider de %s %s - %s",
            $user_data['prenom'],
            $user_data['nom'],
            $objet
        );
        
        $stmt = $pdo->prepare("
            INSERT INTO notifications 
            (id_agent, type, titre, message, lien, statut, date_creation) 
            VALUES (?, ?, ?, ?, ?, 'non_lu', NOW())
        ");
        
        $stmt->execute([
            $chef['id_agent'],
            'demande_creation',
            'Nouvelle demande',
            $message,
            'demande_details.php?id=' . $request_id
        ]);
        
        // Optional: Send email notification
        // sendEmailNotification($chef['email'], 'Nouvelle demande à pré-valider', $message);
    }
    
    // Commit transaction
    $pdo->commit();
    
    // Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Demande créée avec succès',
        'request_id' => $request_id,
        'workflow_info' => [
            'current_step' => 'en_attente',
            'next_step' => 'pre_validation',
            'next_validator' => 'Chef de Service',
            'workflow' => [
                ['step' => 1, 'role' => 'Chef de Service', 'action' => 'Pré-validation', 'status' => 'pending'],
                ['step' => 2, 'role' => 'Directeur', 'action' => 'Validation', 'status' => 'waiting'],
                ['step' => 3, 'role' => 'Directeur Général', 'action' => 'Autorisation', 'status' => 'waiting'],
                ['step' => 4, 'role' => 'Moyens Généraux', 'action' => 'Traitement', 'status' => 'waiting']
            ]
        ]
    ]);
    
} catch (Exception $e) {
    // Rollback on error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    // Log error
    error_log("Error creating request: " . $e->getMessage());
    
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

/**
 * Function to send email notifications (optional)
 * You can implement this based on your email configuration
 */
function sendEmailNotification($to, $subject, $message) {
    // Example using PHP mail() function
    // In production, use a proper email library like PHPMailer
    
    $headers = "From: noreply@votre-entreprise.com\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    
    $html_message = "
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; }
                .container { padding: 20px; background: #f4f4f4; }
                .content { background: white; padding: 20px; border-radius: 5px; }
                .button { background: #667eea; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='content'>
                    <h2>{$subject}</h2>
                    <p>{$message}</p>
                    <p>
                        <a href='http://loussig.42web.io/demande.php' class='button'>
                            Voir la demande
                        </a>
                    </p>
                </div>
            </div>
        </body>
        </html>
    ";
    
    // Uncomment to enable email sending
    // mail($to, $subject, $html_message, $headers);
}
?>