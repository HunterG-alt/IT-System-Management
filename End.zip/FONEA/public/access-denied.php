<?php
require_once __DIR__ . '/../Config/session.php';
http_response_code(403);
?><!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accès refusé</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center" style="min-height:100vh;">
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card shadow-sm">
        <div class="card-body p-4">
          <h1 class="h4 mb-3 text-danger">Accès refusé</h1>
          <p class="mb-4">Vous n'avez pas les privilèges nécessaires pour accéder à cette page.</p>
<a class="btn btn-primary" href="../public/login.php">Retour à la connexion</a>
        </div>
      </div>
    </div>
  </div>
  <?php FlashMessage::display(); ?>
  <?= CSRFProtection::getInputField('access_denied'); ?>
  </div>
</body>
</html>
