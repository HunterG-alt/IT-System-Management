<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Équipement IT</title>
  <style>
    body {
      margin: 0;
      height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      font-family: "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      background: linear-gradient(135deg, #1a2230, #2f4c61);
      color: #fff;
    }
    .glass-container {
      background: rgba(255, 255, 255, 0.1);
      border-radius: 15px;
      box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.3);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      padding: 40px 60px;
      text-align: center;
      max-width: 500px;
      width: 90%;
      transition: all 0.3s ease;
    }

    .glass-container:hover {
      transform: translateY(-5px);
      box-shadow: 0 12px 40px 0 rgba(0, 0, 0, 0.4);
    }

    h1 {
      font-size: 2.5rem;
      margin-bottom: 40px;
      text-align: center;
    }

    .cards {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 30px;
      width: 90%;
      max-width: 1200px;
    }

    .card {
      background: rgba(255, 255, 255, 0.1);
      border-radius: 20px;
      box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.3);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      width: 320px;
      padding: 30px;
      transition: all 0.3s ease;
    }

    .card:hover {
      transform: translateY(-8px);
      box-shadow: 0 12px 40px 0 rgba(0, 0, 0, 0.4);
    }

    .card h2 {
      margin-bottom: 20px;
      font-size: 1.5rem;
      text-align: center;
    }

    .card form {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }

    input, select, textarea, button {
      border: none;
      border-radius: 8px;
      padding: 10px 12px;
      font-size: 1rem;
      font-family: inherit;
    }

    input, select, textarea {
      background: rgba(255, 255, 255, 0.2);
      color: #fff;
    }

    input::placeholder, textarea::placeholder {
      color: rgba(255, 255, 255, 0.7);
    }

    button {
      background: rgba(255, 255, 255, 0.3);
      color: #fff;
      cursor: pointer;
      transition: background 0.3s;
    }

    button:hover {
      background: rgba(255, 255, 255, 0.5);
    }

    textarea {
      resize: none;
      min-height: 80px;
    }
  </style>
</head>
<body>
  <h1>Équipement IT</h1>
  <div class="cards">
    <div class="card">
      <h2>Ajouter un équipement</h2>
      <form>
        <input type="text" placeholder="Nom de l’équipement" required>
        <select required>
          <option value="">Catégorie</option>
          <option>Ordinateur</option>
          <option>Serveur</option>
          <option>Imprimante</option>
          <option>Périphérique</option>
        </select>
        <input type="text" placeholder="Numéro de série" required>
        <input type="text" placeholder="Emplacement ou service">
        <button type="submit">Ajouter</button>
      </form>
    </div>

    <div class="card">
      <h2>Inventaire</h2>
      <form>
        <input type="text" placeholder="Nom, numéro de série...">
        <select>
          <option value="">Filtrer par type</option>
          <option>Ordinateur</option>
          <option>Serveur</option>
          <option>Imprimante</option>
          <option>Périphérique</option>
        </select>
        <button type="submit">Rechercher</button>
      </form>
    </div>

    <div class="card">
      <h2>Exporter</h2>
      <form>
        <select required>
          <option value="">Format d’export</option>
          <option>PDF</option>
        </select>
        <input type="text" placeholder="Filtre (catégorie, emplacement...)">
        <button type="submit">Exporter</button>
      </form>
    </div>
  </div>
</body>
</html>
