DROP DATABASE IF EXISTS fonea;

CREATE DATABASE fonea CHARACTER SET utf8mb4;
USE fonea;

CREATE TABLE agents (
    id_agent INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL,
    role ENUM('demandeur','chef_service','directeur','directeur_general','informatique','moyens_generaux') NOT NULL,
    reset_token VARCHAR(255) DEFAULT NULL,
    reset_expires DATETIME DEFAULT NULL,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL
);

CREATE TABLE IF NOT EXISTS demande (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,                   -- L'utilisateur qui a créé la demande
    titre VARCHAR(255) NOT NULL,            -- Titre de la demande
    description TEXT,                       -- Description détaillée
    status VARCHAR(50) NOT NULL DEFAULT 'En attente',  -- Statut (Ex: En attente, Assigné, En cours, Finalisé, Rejeté)
    assigned_to INT DEFAULT NULL,           -- L'ID de l'utilisateur qui traite ou est assigné à la demande
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES agents(id_agent) ON DELETE CASCADE,
    FOREIGN KEY (assigned_to) REFERENCES agents(id_agent) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE etat_de_besoin (
    id_besoin INT AUTO_INCREMENT PRIMARY KEY,
    id_agent INT NOT NULL,
    designation_materiel VARCHAR(255) NOT NULL,
    justification TEXT NOT NULL,
    fichier_joint VARCHAR(255) DEFAULT NULL,
    statut ENUM(
        'en_attente',
        'pre_validee',
        'refusee_chef',
        'en_attente_validation',
        'validee_directeur',
        'refusee_directeur',
        'en_attente_permission_dg',
        'permission_dg_accordee',
        'refusee_dg',
        'en_analyse_technique',
        'en_acquisition',
        'attribuee',
        'cloturee'
    ) DEFAULT 'en_attente',
    date_limite DATE NULL,
    date_soumission TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_maj TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    id_chef_validation INT NULL,
    date_pre_validation TIMESTAMP NULL,
    commentaire_chef TEXT NULL,
    id_directeur_validation INT NULL,
    date_validation_directeur TIMESTAMP NULL,
    commentaire_directeur TEXT NULL,
    id_dg_validation INT NULL,
    date_permission_dg TIMESTAMP NULL,
    commentaire_dg TEXT NULL,
    -- Added missing logistique columns
    date_livraison_prevue DATE,
    date_livraison_reelle DATE,
    transporteur VARCHAR(255),
    numero_suivi VARCHAR(100),
    commentaire_logistique TEXT,
    commentaire_reception TEXT,
    statut_logistique ENUM('EN_ATTENTE', 'PLANIFIE', 'LIVRE'),
    CONSTRAINT fk_besoin_agent FOREIGN KEY (id_agent) REFERENCES agents(id_agent)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_chef_validation FOREIGN KEY (id_chef_validation) REFERENCES agents(id_agent)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_directeur_validation FOREIGN KEY (id_directeur_validation) REFERENCES agents(id_agent)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_dg_validation FOREIGN KEY (id_dg_validation) REFERENCES agents(id_agent)
        ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE type_materiel (
    id_type INT AUTO_INCREMENT PRIMARY KEY,
    libelle VARCHAR(150) NOT NULL UNIQUE
);

CREATE TABLE type_caracteristique (
    id_type_carac INT AUTO_INCREMENT PRIMARY KEY,
    id_type INT NOT NULL,
    libelle VARCHAR(150) NOT NULL,
    CONSTRAINT fk_typecarac_type FOREIGN KEY (id_type) REFERENCES type_materiel(id_type)
        ON DELETE CASCADE ON UPDATE CASCADE,
    UNIQUE KEY uq_typecarac_pair (id_type, libelle)
);

CREATE TABLE fournisseur (
    id_fournisseur INT AUTO_INCREMENT PRIMARY KEY,
    nom_fournisseur VARCHAR(150) NOT NULL,
    contact VARCHAR(150) DEFAULT NULL,
    adresse VARCHAR(255) DEFAULT NULL
);

CREATE TABLE materiel (
    id_materiel INT AUTO_INCREMENT PRIMARY KEY,
    id_etat INT NOT NULL,
    quantite INT NOT NULL,
    id_type INT NOT NULL,
    reference VARCHAR(100) NOT NULL,
    designation VARCHAR(255) NOT NULL,
    marque VARCHAR(250) NOT NULL,
    modele VARCHAR(150) NOT NULL,
    categorie ENUM('Ordinateur','Ram','Alimentation Central','Disque dur','Autres') NOT NULL DEFAULT 'Autres',
    caracteristique TEXT,
    date_materiel TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    statut VARCHAR(64),
    CONSTRAINT fk_materiel_etat FOREIGN KEY (id_etat) REFERENCES etat_de_besoin(id_besoin)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_materiel_type FOREIGN KEY (id_type) REFERENCES type_materiel(id_type)
        ON DELETE RESTRICT ON UPDATE CASCADE
);

CREATE TABLE caracteristique (
    id_carac INT AUTO_INCREMENT PRIMARY KEY,
    id_materiel INT NOT NULL,
    id_type_carac INT NOT NULL,
    valeur_acquise VARCHAR(255) NOT NULL,
    CONSTRAINT fk_carac_materiel FOREIGN KEY (id_materiel) REFERENCES materiel(id_materiel)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_carac_typecarac FOREIGN KEY (id_type_carac) REFERENCES type_caracteristique(id_type_carac)
        ON DELETE CASCADE ON UPDATE CASCADE,
    UNIQUE KEY uq_carac_unique (id_materiel, id_type_carac)
);

CREATE TABLE besoin_materiel (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_besoin INT NOT NULL,
    nom VARCHAR(255) NOT NULL,
    quantite INT NOT NULL,
    caracteristiques TEXT,
    CONSTRAINT fk_besoin_materiel_besoin FOREIGN KEY (id_besoin) REFERENCES etat_de_besoin(id_besoin) 
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE besoin_archive (
    id INT AUTO_INCREMENT PRIMARY KEY,
    original_id INT NOT NULL,
    agent_id INT,
    designation VARCHAR(255),
    justification TEXT,
    date_soumission DATETIME,
    statut VARCHAR(50),
    deleted_by INT,
    deleted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_archive_deleted_by FOREIGN KEY (deleted_by) REFERENCES agents(id_agent)
        ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE activity_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(50) NOT NULL,
    entity_type VARCHAR(50),
    entity_id INT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_activity_user FOREIGN KEY (user_id) REFERENCES agents(id_agent)
        ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE pre_validation (
    id_preval INT AUTO_INCREMENT PRIMARY KEY,
    id_besoin INT NOT NULL,
    id_chef INT NOT NULL,
    avis ENUM('favorable','defavorable') NOT NULL,
    commentaire TEXT,
    date_preval TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_preval_besoin FOREIGN KEY (id_besoin) REFERENCES etat_de_besoin(id_besoin)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_preval_chef FOREIGN KEY (id_chef) REFERENCES agents(id_agent)
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE validation_direction (
    id_val INT AUTO_INCREMENT PRIMARY KEY,
    id_besoin INT NOT NULL,
    id_directeur INT NOT NULL,
    statut_validation ENUM('valide','refuse') NOT NULL,
    commentaire TEXT,
    date_validation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_val_besoin FOREIGN KEY (id_besoin) REFERENCES etat_de_besoin(id_besoin)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_val_directeur FOREIGN KEY (id_directeur) REFERENCES agents(id_agent)
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE validation_dg (
    id_val_dg INT AUTO_INCREMENT PRIMARY KEY,
    id_besoin INT NOT NULL,
    id_dg INT NOT NULL,
    statut_validation ENUM('valide','refuse') NOT NULL,
    commentaire TEXT,
    date_validation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_valdg_besoin FOREIGN KEY (id_besoin) REFERENCES etat_de_besoin(id_besoin)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_valdg_dg FOREIGN KEY (id_dg) REFERENCES agents(id_agent)
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE analyse_technique (
    id_analyse INT AUTO_INCREMENT PRIMARY KEY,
    id_besoin INT NOT NULL,
    id_informaticien INT NOT NULL,
    specifications TEXT NOT NULL,
    date_analyse TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_analyse_besoin FOREIGN KEY (id_besoin) REFERENCES etat_de_besoin(id_besoin)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_analyse_informaticien FOREIGN KEY (id_informaticien) REFERENCES agents(id_agent)
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE acquisitions (
    id_acq INT AUTO_INCREMENT PRIMARY KEY,
    id_besoin INT NOT NULL,
    id_fournisseur INT DEFAULT NULL,
    statut_acquisition ENUM('commande_en_cours','recu','attribue') DEFAULT 'commande_en_cours',
    date_commande TIMESTAMP NULL,
    date_reception TIMESTAMP NULL,
    date_attribution TIMESTAMP NULL,
    CONSTRAINT fk_acq_besoin FOREIGN KEY (id_besoin) REFERENCES etat_de_besoin(id_besoin)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_acq_fournisseur FOREIGN KEY (id_fournisseur) REFERENCES fournisseur(id_fournisseur)
        ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE commande (
    id_commande INT AUTO_INCREMENT PRIMARY KEY,
    id_acq INT NOT NULL,
    id_fournisseur INT NOT NULL,
    reference_commande VARCHAR(100) DEFAULT NULL,
    statut_commande ENUM('en_cours','envoyee','livree','annulee') DEFAULT 'en_cours',
    date_commande TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_commande_acq FOREIGN KEY (id_acq) REFERENCES acquisitions(id_acq)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_commande_fournisseur FOREIGN KEY (id_fournisseur) REFERENCES fournisseur(id_fournisseur)
        ON DELETE RESTRICT ON UPDATE CASCADE
);

CREATE TABLE livraison (
    id_livraison INT AUTO_INCREMENT PRIMARY KEY,
    id_commande INT NOT NULL,
    id_materiel INT DEFAULT NULL,
    quantite_livree INT NOT NULL,
    date_reception TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    remarques TEXT,
    CONSTRAINT fk_livraison_commande FOREIGN KEY (id_commande) REFERENCES commande(id_commande)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_livraison_materiel FOREIGN KEY (id_materiel) REFERENCES materiel(id_materiel)
        ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE stock (
    id_stock INT AUTO_INCREMENT PRIMARY KEY,
    id_materiel INT NOT NULL,
    quantite INT NOT NULL,
    CONSTRAINT fk_stock_materiel FOREIGN KEY (id_materiel) REFERENCES materiel(id_materiel)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- Table pour les transporteurs
CREATE TABLE transporteurs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(255) NOT NULL,
    contact VARCHAR(100),
    tarif_km DECIMAL(10,2),
    zone_couverture TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE app_settings (
    setting_key   VARCHAR(50) PRIMARY KEY,
    setting_value VARCHAR(255) NOT NULL
);

-- Table pour les notifications (alignée avec le code PHP)
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    related_id INT DEFAULT NULL,
    metadata JSON DEFAULT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    read_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES agents(id_agent)
        ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_notifications_user_read (user_id, is_read),
    INDEX idx_notifications_created_at (created_at),
    INDEX idx_notifications_related (related_id)
);

CREATE TABLE tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titre VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    statut ENUM('Ouvert','Clôturé') DEFAULT 'Ouvert'
);

-- Journal de sécurité (utilisé par SessionConfig::logSecurityEvent)
CREATE TABLE security_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event VARCHAR(100) NOT NULL,
    user_id INT NULL,
    ip_address VARCHAR(45) NOT NULL,
    user_agent VARCHAR(255) NOT NULL,
    timestamp DATETIME NOT NULL,
    data JSON DEFAULT NULL,
    INDEX idx_security_user_time (user_id, timestamp)
);

-- TRIGGERS pour validation des caractéristiques
DELIMITER $$
CREATE TRIGGER trig_carac_check_insert
BEFORE INSERT ON caracteristique
FOR EACH ROW
BEGIN
    DECLARE mat_type INT;
    DECLARE car_type INT;

    SELECT id_type INTO mat_type FROM materiel WHERE id_materiel = NEW.id_materiel;
    IF mat_type IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Matériel introuvable (insert caracteristique).';
    END IF;

    SELECT id_type INTO car_type FROM type_caracteristique WHERE id_type_carac = NEW.id_type_carac;
    IF car_type IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Type de caractéristique introuvable (insert caracteristique).';
    END IF;

    IF mat_type <> car_type THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Incohérence : type du matériel != type de la caractéristique (insert).';
    END IF;
END$$

CREATE TRIGGER trig_carac_check_update
BEFORE UPDATE ON caracteristique
FOR EACH ROW
BEGIN
    DECLARE mat_type INT;
    DECLARE car_type INT;

    SELECT id_type INTO mat_type FROM materiel WHERE id_materiel = NEW.id_materiel;
    IF mat_type IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Matériel introuvable (update caracteristique).';
    END IF;

    SELECT id_type INTO car_type FROM type_caracteristique WHERE id_type_carac = NEW.id_type_carac;
    IF car_type IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Type de caractéristique introuvable (update caracteristique).';
    END IF;

    IF mat_type <> car_type THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Incohérence : type du matériel != type de la caractéristique (update).';
    END IF;
END$$
DELIMITER ;

-- INSERTIONS DE DONNÉES

-- Agents (mots de passe hashés)
INSERT INTO agents (nom, prenom, email, mot_de_passe, role) VALUES
('Mbemba', 'Jean', 'jean.mbemba@gmail.com', SHA2('askpass123',256), 'demandeur'),
('Nzaba', 'Clémentine', 'clementine.nzaba@gmail.com', SHA2('chefpass123',256), 'chef_service'),
('Ngoma', 'Pierre', 'pierre.ngoma@gmail.com', SHA2('directeurpass123',256), 'directeur'),
('Tchicaya', 'Mireille', 'mireille.tchicaya@gmail.com', SHA2('informatiquepass123',256), 'informatique'),
('Koumba', 'Alain', 'alain.koumba@gmail.com', SHA2('moyens_generauxpass123',256), 'moyens_generaux'),
('Loussi', 'Glory', 'glory.loussi@example.com', SHA2('dgpass123',256), 'directeur_general');

-- Type matériel (must be inserted before etat_de_besoin due to foreign key in materiel)
INSERT INTO type_materiel (libelle) VALUES
('Ordinateur'),
('Imprimante'),
('Disque dur'),
('Serveur'),
('Autres');

-- ÉTATS DE BESOIN (demandes émises par agents / direction)
INSERT INTO etat_de_besoin (id_agent, designation_materiel, justification, fichier_joint, statut, date_limite) VALUES
(1, 'Ordinateur portable HP', 'Besoin pour le traitement des rapports', NULL, 'en_attente', '2025-12-31'),
(1, 'Imprimante laser', 'Pour impression des documents administratifs', NULL, 'pre_validee', '2025-11-30'),
(2, 'Disque dur externe 1To', 'Sauvegarde des données du service', NULL, 'en_analyse_technique', '2025-10-15'),
(6, 'Serveur central', 'Mise en place du serveur DG', NULL, 'en_attente_validation', '2025-12-15');

INSERT INTO type_caracteristique (id_type, libelle) VALUES
(1, 'RAM'),
(1, 'Processeur'),
(1, 'Stockage'),
(2, 'Technologie'),
(2, 'Connectivite'),
(2, 'RectoVerso'),
(3, 'Capacite'),
(3, 'Interface'),
(4, 'RAM'),
(4, 'Processeur'),
(4, 'Stockage'),
(4, 'OS');

INSERT INTO fournisseur (nom_fournisseur, contact, adresse) VALUES
('CongoTech SARL', 'contact@congotech.cg', 'Brazzaville'),
('InfoStore Africa', 'sales@infostore.af', 'Brazzaville'),
('ServerPro Ltd', 'contact@serverpro.cg', 'Brazzaville');

INSERT INTO materiel (id_etat, quantite, id_type, reference, designation, marque, modele, categorie, caracteristique, statut) VALUES
(1, 10, 1, 'HP-LAT-2025', 'Laptop HP Elitebook', 'HP', 'Elitebook 840 G8', 'Ordinateur', 'RAM 16Go, SSD 512Go, i7', 'disponible'),
(2, 2, 2, 'CAN-PRN-500', 'Imprimante LaserJet', 'Canon', 'LBP623Cdw', 'Autres', 'Couleur, Wifi, Recto-verso', 'commande'),
(3, 5, 3, 'SEAG-1TO', 'Disque dur externe', 'Seagate', 'Expansion Portable', 'Disque dur', 'USB 3.0, 1To', 'stock'),
(4, 1, 4, 'SRV-DG-2025', 'Serveur central DG', 'Dell', 'PowerEdge R750', 'Autres', 'RAM 64Go, Xeon, SSD 2To, Windows Server', 'en_attente');

-- Laptop HP (Ordinateur)
INSERT INTO caracteristique (id_materiel, id_type_carac, valeur_acquise) VALUES
(1, 1, '16 Go'),
(1, 2, 'Intel i7'),
(1, 3, '512 Go SSD');

-- Imprimante Canon (Imprimante)
INSERT INTO caracteristique (id_materiel, id_type_carac, valeur_acquise) VALUES
(2, 4, 'Laser'),
(2, 5, 'WiFi'),
(2, 6, 'Oui');

-- Disque dur (Disque dur)
INSERT INTO caracteristique (id_materiel, id_type_carac, valeur_acquise) VALUES
(3, 7, '1To'),
(3, 8, 'USB 3.0');

-- Serveur DG (Serveur)
INSERT INTO caracteristique (id_materiel, id_type_carac, valeur_acquise) VALUES
(4, 9, '64 Go'),
(4, 10, 'Xeon Gold 5318'),
(4, 11, '2 To SSD'),
(4, 12, 'Windows Server 2022');

INSERT INTO besoin_materiel (id_besoin, nom, quantite, caracteristiques) VALUES
(1, 'Ordinateur portable HP', 1, 'RAM 16Go, SSD 512Go, i7'),
(2, 'Imprimante laser Canon', 1, 'Couleur, WiFi, Recto-verso'),
(3, 'Disque dur externe Seagate', 1, 'USB 3.0, 1To'),
(4, 'Serveur central DG', 1, 'RAM 64Go, Xeon, SSD 2To, Windows Server');

-- PRÉ-VALIDATION (chef_service)
INSERT INTO pre_validation (id_besoin, id_chef, avis, commentaire) VALUES
(1, 2, 'favorable', 'Matériel nécessaire pour améliorer la productivité'),
(2, 2, 'defavorable', 'Déjà disponible dans le service'),
(4, 2, 'favorable', 'Serveur central requis pour DG');

-- VALIDATION DIRECTION (directeur)
INSERT INTO validation_direction (id_besoin, id_directeur, statut_validation, commentaire) VALUES
(1, 3, 'valide', 'Accord pour l\'achat du matériel informatique'),
(2, 3, 'refuse', 'Budget non disponible cette année'),
(4, 3, 'valide', 'DG serveur approuvé');

-- Validation DG
INSERT INTO validation_dg (id_besoin, id_dg, statut_validation, commentaire) VALUES
(1, 6, 'valide', 'Validation finale par le Directeur Général'),
(4, 6, 'valide', 'Validation finale DG pour serveur central');

-- Mise à jour état_de_besoin pour refléter validation DG
UPDATE etat_de_besoin
SET statut = 'cloturee',
    id_dg_validation = 6,
    date_permission_dg = NOW(),  -- Fixed: was date_validation_dg but should be date_permission_dg
    commentaire_dg = 'Validation finale par DG'
WHERE id_besoin IN (1,4);

INSERT INTO analyse_technique (id_besoin, id_informaticien, specifications) VALUES
(3, 4, 'Capacité minimale 1To, vitesse 7200rpm, connexion USB-C'),
(4, 4, 'Serveur compatible virtualisation, RAID, backup automatique');

INSERT INTO acquisitions (id_besoin, id_fournisseur, statut_acquisition, date_commande, date_reception) VALUES
(1, 1, 'commande_en_cours', NOW(), NULL),
(3, 2, 'recu', '2025-08-20 10:00:00', '2025-08-25 15:30:00'),
(4, 3, 'commande_en_cours', NOW(), NULL);

INSERT INTO commande (id_acq, id_fournisseur, reference_commande, statut_commande, date_commande) VALUES
(1, 1, 'CMD-0001', 'en_cours', NOW()),
(2, 2, 'CMD-0002', 'livree', '2025-08-20 10:00:00'),
(3, 3, 'CMD-0003', 'en_cours', NOW());

INSERT INTO livraison (id_commande, id_materiel, quantite_livree, date_reception, remarques) VALUES
(2, 3, 5, '2025-08-25 15:30:00', 'Livraison complète');

INSERT INTO stock (id_materiel, quantite) VALUES
(1, 10),
(2, 2),
(3, 5),
(4, 0);

-- Notifications initiales
INSERT INTO notifications (user_id, type, message, related_id, metadata, is_read, read_at) VALUES
(1, 'request_created', 'Votre demande a été enregistrée', 1, NULL, 1, NOW()),
(1, 'request_updated', 'Votre demande est en attente de validation du directeur', 2, NULL, 0, NULL),
(2, 'request_updated', 'Un technicien a analysé vos besoins', 3, NULL, 1, NOW()),
(6, 'request_updated', 'Votre demande de serveur DG est en cours de validation', 4, NULL, 0, NULL);