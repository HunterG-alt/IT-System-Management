<?php
require_once '../Config/db.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../public/login.php");
    exit();
}

$pdo = Database::getInstance()->getConnection();
$success = "";
$errors = [];
// Liste des commandes disponibles pour acquisition
$commandes = $pdo->query("SELECT c.id_commande, m.nom AS materiel, f.nom AS fournisseur
                          FROM Commande c
                          JOIN Materiel m ON c.id_materiel = m.id_materiel
                          JOIN Fournisseur f ON c.id_fournisseur = f.id_fournisseur
                          WHERE c.id_commande NOT IN (SELECT id_commande FROM Acquisition)
                          ORDER BY c.id_commande DESC")->fetchAll(PDO::FETCH_ASSOC);
// Ajouter acquisition
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_commande = $_POST['id_commande'] ?? '';
    $date_acquisition = $_POST['date_acquisition'] ?? '';
    if (empty($id_commande)) $errors[] = "Commande requise.";
    if (empty($date_acquisition)) $errors[] = "Date requise.";
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO Acquisition (id_commande, date_acquisition) VALUES (:id_commande, :date_acquisition)");
            $stmt->execute([
                ':id_commande' => $id_commande,
                ':date_acquisition' => $date_acquisition
            ]);
            $success = "Acquisition ajoutée avec succès.";
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de l'ajout : " . $e->getMessage();
        }
    }
}
// Récupérer acquisitions
$acquisitions = $pdo->query("SELECT a.id_acquisition, c.id_commande, m.nom AS materiel, f.nom AS fournisseur, a.date_acquisition, a.statut
                             FROM Acquisition a
                             JOIN Commande c ON a.id_commande = c.id_commande
                             JOIN Materiel m ON c.id_materiel = m.id_materiel
                             JOIN Fournisseur f ON c.id_fournisseur = f.id_fournisseur
                             ORDER BY a.date_acquisition DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acquisitions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        select, input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .success {
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        .error {
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .status-en-cours {
            color: #ffc107;
            font-weight: bold;
        }
        .status-recu {
            color: #28a745;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Gestion des Acquisitions</h1>
        <?php if ($success): ?>
            <div class="success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        <?php if (!empty($errors)): ?>
            <div class="error">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        <h2>Nouvelle Acquisition</h2>
        <form method="post">
            <div class="form-group">
                <label for="id_commande">Commande :</label>
                <select name="id_commande" id="id_commande" required>
                    <option value="">-- Choisir une commande --</option>
                    <?php foreach ($commandes as $commande): ?>
                        <option value="<?= $commande['id_commande'] ?>">
                            Commande #<?= $commande['id_commande'] ?> - <?= htmlspecialchars($commande['materiel']) ?> 
                            (<?= htmlspecialchars($commande['fournisseur']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="date_acquisition">Date d'acquisition :</label>
                <input type="date" name="date_acquisition" id="date_acquisition" value="<?= date('Y-m-d') ?>" required>
            </div>
            <button type="submit">Ajouter l'acquisition</button>
        </form>
        <h2>Historique des Acquisitions</h2>
        <?php if (empty($acquisitions)): ?>
            <p>Aucune acquisition enregistrée.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>ID Acquisition</th>
                        <th>Commande #</th>
                        <th>Matériel</th>
                        <th>Fournisseur</th>
                        <th>Date d'acquisition</th>
                        <th>Statut</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($acquisitions as $acquisition): ?>
                    <tr>
                        <td><?= $acquisition['id_acquisition'] ?></td>
                        <td><?= $acquisition['id_commande'] ?></td>
                        <td><?= htmlspecialchars($acquisition['materiel']) ?></td>
                        <td><?= htmlspecialchars($acquisition['fournisseur']) ?></td>
                        <td><?= date('d/m/Y', strtotime($acquisition['date_acquisition'])) ?></td>
                        <td>
                            <span class="status-<?= strtolower(str_replace(' ', '-', $acquisition['statut'])) ?>">
                                <?= htmlspecialchars($acquisition['statut']) ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>