etat de besoin.php:
<?php
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Config/db.php';
require_login();
$pdo = Database::getInstance()->getConnection();
$errors = [];
$success = "";
// Affichage des messages depuis l'URL
if (isset($_GET['success'])) {
    switch ($_GET['success']) {
        case 'added': $success = "Besoin ajouté avec succès."; break;
        case 'updated': $success = "Besoin modifié avec succès."; break;
        case 'deleted': $success = "Besoin supprimé avec succès."; break;
    }
}
if (isset($_GET['error'])) {
    switch ($_GET['error']) {
        case 'invalid': $errors[] = "Données invalides."; break;
        case 'noaction': $errors[] = "Aucune action spécifiée."; break;
        default: $errors[] = "Une erreur est survenue."; break;
    }
}
// Vérifier si une action est envoyée (POST uniquement + CSRF)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    CSRFProtection::requireToken('etat_de_besoin_action');
    $action = $_POST['action'];
    // Ajouter un besoin
    if ($action === "add") {
        $description = trim($_POST['description'] ?? '');
        $quantite = (int)($_POST['quantite'] ?? 0);
        if (!empty($description) && $quantite > 0) {
            try {
                $stmt = $pdo->prepare("INSERT INTO besoin (description, quantite) VALUES (?, ?)");
                $stmt->execute([$description, $quantite]);
                header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/etat_de_besoin.php?success=added");
                exit;
            } catch (PDOException $e) {
                header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/etat_de_besoin.php?error=db");
                exit;
            }
        } else {
            header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/etat_de_besoin.php?error=invalid");
            exit;
        }
    }
    // Modifier un besoin
    if ($action === "edit") {
        $id = (int)($_POST['id_besoin'] ?? 0);
        $description = trim($_POST['description'] ?? '');
        $quantite = (int)($_POST['quantite'] ?? 0);
        if ($id > 0 && !empty($description) && $quantite > 0) {
            try {
                $stmt = $pdo->prepare("UPDATE besoin SET description = ?, quantite = ? WHERE id_besoin = ?");
                $stmt->execute([$description, $quantite, $id]);
                header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/etat_de_besoin.php?success=updated");
                exit;
            } catch (PDOException $e) {
                header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/etat_de_besoin.php?error=db");
                exit;
            }
        } else {
            header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/etat_de_besoin.php?error=invalid");
            exit;
        }
    }
    // Supprimer un besoin
    if ($action === "delete") {
        $id = (int)($_POST['id_besoin'] ?? 0);
        if ($id > 0) {
            try {
                $stmt = $pdo->prepare("DELETE FROM besoin WHERE id_besoin = ?");
                $stmt->execute([$id]);
                header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/etat_de_besoin.php?success=deleted");
                exit;
            } catch (PDOException $e) {
                header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/etat_de_besoin.php?error=db");
                exit;
            }
        } else {
            header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/etat_de_besoin.php?error=invalid");
            exit;
        }
    }
    // Action inconnue
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/etat_de_besoin.php?error=noaction");
    exit;
}
// Récupérer la liste des besoins pour affichage
try {
    $stmt = $pdo->prepare("SELECT * FROM besoin ORDER BY id_besoin DESC");
    $stmt->execute();
    $besoins = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $besoins = [];
    $errors[] = "Erreur lors de la récupération des données.";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>État de Besoin</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 80%; margin-top: 20px; }
        th, td { border: 1px solid #333; padding: 8px; text-align: center; }
        th { background-color: #f4f4f4; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        h1 { color: #333; }
        form { margin-bottom: 20px; }
        input[type="text"], input[type="number"], textarea { padding: 8px; margin-right: 10px; }
        button { padding: 8px 12px; background-color: #4CAF50; color: white; border: none; cursor: pointer; }
        button:hover { background-color: #45a049; }
        .btn-edit { background-color: #2196F3; }
        .btn-delete { background-color: #f44336; }
        .error { color: red; margin: 10px 0; }
        .success { color: green; margin: 10px 0; }
    </style>
</head>
<body>
    <h1>État de Besoin</h1>
    <?php if ($success) echo "<p class='success'>$success</p>"; ?>
    <?php if (!empty($errors)) echo "<p class='error'>" . implode('<br>', $errors) . "</p>"; ?>
    <h2>Ajouter un Besoin</h2>
    <form method="POST">
        <?= CSRFProtection::getInputField('etat_de_besoin_action') ?>
        <input type="hidden" name="action" value="add">
        <textarea name="description" placeholder="Description du besoin" required></textarea>
        <input type="number" name="quantite" placeholder="Quantité" min="1" required>
        <button type="submit">Ajouter</button>
    </form>
    <h2>Liste des Besoins</h2>
    <?php if (!empty($besoins)): ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Description</th>
                <th>Quantité</th>
                <th>Actions</th>
            </tr>
            <?php foreach ($besoins as $besoin): ?>
                <tr>
                    <td><?= htmlspecialchars($besoin['id_besoin']) ?></td>
                    <td><?= htmlspecialchars($besoin['description']) ?></td>
                    <td><?= htmlspecialchars($besoin['quantite']) ?></td>
                    <td>
                        <form method="POST" style="display: inline;">
                            <?= CSRFProtection::getInputField('etat_de_besoin_action') ?>
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id_besoin" value="<?= $besoin['id_besoin'] ?>">
                            <button type="submit" class="btn-delete" onclick="return confirm('Voulez-vous vraiment supprimer ce besoin ?');">Supprimer</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>Aucun besoin enregistré pour le moment.</p>
    <?php endif; ?>
</body>
</html>