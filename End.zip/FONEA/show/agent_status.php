<?php
// Set proper headers first
header('Content-Type: application/json');
require_once __DIR__ . '/../Config/db.php';
try {
    // Use central Database singleton
    $pdo = Database::getInstance()->getConnection();
    // Get agent ID (replace with your logic - could be from GET/POST/session)
    $agentId = isset($_GET['agent_id']) ? (int)$_GET['agent_id'] : 1;
    // Validate agent ID
    if ($agentId <= 0) {
        throw new InvalidArgumentException('Invalid agent ID');
    }
    // Fetch last activity with proper error handling
    $stmt = $pdo->prepare("SELECT last_activity FROM agents WHERE id = ? AND active = 1");
    $stmt->execute([$agentId]);
    $lastActivity = $stmt->fetchColumn();
    // Check if agent exists
    if ($lastActivity === false) {
        echo json_encode([
            'online' => false, 
            'error' => 'Agent not found or inactive'
        ]);
        exit;
    }
    // Handle NULL last_activity (never logged in)
    if ($lastActivity === null) {
        echo json_encode([
            'online' => false,
            'last_seen' => null,
            'message' => 'Agent has never been online'
        ]);
        exit;
    }
    // Check if last activity was within last 60 seconds
    $lastActivityTimestamp = strtotime($lastActivity);
    $currentTime = time();
    $timeDifference = $currentTime - $lastActivityTimestamp;
    $isOnline = $timeDifference <= 60;
    // Return comprehensive status
    echo json_encode([
        'online' => $isOnline,
        'last_activity' => $lastActivity,
        'seconds_ago' => $timeDifference,
        'agent_id' => $agentId
    ]);
} catch (PDOException $e) {
    // Database error
    http_response_code(500);
    echo json_encode([
        'online' => false,
        'error' => 'Database connection failed'
    ]);
} catch (Exception $e) {
    // Other errors
    http_response_code(400);
    echo json_encode([
        'online' => false,
        'error' => $e->getMessage()
    ]);
}
?>