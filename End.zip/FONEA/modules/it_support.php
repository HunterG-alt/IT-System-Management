<?php
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../modules/permission.php';

AuthMiddleware::requireRole('INFORMATIQUE');
// Connexion PDO
require_once __DIR__ . '/../Config/db.php';
// Ajouter un ticket
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['titre'])) {
    $stmt = $pdo->prepare("INSERT INTO tickets (titre, description, statut) VALUES (?, ?, 'Ouvert')");
    $stmt->execute([$_POST['titre'], $_POST['description']]);
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/it_support.php");
    exit;
}
// Clôturer un ticket
if (isset($_GET['close'])) {
    $stmt = $pdo->prepare("UPDATE tickets SET statut = 'Clôturé' WHERE id = ?");
    $stmt->execute([$_GET['close']]);
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/it_support.php");
    exit;
}
// Récupérer les tickets
$tickets = $pdo->query("SELECT * FROM tickets ORDER BY id DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Support Informatique</title>
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .card { margin-bottom: 20px; }
        .badge { font-size: 0.9em; }
        .table th, .table td { vertical-align: middle; }
        h1{ color: #28a745; }
        div.card-header { background-color: #343a40; color: white; }
        button.btn-success { background-color: #28a745; border: none; }
        button.btn-success:hover { background-color: #218838; }
        a.btn-success { background-color: #28a745; border: none; }
        a.btn-success:hover { background-color: #218838; }
        a.btn-secondary { background-color: #6c757d; border: none; }
        a.btn-secondary:hover { background-color: #5a6268; }
        .form-label { font-weight: bold; }
        .form-control { border-radius: 0.25rem; }
        .container { max-width: 900px; }
        .btn { border-radius: 0.25rem; }
        .btn i { vertical-align: middle; }
        .me-2 { margin-right: 0.5rem; }
        .mb-4 { margin-bottom: 1.5rem; }
        .py-5 { padding-top: 3rem; padding-bottom: 3rem
        }
        .mt-3 { margin-top: 1rem; }
        .mt-5 { margin-top: 3rem; }
        .mb-3 { margin-bottom: 1rem; }
        .mb-5 { margin-bottom: 3rem; }
        .text-muted { color: #6c757d !important; }
        .text-dark { color: #343a40 !important; }
        .bg-dark { background-color: #343a40 !important; }
        .bg-success { background-color: #28a745 !important; }
        .bg-warning { background-color: #ffc107 !important; }
        .text-white { color: #fff !important; }
        .text-light { color: #f8f9fa !important; }
        .table { background-color: #fff; }
        .table-bordered { border: 1px solid #dee2e6; }
        .table-bordered th, .table-bordered td { border: 1px solid #dee2e6; }
    </style>
</head>
<body class="bg-light">
<div class="container py-5">
    <h1 class="mb-4">Support Informatique</h1>
    <!-- Formulaire nouveau ticket -->
    <div class="card mb-4">
        <div class="card-header bg-success text-white">Nouveau ticket</div>
        <div class="card-body">
            <form method="post">
                <div class="mb-3">
                    <label class="form-label">Titre</label>
                    <input type="text" name="titre" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="3" required></textarea>
                </div>
                <button class="btn btn-success"><i class="fas fa-plus-circle me-2"></i>Créer ticket</button>
            </form>
        </div>
    </div>
    <!-- Liste tickets -->
    <div class="card">
        <div class="card-header bg-dark text-white">Tickets en cours</div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Titre</th>
                        <th>Description</th>
                        <th>Statut</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($tickets as $t): ?>
                    <tr>
                        <td><?= $t['id'] ?></td>
                        <td><?= htmlspecialchars($t['titre']) ?></td>
                        <td><?= htmlspecialchars($t['description']) ?></td>
                        <td>
                            <?php if ($t['statut'] === 'Ouvert'): ?>
                                <span class="badge bg-warning text-dark">Ouvert</span>
                            <?php else: ?>
                                <span class="badge bg-success">Clôturé</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($t['statut'] === 'Ouvert'): ?>
                                <a href="?close=<?= $t['id'] ?>" 
                                   onclick="return confirm('Clôturer ce ticket ?')"
                                   class="btn btn-sm btn-success">
                                    <i class="fas fa-check"></i> Clôturer
                                </a>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <a href="../index.php" class="btn btn-secondary mt-3">
        <i class="fas fa-arrow-left me-2"></i>Retour au tableau de bord
    </a>
</div>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="https://kit.fontawesome.com/42e3a6dd3f.js" crossorigin="anonymous"></script>
</body>
</html>
