type de materiel.php:
<?php
require_once '../Config/db.php';
require_login();
$pdo = Database::getInstance()->getConnection();
$errors = [];
$success = "";
// Affichage des messages depuis l'URL
if (isset($_GET['msg'])) {
    $success = htmlspecialchars($_GET['msg']);
}
if (isset($_GET['error'])) {
    $errors[] = htmlspecialchars($_GET['error']);
}
// Traitement de l'ajout d'un type de matériel
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom_type = trim($_POST['nom_type'] ?? '');
    if (empty($nom_type)) {
        $errors[] = "Le nom du type de matériel est requis.";
    }
    // Vérifier si le nom existe déjà
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM Type_Materiel WHERE nom_type = :nom_type");
            $stmt->execute([':nom_type' => $nom_type]);
            if ($stmt->fetchColumn() > 0) {
                $errors[] = "Ce type de matériel existe déjà.";
            }
        } catch (PDOException $e) {
            $errors[] = "Erreur de vérification : " . $e->getMessage();
        }
    }
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO Type_Materiel (nom_type) VALUES (:nom_type)");
            $stmt->execute([':nom_type' => $nom_type]);
            $success = "Type de matériel ajouté avec succès.";
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de l'ajout : " . $e->getMessage();
        }
    }
}
// Récupérer les types de matériel
try {
    $stmt = $pdo->prepare("SELECT * FROM Type_Materiel ORDER BY id_type DESC");
    $stmt->execute();
    $types = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur lors de la récupération des types : " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Types de Matériel</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 50%; margin-top: 20px; }
        th, td { border: 1px solid #333; padding: 8px; text-align: center; }
        th { background-color: #f4f4f4; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        h1 { color: #333; }
        .btn { padding: 5px 10px; text-decoration: none; border-radius: 4px; }
        .btn-edit { background-color: #4CAF50; color: white; border: none; }
        .btn-delete { background-color: #f44336; color: white; border: none; }
        form { margin-top: 30px; width: 300px; }
        input[type="text"] { width: 100%; padding: 8px; margin: 5px 0; }
        input[type="submit"] { padding: 10px 15px; background-color: #2196F3; color: white; border: none; cursor: pointer; }
        .error { color: red; }
        .success { color: green; }
        a { text-decoration: none; color: white; padding: 5px 10px; border-radius: 4px; }
    </style>
</head>
<body>
    <h1>Types de Matériel</h1>
    <?php if ($success) echo "<p class='success'>$success</p>"; ?>
    <?php if (!empty($errors)) echo "<p class='error'>" . implode('<br>', $errors) . "</p>"; ?>
    <?php if (!empty($types)): ?>
        <table>
            <tr>
                <th>ID Type</th>
                <th>Nom Type</th>
                <th>Actions</th>
            </tr>
            <?php foreach ($types as $t): ?>
                <tr>
                    <td><?= htmlspecialchars($t['id_type']) ?></td>
                    <td><?= htmlspecialchars($t['nom_type']) ?></td>
                    <td>
                        <a href="edit_type_materiel.php?id=<?= $t['id_type'] ?>" class="btn btn-edit">Modifier</a>
                        <a href="delete_type_materiel.php?id=<?= $t['id_type'] ?>" class="btn btn-delete" onclick="return confirm('Voulez-vous vraiment supprimer ce type ?');">Supprimer</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>Aucun type de matériel enregistré pour le moment.</p>
    <?php endif; ?>
    <h2>Ajouter un Type de Matériel</h2>
    <form method="POST" action="">
        <label for="nom_type">Nom du Type:</label>
        <input type="text" id="nom_type" name="nom_type" required>
        <input type="submit" value="Ajouter">
    </form>
</body>
</html>