<?php
session_start();
require_once '../Config/config.php';

if (!isset($_GET['token'])) {
    die("Invalid or missing reset token.");
}
$token = $_GET['token'];
$stmt = $pdo->prepare("SELECT id, reset_expires FROM users WHERE reset_token = :token");
$stmt->execute(['token' => $token]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$user) {
    die("Invalid reset link.");
}
if (!empty($user['reset_expires']) && strtotime($user['reset_expires']) < time()) {
    die("Reset link has expired. Please request a new one.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';
    if (strlen($password) < 6) {
        $error = "Password must be at least 6 characters.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $update = $pdo->prepare("UPDATE users SET password = :pass, reset_token = NULL, reset_expires = NULL WHERE id = :id");
        $update->execute([
            'pass' => $hash,
            'id'   => $user['id']
        ]);
        $_SESSION['success'] = "Password successfully reset. You can now log in.";
        header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/login.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Reset Password</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <style>
    body {
      background: linear-gradient(135deg, #74ABE2, #5563DE);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .glass-card {
      backdrop-filter: blur(20px);
      background: rgba(255, 255, 255, 0.15);
      border-radius: 20px;
      box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
      padding: 2rem;
      width: 100%;
      max-width: 420px;
      color: #fff;
    }
    .glass-card h3 {
      font-weight: 600;
      margin-bottom: 1.5rem;
      text-align: center;
    }
    .form-control {
      background: rgba(255, 255, 255, 0.2);
      border: none;
      color: #fff;
    }
    .form-control:focus {
      background: rgba(255, 255, 255, 0.3);
      color: #fff;
      box-shadow: none;
    }
    .btn-primary {
      background-color: rgba(255, 255, 255, 0.25);
      border: none;
      backdrop-filter: blur(10px);
      color: #fff;
      font-weight: 500;
    }
    .btn-primary:hover {
      background-color: rgba(255, 255, 255, 0.35);
    }
    .alert-danger {
      background-color: rgba(255, 0, 0, 0.3);
      border: none;
      color: #fff;
    }
  </style>
</head>
<body>
  <div class="glass-card">
    <h3>Réinitialiser le Mot de Passe</h3>
    <?php if (!empty($error)): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST">
      <div class="mb-3">
        <label for="password" class="form-label">Nouveau Mot de Passe</label>
        <input type="password" class="form-control" id="password" name="password" required>
      </div>
      <div class="mb-3">
        <label for="confirm" class="form-label">Confirmez Votre Mot de Passe</label>
        <input type="password" class="form-control" id="confirm" name="confirm" required>
      </div>
      <button type="submit" class="btn btn-primary w-100">Réinitialiser le Mot de Passe</button>
    </form>
  </div>
</body>
</html>
