<?php
/**
 * Besoin (Need/Request) Management Class for FONEA System
 * 
 * Handles creation, modification, and management of equipment requests
 * 
 * @author Glory LOUSSI and Development Team
 * @version 2.0
 */
require_once __DIR__ . '/../Config/db.php';
class Besoin {
    /**
     * Get requests by status
     * 
     * @param string $status
     * @return int
     */
    public static function countByStatut(string $status): int {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            // Map status values to database enum values
            $status_map = [
                'EN_ATTENTE' => 'en_attente',
                'APPROUVE' => 'validee_directeur',
                'REJETE' => 'refusee_directeur'
            ];
            $db_status = $status_map[$status] ?? $status;
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM etat_de_besoin WHERE statut = ?");
            $stmt->execute([$db_status]);
            return (int) $stmt->fetchColumn();
        } catch (Exception $e) {
            error_log("Error counting besoins by status: " . $e->getMessage());
            return 0;
        }
    }
    /**
     * Get requests by agent
     * 
     * @param int $agent_id
     * @return array
     */
    public static function getByAgent(int $agent_id): array {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            $stmt = $pdo->prepare("
                SELECT id_besoin as id, designation_materiel as designation, 
                       justification, statut, date_soumission, date_limite,
                       fichier_joint
                FROM etat_de_besoin 
                WHERE id_agent = ?
                ORDER BY date_soumission DESC
            ");
            $stmt->execute([$agent_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error fetching besoins by agent: " . $e->getMessage());
            return [];
        }
    }
    /**
     * Create new request
     * 
     * @param array $data
     * @return int|false Request ID on success, false on failure
     */
    public static function create(array $data) {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            $stmt = $pdo->prepare("
                INSERT INTO etat_de_besoin (id_agent, designation_materiel, justification, date_limite, fichier_joint) 
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $data['id_agent'],
                $data['designation_materiel'],
                $data['justification'],
                $data['date_limite'] ?? null,
                $data['fichier_joint'] ?? null
            ]);
            return $pdo->lastInsertId();
        } catch (Exception $e) {
            error_log("Error creating besoin: " . $e->getMessage());
            return false;
        }
    }
    /**
     * Update request
     * 
     * @param int $id
     * @param array $data
     * @return bool
     */
    public static function update(int $id, array $data): bool {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            $set_clauses = [];
            $params = [];
            $allowed_fields = ['designation_materiel', 'justification', 'date_limite', 'statut'];
            foreach ($allowed_fields as $field) {
                if (isset($data[$field])) {
                    $set_clauses[] = "$field = ?";
                    $params[] = $data[$field];
                }
            }
            if (empty($set_clauses)) {
                return false;
            }
            $params[] = $id;
            $sql = "UPDATE etat_de_besoin SET " . implode(', ', $set_clauses) . " WHERE id_besoin = ?";
            $stmt = $pdo->prepare($sql);
            return $stmt->execute($params);
        } catch (Exception $e) {
            error_log("Error updating besoin: " . $e->getMessage());
            return false;
        }
    }
    /**
     * Delete request
     * 
     * @param int $id
     * @return bool
     */
    public static function delete(int $id): bool {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            // Archive before delete
            self::archive($id);
            $stmt = $pdo->prepare("DELETE FROM etat_de_besoin WHERE id_besoin = ?");
            return $stmt->execute([$id]);
        } catch (Exception $e) {
            error_log("Error deleting besoin: " . $e->getMessage());
            return false;
        }
    }
    /**
     * Archive request before deletion
     * 
     * @param int $id
     */
    private static function archive(int $id): void {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            // Get original data
            $stmt = $pdo->prepare("SELECT * FROM etat_de_besoin WHERE id_besoin = ?");
            $stmt->execute([$id]);
            $besoin = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($besoin) {
                // Insert into archive
                $stmt = $pdo->prepare("
                    INSERT INTO besoin_archive (original_id, agent_id, designation, justification, date_soumission, statut, deleted_by) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $besoin['id_besoin'],
                    $besoin['id_agent'],
                    $besoin['designation_materiel'],
                    $besoin['justification'],
                    $besoin['date_soumission'],
                    $besoin['statut'],
                    $_SESSION['user_id'] ?? null
                ]);
            }
        } catch (Exception $e) {
            error_log("Error archiving besoin: " . $e->getMessage());
        }
    }
    /**
     * Get request by ID
     * 
     * @param int $id
     * @return array|null
     */
    public static function getById(int $id): ?array {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            $stmt = $pdo->prepare("
                SELECT b.*, a.nom, a.prenom, a.email,
                       CONCAT(a.prenom, ' ', a.nom) as agent_nom_complet
                FROM etat_de_besoin b
                JOIN agents a ON b.id_agent = a.id_agent
                WHERE b.id_besoin = ?
            ");
            $stmt->execute([$id]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result ?: null;
        } catch (Exception $e) {
            error_log("Error fetching besoin by ID: " . $e->getMessage());
            return null;
        }
    }
    /**
     * Get all requests with pagination
     * 
     * @param int $limit
     * @param int $offset
     * @param string|null $status_filter
     * @return array
     */
    public static function getAll(int $limit = 20, int $offset = 0, ?string $status_filter = null): array {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();
            $where_clause = '';
            $params = [];
            if ($status_filter) {
                $where_clause = 'WHERE b.statut = ?';
                $params[] = $status_filter;
            }
            $params[] = $limit;
            $params[] = $offset;
            $stmt = $pdo->prepare("
                SELECT b.*, a.nom, a.prenom, a.email,
                       CONCAT(a.prenom, ' ', a.nom) as agent_nom_complet
                FROM etat_de_besoin b
                JOIN agents a ON b.id_agent = a.id_agent
                $where_clause
                ORDER BY b.date_soumission DESC 
                LIMIT ? OFFSET ?
            ");
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error fetching all besoins: " . $e->getMessage());
            return [];
        }
    }
}
?>
