<?php
require_once '../Config/db.php';
session_start();
// Initialize variables
$errors = [];
$pdo = null;
try {
    // Get database connection
    if (class_exists('Database')) {
        $pdo = Database::getInstance()->getConnection();
    } else {
        // Fallback to global $pdo if Database class doesn't exist
        global $pdo;
        if (!$pdo) {
            throw new Exception("Database connection not available");
        }
    }
} catch (Exception $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}
// Authentication check
function checkAuth() {
    if (!isset($_SESSION['user_id']) && !isset($_SESSION['logged_in'])) {
        header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
        exit();
    }
}
checkAuth();
// Get order ID from URL or POST
$id_commande = 0;
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id_commande = (int)$_GET['id'];
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_commande'])) {
    $id_commande = (int)$_POST['id_commande'];
}
if ($id_commande <= 0) {
    $_SESSION['message'] = "ID de commande invalide.";
    $_SESSION['message_type'] = "danger";
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/commande.php");
    exit();
}
// Retrieve the order to delete
$commande = null;
try {
    $stmt = $pdo->prepare("
        SELECT c.*, f.nom AS fournisseur_nom, f.email AS fournisseur_email,
               m.nom AS materiel_nom, m.description AS materiel_description
        FROM commande c
        LEFT JOIN fournisseur f ON c.id_fournisseur = f.id
        LEFT JOIN materiel m ON c.id_materiel = m.id
        WHERE c.id = :id
    ");
    $stmt->execute([':id' => $id_commande]);
    $commande = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$commande) {
        $_SESSION['message'] = "Commande introuvable.";
        $_SESSION['message_type'] = "danger";
        header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/commande.php");
        exit();
    }
} catch (PDOException $e) {
    $_SESSION['message'] = "Erreur lors du chargement de la commande : " . $e->getMessage();
    $_SESSION['message_type'] = "danger";
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/commande.php");
    exit();
}
// Handle order deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    try {
        $pdo->beginTransaction();
        // You might want to keep a log of deleted orders instead of actually deleting them
        // For now, we'll do a hard delete
        $stmt = $pdo->prepare("DELETE FROM commande WHERE id = :id");
        $result = $stmt->execute([':id' => $id_commande]);
        if ($result && $stmt->rowCount() > 0) {
            $pdo->commit();
            $_SESSION['message'] = "Commande #" . $id_commande . " supprimée avec succès.";
            $_SESSION['message_type'] = "success";
        } else {
            $pdo->rollBack();
            $_SESSION['message'] = "Erreur lors de la suppression : commande non trouvée.";
            $_SESSION['message_type'] = "danger";
        }
        header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/commande.php");
        exit();
    } catch (PDOException $e) {
        $pdo->rollBack();
        $_SESSION['message'] = "Erreur lors de la suppression : " . $e->getMessage();
        $_SESSION['message_type'] = "danger";
        header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/commande.php");
        exit();
    }
}
// If it's a direct POST request (from JavaScript), handle it immediately
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['confirm_delete'])) {
    // This handles the direct deletion from the main page
    try {
        $stmt = $pdo->prepare("DELETE FROM commande WHERE id = :id");
        $result = $stmt->execute([':id' => $id_commande]);
        if ($result && $stmt->rowCount() > 0) {
            $_SESSION['message'] = "Commande #" . $id_commande . " supprimée avec succès.";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Erreur lors de la suppression : commande non trouvée.";
            $_SESSION['message_type'] = "danger";
        }
    } catch (PDOException $e) {
        $_SESSION['message'] = "Erreur lors de la suppression : " . $e->getMessage();
        $_SESSION['message_type'] = "danger";
    }
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/commande.php");
    exit();
}
$total = $commande['quantite'] * ($commande['prix_unitaire'] ?? 0);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supprimer la Commande #<?= $id_commande ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card {
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .danger-zone {
            background: #fff5f5;
            border: 2px solid #fed7d7;
            border-radius: 12px;
            padding: 25px;
        }
        .status-badge {
            font-size: 0.85em;
        }
        .pulse {
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="text-danger">
                <i class="fas fa-exclamation-triangle pulse"></i> 
                Supprimer la Commande #<?= $id_commande ?>
            </h1>
            <div>
                <a href="commande.php" class="btn btn-outline-secondary me-2">
                    <i class="fas fa-arrow-left"></i> Retour aux commandes
                </a>
                <a href="../dashboard.php" class="btn btn-outline-primary">
                    <i class="fas fa-home"></i> Dashboard
                </a>
            </div>
        </div>
        <!-- Warning Alert -->
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle"></i>
            <strong>Attention !</strong> Cette action est irréversible. Une fois supprimée, la commande ne pourra pas être récupérée.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <!-- Order Details -->
        <div class="card mb-4">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0">
                    <i class="fas fa-info-circle"></i> 
                    Détails de la commande à supprimer
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="text-muted">Informations générales</h6>
                        <table class="table table-sm table-borderless">
                            <tr>
                                <td><strong>ID Commande:</strong></td>
                                <td>#<?= $commande['id'] ?></td>
                            </tr>
                            <tr>
                                <td><strong>Date de commande:</strong></td>
                                <td><?= date("d/m/Y", strtotime($commande['date_commande'])) ?></td>
                            </tr>
                            <tr>
                                <td><strong>Statut:</strong></td>
                                <td>
                                    <?php
                                    $status_class = match($commande['statut']) {
                                        'en_attente' => 'bg-warning text-dark',
                                        'confirmee' => 'bg-info',
                                        'livree' => 'bg-success',
                                        'annulee' => 'bg-danger',
                                        default => 'bg-secondary'
                                    };
                                    ?>
                                    <span class="badge status-badge <?= $status_class ?>">
                                        <?= ucfirst($commande['statut']) ?>
                                    </span>
                                </td>
                            </tr>
                            <?php if (isset($commande['created_at']) && $commande['created_at']): ?>
                            <tr>
                                <td><strong>Créée le:</strong></td>
                                <td><?= date("d/m/Y H:i", strtotime($commande['created_at'])) ?></td>
                            </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-muted">Détails de la commande</h6>
                        <table class="table table-sm table-borderless">
                            <tr>
                                <td><strong>Fournisseur:</strong></td>
                                <td>
                                    <?= htmlspecialchars($commande['fournisseur_nom'] ?? 'N/A') ?>
                                    <?php if (!empty($commande['fournisseur_email'])): ?>
                                        <br><small class="text-muted"><?= htmlspecialchars($commande['fournisseur_email']) ?></small>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Matériel:</strong></td>
                                <td>
                                    <?= htmlspecialchars($commande['materiel_nom'] ?? 'N/A') ?>
                                    <?php if (!empty($commande['materiel_description'])): ?>
                                        <br><small class="text-muted"><?= htmlspecialchars(substr($commande['materiel_description'], 0, 100)) ?><?= strlen($commande['materiel_description']) > 100 ? '...' : '' ?></small>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Quantité:</strong></td>
                                <td><span class="badge bg-info"><?= $commande['quantite'] ?></span></td>
                            </tr>
                            <tr>
                                <td><strong>Prix unitaire:</strong></td>
                                <td><?= $commande['prix_unitaire'] ? number_format($commande['prix_unitaire'], 2) . ' €' : 'N/A' ?></td>
                            </tr>
                            <?php if ($total > 0): ?>
                            <tr>
                                <td><strong>Total:</strong></td>
                                <td><strong class="text-primary"><?= number_format($total, 2) ?> €</strong></td>
                            </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Deletion Confirmation -->
        <div class="danger-zone">
            <div class="text-center">
                <i class="fas fa-trash-alt fa-3x text-danger mb-3"></i>
                <h4 class="text-danger mb-3">Confirmer la suppression</h4>
                <p class="mb-4">
                    Êtes-vous absolument sûr de vouloir supprimer cette commande ?<br>
                    <strong>Cette action est définitive et irréversible.</strong>
                </p>
                <form method="POST" class="d-inline" id="deleteForm">
                    <input type="hidden" name="id_commande" value="<?= $id_commande ?>">
                    <input type="hidden" name="confirm_delete" value="1">
                    <div class="d-flex gap-3 justify-content-center">
                        <button type="submit" class="btn btn-danger btn-lg pulse">
                            <i class="fas fa-trash-alt"></i> Supprimer définitivement
                        </button>
                        <a href="commande.php" class="btn btn-success btn-lg">
                            <i class="fas fa-shield-alt"></i> Annuler (Conserver)
                        </a>
                    </div>
                </form>
                <div class="mt-4">
                    <small class="text-muted">
                        <i class="fas fa-info-circle"></i>
                        Conseil : Si vous souhaitez juste désactiver cette commande, 
                        <a href="edit_commande.php?id=<?= $id_commande ?>" class="text-decoration-none">
                            modifiez son statut</a> plutôt que de la supprimer.
                    </small>
                </div>
            </div>
        </div>
        <!-- Additional Information -->
        <div class="card">
            <div class="card-header bg-light">
                <h6 class="mb-0">
                    <i class="fas fa-lightbulb"></i> 
                    Alternatives à la suppression
                </h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <div class="text-center p-3 border rounded h-100">
                            <i class="fas fa-edit fa-2x text-primary mb-2"></i>
                            <h6>Modifier</h6>
                            <p class="small text-muted">Changez les détails de la commande</p>
                            <a href="edit_commande.php?id=<?= $id_commande ?>" class="btn btn-sm btn-outline-primary">
                                Modifier
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-center p-3 border rounded h-100">
                            <i class="fas fa-ban fa-2x text-warning mb-2"></i>
                            <h6>Annuler</h6>
                            <p class="small text-muted">Marquez la commande comme annulée</p>
                            <form method="POST" action="edit_commande.php" style="display: inline;">
                                <input type="hidden" name="id" value="<?= $id_commande ?>">
                                <input type="hidden" name="quick_status" value="annulee">
                                <button type="submit" class="btn btn-sm btn-outline-warning" 
                                        onclick="return confirm('Marquer cette commande comme annulée ?')">
                                    Annuler commande
                                </button>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-center p-3 border rounded h-100">
                            <i class="fas fa-archive fa-2x text-info mb-2"></i>
                            <h6>Archiver</h6>
                            <p class="small text-muted">Gardez un historique (recommandé)</p>
                            <button class="btn btn-sm btn-outline-info" onclick="archiveCommande(<?= $id_commande ?>)">
                                Archiver
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Back to Safety -->
        <div class="text-center mt-4 mb-5">
            <a href="commande.php" class="btn btn-success btn-lg">
                <i class="fas fa-arrow-left"></i> 
                Retourner aux commandes en sécurité
            </a>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script>
        // Archive function (placeholder for future implementation)
        function archiveCommande(id) {
            if (confirm('Archiver cette commande ?\n\nCela changera son statut à "archivée" au lieu de la supprimer.')) {
                // For now, redirect to edit page with archive status
                window.location.href = 'edit_commande.php?id=' + id + '&action=archive';
            }
        }
        // Prevent accidental page refresh
        let pageUnloadWarning = true;
        window.addEventListener('beforeunload', function(e) {
            if (pageUnloadWarning) {
                e.preventDefault();
                e.returnValue = 'Êtes-vous sûr de vouloir quitter cette page ?';
                return e.returnValue;
            }
        });
        // Remove beforeunload when clicking on safe links
        document.querySelectorAll('a[href*="commande.php"], a[href*="edit_commande.php"], a[href*="dashboard.php"]').forEach(function(link) {
            link.addEventListener('click', function() {
                pageUnloadWarning = false;
            });
        });
        // Enhanced confirmation for delete form
        document.getElementById('deleteForm').addEventListener('submit', function(e) {
            e.preventDefault();
            // First confirmation
            const firstConfirm = confirm('ATTENTION: Vous êtes sur le point de supprimer définitivement cette commande.\n\nID: #<?= $id_commande ?>\nMatériel: <?= htmlspecialchars($commande['materiel_nom'] ?? 'N/A') ?>\nQuantité: <?= $commande['quantite'] ?>\n\nCette action est IRRÉVERSIBLE!\n\nCliquez OK pour continuer vers la confirmation finale.');
            if (!firstConfirm) {
                return false;
            }
            // Second confirmation with typed input
            const finalConfirm = prompt('Pour confirmer la suppression définitive, tapez exactement "SUPPRIMER" (en majuscules):');
            if (finalConfirm !== 'SUPPRIMER') {
                alert('Suppression annulée. La commande a été conservée.\n\nTexte saisi: "' + (finalConfirm || '') + '"\nTexte requis: "SUPPRIMER"');
                return false;
            }
            // Third and final confirmation
            const lastConfirm = confirm('DERNIÈRE CONFIRMATION:\n\nVous avez tapé "SUPPRIMER" correctement.\nLa commande #<?= $id_commande ?> sera définitivement supprimée.\n\nIl n\'y aura AUCUN moyen de récupérer ces données.\n\nContinuer avec la suppression ?');
            if (lastConfirm) {
                // Disable the warning and submit
                pageUnloadWarning = false;
                this.submit();
            } else {
                alert('Suppression annulée au dernier moment. La commande a été conservée.');
            }
            return false;
        });
        // Auto-focus on cancel button when page loads (safer option)
        window.addEventListener('load', function() {
            const cancelButton = document.querySelector('a[href="commande.php"].btn-success');
            if (cancelButton) {
                cancelButton.focus();
            }
            // Add visual countdown timer to make user think twice
            let countdown = 10;
            const deleteButton = document.querySelector('button[type="submit"].btn-danger');
            const originalText = deleteButton.innerHTML;
            function updateCountdown() {
                if (countdown > 0) {
                    deleteButton.innerHTML = `<i class="fas fa-hourglass-half"></i> Attendre ${countdown}s avant suppression`;
                    deleteButton.disabled = true;
                    countdown--;
                    setTimeout(updateCountdown, 1000);
                } else {
                    deleteButton.innerHTML = originalText;
                    deleteButton.disabled = false;
                    deleteButton.classList.add('pulse');
                }
            }
            updateCountdown();
        });
        // Add warning sound effect on hover over delete button (if supported)
        document.querySelector('button[type="submit"].btn-danger').addEventListener('mouseenter', function() {
            // Simple audio feedback (modern browsers)
            try {
                const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                const oscillator = audioContext.createOscillator();
                const gainNode = audioContext.createGain();
                oscillator.connect(gainNode);
                gainNode.connect(audioContext.destination);
                oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
                oscillator.frequency.setValueAtTime(400, audioContext.currentTime + 0.1);
                gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
                oscillator.start(audioContext.currentTime);
                oscillator.stop(audioContext.currentTime + 0.2);
            } catch (e) {
                // Audio not supported, silently ignore
            }
        });
    </script>
</body>
</html>