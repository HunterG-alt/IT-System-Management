<?php
session_start();
require_once '../Config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute(['id' => $userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$user) {
    die("User not found.");
}

$role = $user['role'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Profile - <?= htmlspecialchars($user['nom'] . ' ' . $user['prenom']) ?></title>
    <style>
        body {
            background-color: #f9fafb;
            margin: 0;
            padding: 20px;
        }
        .profile-card {
            max-width: 500px;
            margin: 50px auto;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            background: #f0f4f8;
            font-family: Arial, sans-serif;
        }
        h2 { margin-bottom: 20px; }
        p { margin: 5px 0; }
        .profile-container {
            max-width: 700px;
            margin: 50px auto;
            padding: 30px;
            background: #ffffff;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        h2 { margin-bottom: 20px; text-align: center; }
        p { margin: 8px 0; }
        .role-card {
            padding: 20px;
            border-radius: 12px;
            margin-top: 20px;
            color: #fff;
            text-align: center;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 15px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }
        .btn:hover { opacity: 0.9; }
        /* Couleurs par rôle */
        .DG { background: #1abc9c; }
        .Directeur { background: #3498db; }
        .ChefService { background: #9b59b6; }
        .Informatique { background: #e67e22; }
        .MoyenGeneraux { background: #e74c3c; }
        .Agent { background: #2ecc71; }
        .Demandeur { background: #f1c40f; color: #000; }
    </style>
</head>
<body>
<div class="profile-card">
    <h2>Profile</h2>
    <p><strong>Name:</strong> <?= htmlspecialchars($user['nom'] . ' ' . $user['prenom']) ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
    <p><strong>Role:</strong> <?= htmlspecialchars($role) ?></p>
    <hr>
    <?php
    
    switch ($role) {
    case 'DG':
        echo "<p>Bienvenue, Directeur Général ! Vous avez un accès complet au système.</p>";
        echo "<a href='admin_dashboard.php'>Aller au tableau de bord Admin</a>";
        break;
    case 'Directeur':
        echo "<p>Bienvenue, Directeur ! Vous pouvez autoriser les demandes et gérer les départements.</p>";
        echo "<a href='directeur_dashboard.php'>Aller au tableau de bord</a>";
        break;
    case 'Chef de Service':
        echo "<p>Bienvenue, Chef de Service ! Vous pouvez gérer les demandes dans votre service.</p>";
        echo "<a href='chef_service_dashboard.php'>Aller au tableau de bord</a>";
        break;
    case 'Informatique':
        echo "<p>Bienvenue, Informatique ! Vous pouvez gérer les demandes techniques et assister les utilisateurs.</p>";
        echo "<a href='it_dashboard.php'>Aller au tableau de bord IT</a>";
        break;
    case 'Moyen Generaux':
        echo "<p>Bienvenue, Moyen Généraux ! Vous pouvez gérer le matériel et les demandes logistiques.</p>";
        echo "<a href='moyens_dashboard.php'>Aller au tableau de bord</a>";
        break;
    case 'Agent':
        echo "<p>Bienvenue, Agent ! Vous pouvez soumettre et suivre vos demandes.</p>";
        echo "<a href='my_requests.php'>Mes demandes</a>";
        break;
    case 'Demandeur':
        echo "<p>Bienvenue, Demandeur ! Vous pouvez créer et suivre vos demandes.</p>";
        echo "<a href='create_request.php'>Créer une demande</a>";
        break;
    default:
        echo "<p>Rôle non reconnu. Contactez l'administrateur.</p>";
        break;
}
    ?>
</div>
</body>
</html>
