<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Requests System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f8fafc;
            padding: 20px;
            margin: 0;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 24px;
            text-align: center;
        }
        .header h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }
        .controls {
            padding: 20px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .refresh-btn {
            background: #3b82f6;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: background 0.2s;
        }
        .refresh-btn:hover {
            background: #2563eb;
        }
        .loading {
            color: #6b7280;
            font-style: italic;
        }
        .error {
            color: #dc2626;
            background: #fef2f2;
            padding: 12px;
            border-radius: 6px;
            margin: 20px;
        }
        #requests-container {
            padding: 20px;
        }
        .request-item {
            display: flex;
            align-items: center;
            padding: 16px;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            margin-bottom: 12px;
            transition: all 0.2s;
            background: white;
        }
        .request-item:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            border-color: #3b82f6;
        }
        .request-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 16px;
            flex-shrink: 0;
        }
        .request-icon i {
            color: white;
            font-size: 18px;
        }
        .request-info {
            flex: 1;
        }
        .request-info h6 {
            margin: 0 0 4px 0;
            font-size: 16px;
            font-weight: 600;
            color: #1f2937;
        }
        .request-info p {
            margin: 0;
            font-size: 14px;
            color: #6b7280;
        }
        .status {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 12px;
        }
        .status.en-attente {
            background: #fef3c7;
            color: #92400e;
        }
        .status.approuvee {
            background: #dbeafe;
            color: #1e40af;
        }
        .status.livree {
            background: #dcfce7;
            color: #166534;
        }
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #6b7280;
        }
        .empty-state i {
            font-size: 48px;
            margin-bottom: 16px;
            color: #d1d5db;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2><i class="fas fa-clipboard-list"></i> Gestionnaire de Demandes</h2>
        </div>
        <div class="controls">
            <div id="status" class="loading">Chargement des demandes...</div>
            <button class="refresh-btn" onclick="loadRequests()">
                <i class="fas fa-sync-alt"></i> Actualiser
            </button>
        </div>
        <div id="requests-container">
            <!-- Requests will be loaded here -->
        </div>
    </div>
    <script>
        let requests = [];
        const container = document.getElementById("requests-container");
        const statusElement = document.getElementById("status");
        function formatTimeAgo(date) {
            const now = new Date();
            const diffMs = now - date;
            const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
            const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
            if (diffHours < 1) return "Soumise il y a moins d'une heure";
            if (diffHours < 24) return `Soumise il y a ${diffHours} heure${diffHours > 1 ? 's' : ''}`;
            return `Soumise il y a ${diffDays} jour${diffDays > 1 ? 's' : ''}`;
        }
        function getStatusClass(status) {
            return status.toLowerCase().replace(/[^a-z]/g, '');
        }
        function renderRequests() {
            if (requests.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h3>Aucune demande trouvée</h3>
                        <p>Il n'y a actuellement aucune demande à afficher.</p>
                    </div>
                `;
                return;
            }
            container.innerHTML = "";
            requests.forEach(req => {
                const item = document.createElement("div");
                item.className = "request-item";
                item.innerHTML = `
                    <div class="request-icon">
                        <i class="${req.icon}"></i>
                    </div>
                    <div class="request-info">
                        <h6>${req.name}</h6>
                        <p>${formatTimeAgo(req.submitted)}</p>
                    </div>
                    <div class="status ${getStatusClass(req.status)}">${req.status}</div>
                `;
                container.appendChild(item);
            });
        }
        function showError(message) {
            container.innerHTML = `
                <div class="error">
                    <i class="fas fa-exclamation-triangle"></i> ${message}
                </div>
            `;
        }
        function loadRequests() {
            statusElement.textContent = "Chargement...";
            statusElement.className = "loading";
            fetch('get_requests.php')
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.error) {
                        throw new Error(data.error);
                    }
                    // Convert date strings to Date objects
                    data.forEach(req => {
                        req.submitted = new Date(req.submitted);
                    });
                    requests = data;
                    renderRequests();
                    statusElement.textContent = `${requests.length} demande${requests.length !== 1 ? 's' : ''} trouvée${requests.length !== 1 ? 's' : ''}`;
                    statusElement.className = "";
                })
                .catch(error => {
                    console.error('Error loading requests:', error);
                    showError('Erreur lors du chargement des demandes: ' + error.message);
                    statusElement.textContent = "Erreur de chargement";
                    statusElement.className = "error";
                });
        }
        // Load requests when page loads
        document.addEventListener('DOMContentLoaded', loadRequests);
        // Auto-refresh every 30 seconds
        setInterval(loadRequests, 30000);
    </script>
</body>
</html>