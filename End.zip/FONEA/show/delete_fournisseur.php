<?php
session_start();
require_once '../Config/db.php';
require_login();
// Vérifier le token CSRF pour la sécurité
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die("Token CSRF invalide.");
    }
}
$pdo = Database::getInstance()->getConnection();
// Vérifier que l'ID du fournisseur est fourni
$id = $_POST['id'] ?? $_GET['id'] ?? null;
if (!$id || !is_numeric($id)) {
    $_SESSION['error'] = "ID fournisseur manquant ou invalide.";
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/fournisseur.php");
    exit;
}
// Vérifier que le fournisseur existe et récupérer ses informations
try {
    $stmt = $pdo->prepare("SELECT nom, email FROM Fournisseur WHERE id_fournisseur = :id");
    $stmt->execute([':id' => $id]);
    $fournisseur = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$fournisseur) {
        $_SESSION['error'] = "Fournisseur non trouvé.";
        header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/fournisseur.php");
        exit;
    }
} catch (PDOException $e) {
    error_log("Erreur lors de la recherche du fournisseur: " . $e->getMessage());
    $_SESSION['error'] = "Erreur lors de la recherche du fournisseur.";
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/fournisseur.php");
    exit;
}
// Si c'est une requête GET, afficher la page de confirmation
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Générer un token CSRF
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    ?>
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Supprimer le fournisseur</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 600px;
                margin: 50px auto;
                padding: 20px;
                background-color: #f5f5f5;
            }
            .confirmation-box {
                background: white;
                padding: 30px;
                border-radius: 8px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                text-align: center;
            }
            .warning {
                color: #d32f2f;
                font-size: 18px;
                margin-bottom: 20px;
            }
            .supplier-info {
                background: #f8f9fa;
                padding: 15px;
                border-radius: 4px;
                margin: 20px 0;
                border-left: 4px solid #007bff;
            }
            .buttons {
                margin-top: 30px;
            }
            .btn {
                padding: 12px 24px;
                border: none;
                border-radius: 4px;
                cursor: pointer;
                font-size: 16px;
                margin: 0 10px;
                text-decoration: none;
                display: inline-block;
            }
            .btn-danger {
                background-color: #dc3545;
                color: white;
            }
            .btn-danger:hover {
                background-color: #c82333;
            }
            .btn-secondary {
                background-color: #6c757d;
                color: white;
            }
            .btn-secondary:hover {
                background-color: #545b62;
            }
        </style>
    </head>
    <body>
        <div class="confirmation-box">
            <h2 class="warning">⚠️ Confirmation de suppression</h2>
            <p>Êtes-vous sûr de vouloir supprimer ce fournisseur ?</p>
            <div class="supplier-info">
                <strong>Nom :</strong> <?php echo htmlspecialchars($fournisseur['nom']); ?><br>
                <strong>Email :</strong> <?php echo htmlspecialchars($fournisseur['email']); ?>
            </div>
            <p><strong>Cette action est irréversible !</strong></p>
            <div class="buttons">
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Êtes-vous vraiment sûr ?');">
                        Oui, supprimer
                    </button>
                </form>
                <a href="fournisseur.php" class="btn btn-secondary">Annuler</a>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}
// Si c'est une requête POST, procéder à la suppression
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Commencer une transaction pour s'assurer de la cohérence
        $pdo->beginTransaction();
        // Vérifier s'il y a des contraintes de clé étrangère
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM Commande WHERE id_fournisseur = :id");
        $stmt->execute([':id' => $id]);
        $commandeCount = $stmt->fetchColumn();
        if ($commandeCount > 0) {
            $pdo->rollBack();
            $_SESSION['error'] = "Impossible de supprimer ce fournisseur car il est lié à $commandeCount commande(s).";
            header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/fournisseur.php");
            exit;
        }
        // Supprimer le fournisseur
        $stmt = $pdo->prepare("DELETE FROM Fournisseur WHERE id_fournisseur = :id");
        $stmt->execute([':id' => $id]);
        // Vérifier si la suppression a bien eu lieu
        if ($stmt->rowCount() > 0) {
            $pdo->commit();
            $_SESSION['success'] = "Fournisseur '{$fournisseur['nom']}' supprimé avec succès.";
        } else {
            $pdo->rollBack();
            $_SESSION['error'] = "Aucun fournisseur n'a été supprimé.";
        }
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Erreur lors de la suppression du fournisseur: " . $e->getMessage());
        $_SESSION['error'] = "Erreur lors de la suppression du fournisseur.";
    }
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/fournisseur.php");
    exit;
}
?>