# 📦 Gestion des acquisitions du matériel informatique - FONEA

 Description
Cette application a pour objectif d’automatiser et de gérer l’ensemble du cycle de vie des acquisitions de matériel informatique au sein du **FONEA**.  
Elle permet aux agents de soumettre leurs besoins, aux responsables de valider ou refuser les demandes, et aux services compétents de suivre l’acquisition, la livraison et la mise en stock du matériel.

Le système repose sur une base de données relationnelle MySQL et une interface applicative en PHP.

---

 Fonctionnalités principales
**Gestion des utilisateurs (agents)**
 Rôles : `demandeur`, `chef_service`, `directeur`, `directeur_general`, `informatique`, `moyens_generaux`.
 Authentification sécurisée (mots de passe hashés).
**Gestion des besoins**
 Soumission d’un état de besoin par un agent.
 Validation par le chef de service, puis le directeur / directeur général.
 Analyse technique par le service informatique.
 **Cycle d’acquisition**
 Pré-validation et validation hiérarchique.
 Analyse technique détaillée.
 Acquisition (commande, suivi fournisseur, réception).
 Attribution et mise en stock.
**Suivi et notifications** Historique des actions (journal d’activité). Notifications envoyées aux agents selon l’état de leur demande.
*Archivage**
 Conservation des besoins supprimés dans une table d’archive.

---

 Structure de la base de données
La base `fonea` est organisée autour de plusieurs tables clés :

- `agents` : gestion des utilisateurs et de leurs rôles.
- `etat_de_besoin` : demandes de matériel soumises par les agents.
- `type_materiel` et `type_caracteristique` : typologie du matériel et de ses caractéristiques.
- `fournisseur` : liste des fournisseurs.
- `materiel` et `caracteristique` : matériel acquis avec ses spécifications.
- `besoin_materiel` : détail des besoins exprimés dans chaque demande.
- `pre_validation`, `validation_direction`, `analyse_technique` : étapes de validation et analyse.
- `acquisitions`, `commande`, `livraison`, `stock` : suivi du cycle d’acquisition.
- `besoin_archive` : sauvegarde des besoins supprimés.
- `activity_log` : journalisation des actions.
- `notifications` : alertes aux agents.

---

 Workflow simplifié
1.**Demande soumise** par un agent (`etat_de_besoin`).
2. **Pré-validation** par le chef de service (`pre_validation`).
3. **Validation** par le directeur / DG (`validation_direction`).
4. **Analyse technique** par le service informatique (`analyse_technique`).
5. **Acquisition** : commande et suivi fournisseur (`acquisitions`, `commande`, `livraison`).
6. **Attribution et mise en stock** (`materiel`, `stock`).
7. **Notification** envoyée à l’agent (`notifications`).

---

 Installation
 Prérequis
PHP >= 8.0  
 MySQL >= 8.0  
Serveur web (Apache / Nginx)  

 Étapes
1.Cloner le projet :
  `bash
   git clonehttps://github.com/votre-repo/fonea-gestion.git
   cd fonea-gestion
