<?php
// procurement_mg.php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit;
}

$role = $_SESSION['role'] ?? '';
if ($role !== 'Moyen Generaux'&& $role !== 'Directeur General') {
    echo "<p>Accès refusé. Vous n'avez pas les permissions nécessaires.</p>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approvisionnement</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #4facfe, #00f2fe);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            max-width: 700px;
        }
        .card {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 20px;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
            padding: 2rem;
            color: #fff;
        }
        h1 {
            font-weight: 700;
            color: #fff;
            text-shadow: 1px 1px 4px rgba(0,0,0,0.4);
        }
        a.btn {
            margin: 0.5rem;
            padding: 0.6rem 1.2rem;
            border-radius: 30px;
            font-weight: 600;
            transition: all 0.3s ease-in-out;
        }
        a.btn-secondary {
            background-color: rgba(255,255,255,0.2);
            border: none;
            color: #fff;
        }
        a.btn-secondary:hover {
            background-color: rgba(255,255,255,0.35);
        }
        a.btn-danger {
            background-color: #ff4d4d;
            border: none;
        }
        a.btn-danger:hover {
            background-color: #e60000;
        }
        ul {
            list-style-type: none;
            padding-left: 0;
        }
        li::before {
            content: "✔ ";
            color: #00f2fe;
        }
</style>
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center mb-4">Module Approvisionnement</h1>
    <div class="card p-4 shadow-sm">
        <p>Bienvenue dans le module Approvisionnement. Ici vous pouvez :</p>
        <ul>
            <li>Assigner des demandes d'achat de matériel.</li>
            <li>Suivre les commandes en cours.</li>
            <li>Générer des rapports d'approvisionnement.</li>
        </ul>
    </div>
    <div class="mt-4 text-center">
        <a href="dashboard_moyens_generaux.php" class="btn btn-secondary">Retour au tableau de bord</a>
        <a href="logout.php" class="btn btn-danger">Se déconnecter</a>
    </div>
</div>
</body>
</html>
