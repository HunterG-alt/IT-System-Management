<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FONEA - Glassmorphism Footer</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
  <!-- Font Awesome 6.5 -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
 <style>
  body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    min-height: 100vh;
    background: #e5eaee; 
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding: 2rem 0;
    color: #8b8e91; 
  }
  .content-spacer {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 60vh;
  }
  .demo-content {
    text-align: center;
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 20px;
    padding: 3rem;
    color: #8b8e91; 
  }
  /* Professional Glassmorphism Footer */
  .professional-footer {
    position: relative;
    background: rgba(255, 255, 255, 0.02);
    backdrop-filter: blur(30px);
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow:
      0 -8px 32px rgba(0, 0, 0, 0.12),
      inset 0 1px 0 rgba(255, 255, 255, 0.1);
    padding: 3rem 0 2rem;
    margin-top: auto;
    overflow: hidden;
  }
  /* Animated Background Elements */
  .professional-footer::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(
      circle at 30% 70%,
      rgba(0, 255, 153, 0.03) 0%,
      transparent 50%
    ),
    radial-gradient(
      circle at 70% 30%,
      rgba(0, 204, 255, 0.03) 0%,
      transparent 50%
    ),
    radial-gradient(
      circle at 80% 80%,
      rgba(255, 255, 255, 0.02) 0%,
      transparent 50%
    );
    animation: footerFloat 20s ease-in-out infinite;
    z-index: -1;
  }
  @keyframes footerFloat {
    0%, 100% { transform: translateX(0px) translateY(0px) rotate(0deg); }
    33% { transform: translateX(-20px) translateY(-10px) rotate(120deg); }
    66% { transform: translateX(15px) translateY(-20px) rotate(240deg); }
  }
  .footer-bg-text {
    position: absolute;
    top: 25%;
    left: 50%;
    transform: translateX(-50%);
    font-size: 5rem;
    font-weight: 800;
    color: #ffffff;
    opacity: 0.1; /* Faded background text */
    pointer-events: none;
    user-select: none;
    white-space: nowrap;
  }
  .footer-content {
    position: relative;
    z-index: 10;
    text-align: center;
  }
  .footer-brand {
    font-size: 2.5rem;
    font-weight: bold;
    letter-spacing: 4px;
    margin-bottom: 1rem;
    color: #000000; /* Bold black heading */
    transition: all 0.3s ease;
    cursor: pointer;
  }
  .footer-tagline {
    font-size: 1.1rem;
    color: #8b8e91; /* Paragraph text color */
    font-weight: 400;
    margin-bottom: 2rem;
  }
  .footer-links {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 1.5rem;
    margin-bottom: 2rem;
  }
  .footer-link {
    position: relative;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 255, 255, 0.08);
    backdrop-filter: blur(15px);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 50%;
    color: #000000; 
    text-decoration: none;
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    overflow: hidden;
  }
  .footer-link:hover {
    color: #000000;
    background: #ffffff;
    transform: translateY(-8px) scale(1.1);
    box-shadow:
      0 10px 25px rgba(0, 0, 0, 0.1),
      0 0 0 8px rgba(255, 255, 255, 0.1);
    border-color: rgba(0, 0, 0, 0.2);
  }
  .footer-bottom {
    background: rgba(0, 0, 0, 0.05);
    backdrop-filter: blur(20px);
    border-top: 1px solid rgba(255, 255, 255, 0.05);
    border-radius: 15px 15px 0 0;
    padding: 1.5rem 0 1rem;
    margin-top: 2rem;
    position: relative;
    color: #8b8e91;
  }
  .footer-copyright {
    font-size: 0.95rem;
    margin-bottom: 0.5rem;
  }
  /* Floating Particles */
  .particle {
    position: absolute;
    width: 4px;
    height: 4px;
    background: rgba(0, 255, 153, 0.6);
    border-radius: 50%;
    animation: particleFloat 8s linear infinite;
  }
  .particle:nth-child(1) { left: 10%; animation-delay: 0s; }
  .particle:nth-child(2) { left: 30%; animation-delay: -2s; }
  .particle:nth-child(3) { left: 50%; animation-delay: -4s; }
  .particle:nth-child(4) { left: 70%; animation-delay: -6s; }
  .particle:nth-child(5) { left: 90%; animation-delay: -8s; }
  @keyframes particleFloat {
    0% { transform: translateY(0px) scale(1); opacity: 0; }
    10%, 90% { opacity: 1; }
    100% { transform: translateY(-100px) scale(0); opacity: 0; }
  }
  @media (max-width: 768px) {
    .footer-brand { font-size: 2rem; letter-spacing: 2px; }
    .footer-bg-text { font-size: 3rem; }
    .footer-links { gap: 1rem; }
    .footer-link { width: 45px; height: 45px; }
  }
  @media (prefers-reduced-motion: reduce) {
    .professional-footer::before,
    .particle,
    .footer-link {
      animation: none;
    }
  }
</style>
</head>
<body>

<div class="content-spacer">
  <div class="demo-content">
    <h2>A propos</h2>
    <p>Cette plateforme a été mise en place dans le but de facilité vos besoins.</p>
    <p>Nous espérions que vous trouveriez ce dont il vous faut à porter de main.</p>
  </div>
</div>

<footer class="professional-footer text-light">
  
  <div class="particle"></div>
  <div class="particle"></div>
  <div class="particle"></div>
  <div class="particle"></div>
  <div class="particle"></div>
  <div class="container">
    <div class="footer-content text-center">
      <!-- Brand Section -->
      <div class="footer-brand" tabindex="0">FONEA</div>
      <p class="footer-tagline">Gestion professionnelle des acquisitions</p>
      <!-- Social Links -->
      <div class="footer-links">
        <a href="https://www.instagram.com/fonea_officiel" 
           target="_blank" 
           class="footer-link instagram" 
           aria-label="Suivez-nous sur Instagram"
           rel="noopener noreferrer">
          <i class="fab fa-instagram" aria-hidden="true"></i>
        </a>
        <a href="https://www.facebook.com/fonea.officiel" 
           target="_blank" 
           class="footer-link facebook" 
           aria-label="Suivez-nous sur Facebook"
           rel="noopener noreferrer">
          <i class="fab fa-facebook" aria-hidden="true"></i>
        </a>
        <a href="https://www.google.com" 
           target="_blank" 
           class="footer-link google" 
           aria-label="Trouvez-nous sur Google"
           rel="noopener noreferrer">
          <i class="fab fa-google" aria-hidden="true"></i>
        </a>
        <a href="https://www.twitter.com/fonea_officiel" 
           target="_blank" 
           class="footer-link twitter" 
           aria-label="Suivez-nous sur X (Twitter)"
           rel="noopener noreferrer">
          <i class="fab fa-x-twitter fa-2x" aria-hidden="true"></i>
        </a>
      </div>
    </div>
    <!-- Footer Bottom -->
    <div class="footer-bottom text-center">
      <div class="footer-copyright">
        &copy; <span id="currentYear">2025</span> <strong>FONEA</strong>. Tous droits réservés.
      </div>
      <div class="footer-contact">
        <div>
          <i class="fas fa-envelope" aria-hidden="true"></i>
          <span class="email">gloryloudmith@gmail.com</span>
        </div>
        <span>•</span>
        <div>
          Développé par <span class="developer">Glory LOUSSI</span>
        </div>
      </div>
    </div>
  </div>
</footer>
<script>
  // Update current year
  document.getElementById('currentYear').textContent = new Date().getFullYear();
  // Add smooth scroll behavior for links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });
</script>
</div>
</body>
</html><!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FONEA - Glassmorphism Footer</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
  <!-- Font Awesome 6.5 -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
 <style>
  body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    min-height: 100vh;
    background: #e5eaee; 
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding: 2rem 0;
    color: #8b8e91; 
  }
  .content-spacer {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 60vh;
  }
  .demo-content {
    text-align: center;
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 20px;
    padding: 3rem;
    color: #8b8e91; 
  }
  /* Professional Glassmorphism Footer */
  .professional-footer {
    position: relative;
    background: rgba(255, 255, 255, 0.02);
    backdrop-filter: blur(30px);
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow:
      0 -8px 32px rgba(0, 0, 0, 0.12),
      inset 0 1px 0 rgba(255, 255, 255, 0.1);
    padding: 3rem 0 2rem;
    margin-top: auto;
    overflow: hidden;
  }
  /* Animated Background Elements */
  .professional-footer::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(
      circle at 30% 70%,
      rgba(0, 255, 153, 0.03) 0%,
      transparent 50%
    ),
    radial-gradient(
      circle at 70% 30%,
      rgba(0, 204, 255, 0.03) 0%,
      transparent 50%
    ),
    radial-gradient(
      circle at 80% 80%,
      rgba(255, 255, 255, 0.02) 0%,
      transparent 50%
    );
    animation: footerFloat 20s ease-in-out infinite;
    z-index: -1;
  }
  @keyframes footerFloat {
    0%, 100% { transform: translateX(0px) translateY(0px) rotate(0deg); }
    33% { transform: translateX(-20px) translateY(-10px) rotate(120deg); }
    66% { transform: translateX(15px) translateY(-20px) rotate(240deg); }
  }
  .footer-bg-text {
    position: absolute;
    top: 25%;
    left: 50%;
    transform: translateX(-50%);
    font-size: 5rem;
    font-weight: 800;
    color: #ffffff;
    opacity: 0.1;
    pointer-events: none;
    user-select: none;
    white-space: nowrap;
  }
  .footer-content {
    position: relative;
    z-index: 10;
    text-align: center;
  }
  .footer-brand {
    font-size: 2.5rem;
    font-weight: bold;
    letter-spacing: 4px;
    margin-bottom: 1rem;
    color: #000000;
    transition: all 0.3s ease;
    cursor: pointer;
  }
  .footer-tagline {
    font-size: 1.1rem;
    color: #8b8e91;
    font-weight: 400;
    margin-bottom: 2rem;
  }
  .footer-links {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 1.5rem;
    margin-bottom: 2rem;
  }
  .footer-link {
    position: relative;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 255, 255, 0.08);
    backdrop-filter: blur(15px);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 50%;
    color: #000000; 
    text-decoration: none;
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    overflow: hidden;
  }
  .footer-link:hover {
    color: #000000;
    background: #ffffff;
    transform: translateY(-8px) scale(1.1);
    box-shadow:
      0 10px 25px rgba(0, 0, 0, 0.1),
      0 0 0 8px rgba(255, 255, 255, 0.1);
    border-color: rgba(0, 0, 0, 0.2);
  }
  .footer-bottom {
    background: rgba(0, 0, 0, 0.05);
    backdrop-filter: blur(20px);
    border-top: 1px solid rgba(255, 255, 255, 0.05);
    border-radius: 15px 15px 0 0;
    padding: 1.5rem 0 1rem;
    margin-top: 2rem;
    position: relative;
    color: #8b8e91;
  }
  .footer-copyright {
    font-size: 0.95rem;
    margin-bottom: 0.5rem;
  }
  .footer-contact {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 0.5rem;
    flex-wrap: wrap;
  }
  .email, .developer {
    font-weight: 500;
  }
  /* Floating Particles */
  .particle {
    position: absolute;
    width: 4px;
    height: 4px;
    background: rgba(0, 255, 153, 0.6);
    border-radius: 50%;
    animation: particleFloat 8s linear infinite;
  }
  .particle:nth-child(1) { left: 10%; animation-delay: 0s; }
  .particle:nth-child(2) { left: 30%; animation-delay: -2s; }
  .particle:nth-child(3) { left: 50%; animation-delay: -4s; }
  .particle:nth-child(4) { left: 70%; animation-delay: -6s; }
  .particle:nth-child(5) { left: 90%; animation-delay: -8s; }
  @keyframes particleFloat {
    0% { transform: translateY(0px) scale(1); opacity: 0; }
    10%, 90% { opacity: 1; }
    100% { transform: translateY(-100px) scale(0); opacity: 0; }
  }
  @media (max-width: 768px) {
    .footer-brand { font-size: 2rem; letter-spacing: 2px; }
    .footer-bg-text { font-size: 3rem; }
    .footer-links { gap: 1rem; }
    .footer-link { width: 45px; height: 45px; }
    .footer-contact {
      flex-direction: column;
      gap: 0.3rem;
    }
    .footer-contact span:not(.email):not(.developer) {
      display: none;
    }
  }
  @media (prefers-reduced-motion: reduce) {
    .professional-footer::before,
    .particle,
    .footer-link {
      animation: none;
    }
  }
</style>
</head>
<body>

<div class="content-spacer">
  <div class="demo-content">
    <h2>A propos</h2>
    <p>Cette plateforme a été mise en place dans le but de faciliter vos besoins.</p>
    <p>Nous espérons que vous trouverez ce dont il vous faut à portée de main.</p>
  </div>
</div>

<footer class="professional-footer text-light">
  
  <div class="particle"></div>
  <div class="particle"></div>
  <div class="particle"></div>
  <div class="particle"></div>
  <div class="particle"></div>
  <div class="container">
    <div class="footer-content text-center">
      <!-- Brand Section -->
      <div class="footer-brand" tabindex="0">FONEA</div>
      <p class="footer-tagline">Gestion professionnelle des acquisitions</p>
      <!-- Social Links -->
      <div class="footer-links">
        <a href="https://www.instagram.com/fonea_officiel" 
           target="_blank" 
           class="footer-link instagram" 
           aria-label="Suivez-nous sur Instagram"
           rel="noopener noreferrer">
          <i class="fab fa-instagram" aria-hidden="true"></i>
        </a>
        <a href="https://www.facebook.com/fonea.officiel" 
           target="_blank" 
           class="footer-link facebook" 
           aria-label="Suivez-nous sur Facebook"
           rel="noopener noreferrer">
          <i class="fab fa-facebook" aria-hidden="true"></i>
        </a>
        <a href="https://www.google.com" 
           target="_blank" 
           class="footer-link google" 
           aria-label="Trouvez-nous sur Google"
           rel="noopener noreferrer">
          <i class="fab fa-google" aria-hidden="true"></i>
        </a>
        <a href="https://www.twitter.com/fonea_officiel" 
           target="_blank" 
           class="footer-link twitter" 
           aria-label="Suivez-nous sur X (Twitter)"
           rel="noopener noreferrer">
          <i class="fab fa-x-twitter" aria-hidden="true"></i>
        </a>
      </div>
    </div>
    <!-- Footer Bottom -->
    <div class="footer-bottom text-center">
      <div class="footer-copyright">
        &copy; <span id="currentYear">2025</span> <strong>FONEA</strong>. Tous droits réservés.
      </div>
      <div class="footer-contact">
        <div>
          <i class="fas fa-envelope" aria-hidden="true"></i>
          <span class="email">gloryloudmith@gmail.com</span>
        </div>
        <span>•</span>
        <div>
          Développé par <span class="developer">Glory LOUSSI</span>
        </div>
      </div>
    </div>
  </div>
</footer>
<script>
  
  document.getElementById('currentYear').textContent = new Date().getFullYear();
  
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });
</script>
</body>
</html>