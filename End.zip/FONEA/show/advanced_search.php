<?php
require_once __DIR__ . '/../Config/session.php';
require_login();
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../include/besoin.php';
require_once __DIR__ . '/../public/user.php';
$user_role = $_SESSION['user']['role'] ?? '';
$user_id = $_SESSION['user']['id'] ?? 0;
// Handle search parameters
$search_params = [
    'keyword' => $_GET['keyword'] ?? '',
    'status' => $_GET['status'] ?? '',
    'date_from' => $_GET['date_from'] ?? '',
    'date_to' => $_GET['date_to'] ?? '',
    'agent' => $_GET['agent'] ?? '',
    'category' => $_GET['category'] ?? '',
    'priority' => $_GET['priority'] ?? '',
    'sort_by' => $_GET['sort_by'] ?? 'date_soumission',
    'sort_order' => $_GET['sort_order'] ?? 'DESC',
    'page' => (int)($_GET['page'] ?? 1)
];
$per_page = 20;
$offset = ($search_params['page'] - 1) * $per_page;
$pdo = Database::getInstance()->getConnection();
// Build search query
$where_conditions = [];
$params = [];
if (!empty($search_params['keyword'])) {
    $where_conditions[] = "(b.designation_materiel LIKE ? OR b.justification LIKE ?)";
    $keyword = '%' . $search_params['keyword'] . '%';
    $params[] = $keyword;
    $params[] = $keyword;
}
if (!empty($search_params['status'])) {
    $where_conditions[] = "b.statut = ?";
    $params[] = $search_params['status'];
}
if (!empty($search_params['date_from'])) {
    $where_conditions[] = "DATE(b.date_soumission) >= ?";
    $params[] = $search_params['date_from'];
}
if (!empty($search_params['date_to'])) {
    $where_conditions[] = "DATE(b.date_soumission) <= ?";
    $params[] = $search_params['date_to'];
}
if (!empty($search_params['agent'])) {
    $where_conditions[] = "b.id_agent = ?";
    $params[] = $search_params['agent'];
}
$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
// Get total count for pagination
$count_sql = "
    SELECT COUNT(*) 
    FROM etat_de_besoin b
    JOIN agents a ON b.id_agent = a.id_agent
    $where_clause
";
$count_stmt = $pdo->prepare($count_sql);
$count_stmt->execute($params);
$total_records = $count_stmt->fetchColumn();
$total_pages = ceil($total_records / $per_page);
// Get search results
$search_sql = "
    SELECT 
        b.id_besoin,
        b.designation_materiel,
        b.justification,
        b.statut,
        b.date_soumission,
        b.date_limite,
        b.fichier_joint,
        CONCAT(a.prenom, ' ', a.nom) as agent_name,
        a.email as agent_email,
        a.role as agent_role
    FROM etat_de_besoin b
    JOIN agents a ON b.id_agent = a.id_agent
    $where_clause
    ORDER BY b.{$search_params['sort_by']} {$search_params['sort_order']}
    LIMIT ? OFFSET ?
";
$params[] = $per_page;
$params[] = $offset;
$search_stmt = $pdo->prepare($search_sql);
$search_stmt->execute($params);
$results = $search_stmt->fetchAll(PDO::FETCH_ASSOC);
// Get filter options
$agents = $pdo->query("SELECT id_agent, CONCAT(prenom, ' ', nom) as name FROM agents ORDER BY nom")->fetchAll(PDO::FETCH_ASSOC);
$statuses = [
    'en_attente' => 'En attente',
    'validee_chef' => 'Validée par chef',
    'refusee_chef' => 'Refusée par chef',
    'validee_directeur' => 'Approuvée',
    'refusee_directeur' => 'Rejetée'
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recherche Avancée - FONEA</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="../Design/assets/style.css" rel="stylesheet">
    <style>
        .search-container {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        }
        .filter-section {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        .search-input {
            border-radius: 25px;
            border: 2px solid #e9ecef;
            padding: 12px 20px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        .search-input:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        .search-btn {
            border-radius: 25px;
            padding: 12px 30px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
            transition: all 0.3s ease;
        }
        .search-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
        }
        .result-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            border-left: 4px solid;
            transition: all 0.3s ease;
        }
        .result-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        .status-en_attente { border-left-color: #fbbf24; }
        .status-validee_chef { border-left-color: #60a5fa; }
        .status-refusee_chef { border-left-color: #f87171; }
        .status-validee_directeur { border-left-color: #10b981; }
        .status-refusee_directeur { border-left-color: #ef4444; }
        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 25px;
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .status-en_attente-badge { background: #fef3c7; color: #92400e; }
        .status-validee_chef-badge { background: #dbeafe; color: #1e40af; }
        .status-refusee_chef-badge { background: #fee2e2; color: #dc2626; }
        .status-validee_directeur-badge { background: #d1fae5; color: #065f46; }
        .status-refusee_directeur-badge { background: #fee2e2; color: #dc2626; }
        .pagination-modern .page-link {
            border: none;
            border-radius: 10px;
            margin: 0 2px;
            padding: 10px 15px;
            color: #667eea;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .pagination-modern .page-link:hover {
            background: #667eea;
            color: white;
            transform: translateY(-2px);
        }
        .pagination-modern .page-item.active .page-link {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .sort-controls {
            background: white;
            border-radius: 15px;
            padding: 1rem;
            margin-bottom: 1rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        .export-btn {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            border: none;
            border-radius: 10px;
            padding: 10px 20px;
            color: white;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .export-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.3);
        }
        .quick-filters {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 1rem;
        }
        .quick-filter-btn {
            background: white;
            border: 2px solid #e9ecef;
            border-radius: 25px;
            padding: 8px 16px;
            font-size: 0.9rem;
            font-weight: 600;
            color: #6c757d;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        .quick-filter-btn:hover,
        .quick-filter-btn.active {
            background: #667eea;
            border-color: #667eea;
            color: white;
        }
        @media (max-width: 768px) {
            .search-container {
                padding: 1.5rem;
            }
            .filter-section {
                padding: 1rem;
            }
            .quick-filters {
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
        <div class="container">
            <a class="navbar-brand fw-bold" href="../Show/enhanced_dashboard.php">
                <i class="fas fa-building me-2"></i>FONEA
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../Show/enhanced_dashboard.php"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#"><i class="fas fa-search me-2"></i>Recherche</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../Show/Content.php"><i class="fas fa-list me-2"></i>Demandes</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../Public/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Déconnexion</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-4">
        <!-- Page Header -->
        <div class="row mb-4">
            <div class="col">
                <h1 class="display-6 fw-bold">
                    <i class="fas fa-search text-primary me-3"></i>
                    Recherche Avancée
                </h1>
                <p class="lead text-muted">Trouvez rapidement les demandes avec des filtres avancés</p>
            </div>
        </div>
        <!-- Search Form -->
        <div class="search-container">
            <form method="GET" action="" id="searchForm">
                <div class="row">
                    <div class="col-md-8">
                        <div class="input-group">
                            <input type="text" 
                                   name="keyword" 
                                   class="form-control search-input" 
                                   placeholder="Rechercher par désignation ou justification..."
                                   value="<?= htmlspecialchars($search_params['keyword']) ?>">
                            <button type="submit" class="btn search-btn">
                                <i class="fas fa-search me-2"></i>Rechercher
                            </button>
                        </div>
                    </div>
                    <div class="col-md-4 text-end">
                        <button type="button" class="btn export-btn" onclick="exportResults()">
                            <i class="fas fa-download me-2"></i>Exporter
                        </button>
                    </div>
                </div>
                <!-- Quick Filters -->
                <div class="quick-filters mt-3">
                    <a href="?status=" class="quick-filter-btn <?= empty($search_params['status']) ? 'active' : '' ?>">
                        Tous
                    </a>
                    <a href="?status=en_attente" class="quick-filter-btn <?= $search_params['status'] === 'en_attente' ? 'active' : '' ?>">
                        En attente
                    </a>
                    <a href="?status=validee_directeur" class="quick-filter-btn <?= $search_params['status'] === 'validee_directeur' ? 'active' : '' ?>">
                        Approuvées
                    </a>
                    <a href="?status=refusee_directeur" class="quick-filter-btn <?= $search_params['status'] === 'refusee_directeur' ? 'active' : '' ?>">
                        Rejetées
                    </a>
                </div>
                <!-- Advanced Filters -->
                <div class="filter-section mt-3">
                    <h6 class="fw-bold mb-3">
                        <i class="fas fa-filter me-2"></i>Filtres Avancés
                    </h6>
                    <div class="row">
                        <div class="col-md-3">
                            <label class="form-label">Statut</label>
                            <select name="status" class="form-select">
                                <option value="">Tous les statuts</option>
                                <?php foreach($statuses as $value => $label): ?>
                                    <option value="<?= $value ?>" <?= $search_params['status'] === $value ? 'selected' : '' ?>>
                                        <?= $label ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Agent</label>
                            <select name="agent" class="form-select">
                                <option value="">Tous les agents</option>
                                <?php foreach($agents as $agent): ?>
                                    <option value="<?= $agent['id_agent'] ?>" <?= $search_params['agent'] == $agent['id_agent'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($agent['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Date de début</label>
                            <input type="date" name="date_from" class="form-control" value="<?= $search_params['date_from'] ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Date de fin</label>
                            <input type="date" name="date_to" class="form-control" value="<?= $search_params['date_to'] ?>">
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <label class="form-label">Trier par</label>
                            <select name="sort_by" class="form-select">
                                <option value="date_soumission" <?= $search_params['sort_by'] === 'date_soumission' ? 'selected' : '' ?>>Date de soumission</option>
                                <option value="designation_materiel" <?= $search_params['sort_by'] === 'designation_materiel' ? 'selected' : '' ?>>Désignation</option>
                                <option value="statut" <?= $search_params['sort_by'] === 'statut' ? 'selected' : '' ?>>Statut</option>
                                <option value="date_limite" <?= $search_params['sort_by'] === 'date_limite' ? 'selected' : '' ?>>Date limite</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Ordre</label>
                            <select name="sort_order" class="form-select">
                                <option value="DESC" <?= $search_params['sort_order'] === 'DESC' ? 'selected' : '' ?>>Décroissant</option>
                                <option value="ASC" <?= $search_params['sort_order'] === 'ASC' ? 'selected' : '' ?>>Croissant</option>
                            </select>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <!-- Results -->
        <div class="sort-controls">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <strong><?= $total_records ?></strong> résultat(s) trouvé(s)
                    <?php if(!empty($search_params['keyword'])): ?>
                        pour "<em><?= htmlspecialchars($search_params['keyword']) ?></em>"
                    <?php endif; ?>
                </div>
                <div>
                    Page <?= $search_params['page'] ?> sur <?= $total_pages ?>
                </div>
            </div>
        </div>
        <!-- Results List -->
        <div class="results-container">
            <?php if(empty($results)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-search text-muted" style="font-size: 4rem;"></i>
                    <h4 class="mt-3 text-muted">Aucun résultat trouvé</h4>
                    <p class="text-muted">Essayez de modifier vos critères de recherche</p>
                </div>
            <?php else: ?>
                <?php foreach($results as $result): ?>
                    <div class="result-card status-<?= $result['statut'] ?>">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h5 class="fw-bold mb-2">
                                    <?= htmlspecialchars($result['designation_materiel']) ?>
                                </h5>
                                <p class="text-muted mb-2">
                                    <?= htmlspecialchars(substr($result['justification'], 0, 150)) ?>
                                    <?= strlen($result['justification']) > 150 ? '...' : '' ?>
                                </p>
                                <div class="d-flex align-items-center gap-3">
                                    <small class="text-muted">
                                        <i class="fas fa-user me-1"></i>
                                        <?= htmlspecialchars($result['agent_name']) ?>
                                    </small>
                                    <small class="text-muted">
                                        <i class="fas fa-calendar me-1"></i>
                                        <?= date('d/m/Y H:i', strtotime($result['date_soumission'])) ?>
                                    </small>
                                    <?php if($result['fichier_joint']): ?>
                                        <small class="text-muted">
                                            <i class="fas fa-paperclip me-1"></i>
                                            Fichier joint
                                        </small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-4 text-end">
                                <span class="status-badge status-<?= $result['statut'] ?>-badge">
                                    <?= $statuses[$result['statut']] ?? $result['statut'] ?>
                                </span>
                                <div class="mt-2">
                                    <a href="../Show/Content.php?id=<?= $result['id_besoin'] ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye me-1"></i>Voir détails
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <!-- Pagination -->
        <?php if($total_pages > 1): ?>
            <nav aria-label="Navigation des résultats">
                <ul class="pagination pagination-modern justify-content-center">
                    <?php if($search_params['page'] > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?<?= http_build_query(array_merge($search_params, ['page' => $search_params['page'] - 1])) ?>">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php for($i = max(1, $search_params['page'] - 2); $i <= min($total_pages, $search_params['page'] + 2); $i++): ?>
                        <li class="page-item <?= $i === $search_params['page'] ? 'active' : '' ?>">
                            <a class="page-link" href="?<?= http_build_query(array_merge($search_params, ['page' => $i])) ?>">
                                <?= $i ?>
                            </a>
                        </li>
                    <?php endfor; ?>
                    <?php if($search_params['page'] < $total_pages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?<?= http_build_query(array_merge($search_params, ['page' => $search_params['page'] + 1])) ?>">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        <?php endif; ?>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-submit form when filters change
        document.querySelectorAll('select[name="status"], select[name="agent"], input[name="date_from"], input[name="date_to"], select[name="sort_by"], select[name="sort_order"]').forEach(element => {
            element.addEventListener('change', function() {
                document.getElementById('searchForm').submit();
            });
        });
        // Export functionality
        function exportResults() {
            const params = new URLSearchParams(window.location.search);
            params.set('export', 'csv');
            window.location.href = 'export_results.php?' + params.toString();
        }
        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && e.key === 'f') {
                e.preventDefault();
                document.querySelector('input[name="keyword"]').focus();
            }
        });
        // Real-time search suggestions (placeholder for future implementation)
        let searchTimeout;
        document.querySelector('input[name="keyword"]').addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                // Implement search suggestions here
            }, 300);
        });
    </script>
</body>
</html>
