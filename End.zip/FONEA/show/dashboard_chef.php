<?php
require_once '../Config/session.php';
require_once __DIR__ . '/../public/userClass.php';
require_once '../include/besoin.php';
require_once __DIR__ . '/../public/notifications.php';
require_once '../Config/db.php';
require_once __DIR__ . '/../Config/titles.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'chef_service') {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit();
}

$user = User::getById($_SESSION['user_id']);
$user_name = $user ? $user['nom_complet'] : 'Chef de Service';

$total_team_requests = Besoin::countByStatut('EN_ATTENTE');
$approved_by_chef = Besoin::countByStatut('APPROUVE');
$notif_stats = Notification::getStats($_SESSION['user_id']);
$total_notifications = $notif_stats['unread'];

$currentPage = basename(__FILE__);
$pageTitle = $pageTitles[$currentPage] ?? 'Dashboard - FONEA';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="../assets/css/dashboard-common.css" rel="stylesheet">
    <style>
        
        .dashboard-chef .sidebar {
            background: linear-gradient(180deg, #065f46 0%, #064e3b 100%);
        }
        
        .dashboard-chef .btn-accueil {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 90%;
            margin: 30px auto 20px auto;
            padding: 14px 0;
            border-radius: 30px;
            font-size: 1.1rem;
            font-weight: bold;
            background: linear-gradient(135deg, #065f46, #10b981);
            color: #fff !important;
            box-shadow: 0 4px 16px rgba(16,185,129,0.15);
            border: none;
            transition: background 0.3s, transform 0.2s;
            text-decoration: none !important;
        }
        .btn-accueil i {
            margin-right: 10px;
            font-size: 1.2em;
        }
        .btn-accueil:hover {
            background: linear-gradient(135deg, #064e3b, #065f46);
            color: #fff !important;
            transform: translateY(-2px) scale(1.03);
            text-decoration: none !important;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #ffffff;
            color: #1a1a1a;
            overflow-x: hidden;
        }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 240px;
            height: 100vh;
            background: linear-gradient(180deg, #10b981 0%, #059669 100%);
            z-index: 1000;
            transition: all 0.3s ease;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
        }
        .sidebar-header {
            padding: 30px 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .sidebar-logo {
            color: #ffffff;
            font-size: 24px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .sidebar-logo i {
            color: #ffffff;
            font-size: 28px;
        }
        .sidebar-nav {
            padding: 20px 0;
            padding-bottom: 180px;
        }
        .nav-item {
            margin: 8px 20px;
        }
        .nav-link {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
            gap: 15px;
        }
        .nav-link:hover {
            background: rgba(255, 255, 255, 0.1);
            color: #ffffff;
            transform: translateX(5px);
            text-decoration: none;
        }
        .nav-link.active {
            background: rgba(255, 255, 255, 0.2);
            color: #ffffff;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
        }
        .nav-link i {
            font-size: 18px;
            width: 20px;
        }
        /* Main Content */
        .main-content {
            margin-left: 240px;
            min-height: 100vh;
            background: #ffffff;
        }
        /* Top Header */
        .top-header {
            background: #ffffff;
            padding: 20px 40px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        .search-bar {
            flex: 1;
            max-width: 400px;
            margin: 0 30px;
            position: relative;
        }
        .search-input {
            width: 100%;
            padding: 12px 20px 12px 45px;
            border: 2px solid #e2e8f0;
            border-radius: 25px;
            background: #f8fafc;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        .search-input:focus {
            outline: none;
            border-color: #10b981;
            background: #ffffff;
            box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.1);
        }
        .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
        }
        .header-actions {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .notification-btn {
            position: relative;
            background: #f8fafc;
            border: none;
            width: 45px;
            height: 45px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .notification-btn:hover {
            background: #10b981;
            color: #ffffff;
            transform: translateY(-2px);
        }
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #ef4444;
            color: #ffffff;
            font-size: 11px;
            padding: 2px 6px;
            border-radius: 10px;
            font-weight: 600;
        }
        .profile-section {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 16px;
            background: #f8fafc;
            border-radius: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            color: inherit;
        }
        .profile-section:hover {
            background: #e2e8f0;
            text-decoration: none;
            color: inherit;
        }
        .profile-avatar {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            background: linear-gradient(135deg, #10b981, #059669);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            font-weight: 600;
            font-size: 16px;
        }
        .profile-info h6 {
            margin: 0;
            font-size: 14px;
            font-weight: 600;
            color: #1e293b;
        }
        .profile-info p {
            margin: 0;
            font-size: 12px;
            color: #64748b;
        }
        /* Welcome Section */
        .welcome-section {
            padding: 40px;
            background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
        }
        .welcome-title {
            font-size: 32px;
            font-weight: 700;
            color: #065f46;
            margin-bottom: 8px;
        }
        .welcome-subtitle {
            font-size: 16px;
            color: #047857;
            margin-bottom: 0;
        }
        /* Dashboard Cards */
        .dashboard-section {
            padding: 40px;
        }
        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        .chef-dashboard-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 25px;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            border: 1px solid #e2e8f0;
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-decoration: none !important;
            color: inherit;
        }
        .chef-dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(16, 185, 129, 0.2);
        }
        .card-icon {
            width: 60px;
            height: 60px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: #ffffff;
            margin-bottom: 20px;
        }
        .card-title {
            font-size: 20px;
            font-weight: 600;
            color: #065f46;
            margin-bottom: 8px;
        }
        .card-description {
            font-size: 14px;
            color: #047857;
            margin-bottom: 15px;
            line-height: 1.5;
        }
        .card-metric {
            font-size: 28px;
            font-weight: 700;
            color: #065f46;
        }
        /* Card Colors - Green/Teal Theme */
        .card-requests .card-icon { background: linear-gradient(135deg, #10b981, #059669); }
        .card-team .card-icon { background: linear-gradient(135deg, #14b8a6, #0d9488); }
        .card-reports .card-icon { background: linear-gradient(135deg, #06b6d4, #0891b2); }
        .card-workflow .card-icon { background: linear-gradient(135deg, #22c55e, #16a34a); }
        .card-validation .card-icon { background: linear-gradient(135deg, #84cc16, #65a30d); }
        .card-notifications .card-icon { background: linear-gradient(135deg, #f59e0b, #d97706); }
        /* Side Panels */
        .side-panels {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
            margin-top: 30px;
        }
        .dashboard-card,
        .chef-side-panel {
            background: #ffffff;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            border: 1px solid #e2e8f0;
        }
        .panel-title {
            font-size: 18px;
            font-weight: 600;
            color: #065f46;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .team-member {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 0;
            border-bottom: 1px solid #f1f5f9;
        }
        .team-member:last-child {
            border-bottom: none;
        }
        .member-avatar {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: linear-gradient(135deg, #10b981, #059669);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            font-weight: 600;
            font-size: 14px;
        }
        .member-info h6 {
            margin: 0;
            font-size: 14px;
            font-weight: 500;
            color: #065f46;
        }
        .member-info p {
            margin: 0;
            font-size: 12px;
            color: #047857;
        }
        #serviceStatsChart {
             width: 100% !important;
             height: 220px !important;
             display: block !important;
             margin: 0 auto !important;
        }
        .logout-btn {
            position: fixed;
            bottom: 30px;
            left: 20px;
            width: 200px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #ffffff;
            padding: 12px 20px;
            border-radius: 12px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
        }
        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            color: #ffffff;
            text-decoration: none;
        }
        .chart-container {
            position: relative;
            height: 220px;
            width: 100%;
        }
        a, a:hover, a:focus, a:active {
            text-decoration: none !important;
            outline: none;
        }
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .main-content {
                margin-left: 0;
            }
            .top-header {
                padding: 15px 20px;
            }
            .dashboard-section {
                padding: 20px;
            }
            .cards-grid {
                grid-template-columns: 1fr;
            }
            .side-panels {
                grid-template-columns: 1fr;
            }
        }
        .btn-action {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            margin: 3px;
            min-width: 90px;
            justify-content: center;
        }
        .actions-cell {
            text-align: center;
            white-space: nowrap;
        }
        .actions-cell .btn-action {
                margin: 0 4px 4px 0;
        }
    </style>
</head>
<body class="dashboard-chef">.
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-users-cog"></i>
                FONEA Chef
            </div>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-item">
                <a href="#" class="nav-link active">
                    <i class="fas fa-chart-pie"></i>
                    Dashboard
                </a>
            </div>
            <div class="nav-item">
                <a href="content.php#requests" class="nav-link">
                    <i class="fas fa-file-alt"></i>
                    Demandes Équipe
                </a>
            </div>
            <div class="nav-item">
                <a href="content.php#team" class="nav-link">
                    <i class="fas fa-users"></i>
                    Gestion Équipe
                </a>
            </div>
            <div class="nav-item">
                <a href="../modules/pre_validation.php" class="nav-link">
                    <i class="fas fa-check-circle"></i>
                    Validation
                </a>
            </div>
            <div class="nav-item">
                <a href="export_reports.php" class="nav-link">
                    <i class="fas fa-chart-bar"></i>
                    Rapports Service
                </a>
            </div>
            <div class="nav-item">
                <a href="document_management.php" class="nav-link">
                    <i class="fas fa-boxes"></i>
                    Inventaire
                </a>
            </div>
            <div class="nav-item">
                <a href="notifications.php" class="nav-link">
                    <i class="fas fa-bell"></i>
                    Notifications
                </a>
            </div>
            <div class="nav-item">
                <a href="settings.php" class="nav-link">
                    <i class="fas fa-cog"></i>
                    Paramètres
                </a>
            </div>
        </nav>
        <a href="../layout/header.php" class="btn-accueil"><i class="fas fa-home"></i>Accueil</a>
    </div>
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <div class="search-bar position-relative">
                <i class="fas fa-search search-icon"></i>
                <input type="text" class="search-input" placeholder="Rechercher...">
            </div>
            <div class="header-actions">
                <button class="notification-btn">
                    <i class="fas fa-bell"></i>
                    <?php if ($total_notifications > 0): ?>
                        <span class="notification-badge"><?= $total_notifications ?></span>
                    <?php endif; ?>
                </button>
                <div class="profile-section">
                    <div class="profile-avatar">
                        <?= strtoupper(substr($user_name, 0, 2)) ?>
                    </div>
                    <div class="profile-info">
                        <h6><?= htmlspecialchars($user_name) ?></h6>
                        <p>Chef de Service</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Welcome Section -->
        <div class="welcome-section">
            <h1 class="welcome-title">Bienvenue Chef de Service, <?= htmlspecialchars($user_name) ?></h1>
            <p class="welcome-subtitle">Tableau de bord de gestion d'équipe - Supervision des demandes et validation</p>
        </div>
        <!-- Dashboard Section -->
        <div class="dashboard-section">
            <div class="cards-grid">
                <a href="content.php#requests" class="chef-dashboard-card card-requests">
                    <div class="card-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <h3 class="card-title">Demandes Équipe</h3>
                    <p class="card-description">Demandes en attente de pré-validation par votre équipe</p>
                    <div class="card-metric"><?= $total_team_requests ?></div>
                </a>
                <a href="content.php#team" class="chef-dashboard-card card-team">
                    <div class="card-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3 class="card-title">Gestion Équipe</h3>
                    <p class="card-description">Supervision et coordination des membres de votre service</p>
                    <div class="card-metric">Actif</div>
                </a>
                <a href="../modules/pre_validation.php" class="chef-dashboard-card card-validation">
                    <div class="card-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <h3 class="card-title">Validation</h3>
                    <p class="card-description">Processus de validation et approbation des demandes</p>
                    <div class="card-metric"><?= $approved_by_chef ?></div>
                </a>
                <a href="export_reports.php" class="chef-dashboard-card card-reports">
                    <div class="card-icon">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <h3 class="card-title">Rapports Service</h3>
                    <p class="card-description">Statistiques et performance de votre service</p>
                    <div class="card-metric">Suivi</div>
                </a>
                <a href="content.php" class="chef-dashboard-card card-workflow">
                    <div class="card-icon">
                        <i class="fas fa-project-diagram"></i>
                    </div>
                    <h3 class="card-title">Workflow</h3>
                    <p class="card-description">Flux de travail et processus de votre service</p>
                    <div class="card-metric">Optimisé</div>
                </a>
                <a href="../public/notifications.php" class="chef-dashboard-card card-notifications">
                    <div class="card-icon">
                        <i class="fas fa-bell"></i>
                    </div>
                    <h3 class="card-title">Notifications</h3>
                    <p class="card-description">Alertes et notifications importantes du service</p>
                    <div class="card-metric"><?= $total_notifications ?></div>
                </a>
            </div>
            <!-- Side Panels -->
            <div class="side-panels">
                <div class="dashboard-card">
                    <h4 class="panel-title">
                        <i class="fas fa-users"></i>
                        Équipe Active
                    </h4>
                    <div class="team-member">
                        <div class="member-avatar">
                            <?= strtoupper(substr($user_name, 0, 2)) ?>
                        </div>
                        <div class="member-info">
                            <h6><?= htmlspecialchars($user_name) ?></h6>
                            <p id="agent-status">Agent - Vérification...</p>
                        </div>
                    </div>
                    <div class="team-member">
                        <div class="member-avatar">
                            <?= strtoupper(substr($user_name, 0, 2)) ?>
                        </div>
                        <div class="member-info">
                            <h6><?= htmlspecialchars($user_name) ?></h6>
                            <p>Agent - Vérification...</p>
                        </div>
                    </div>
                    <div class="team-member">
                        <div class="member-avatar">
                            <?= strtoupper(substr($user_name, 0, 2)) ?>
                        </div>
                        <div class="member-info">
                            <h6><?= htmlspecialchars($user_name) ?></h6>
                            <p>Agent - Vérification...</p>
                        </div>
                    </div>
                </div>
                <div class="chef-side-panel">
                    <h4 class="panel-title">
                        <i class="fas fa-chart-line"></i>
                        <a href="service_performance.php" style="text-decoration:none; color:inherit;">
                            Performance Service
                        </a>
                    </h4>
                    <canvas id="serviceStatsChart"></canvas>
                </div>
            </div>
            <!-- Pending Team Requests (en_attente) for Chef pre-validation -->
            <div class="mt-4">
                <div class="dashboard-card" style="max-width:100%">
                    <h4 class="panel-title"><i class="fas fa-check-circle"></i> Demandes en attente de pré-validation</h4>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Demandeur</th>
                                    <th>Désignation</th>
                                    <th>Statut</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>                               
                                <?php if (empty($pending_list)): ?>
                                    <tr><td colspan="5" class="text-center text-muted">Aucune demande en attente</td></tr>
                                <?php else: foreach ($pending_list as $row): ?>
                                    <tr data-id="<?= (int)$row['id_besoin'] ?>">
                                        <td><?= (int)$row['id_besoin'] ?></td>
                                        <td><?= htmlspecialchars($row['prenom'] . ' ' . $row['nom']) ?></td>
                                        <td><?= htmlspecialchars($row['designation_materiel'] ?? '') ?></td>
                                        <td><span class="status-badge <?= htmlspecialchars($row['statut']) ?>"><?= htmlspecialchars($row['statut']) ?></span></td>
                                        <td class="actions-cell">
                                            <button type="button" class="btn btn-sm btn-success btn-action" 
                                                onclick="window.location.href='../modules/pre_validation.php?id=<?= (int)$row['id_besoin'] ?>'">
                                                <i class="fas fa-check"></i> Favorable
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger btn-action" 
                                                onclick="window.location.href='../modules/reject.php?id=<?= (int)$row['id_besoin'] ?>'">
                                                <i class="fas fa-times"></i> Défavorable
                                            </button>
                                            <span class="status-badge status-<?= strtolower(htmlspecialchars($row['statut'])) ?>">
                                                <?= htmlspecialchars($row['statut']) ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Service Stats Chart
        const ctx = document.getElementById('serviceStatsChart').getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Validées', 'En attente', 'Rejetées'],
                datasets: [{
                    data: [65, 25, 10],
                    backgroundColor: ['#10b981', '#f59e0b', '#ef4444'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                }
            }
        });
        // Add click handlers to notification button
        document.querySelector('.notification-btn').addEventListener('click', function() {
            window.location.href = 'notifications.php';
        });
        function fetchAgentStatus() {
                fetch('agent_status.php')
                .then(res => res.json())
                .then(data => {
                  const statusEl = document.getElementById('agent-status');
                  if (data.online) {
                    statusEl.textContent = 'Agent - En ligne';
                    statusEl.style.color = 'green';
                  } else {
                    statusEl.textContent = 'Agent - Absent';
                    statusEl.style.color = 'red';
                  }
                })
                .catch(() => {
                  const statusEl = document.getElementById('agent-status');
                  statusEl.textContent = 'Agent - Statut inconnu';
                  statusEl.style.color = 'gray';
                });
}
// Check every 10 seconds
setInterval(fetchAgentStatus, 10000);
fetchAgentStatus();
// Chef Action AJAX handling
document.querySelectorAll('.chef-action-form').forEach(form => {
  form.addEventListener('submit', async function (e) {
    e.preventDefault();
    const row = this.closest('tr');
    const fd = new FormData(this);
    try {
      const res = await fetch('../public/api_chef_action.php', { method: 'POST', body: fd, headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      const data = await res.json();
      if (!res.ok || !data || data.error) throw new Error(data?.error || 'Erreur');
      const statusEl = row.querySelector('.status-badge');
      if (statusEl) {
        statusEl.textContent = data.new_status;
        statusEl.className = 'status-badge ' + data.new_status;
        }
      row.querySelectorAll('.chef-action-form').forEach(f => f.remove());
    } catch (err) {
      alert('Action impossible: ' + err.message);
    }
  });
});
    </script>
</body>
</html>