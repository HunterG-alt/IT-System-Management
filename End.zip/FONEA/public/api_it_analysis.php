<?php
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Config/db.php';
header('Content-Type: application/json');
if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['error' => 'Non authentifié']);
    exit;
}
if (($_SESSION['role'] ?? '') !== 'informatique') {
    http_response_code(403);
    echo json_encode(['error' => 'Accès refusé']);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Méthode non autorisée']);
    exit;
}
if (!CSRFProtection::verifyTokenFor('it_analysis_action', $_POST['csrf_token_it_analysis_action'] ?? null)) {
    http_response_code(403);
    echo json_encode(['error' => 'Token CSRF invalide']);
    exit;
}
$id_besoin = (int)($_POST['id_besoin'] ?? 0);
$note = trim($_POST['note'] ?? '');
$action = $_POST['action'] ?? 'save'; // save or finalize
if ($id_besoin <= 0 || $note === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Paramètres invalides']);
    exit;
}
try {
    $pdo = Database::getInstance()->getConnection();
    $pdo->beginTransaction();
    // Insert or update analysis
    $stmt = $pdo->prepare("INSERT INTO analyses_techniques (id_besoin, id_it, note, date_maj)
                           VALUES (?, ?, ?, NOW())
                           ON DUPLICATE KEY UPDATE note = VALUES(note), date_maj = VALUES(date_maj)");
    $stmt->execute([$id_besoin, (int)$_SESSION['user_id'], $note]);
    $newStatus = null;
    if ($action === 'finalize') {
        // Only move to en_analyse_technique if currently approved by director or permission granted
        $get = $pdo->prepare('SELECT statut FROM etat_de_besoin WHERE id_besoin = ?');
        $get->execute([$id_besoin]);
        $current = $get->fetchColumn();
        if (!$current) throw new Exception('Demande introuvable');
        if (in_array($current, ['validee_directeur','permission_dg_accordee'])) {
            $newStatus = 'en_analyse_technique';
            $up = $pdo->prepare("UPDATE etat_de_besoin SET statut = ?, date_maj = NOW() WHERE id_besoin = ?");
            $up->execute([$newStatus, $id_besoin]);
        }
    }
    $pdo->commit();
    echo json_encode(['success' => true, 'new_status' => $newStatus]);
} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Erreur serveur']);
}
?>
