<?php
require_once __DIR__ . '/../Config/db.php';

class WorkflowManager {
    private $pdo;
    public function __construct() {
        $this->pdo = Database::getInstance()->getConnection();
    }
    
    public function preValidateByChef($besoin_id, $chef_id, $action, $commentaire = '') {
        try {
            $this->pdo->beginTransaction();
            $new_status = $action === 'approve' ? 'pre_validee' : 'refusee_chef';
            $stmt = $this->pdo->prepare("
                UPDATE etat_de_besoin 
                SET statut = :statut, 
                    id_chef_validation = :chef_id,
                    date_pre_validation = NOW(),
                    commentaire_chef = :commentaire,
                    date_maj = NOW()
                WHERE id_besoin = :besoin_id AND statut = 'en_attente'
            ");
            $stmt->execute([
                ':statut' => $new_status,
                ':chef_id' => $chef_id,
                ':commentaire' => $commentaire,
                ':besoin_id' => $besoin_id
            ]);
            if ($action === 'approve') {
                // Send notification to Directeur
                $this->notifyDirecteur($besoin_id);
            } else {
                // Send notification to demandeur about rejection
                $this->notifyDemandeurRejection($besoin_id, $commentaire);
            }
            $this->pdo->commit();
            return true;
        } catch (Exception $e) {
            $this->pdo->rollBack();
            error_log("Erreur pré-validation chef: " . $e->getMessage());
            return false;
        }
    }
    
    public function validateByDirecteur($besoin_id, $directeur_id, $action, $commentaire = '') {
        try {
            $this->pdo->beginTransaction();
            $new_status = $action === 'approve' ? 'validee_directeur' : 'refusee_directeur';
            $stmt = $this->pdo->prepare("
                UPDATE etat_de_besoin 
                SET statut = :statut, 
                    id_directeur_validation = :directeur_id,
                    date_validation_directeur = NOW(),
                    commentaire_directeur = :commentaire,
                    date_maj = NOW()
                WHERE id_besoin = :besoin_id AND statut = 'pre_validee'
            ");
            $stmt->execute([
                ':statut' => $new_status,
                ':directeur_id' => $directeur_id,
                ':commentaire' => $commentaire,
                ':besoin_id' => $besoin_id
            ]);
            if ($action === 'approve') {
                // Update status to wait for DG permission
                $stmt2 = $this->pdo->prepare("
                    UPDATE etat_de_besoin 
                    SET statut = 'en_attente_permission_dg'
                    WHERE id_besoin = :besoin_id
                ");
                $stmt2->execute([':besoin_id' => $besoin_id]);
                // Send notification to DG
                $this->notifyDG($besoin_id);
            } else {
                // Send notification to demandeur about rejection
                $this->notifyDemandeurRejection($besoin_id, $commentaire);
            }
            $this->pdo->commit();
            return true;
        } catch (Exception $e) {
            $this->pdo->rollBack();
            error_log("Erreur validation directeur: " . $e->getMessage());
            return false;
        }
    }
    
    public function grantPermissionByDG($besoin_id, $dg_id, $action, $commentaire = '') {
        try {
            $this->pdo->beginTransaction();
            $new_status = $action === 'approve' ? 'permission_dg_accordee' : 'refusee_dg';
            $stmt = $this->pdo->prepare("
                UPDATE etat_de_besoin 
                SET statut = :statut, 
                    id_dg_validation = :dg_id,
                    date_permission_dg = NOW(),
                    commentaire_dg = :commentaire,
                    date_maj = NOW()
                WHERE id_besoin = :besoin_id AND statut = 'en_attente_permission_dg'
            ");
            $stmt->execute([
                ':statut' => $new_status,
                ':dg_id' => $dg_id,
                ':commentaire' => $commentaire,
                ':besoin_id' => $besoin_id
            ]);
            if ($action === 'approve') {
                // Send notification to Moyens Généraux
                $this->notifyMoyensGeneraux($besoin_id);
                // Send notification to demandeur about approval
                $this->notifyDemandeurApproval($besoin_id);
            } else {
                // Send notification to demandeur about rejection
                $this->notifyDemandeurRejection($besoin_id, $commentaire);
            }
            $this->pdo->commit();
            return true;
        } catch (Exception $e) {
            $this->pdo->rollBack();
            error_log("Erreur permission DG: " . $e->getMessage());
            return false;
        }
    }
    
    public function getPendingRequests($role) {
        $statuses = [];
        switch ($role) {
            case 'chef_service':
                $statuses = ['en_attente'];
                break;
            case 'directeur':
                $statuses = ['pre_validee'];
                break;
            case 'directeur_general':
                $statuses = ['en_attente_permission_dg'];
                break;
            case 'moyens_generaux':
                $statuses = ['permission_dg_accordee'];
                break;
        }
        if (empty($statuses)) {
            return [];
        }
        $placeholders = str_repeat('?,', count($statuses) - 1) . '?';
        $stmt = $this->pdo->prepare("
            SELECT eb.*, a.nom, a.prenom, a.email
            FROM etat_de_besoin eb
            JOIN agents a ON eb.id_agent = a.id_agent
            WHERE eb.statut IN ($placeholders)
            ORDER BY eb.date_soumission DESC
        ");
        $stmt->execute($statuses);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getWorkflowStatistics() {
        $stmt = $this->pdo->query("
            SELECT 
                statut,
                COUNT(*) as count
            FROM etat_de_besoin 
            WHERE date_soumission >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY statut
        ");
        $stats = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $stats[$row['statut']] = $row['count'];
        }
        return $stats;
    }
    
    private function notifyDirecteur($besoin_id) {
        // Get all directeurs
        $stmt = $this->pdo->query("SELECT id_agent FROM agents WHERE role = 'directeur'");
        $directeurs = $stmt->fetchAll(PDO::FETCH_COLUMN);
        foreach ($directeurs as $directeur_id) {
            Notification::create(
                $directeur_id,
                Notification::TYPE_REQUEST_UPDATED,
                "Nouvelle demande pré-validée nécessitant votre validation",
                $besoin_id
            );
        }
    }
    private function notifyDG($besoin_id) {
        
        $stmt = $this->pdo->query("SELECT id_agent FROM agents WHERE role = 'directeur_general'");
        $dgs = $stmt->fetchAll(PDO::FETCH_COLUMN);
        foreach ($dgs as $dg_id) {
            Notification::create(
                $dg_id,
                Notification::TYPE_REQUEST_UPDATED,
                "Demande validée nécessitant votre permission finale",
                $besoin_id
            );
        }
    }
    private function notifyMoyensGeneraux($besoin_id) {
        // Get all Moyens Généraux
        $stmt = $this->pdo->query("SELECT id_agent FROM agents WHERE role = 'moyens_generaux'");
        $mgs = $stmt->fetchAll(PDO::FETCH_COLUMN);
        foreach ($mgs as $mg_id) {
            Notification::create(
                $mg_id,
                Notification::TYPE_REQUEST_APPROVED,
                "Demande autorisée par le DG - Prêt pour acquisition",
                $besoin_id
            );
        }
    }
    private function notifyDemandeurApproval($besoin_id) {
        // Get demandeur ID
        $stmt = $this->pdo->prepare("SELECT id_agent FROM etat_de_besoin WHERE id_besoin = ?");
        $stmt->execute([$besoin_id]);
        $demandeur_id = $stmt->fetchColumn();
        if ($demandeur_id) {
            Notification::create(
                $demandeur_id,
                Notification::TYPE_REQUEST_APPROVED,
                "Votre demande a été approuvée par le DG et transmise aux Moyens Généraux",
                $besoin_id
            );
        }
    }
    private function notifyDemandeurRejection($besoin_id, $commentaire) {
        // Get demandeur ID
        $stmt = $this->pdo->prepare("SELECT id_agent FROM etat_de_besoin WHERE id_besoin = ?");
        $stmt->execute([$besoin_id]);
        $demandeur_id = $stmt->fetchColumn();
        if ($demandeur_id) {
            $message = "Votre demande a été refusée";
            if ($commentaire) {
                $message .= ". Commentaire: " . $commentaire;
            }
            Notification::create($demandeur_id, Notification::TYPE_REQUEST_REJECTED, $message, $besoin_id);
        }
    }
}
?>
