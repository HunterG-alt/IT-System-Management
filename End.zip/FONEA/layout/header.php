<?php
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Config/config.php';
require_once __DIR__ . '/../Config/titles.php';

// Allow the users to redirect to the dashboard page where it belongs
$dashboards_url = 'show/';
$board_url = $dashboards_url; 
// If the role exist, redirect to the following pqge below
if (isset($_SESSION['role'])) {
    $role = $_SESSION['role'];
    if ($role === 'directeur') {
        $board_url = $dashboards_url . 'dashboard_directeur.php';
    } elseif ($role === 'agent') {
        $board_url = $dashboards_url . 'dashboard_agent.php';
    } elseif ($role === 'chef') {
        $board_url = $dashboards_url . 'dashboard_chef.php';
    } elseif ($role === 'informatique') {
        $board_url = $dashboards_url . 'dashboard_informatique.php';
    } elseif ($role === 'moyens_generaux') {
        $board_url = $dashboards_url . 'dashboard_moyens_generaux.php';
    } elseif ($role === 'directeur_general') {
        $board_url = $dashboards_url . 'dashboard_dg.php';
    }
}
// Redirect to the current page title
$currentPage = basename($_SERVER['PHP_SELF'] ?? '');
$pageTitle = function_exists('get_page_title')
    ? get_page_title($currentPage, $pagetitle ?? null)
    : 'FONEA';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($pageTitle) ?></title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      overflow-x: hidden;
      min-height: 100vh;
      color: #1a1a1a; 
      position: relative;
      background-color: #dbe3ea; 
    }
    /* Glassmorphism Background */
    .glassmorphism-bg {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: -1;
      background: linear-gradient(135deg, 
        #dbe3ea 0%, 
        #c7d4de 25%, 
        #b6c7d4 50%, 
        #a5b7c7 75%, 
        #90a9bb 100%);
      animation: gradientShift 15s ease infinite;
    }
    @keyframes gradientShift {
      0%, 100% {
        background: linear-gradient(135deg, 
          #dbe3ea 0%, 
          #c7d4de 25%, 
          #b6c7d4 50%, 
          #a5b7c7 75%, 
          #90a9bb 100%);
      }
      33% {
        background: linear-gradient(135deg, 
          #cfd9df 0%, 
          #e2ebf0 25%, 
          #dfe7ec 50%, 
          #cfd9df 75%, 
          #aabecb 100%);
      }
      66% {
        background: linear-gradient(135deg, 
          #b6c7d4 0%, 
          #a5b7c7 25%, 
          #90a9bb 50%, 
          #7a94a7 75%, 
          #607d92 100%);
      }
    }
    /* Floating Glass Orbs */
    .glass-orb {
      position: absolute;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      animation: float 6s ease-in-out infinite;
    }
    .glass-orb:nth-child(1) {
      width: 300px;
      height: 300px;
      top: 10%;
      left: -10%;
      animation-delay: 0s;
    }
    .glass-orb:nth-child(2) {
      width: 200px;
      height: 200px;
      top: 60%;
      right: -5%;
      animation-delay: -2s;
    }
    .glass-orb:nth-child(3) {
      width: 150px;
      height: 150px;
      top: 30%;
      right: 20%;
      animation-delay: -4s;
    }
    .glass-orb:nth-child(4) {
      width: 100px;
      height: 100px;
      bottom: 20%;
      left: 15%;
      animation-delay: -1s;
    }
    @keyframes float {
      0%, 100% {
        transform: translateY(0px) translateX(0px) rotate(0deg);
      }
      33% {
        transform: translateY(-20px) translateX(10px) rotate(120deg);
      }
      66% {
        transform: translateY(10px) translateX(-15px) rotate(240deg);
      }
    }
    /* Glass Panels */
    .glass-panel {
      position: absolute;
      background: rgba(255, 255, 255, 0.08);
      backdrop-filter: blur(15px);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 20px;
      animation: panelFloat 8s ease-in-out infinite;
    }
    .glass-panel:nth-child(1) {
      width: 250px;
      height: 400px;
      top: 5%;
      right: 10%;
      transform: rotate(15deg);
      animation-delay: 0s;
    }
    .glass-panel:nth-child(2) {
      width: 180px;
      height: 300px;
      bottom: 10%;
      left: 5%;
      transform: rotate(-10deg);
      animation-delay: -3s;
    }
    .glass-panel:nth-child(3) {
      width: 120px;
      height: 200px;
      top: 45%;
      left: 10%;
      transform: rotate(25deg);
      animation-delay: -6s;
    }
    @keyframes panelFloat {
      0%, 100% {
        transform: translateY(0px) rotate(var(--rotation, 0deg));
      }
      50% {
        transform: translateY(-30px) rotate(calc(var(--rotation, 0deg) + 5deg));
      }
    }
    .fonea-main-wrapper {
      position: relative;
      z-index: 1;
    }
    /* Navbar Glassmorphism */
    .professional-navbar {
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(20px);
      border-bottom: 1px solid rgba(255, 255, 255, 0.25);
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      padding: 1rem 0;
      transition: all 0.3s ease;
      position: relative;
      z-index: 1000;
    }
    .professional-navbar::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(90deg, 
        rgba(255, 255, 255, 0.15) 0%, 
        rgba(255, 255, 255, 0.08) 50%, 
        rgba(255, 255, 255, 0.15) 100%);
      z-index: -1;
      border-radius: 0;
    }
    .professional-navbar .navbar-brand {
      color: #2d5f73;
      font-weight: 700;
      font-size: 1.5rem;
      text-shadow: 0 2px 4px rgba(255, 255, 255, 0.4);
    }
    .professional-navbar .nav-link {
      color: rgba(30, 30, 30, 0.9);
      font-weight: 500;
      margin: 0 1rem;
      position: relative;
      transition: all 0.3s ease;
      text-shadow: 0 2px 4px rgba(255, 255, 255, 0.4);
    }
    .professional-navbar .nav-link::after {
      content: "";
      position: absolute;
      width: 0;
      height: 2px;
      bottom: -5px;
      left: 0;
      background: linear-gradient(90deg, #2d5f73, #90a9bb);
      transition: width 0.3s ease;
    }
    .professional-navbar .nav-link:hover {
      color: #000;
      transform: translateY(-2px);
    }
    .professional-navbar .nav-link:hover::after {
      width: 100%;
    }
    .professional-navbar .btn {
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.3);
      color: #2d5f73;
      backdrop-filter: blur(10px);
      border-radius: 25px;
      padding: 0.5rem 1.5rem;
      transition: all 0.3s ease;
    }
    .professional-navbar .btn:hover {
      background: rgba(45, 95, 115, 0.2);
      border-color: #2d5f73;
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(45, 95, 115, 0.3);
    }
    /* Hero Section Glassmorphism */
    .professional-header {
      position: relative;
      z-index: 10;
    }
    .hero-section {
      padding: 8rem 0 4rem;
      text-align: center;
    }
    .hero-content {
      background: rgba(255, 255, 255, 0.05);
      backdrop-filter: blur(25px);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 30px;
      padding: 4rem 2rem;
      max-width: 800px;
      margin: 0 auto;
      box-shadow: 
        0 20px 40px rgba(0, 0, 0, 0.1),
        inset 0 1px 0 rgba(255, 255, 255, 0.2);
      position: relative;
      overflow: hidden;
    }
    .fonea-header-glass {
      font-size: 4rem;
      font-weight: 800;
      letter-spacing: 8px;
      margin-bottom: 1rem;
      background: linear-gradient(135deg, #2d5f73, #607d92, #90a9bb);
      background-clip: text;
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      text-shadow: 0 5px 10px rgba(0, 0, 0, 0.15);
      position: relative;
      z-index: 1;
    }
    .professional-badge {
      background: linear-gradient(135deg, rgba(144, 169, 187, 0.3), rgba(173, 193, 208, 0.3));
      border: 1px solid rgba(144, 169, 187, 0.4);
      color: #2d5f73;
      padding: 0.5rem 1.5rem;
      border-radius: 20px;
      display: inline-block;
      font-weight: 600;
      margin-top: 1rem;
    }
    .welcome-text {
      font-size: 1.3rem;
      line-height: 1.8;
      color: rgba(30, 30, 30, 0.85);
      margin-top: 2rem;
      font-weight: 300;
      position: relative;
      z-index: 1;
    }
    .section-intermediate {
      padding: 4rem 0;
      position: relative;
      z-index: 10;
    }
    .section-intermediate h2 {
      color: #2d5f73;
      margin-bottom: 3rem;
    }
    .section-intermediate i {
      font-size: 3rem;
      margin-bottom: 1rem;
    }
    .section-intermediate p {
      color: rgba(30, 30, 30, 0.8);
      font-size: 1rem;
    }
    .feature-card {
      background: rgba(255, 255, 255, 0.08);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(255, 255, 255, 0.15);
    }
    .feature-card:hover {
      background: rgba(255, 255, 255, 0.12);
    }
    .feature-card h4 {
      color: #2d5f73;
    }
    .feature-card p {
      color: rgba(30, 30, 30, 0.8);
    }
</style>
</head>
<body>
<div class="glassmorphism-bg">
  <div class="glass-orb"></div>
  <div class="glass-orb"></div>
  <div class="glass-orb"></div>
  <div class="glass-orb"></div>
</div>

<div class="fonea-main-wrapper">

<nav class="navbar navbar-expand-lg professional-navbar">
  <div class="container">
    
    <a class="navbar-brand d-flex align-items-center" href="<?= $dashboard_url ?? '#' ?>">
      <i class="fas fa-cube me-2"></i>FONEA
    </a>
    
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse justify-content-between" id="navbarNav">
      <ul class="navbar-nav mx-auto">
        <li class="nav-item"><a class="nav-link" href="<?= $dashboard_url ?? '#' ?>">Tableau de bord</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= $create_url ?? '#' ?>">Créer une demande</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= $user_url ?? '#' ?>">Utilisateurs</a></li>
      </ul>
      <ul class="navbar-nav ms-auto align-items-center">
        <?php if(isset($_SESSION['user_id'])): ?>
        <li class="nav-item">
          <span class="navbar-text me-3">
            <i class="fas fa-user-circle me-1"></i>
            <a href="<?= $board_url ?>" style="text-decoration: none; color: inherit;">Bonjour, <?= htmlspecialchars($_SESSION['prenom'] ?? 'Utilisateur') ?></a>
          </span>
        </li>
        <li class="nav-item"><a class="btn btn-outline-light btn-sm me-2" href="<?= $logout_url ?? '#' ?>">Déconnexion</a></li>
        <?php else: ?>
        <li class="nav-item"><a class="btn btn-outline-light btn-sm me-2" href="<?= $login_url ?? '#' ?>">Connexion</a></li>
        <li class="nav-item"><a class="btn btn-outline-light btn-sm" href="<?= $register_url ?? '#' ?>">Inscription</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<div class="professional-header">
  <div class="hero-section">
    <div class="container">
      <div class="hero-content">
        <h1 class="fonea-header-glass">
          FONEA
        </h1>
        <div class="professional-badge">
          <i class="fas fa-shield-alt me-1"></i> Système Professionnel
        </div>
        <p class="welcome-text">
          Bienvenue sur notre plateforme!<br>
          Votre portail de gestion des demandes du matériel informatique,<br>
          prêt à simplifier vos processus.
        </p>
      </div>
    </div>
  </div>
</div>

<section class="section-intermediate">
  <div class="container text-center">
    <h2 class="mb-4 fw-bold">Pourquoi choisir notre plateforme de gestion d'acquisition ?</h2>
    <div class="row g-4 justify-content-center">
      <div class="col-md-4">
        <i class="fas fa-bolt text-success"></i>
        <p>Un traitement rapide et efficace de vos demandes pour gagner du temps.</p>
      </div>
      <div class="col-md-4">
        <i class="fas fa-shield-alt text-info"></i>
        <p>Une sécurité renforcée pour protéger vos données sensibles.</p>
      </div>
      <div class="col-md-4">
        <i class="fas fa-users-cog text-warning"></i>
        <p>Une interface intuitive adaptée à tous les rôles de votre organisation.</p>
      </div>
    </div>
  </div>
</section>
</div>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
</body>
</html>
<?php include 'footer.php'; ?>