<?php
require_once '../Config/db.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../public/login.php");
    exit();
}

$pdo = Database::getInstance()->getConnection();
$errors = [];
$success = "";
$user_role = $_SESSION['role'] ?? 'agent';
// Gestion des actions (ajouter, modifier, supprimer)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'add';
    if ($action === 'add') {
        $nom = trim($_POST['nom'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $telephone = trim($_POST['telephone'] ?? '');
        $adresse = trim($_POST['adresse'] ?? '');
        $contact_principal = trim($_POST['contact_principal'] ?? '');
        // Validation
        if (empty($nom)) $errors[] = "Le nom est requis.";
        if (empty($email)) $errors[] = "L'email est requis.";
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Format d'email invalide.";
        if (empty($telephone)) $errors[] = "Le téléphone est requis.";
        if (empty($errors)) {
            try {
                $stmt = $pdo->prepare("INSERT INTO Fournisseur (nom, email, telephone, adresse, contact_principal) VALUES (:nom, :email, :telephone, :adresse, :contact_principal)");
                $stmt->execute([
                    ':nom' => $nom,
                    ':email' => $email,
                    ':telephone' => $telephone,
                    ':adresse' => $adresse,
                    ':contact_principal' => $contact_principal
                ]);
                $success = "Fournisseur ajouté avec succès.";
            } catch (PDOException $e) {
                $errors[] = "Erreur lors de l'ajout : " . $e->getMessage();
            }
        }
    }
    elseif ($action === 'edit' && in_array($user_role, ['admin', 'direction', 'it'])) {
        $id_fournisseur = $_POST['id_fournisseur'] ?? '';
        $nom = trim($_POST['nom'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $telephone = trim($_POST['telephone'] ?? '');
        $adresse = trim($_POST['adresse'] ?? '');
        $contact_principal = trim($_POST['contact_principal'] ?? '');
        if (empty($nom)) $errors[] = "Le nom est requis.";
        if (empty($email)) $errors[] = "L'email est requis.";
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Format d'email invalide.";
        if (empty($errors)) {
            try {
                $stmt = $pdo->prepare("UPDATE Fournisseur SET nom = :nom, email = :email, telephone = :telephone, adresse = :adresse, contact_principal = :contact_principal WHERE id_fournisseur = :id");
                $stmt->execute([
                    ':nom' => $nom,
                    ':email' => $email,
                    ':telephone' => $telephone,
                    ':adresse' => $adresse,
                    ':contact_principal' => $contact_principal,
                    ':id' => $id_fournisseur
                ]);
                $success = "Fournisseur modifié avec succès.";
            } catch (PDOException $e) {
                $errors[] = "Erreur lors de la modification : " . $e->getMessage();
            }
        }
    }
    elseif ($action === 'delete' && in_array($user_role, ['admin', 'direction'])) {
        $id_fournisseur = $_POST['id_fournisseur'] ?? '';
        try {
            // Vérifier si le fournisseur est utilisé dans des commandes
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM Commande WHERE id_fournisseur = :id");
            $stmt->execute([':id' => $id_fournisseur]);
            $count = $stmt->fetchColumn();
            if ($count > 0) {
                $errors[] = "Impossible de supprimer ce fournisseur car il est utilisé dans des commandes.";
            } else {
                $stmt = $pdo->prepare("DELETE FROM Fournisseur WHERE id_fournisseur = :id");
                $stmt->execute([':id' => $id_fournisseur]);
                $success = "Fournisseur supprimé avec succès.";
            }
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de la suppression : " . $e->getMessage();
        }
    }
}
// Récupérer les fournisseurs avec statistiques
try {
    $stmt = $pdo->prepare("
        SELECT f.*, 
               COUNT(c.id_commande) as nb_commandes,
               COALESCE(SUM(c.montant_total), 0) as montant_total
        FROM Fournisseur f
        LEFT JOIN Commande c ON f.id_fournisseur = c.id_fournisseur
        GROUP BY f.id_fournisseur
        ORDER BY f.nom ASC
    ");
    $stmt->execute();
    $fournisseurs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur lors de la récupération des fournisseurs : " . $e->getMessage());
}
// Récupérer un fournisseur spécifique pour modification
$edit_fournisseur = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM Fournisseur WHERE id_fournisseur = :id");
        $stmt->execute([':id' => $_GET['edit']]);
        $edit_fournisseur = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $errors[] = "Erreur lors de la récupération du fournisseur : " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Fournisseurs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .glass-container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 15px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
            padding: 30px;
            margin: 20px 0;
        }
        .btn-glass {
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
        }
        .btn-glass:hover {
            background: rgba(255, 255, 255, 0.3);
            color: white;
            transform: translateY(-2px);
        }
        .table-glass {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            overflow: hidden;
        }
        .table-glass th {
            background: rgba(255, 255, 255, 0.1);
            border: none;
            color: white;
            font-weight: 600;
        }
        .table-glass td {
            border: none;
            color: rgba(255, 255, 255, 0.9);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .form-control {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
        }
        .form-control:focus {
            background: rgba(255, 255, 255, 0.15);
            border-color: rgba(255, 255, 255, 0.5);
            color: white;
            box-shadow: 0 0 0 0.2rem rgba(255, 255, 255, 0.25);
        }
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }
        .alert {
            border: none;
            border-radius: 10px;
        }
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8em;
            font-weight: 500;
        }
        .status-active {
            background: rgba(40, 167, 69, 0.2);
            color: #28a745;
            border: 1px solid #28a745;
        }
        .modal-content {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border: none;
            border-radius: 15px;
        }
    </style>
</head>
<body>
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="glass-container">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h1 class="text-white mb-0">
                            <i class="fas fa-truck-loading me-3"></i>Gestion des Fournisseurs
                        </h1>
                        <?php if (in_array($user_role, ['admin', 'direction', 'it'])): ?>
                        <button class="btn btn-glass" data-bs-toggle="modal" data-bs-target="#addSupplierModal">
                            <i class="fas fa-plus me-2"></i>Nouveau Fournisseur
                        </button>
                        <?php endif; ?>
                    </div>
                    <?php if ($success): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle me-2"></i><?= htmlspecialchars($success) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <?= implode('<br>', array_map('htmlspecialchars', $errors)) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table table-glass table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nom</th>
                                    <th>Email</th>
                                    <th>Téléphone</th>
                                    <th>Contact Principal</th>
                                    <th>Commandes</th>
                                    <th>Montant Total</th>
                                    <th>Statut</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($fournisseurs)): ?>
                                    <tr>
                                        <td colspan="9" class="text-center py-4">
                                            <i class="fas fa-inbox fa-3x mb-3 text-muted"></i>
                                            <p class="text-muted">Aucun fournisseur enregistré</p>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($fournisseurs as $f): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($f['id_fournisseur']) ?></td>
                                            <td>
                                                <strong><?= htmlspecialchars($f['nom']) ?></strong>
                                                <?php if (!empty($f['adresse'])): ?>
                                                    <br><small class="text-muted"><?= htmlspecialchars($f['adresse']) ?></small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="mailto:<?= htmlspecialchars($f['email']) ?>" class="text-decoration-none text-white">
                                                    <?= htmlspecialchars($f['email']) ?>
                                                </a>
                                            </td>
                                            <td>
                                                <a href="tel:<?= htmlspecialchars($f['telephone']) ?>" class="text-decoration-none text-white">
                                                    <?= htmlspecialchars($f['telephone']) ?>
                                                </a>
                                            </td>
                                            <td><?= htmlspecialchars($f['contact_principal'] ?? 'N/A') ?></td>
                                            <td>
                                                <span class="badge bg-info"><?= $f['nb_commandes'] ?></span>
                                            </td>
                                            <td>
                                                <strong><?= number_format($f['montant_total'], 0, ',', ' ') ?> FCFA</strong>
                                            </td>
                                            <td>
                                                <span class="status-badge status-active">Actif</span>
                                            </td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <button class="btn btn-sm btn-glass" onclick="viewSupplier(<?= $f['id_fournisseur'] ?>)" title="Voir">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                    <?php if (in_array($user_role, ['admin', 'direction', 'it'])): ?>
                                                    <button class="btn btn-sm btn-glass" onclick="editSupplier(<?= $f['id_fournisseur'] ?>)" title="Modifier">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <?php if (in_array($user_role, ['admin', 'direction'])): ?>
                                                    <button class="btn btn-sm btn-glass" onclick="deleteSupplier(<?= $f['id_fournisseur'] ?>)" title="Supprimer">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                    <?php endif; ?>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Ajouter Fournisseur -->
    <div class="modal fade" id="addSupplierModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-plus me-2"></i>Nouveau Fournisseur
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="nom" class="form-label">Nom *</label>
                                <input type="text" class="form-control" id="nom" name="nom" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="email" class="form-label">Email *</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="telephone" class="form-label">Téléphone *</label>
                                <input type="tel" class="form-control" id="telephone" name="telephone" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="contact_principal" class="form-label">Contact Principal</label>
                                <input type="text" class="form-control" id="contact_principal" name="contact_principal">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="adresse" class="form-label">Adresse</label>
                            <textarea class="form-control" id="adresse" name="adresse" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Modal Modifier Fournisseur -->
    <div class="modal fade" id="editSupplierModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-edit me-2"></i>Modifier Fournisseur
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="editSupplierForm">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="id_fournisseur" id="edit_id">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_nom" class="form-label">Nom *</label>
                                <input type="text" class="form-control" id="edit_nom" name="nom" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_email" class="form-label">Email *</label>
                                <input type="email" class="form-control" id="edit_email" name="email" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_telephone" class="form-label">Téléphone *</label>
                                <input type="tel" class="form-control" id="edit_telephone" name="telephone" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_contact_principal" class="form-label">Contact Principal</label>
                                <input type="text" class="form-control" id="edit_contact_principal" name="contact_principal">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="edit_adresse" class="form-label">Adresse</label>
                            <textarea class="form-control" id="edit_adresse" name="adresse" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Mettre à jour
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Form caché pour suppression -->
    <form method="POST" id="deleteForm" style="display: none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id_fournisseur" id="delete_id">
    </form>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function viewSupplier(id) {
            // Rediriger vers une page de détails ou ouvrir un modal
            window.location.href = `supplier_details.php?id=${id}`;
        }
        function editSupplier(id) {
            // Récupérer les données du fournisseur via AJAX ou utiliser les données PHP
            fetch(`get_supplier.php?id=${id}`)
                .then(response => response.json())
                .then(data => {
                    document.getElementById('edit_id').value = data.id_fournisseur;
                    document.getElementById('edit_nom').value = data.nom;
                    document.getElementById('edit_email').value = data.email;
                    document.getElementById('edit_telephone').value = data.telephone;
                    document.getElementById('edit_contact_principal').value = data.contact_principal || '';
                    document.getElementById('edit_adresse').value = data.adresse || '';
                    new bootstrap.Modal(document.getElementById('editSupplierModal')).show();
                })
                .catch(error => {
                    console.error('Erreur:', error);
                    alert('Erreur lors de la récupération des données du fournisseur');
                });
        }
        function deleteSupplier(id) {
            if (confirm('Êtes-vous sûr de vouloir supprimer ce fournisseur ? Cette action est irréversible.')) {
                document.getElementById('delete_id').value = id;
                document.getElementById('deleteForm').submit();
            }
        }
    </script>
</body>
</html>