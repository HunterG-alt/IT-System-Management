<?php
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Config/db.php';
require_login();

$user = get_current_user_data();
$userRole = $user['role'] ?? ($_SESSION['role'] ?? '');
if ($userRole !== 'chef_service') {
    http_response_code(403);
    exit('Accès refusé.');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Méthode non autorisée');
}
CSRFProtection::requireToken('chef_request_action');
$id_besoin = (int)($_POST['id_besoin'] ?? 0);
$action = $_POST['action'] ?? '';
if ($id_besoin <= 0 || !in_array($action, ['approve', 'reject'], true)) {
    http_response_code(400);
    exit('Paramètres invalides.');
}
$pdo = Database::getInstance()->getConnection();
// Vérifier que la demande existe et est en attente
$st = $pdo->prepare("SELECT id_besoin FROM etat_de_besoin WHERE id_besoin = ? AND statut = 'en_attente'");
$st->execute([$id_besoin]);
$demande = $st->fetch(PDO::FETCH_ASSOC);
if (!$demande) {
    http_response_code(404);
    exit("Demande introuvable ou déjà traitée.");
}
// Mettre à jour le statut
$newStatus = $action === 'approve' ? 'pre_validee' : 'refusee_chef';
$st = $pdo->prepare("UPDATE etat_de_besoin SET statut = ?, date_maj = NOW() WHERE id_besoin = ?");
$st->execute([$newStatus, $id_besoin]);
header("Location: demande.php?msg=" . urlencode("Demande #$id_besoin mise à jour en '$newStatus'."));
exit;
?>