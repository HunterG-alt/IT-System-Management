<?php
session_start();
require_once '../Config/config.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } else {
        // Check if the email exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email");
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            // Generate token and expiry
            $reset_token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', time() + 3600);
            // Store in DB
            $update = $pdo->prepare("UPDATE users SET reset_token = :token, reset_expires = :exp WHERE id = :id");
            $update->execute([
                'token' => $reset_token,
                'exp'   => $expires,
                'id'    => $user['id']
            ]);
            // Correct subdomain for link
            $reset_link = "https://loussig.42web.io/reset_password.php?token=$reset_token";
            // Send email
            $subject = "Password Reset Request";
            $message = "Click the following link to reset your password:\n\n$reset_link\n\nThis link expires in 1 hour.";
            $headers = "From: no-reply@loussig.42web.io\r\n";
            @mail($email, $subject, $message, $headers);
        }
        // Generic message
        $success = "If the email exists, a reset link has been sent.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Mot de Passe Oublié</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <style>
    body {
      background: linear-gradient(135deg, #74ABE2, #5563DE);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .glass-card {
      backdrop-filter: blur(20px);
      background: rgba(255, 255, 255, 0.15);
      border-radius: 20px;
      box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
      padding: 2rem;
      width: 100%;
      max-width: 420px;
      color: #fff;
    }
    .glass-card h3 {
      font-weight: 600;
      margin-bottom: 1.5rem;
      text-align: center;
    }
    .form-control {
      background: rgba(255, 255, 255, 0.2);
      border: none;
      color: #fff;
    }
    .form-control:focus {
      background: rgba(255, 255, 255, 0.3);
      color: #fff;
      box-shadow: none;
    }
    .btn-primary {
      background-color: rgba(255, 255, 255, 0.25);
      border: none;
      backdrop-filter: blur(10px);
      color: #fff;
      font-weight: 500;
    }
    .btn-primary:hover {
      background-color: rgba(255, 255, 255, 0.35);
    }
    .alert-success {
      background-color: rgba(0, 128, 0, 0.3);
      border: none;
      color: #fff;
    }
    .alert-danger {
      background-color: rgba(255, 0, 0, 0.3);
      border: none;
      color: #fff;
    }
  </style>
</head>
<body>
  <div class="glass-card">
    <h3>Mot de Passe Oublié</h3>
    <?php if (!empty($error)): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if (!empty($success)): ?>
      <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <form method="POST">
      <div class="mb-3">
        <label for="email" class="form-label">Entrez votre adresse mail</label>
        <input type="email" class="form-control" id="email" name="email" required>
      </div>
      <button type="submit" class="btn btn-primary w-100">Renvoyer le lien</button>
    </form>
  </div>
</body>
</html>
