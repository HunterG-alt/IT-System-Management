<?php
require_once '../Config/session.php';
require_once '../modules/permission.php';
// Restreindre l'accès uniquement au rôle Moyens Généraux
AuthMiddleware::requireRole('MOYENS_GENERAUX');
// Connexion PDO
require_once '../Config/db.php';
// Ajouter un matériel
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nom'])) {
    $stmt = $pdo->prepare("INSERT INTO materiel (nom, quantite) VALUES (?, ?)");
    $stmt->execute([$_POST['nom'], $_POST['quantite']]);
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/moyens.php");
    exit;
}
// Supprimer un matériel
if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM materiel WHERE id = ?");
    $stmt->execute([$_GET['delete']]);
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/moyens.php");
    exit;
}
// Récupérer la liste
$materiels = $pdo->query("SELECT * FROM materiel ORDER BY id DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Moyens</title>
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/styles.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .btn i {
            margin-right: 5px;
        }
        .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }
        .btn-primary:hover {
            background-color: #0b5ed7;
            border-color: #0a58ca;
        }
        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        .btn-danger:hover {
            background-color: #c82333;
            border-color: #bd2130;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #545b62;
        }
        .form-control:focus {
            border-color: #0d6efd;
            box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25);
        }
        .card-header {
            font-weight: 600;
            font-size: 1.25rem;
        }
        h1 {
            font-weight: 700;
            color: #343a40;
        }
        label {
            font-weight: 500;
        }
        .container {
            max-width: 900px;
        }
        a {
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .table thead {
            background-color: #343a40;
            color: #fff;
        }
        .table tbody tr:nth-child(odd) {
            background-color: #f2f2f2;
        }
        .table tbody tr:hover {
            background-color: #e9ecef;
        }
        .btn:focus {
            box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25);
        }
        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
            border-radius: 0.2rem;
        }
    </style>
</head>
<body class="bg-light">
<div class="container py-5">
    <h1 class="mb-4">Gestion des Moyens Généraux</h1>
    <!-- Formulaire ajout -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">Ajouter un matériel</div>
        <div class="card-body">
            <form method="post">
                <div class="mb-3">
                    <label class="form-label">Nom du matériel</label>
                    <input type="text" name="nom" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Quantité</label>
                    <input type="number" name="quantite" class="form-control" min="1" required>
                </div>
                <button class="btn btn-primary"><i class="fas fa-save me-2"></i>Ajouter</button>
            </form>
        </div>
    </div>
    <!-- Tableau -->
    <div class="card">
        <div class="card-header bg-dark text-white">Liste du matériel</div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nom</th>
                        <th>Quantité</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($materiels as $m): ?>
                    <tr>
                        <td><?= $m['id'] ?></td>
                        <td><?= htmlspecialchars($m['nom']) ?></td>
                        <td><?= $m['quantite'] ?></td>
                        <td>
<a href="?delete=<?= $m['id'] ?>" 
                               onclick="if(confirm('Supprimer ce matériel ?')){ window.location.href='../include/delete_type_materiel.php?delete=<?= $m['id'] ?>'; return false; } return false;"
                               class="btn btn-danger btn-sm">
                                <i class="fas fa-trash"></i> Supprimer
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <a href="../index.php" class="btn btn-secondary mt-3">
        <i class="fas fa-arrow-left me-2"></i>Retour au tableau de bord
    </a>
</div>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="https://kit.fontawesome.com/42e3a6dd3f.js" crossorigin="anonymous"></script>
</body>
</html>
