<?php
session_start();
require_once __DIR__ . '/../Config/session.php';
require_login();
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../Config/config.php';

// Remove role restriction: allow all authenticated users
$user_id = $_SESSION['user_id'] ?? 0;
$user_name = $_SESSION['nom_complet'] ?? 'Utilisateur';

// Notifications de démonstration
$notifications = [
    ['id' => 1, 'type' => 'Nouvelle demande', 'message' => 'Demande d\'ordinateur portable soumise', 'created_at' => date('Y-m-d H:i:s', strtotime('-2 hours'))],
    ['id' => 2, 'type' => 'Validation requise', 'message' => 'Demande #2024-001 en attente de validation', 'created_at' => date('Y-m-d H:i:s', strtotime('-1 day'))],
    ['id' => 3, 'type' => 'Livraison', 'message' => 'Équipement livré avec succès', 'created_at' => date('Y-m-d H:i:s', strtotime('-3 days'))]
];

try {
    $pdo = Database::getInstance()->getConnection();

    $totalRequests    = $pdo->query("SELECT COUNT(*) FROM etat_de_besoin")->fetchColumn();
    $approvedRequests = $pdo->query("SELECT COUNT(*) FROM etat_de_besoin WHERE statut='validee_directeur'")->fetchColumn();
    $rejectedRequests = $pdo->query("SELECT COUNT(*) FROM etat_de_besoin WHERE statut='refusee_directeur'")->fetchColumn();
    $acquisitions     = $pdo->query("SELECT COUNT(*) FROM acquisitions")->fetchColumn();
    $equipment        = $pdo->query("SELECT COUNT(*) FROM materiel")->fetchColumn();
} catch (PDOException $e) {
    error_log("Database error in dashboard: " . $e->getMessage());
    $totalRequests = $approvedRequests = $rejectedRequests = $acquisitions = $equipment = 0;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Dashboard FONEA - Administration</title>

    <!-- Dependencies -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        /* Reset + Base */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        html, body {
            height: 100%;
        }
        
        body {
            font-family: 'Inter', system-ui, -apple-system, 'Segoe UI', Roboto, "Helvetica Neue", Arial, sans-serif;
            background: #f8fafc;
            color: #1e293b;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }
        
        /* Subtle background pattern (professional) */
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background: 
                linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            z-index: 0;
            pointer-events: none;
        }
        
        /* Page container */
        .page-wrap {
            position: relative;
            z-index: 1;
            padding: 28px;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        /* Header */
        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            margin-bottom: 32px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .brand {
            display: flex;
            align-items: center;
            gap: 14px;
        }
        
        .brand-badge {
            width: 56px;
            height: 56px;
            border-radius: 12px;
            display: grid;
            place-items: center;
            background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
            box-shadow: 0 4px 12px rgba(99, 102, 241, 0.2);
        }
        
        .brand-badge i {
            font-size: 24px;
            color: #fff;
        }
        
        .header-title {
            font-size: 28px;
            line-height: 1.2;
            font-weight: 700;
            color: #0f172a;
            display: block;
        }
        
        .header-sub {
            font-size: 14px;
            color: #64748b;
            margin-top: 4px;
        }
        
        /* Header actions */
        .header-actions {
            display: flex;
            gap: 12px;
            align-items: center;
        }
        
        .notification-btn {
            position: relative;
            padding: 10px 16px;
            border-radius: 10px;
            border: 1px solid #e2e8f0;
            background: #ffffff;
            color: #1e293b;
            font-weight: 600;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .notification-btn:hover {
            background: #f8fafc;
            border-color: #cbd5e1;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        }
        
        .notification-badge {
            position: absolute;
            top: -6px;
            right: -6px;
            font-size: 11px;
            padding: 4px 8px;
            border-radius: 999px;
            background: #ef4444;
            color: #fff;
            font-weight: 700;
            box-shadow: 0 2px 8px rgba(239, 68, 68, 0.3);
        }
        
        /* Dashboard stats grid */
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 20px;
            margin-bottom: 32px;
        }
        
        .dashboard-card {
            padding: 24px;
            border-radius: 12px;
            min-height: 140px;
            display: flex;
            flex-direction: column;
            gap: 12px;
            justify-content: center;
            background: #ffffff;
            border: 1px solid #e2e8f0;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
            transition: all 0.25s ease;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }
        
        .dashboard-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, #6366f1, #8b5cf6);
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }
        
        .dashboard-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
            border-color: #cbd5e1;
        }
        
        .dashboard-card:hover::before {
            transform: scaleX(1);
        }
        
        .dashboard-card .icon-wrap {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            display: grid;
            place-items: center;
            background: linear-gradient(135deg, #f8fafc, #f1f5f9);
            border: 1px solid #e2e8f0;
        }
        
        .dashboard-card i {
            font-size: 20px;
            color: #6366f1;
        }
        
        .card-title {
            font-size: 13px;
            color: #64748b;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .card-value {
            font-size: 32px;
            font-weight: 700;
            color: #0f172a;
            letter-spacing: -0.5px;
            line-height: 1;
        }
        
        .card-desc {
            font-size: 13px;
            color: #94a3b8;
        }
        
        /* Card theme variations */
        .dashboard-card[data-theme="success"] .icon-wrap {
            background: linear-gradient(135deg, #ecfdf5, #d1fae5);
        }
        
        .dashboard-card[data-theme="success"] i {
            color: #10b981;
        }
        
        .dashboard-card[data-theme="success"]::before {
            background: linear-gradient(90deg, #10b981, #059669);
        }
        
        .dashboard-card[data-theme="danger"] .icon-wrap {
            background: linear-gradient(135deg, #fef2f2, #fee2e2);
        }
        
        .dashboard-card[data-theme="danger"] i {
            color: #ef4444;
        }
        
        .dashboard-card[data-theme="danger"]::before {
            background: linear-gradient(90deg, #ef4444, #dc2626);
        }
        
        .dashboard-card[data-theme="info"] .icon-wrap {
            background: linear-gradient(135deg, #eff6ff, #dbeafe);
        }
        
        .dashboard-card[data-theme="info"] i {
            color: #3b82f6;
        }
        
        .dashboard-card[data-theme="info"]::before {
            background: linear-gradient(90deg, #3b82f6, #2563eb);
        }
        
        .dashboard-card[data-theme="warning"] .icon-wrap {
            background: linear-gradient(135deg, #fffbeb, #fef3c7);
        }
        
        .dashboard-card[data-theme="warning"] i {
            color: #f59e0b;
        }
        
        .dashboard-card[data-theme="warning"]::before {
            background: linear-gradient(90deg, #f59e0b, #d97706);
        }
        
        /* Modules section */
        .modules {
            margin-top: 32px;
            padding-top: 32px;
            border-top: 1px solid #e2e8f0;
        }
        
        .modules-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
        }
        
        .modules-title {
            font-size: 20px;
            font-weight: 700;
            color: #0f172a;
        }
        
        .modules-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }
        
        .module-card {
            padding: 24px;
            border-radius: 12px;
            min-height: 160px;
            background: #ffffff;
            border: 1px solid #e2e8f0;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
            display: flex;
            flex-direction: column;
            gap: 12px;
            justify-content: space-between;
            transition: all 0.25s ease;
        }
        
        .module-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
            border-color: #cbd5e1;
        }
        
        .module-card h5 {
            font-size: 16px;
            margin: 0;
            font-weight: 700;
            color: #0f172a;
        }
        
        .module-card p {
            font-size: 14px;
            color: #64748b;
            margin: 0;
            line-height: 1.6;
        }
        
        .btn-glass {
            display: inline-block;
            padding: 10px 18px;
            border-radius: 8px;
            background: #6366f1;
            border: none;
            color: #fff;
            font-weight: 600;
            text-decoration: none;
            box-shadow: 0 2px 8px rgba(99, 102, 241, 0.2);
            transition: all 0.2s ease;
            align-self: flex-start;
            font-size: 14px;
        }
        
        .btn-glass:hover {
            background: #4f46e5;
            box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
            transform: translateY(-1px);
        }
        
        .btn-glass:active {
            transform: translateY(0);
        }
        
        /* Utility classes */
        .muted {
            color: #94a3b8;
        }
        
        .small {
            font-size: 13px;
        }
        
        /* Responsive design */
        @media (max-width: 1200px) {
            .dashboard-grid {
                grid-template-columns: repeat(3, 1fr);
            }
        }
        
        @media (max-width: 900px) {
            .dashboard-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .modules-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 700px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                gap: 12px;
            }
            
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
            
            .modules-grid {
                grid-template-columns: 1fr;
            }
            
            .brand-badge {
                width: 48px;
                height: 48px;
            }
            
            .header-title {
                font-size: 24px;
            }
            
            .page-wrap {
                padding: 20px;
            }
        }
        
        /* Print styles */
        @media print {
            body {
                background: white;
                color: black;
            }
            
            .dashboard-card,
            .module-card {
                break-inside: avoid;
                box-shadow: none;
                border: 1px solid #ddd;
            }
            
            .notification-btn,
            .btn-glass {
                display: none;
            }
        }
        
        /* Focus states for accessibility */
        .dashboard-card:focus-visible,
        .module-card:focus-visible,
        .btn-glass:focus-visible,
        .notification-btn:focus-visible {
            outline: 2px solid #6366f1;
            outline-offset: 2px;
        }
        
        /* Loading state (optional) */
        .loading {
            opacity: 0.6;
            pointer-events: none;
        }
        
        .loading::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 24px;
            height: 24px;
            border: 3px solid #e2e8f0;
            border-top-color: #6366f1;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }
        
        @keyframes spin {
            to { transform: translate(-50%, -50%) rotate(360deg); }
        }
    </style>
</head>
<body>

    <!-- background particles -->
    <div class="floating-particles" aria-hidden="true"></div>

    <!-- main content -->
    <div class="page-wrap container">

        <!-- header -->
        <div class="header">
            <div class="brand">
                <div class="brand-badge"><i class="fas fa-network-wired"></i></div>
                <div>
                    <div class="header-title">FONEA Dashboard</div>
                    <div class="header-sub">Système de Gestion des Équipements — Interface Administrative</div>
                </div>
            </div>

            <div class="header-actions">
                <!-- quick stats / actions could go here -->
                <div class="dropdown">
                    <button class="notification-btn dropdown-toggle" id="notifDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <?php if(!empty($notifications) && count($notifications) > 0): ?>
                            <span class="notification-badge"><?= count($notifications) ?></span>
                        <?php endif; ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notifDropdown" style="backdrop-filter:blur(16px);background:rgba(15,15,30,0.88);border-radius:12px;border:1px solid rgba(255,255,255,0.04)">
                        <?php if(empty($notifications)): ?>
                            <li class="px-3 py-2 text-white-50 small">Aucune notification</li>
                        <?php else: ?>
                            <?php foreach($notifications as $notif): ?>
                                <li>
                                    <a class="dropdown-item d-flex flex-column" href="../show/notifications.php" data-id="<?= $notif['id'] ?>">
                                        <strong class="small"><?= htmlspecialchars($notif['type']) ?></strong>
                                        <span class="small muted"><?= htmlspecialchars($notif['message']) ?></span>
                                        <small class="text-white-50"><?= date('d/m/Y H:i', strtotime($notif['created_at'])) ?></small>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Dashboard Cards -->
        <section aria-label="Résumé" class="mb-3">
            <div class="dashboard-grid">
                <div class="dashboard-card" role="button" data-theme="info" onclick="navigateToSection('etats', event)">
                    <div style="display:flex;align-items:center;gap:12px">
                        <div class="icon-wrap"><i class="fas fa-clipboard-list"></i></div>
                        <div>
                            <div class="card-title">États de Besoin</div>
                            <div class="card-value"><span class="count" data-target="<?= intval($totalRequests ?? 0) ?>">0</span></div>
                            <div class="card-desc small">Demandes en cours</div>
                        </div>
                    </div>
                </div>

                <div class="dashboard-card" role="button" data-theme="success" onclick="navigateToSection('validees', event)">
                    <div style="display:flex;align-items:center;gap:12px">
                        <div class="icon-wrap"><i class="fas fa-check-circle"></i></div>
                        <div>
                            <div class="card-title">Validées</div>
                            <div class="card-value"><span class="count" data-target="<?= intval($approvedRequests ?? 0) ?>">0</span></div>
                            <div class="card-desc small">Demandes approuvées</div>
                        </div>
                    </div>
                </div>

                <div class="dashboard-card" role="button" data-theme="danger" onclick="navigateToSection('refusees', event)">
                    <div style="display:flex;align-items:center;gap:12px">
                        <div class="icon-wrap"><i class="fas fa-times-circle"></i></div>
                        <div>
                            <div class="card-title">Refusées</div>
                            <div class="card-value"><span class="count" data-target="<?= intval($rejectedRequests ?? 0) ?>">0</span></div>
                            <div class="card-desc small">Demandes rejetées</div>
                        </div>
                    </div>
                </div>

                <div class="dashboard-card" role="button" data-theme="info" onclick="navigateToSection('acquisitions', event)">
                    <div style="display:flex;align-items:center;gap:12px">
                        <div class="icon-wrap"><i class="fas fa-shopping-cart"></i></div>
                        <div>
                            <div class="card-title">Acquisitions</div>
                            <div class="card-value"><span class="count" data-target="<?= intval($acquisitions ?? 0) ?>">0</span></div>
                            <div class="card-desc small">Acquisitions en cours</div>
                        </div>
                    </div>
                </div>

                <div class="dashboard-card" role="button" data-theme="info" onclick="navigateToSection('equipements', event)">
                    <div style="display:flex;align-items:center;gap:12px">
                        <div class="icon-wrap"><i class="fas fa-laptop"></i></div>
                        <div>
                            <div class="card-title">Équipements</div>
                            <div class="card-value"><span class="count" data-target="<?= intval($equipment ?? 0) ?>">0</span></div>
                            <div class="card-desc small">Équipements gérés</div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Modules -->
        <section class="modules" aria-label="Modules intégrés">
            <div class="modules-header">
                <div>
                    <div class="modules-title">Modules Intégrés</div>
                    <div class="muted small">Accédez aux différentes fonctionnalités du système</div>
                </div>
            </div>

            <div class="modules-grid">
                <div class="module-card shimmer">
                    <div>
                        <h5><i class="fas fa-plus-circle me-2"></i>Nouvelle Demande</h5>
                        <p>Créer une nouvelle demande d'équipement avec validation automatique</p>
                    </div>
                    <a href="../public/create.php" class="btn-glass">Créer une demande</a>
                </div>

                <div class="module-card shimmer">
                    <div>
                        <h5><i class="fas fa-list-alt me-2"></i>Gestion des Demandes</h5>
                        <p>Consulter, modifier et suivre toutes les demandes d'équipement</p>
                    </div>
                    <a href="../show/content.php" class="btn-glass">Voir les demandes</a>
                </div>

                <div class="module-card shimmer">
                    <div>
                        <h5><i class="fas fa-warehouse me-2"></i>Stock</h5>
                        <p>Gérer l'inventaire et les stocks disponibles</p>
                    </div>
                    <a href="../show/stock.php" class="btn-glass">Voir le stock</a>
                </div>

                <div class="module-card shimmer">
                    <div>
                        <h5><i class="fas fa-truck me-2"></i>Fournisseurs</h5>
                        <p>Gérer les informations des fournisseurs et contacts</p>
                    </div>
                    <a href="../show/fournisseur.php" class="btn-glass">Voir les fournisseurs</a>
                </div>

                <div class="module-card shimmer">
                    <div>
                        <h5><i class="fas fa-desktop me-2"></i>Matériel</h5>
                        <p>Suivi détaillé du matériel et des équipements</p>
                    </div>
                    <a href="../include/type_materiel.php" class="btn-glass">Voir le matériel</a>
                </div>

                <div class="module-card shimmer">
                    <div>
                        <h5><i class="fas fa-file-export me-2"></i>Rapports</h5>
                        <p>Exporter les rapports et statistiques du système</p>
                    </div>
                    <a href="../show/export_reports.php" class="btn-glass">Exporter</a>
                </div>
            </div>
        </section>

    </div>

    <!-- scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>

    <script>
        /* Navigation animation then redirect */
        function navigateToSection(section, event) {
            const card = event.currentTarget;
            card.style.transform = 'translateY(-6px) scale(.995)';
            card.style.opacity = '0.9';
            setTimeout(() => {
                switch(section){
                    case 'etats': window.location.href = '../show/content.php'; break;
                    case 'validees': window.location.href = '../show/content.php?status=validee_directeur'; break;
                    case 'refusees': window.location.href = '../show/content.php?status=refusee_directeur'; break;
                    case 'acquisitions': window.location.href = '../show/acquisition.php'; break;
                    case 'equipements': window.location.href = '../show/equipement.php'; break;
                    default: card.style.transform=''; card.style.opacity='';
                }
            },180);
        }

        /* particles generation */
        (function generateParticles(){
            const container = document.querySelector('.floating-particles');
            if(!container) return;
            const colors = ['rgba(139,92,246,0.6)','rgba(59,130,246,0.55)','rgba(236,72,153,0.5)'];
            const total = 18;
            for(let i=0;i<total;i++){
                const p = document.createElement('div');
                p.className = 'particle';
                const size = Math.round(Math.random()*10)+4;
                p.style.width = p.style.height = size + 'px';
                p.style.left = Math.random()*100 + '%';
                p.style.top = Math.random()*100 + '%';
                p.style.background = colors[i % colors.length];
                p.style.opacity = 0.6 + Math.random()*0.4;
                const duration = 18 + Math.random()*18;
                const delay = Math.random()*-duration;
                p.style.transition = 'transform ' + duration + 's linear';
                p.style.animation = `float${i} ${duration}s linear ${delay}s infinite`;
                p.style.boxShadow = '0 0 8px rgba(0,0,0,0.45)';
                container.appendChild(p);

                /* create per-particle keyframes dynamically for varied motion */
                const dx = (Math.random()*200)-100;
                const dy = (Math.random()*200)-100;
                const styleSheet = document.styleSheets[0];
                const name = 'float' + i;
                const keyframes =
                  `@keyframes ${name}{
                      0%{transform:translate3d(0,0,0) scale(.5); opacity:0}
                      10%{opacity:1}
                      50%{transform:translate3d(${dx/3}px,${dy/3}px,0) scale(1)}
                      90%{opacity:1}
                      100%{transform:translate3d(${dx}px,${dy}px,0) scale(1); opacity:0}
                  }`;
                try { styleSheet.insertRule(keyframes, styleSheet.cssRules.length); } catch(e){ /* fail silently if CSP */ }
            }
        })();

        /* Count up animation for metric numbers */
        (function countUp(){
            const nodes = document.querySelectorAll('.count');
            nodes.forEach(node=>{
                const target = parseInt(node.getAttribute('data-target') || '0',10);
                let start = 0;
                if(target <= 0){ node.textContent = '0'; return; }
                const duration = 900; // ms
                const step = Math.max(1, Math.floor(target / (duration / 20)));
                const timer = setInterval(()=>{
                    start += step;
                    if(start >= target){
                        node.textContent = target;
                        clearInterval(timer);
                    } else {
                        node.textContent = start;
                    }
                }, 20);
            });
        })();

        /* small UX: restore transform after mouseleave if user doesn't click */
        document.addEventListener('pointerup', e=>{
            const cards = document.querySelectorAll('.dashboard-card');
            cards.forEach(c=>{ c.style.transform=''; c.style.opacity=''; });
        });
    </script>
</body>
</html>
