<?php
require_once '../Config/db.php';
require_once '../Config/session.php';
require_once '../modules/permission.php';

// Check authentication
AuthMiddleware::requireLogin();

$user_data = $_SESSION['user_data'];
$user_role = $user_data['role'];
$user_id = $user_data['id_agent'];

// Get request ID
$request_id = intval($_GET['id'] ?? 0);

if (!$request_id) {
    header("Location: my_requests.php");
    exit;
}

// Fetch request details
$stmt = $pdo->prepare("
    SELECT eb.*, 
           a.nom as demandeur_nom, 
           a.prenom as demandeur_prenom,
           a.email as demandeur_email,
           d.nom_departement,
           cs.nom as chef_nom, cs.prenom as chef_prenom,
           dir.nom as directeur_nom, dir.prenom as directeur_prenom,
           dg.nom as dg_nom, dg.prenom as dg_prenom,
           mg.nom as mg_nom, mg.prenom as mg_prenom
    FROM etat_de_besoin eb
    LEFT JOIN agents a ON eb.id_agent = a.id_agent
    LEFT JOIN departements d ON eb.id_departement = d.id_departement
    LEFT JOIN agents cs ON eb.id_chef_service = cs.id_agent
    LEFT JOIN agents dir ON eb.id_directeur = dir.id_agent
    LEFT JOIN agents dg ON eb.id_directeur_general = dg.id_agent
    LEFT JOIN agents mg ON eb.id_moyens_generaux = mg.id_agent
    WHERE eb.id_besoin = ?
");

$stmt->execute([$request_id]);
$request = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$request) {
    header("Location: my_requests.php");
    exit;
}

// Check if user can view this request
$pm = PermissionManager::getInstance();
if (!$pm->hasResourcePermission('requests', 'view', $request_id)) {
    http_response_code(403);
    die("Accès refusé");
}

// Fetch history
$stmt = $pdo->prepare("
    SELECT h.*, a.nom, a.prenom, a.role
    FROM historique_besoin h
    LEFT JOIN agents a ON h.id_agent = a.id_agent
    WHERE h.id_besoin = ?
    ORDER BY h.date_action DESC
");
$stmt->execute([$request_id]);
$history = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Status labels and colors
$status_config = [
    STATUS_EN_ATTENTE => ['label' => 'En Attente', 'color' => '#f59e0b', 'icon' => 'fa-clock'],
    STATUS_PRE_VALIDEE => ['label' => 'Pré-validée', 'color' => '#3b82f6', 'icon' => 'fa-check-circle'],
    STATUS_REFUSEE_CHEF => ['label' => 'Rejetée (Chef)', 'color' => '#ef4444', 'icon' => 'fa-times-circle'],
    STATUS_VALIDEE_DIRECTEUR => ['label' => 'Validée', 'color' => '#10b981', 'icon' => 'fa-check-double'],
    STATUS_REFUSEE_DIRECTEUR => ['label' => 'Rejetée (Directeur)', 'color' => '#ef4444', 'icon' => 'fa-times-circle'],
    STATUS_EN_ANALYSE_TECHNIQUE => ['label' => 'En Analyse', 'color' => '#8b5cf6', 'icon' => 'fa-search'],
    STATUS_EN_ACQUISITION => ['label' => 'En Acquisition', 'color' => '#06b6d4', 'icon' => 'fa-shopping-cart'],
    STATUS_ATTRIBUEE => ['label' => 'Attribuée', 'color' => '#14b8a6', 'icon' => 'fa-hand-holding'],
    STATUS_CLOTUREE => ['label' => 'Clôturée', 'color' => '#6b7280', 'icon' => 'fa-check'],
    'refusee_dg' => ['label' => 'Rejetée (DG)', 'color' => '#ef4444', 'icon' => 'fa-times-circle']
];

$current_status = $status_config[$request['statut']] ?? ['label' => $request['statut'], 'color' => '#6b7280', 'icon' => 'fa-question'];

// Determine available actions based on role and status
$available_actions = [];

if ($user_role === ROLE_CHEF_SERVICE && $request['statut'] === STATUS_EN_ATTENTE && $request['id_agent'] != $user_id) {
    $available_actions = ['pre_validate', 'reject_pre_validation'];
}

if ($user_role === ROLE_DIRECTEUR && $request['statut'] === STATUS_PRE_VALIDEE && $request['id_agent'] != $user_id) {
    $available_actions = ['validate', 'reject_validation'];
}

if ($user_role === ROLE_DIRECTEUR_GENERAL && $request['statut'] === STATUS_VALIDEE_DIRECTEUR) {
    $available_actions = ['authorize', 'reject_authorization'];
}

if ($user_role === ROLE_MOYENS_GENERAUX && in_array($request['statut'], [STATUS_EN_ANALYSE_TECHNIQUE, STATUS_VALIDEE_DIRECTEUR])) {
    $available_actions = ['process'];
}

if ($user_role === ROLE_MOYENS_GENERAUX && $request['statut'] === STATUS_EN_ACQUISITION) {
    $available_actions = ['complete'];
}

// Priority labels
$priority_config = [
    'normale' => ['label' => 'Normale', 'color' => '#10b981'],
    'urgente' => ['label' => 'Urgente', 'color' => '#f59e0b'],
    'critique' => ['label' => 'Critique', 'color' => '#ef4444']
];

$priority = $priority_config[$request['priorite']] ?? ['label' => 'Normale', 'color' => '#10b981'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails de la Demande #<?php echo $request_id; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 40px 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            color: white;
        }

        .header h1 {
            font-size: 2em;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .back-btn {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            padding: 12px 24px;
            border-radius: 12px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
            backdrop-filter: blur(5px);
        }

        .back-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateX(-5px);
        }

        .glass-card {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
            border: 1px solid rgba(255, 255, 255, 0.18);
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 25px;
            font-weight: 600;
            color: white;
            font-size: 1em;
        }

        .priority-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 15px;
            border-radius: 15px;
            font-weight: 600;
            color: white;
            font-size: 0.9em;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .info-item {
            background: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 12px;
            color: white;
        }

        .info-item label {
            display: block;
            font-size: 0.85em;
            opacity: 0.8;
            margin-bottom: 5px;
        }

        .info-item .value {
            font-size: 1.1em;
            font-weight: 600;
        }

        .section-title {
            color: white;
            font-size: 1.4em;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .description-box {
            background: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 12px;
            color: white;
            line-height: 1.6;
            margin-top: 15px;
        }

        /* Workflow Timeline */
        .workflow-timeline {
            position: relative;
            padding-left: 30px;
        }

        .workflow-timeline::before {
            content: '';
            position: absolute;
            left: 12px;
            top: 0;
            bottom: 0;
            width: 3px;
            background: rgba(255, 255, 255, 0.3);
        }

        .workflow-step {
            position: relative;
            margin-bottom: 25px;
            padding: 15px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: white;
        }

        .workflow-step::before {
            content: '';
            position: absolute;
            left: -22px;
            top: 20px;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            background: white;
            border: 3px solid #667eea;
        }

        .workflow-step.completed::before {
            background: #10b981;
        }

        .workflow-step.active::before {
            background: #f59e0b;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .workflow-step-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .workflow-step-title {
            font-weight: 600;
            font-size: 1.1em;
        }

        .workflow-step-date {
            font-size: 0.85em;
            opacity: 0.8;
        }

        .workflow-step-info {
            font-size: 0.95em;
            opacity: 0.9;
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 20px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 12px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .btn-success {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
        }

        .btn-success:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(16, 185, 129, 0.4);
        }

        .btn-danger {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white;
        }

        .btn-danger:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(239, 68, 68, 0.4);
        }

        .btn-primary {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
        }

        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 20px;
            max-width: 500px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .modal-header h3 {
            margin: 0;
            color: #333;
        }

        .close-modal {
            background: none;
            border: none;
            font-size: 1.5em;
            cursor: pointer;
            color: #666;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
        }

        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-family: inherit;
            font-size: 1em;
            min-height: 100px;
            resize: vertical;
        }

        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }

        /* History Timeline */
        .history-item {
            padding: 15px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            margin-bottom: 15px;
            color: white;
        }

        .history-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
        }

        .history-user {
            font-weight: 600;
        }

        .history-date {
            font-size: 0.85em;
            opacity: 0.8;
        }

        .history-action {
            font-size: 0.9em;
            padding: 4px 12px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 15px;
            display: inline-block;
            margin-bottom: 8px;
        }

        .history-comment {
            font-size: 0.95em;
            opacity: 0.9;
            font-style: italic;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            display: none;
            animation: slideIn 0.3s ease-out;
        }

        .alert.success {
            background: rgba(16, 185, 129, 0.9);
            color: white;
        }

        .alert.error {
            background: rgba(239, 68, 68, 0.9);
            color: white;
        }

        .alert.show {
            display: block;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }

            .info-grid {
                grid-template-columns: 1fr;
            }

            .action-buttons {
                flex-direction: column;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Alert Messages -->
        <div id="alertMsg" class="alert"></div>

        <div class="header">
            <h1>
                <i class="fas fa-file-alt"></i>
                Demande #<?php echo $request_id; ?>
            </h1>
            <a href="my_requests.php" class="back-btn">
                <i class="fas fa-arrow-left"></i>
                Retour
            </a>
        </div>

        <!-- Request Details Card -->
        <div class="glass-card">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 15px;">
                <div>
                    <span class="status-badge" style="background-color: <?php echo $current_status['color']; ?>">
                        <i class="fas <?php echo $current_status['icon']; ?>"></i>
                        <?php echo $current_status['label']; ?>
                    </span>
                </div>
                <div>
                    <span class="priority-badge" style="background-color: <?php echo $priority['color']; ?>">
                        <i class="fas fa-flag"></i>
                        <?php echo $priority['label']; ?>
                    </span>
                </div>
            </div>

            <h2 class="section-title">
                <i class="fas fa-info-circle"></i>
                Informations Générales
            </h2>

            <div class="info-grid">
                <div class="info-item">
                    <label><i class="fas fa-heading"></i> Objet</label>
                    <div class="value"><?php echo htmlspecialchars($request['objet']); ?></div>
                </div>
                <div class="info-item">
                    <label><i class="fas fa-user"></i> Demandeur</label>
                    <div class="value"><?php echo htmlspecialchars($request['demandeur_prenom'] . ' ' . $request['demandeur_nom']); ?></div>
                </div>
                <div class="info-item">
                    <label><i class="fas fa-building"></i> Département</label>
                    <div class="value"><?php echo htmlspecialchars($request['nom_departement']); ?></div>
                </div>
                <div class="info-item">
                    <label><i class="fas fa-sort-numeric-up"></i> Quantité</label>
                    <div class="value"><?php echo $request['quantite']; ?></div>
                </div>
                <div class="info-item">
                    <label><i class="fas fa-calendar"></i> Date de création</label>
                    <div class="value"><?php echo date('d/m/Y H:i', strtotime($request['date_creation'])); ?></div>
                </div>
                <div class="info-item">
                    <label><i class="fas fa-clock"></i> Dernière modification</label>
                    <div class="value"><?php echo date('d/m/Y H:i', strtotime($request['date_modification'])); ?></div>
                </div>
            </div>

            <h3 style="color: white; margin-top: 25px; margin-bottom: 10px;">
                <i class="fas fa-align-left"></i> Description
            </h3>
            <div class="description-box">
                <?php echo nl2br(htmlspecialchars($request['description'])); ?>
            </div>

            <!-- Action Buttons -->
            <?php if (!empty($available_actions)): ?>
            <div class="action-buttons">
                <?php if (in_array('pre_validate', $available_actions)): ?>
                    <button class="btn btn-success" onclick="openActionModal('pre_validate', 'Pré-valider la Demande')">
                        <i class="fas fa-check"></i>
                        Pré-valider
                    </button>
                    <button class="btn btn-danger" onclick="openActionModal('reject_pre_validation', 'Rejeter la Demande')">
                        <i class="fas fa-times"></i>
                        Rejeter
                    </button>
                <?php endif; ?>

                <?php if (in_array('validate', $available_actions)): ?>
                    <button class="btn btn-success" onclick="openActionModal('validate', 'Valider la Demande')">
                        <i class="fas fa-check-double"></i>
                        Valider
                    </button>
                    <button class="btn btn-danger" onclick="openActionModal('reject_validation', 'Rejeter la Demande')">
                        <i class="fas fa-times"></i>
                        Rejeter
                    </button>
                <?php endif; ?>

                <?php if (in_array('authorize', $available_actions)): ?>
                    <button class="btn btn-success" onclick="openActionModal('authorize', 'Autoriser la Demande')">
                        <i class="fas fa-stamp"></i>
                        Autoriser
                    </button>
                    <button class="btn btn-danger" onclick="openActionModal('reject_authorization', 'Rejeter la Demande')">
                        <i class="fas fa-times"></i>
                        Rejeter
                    </button>
                <?php endif; ?>

                <?php if (in_array('process', $available_actions)): ?>
                    <button class="btn btn-primary" onclick="openActionModal('process', 'Prendre en Charge')">
                        <i class="fas fa-cogs"></i>
                        Prendre en Charge
                    </button>
                <?php endif; ?>

                <?php if (in_array('complete', $available_actions)): ?>
                    <button class="btn btn-success" onclick="openActionModal('complete', 'Clôturer la Demande')">
                        <i class="fas fa-check-circle"></i>
                        Clôturer
                    </button>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- Workflow Progress Card -->
        <div class="glass-card">
            <h2 class="section-title">
                <i class="fas fa-route"></i>
                Suivi du Processus
            </h2>

            <div class="workflow-timeline">
                <div class="workflow-step <?php echo $request['date_pre_validation'] ? 'completed' : ($request['statut'] === STATUS_EN_ATTENTE ? 'active' : ''); ?>">
                    <div class="workflow-step-header">
                        <div class="workflow-step-title">
                            <i class="fas fa-user-tie"></i> Chef de Service - Pré-validation
                        </div>
                        <?php if ($request['date_pre_validation']): ?>
                        <div class="workflow-step-date">
                            <?php echo date('d/m/Y H:i', strtotime($request['date_pre_validation'])); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php if ($request['chef_nom']): ?>
                    <div class="workflow-step-info">
                        Par: <?php echo htmlspecialchars($request['chef_prenom'] . ' ' . $request['chef_nom']); ?>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="workflow-step <?php echo $request['date_validation'] ? 'completed' : ($request['statut'] === STATUS_PRE_VALIDEE ? 'active' : ''); ?>">
                    <div class="workflow-step-header">
                        <div class="workflow-step-title">
                            <i class="fas fa-user-shield"></i> Directeur - Validation
                        </div>
                        <?php if ($request['date_validation']): ?>
                        <div class="workflow-step-date">
                            <?php echo date('d/m/Y H:i', strtotime($request['date_validation'])); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php if ($request['directeur_nom']): ?>
                    <div class="workflow-step-info">
                        Par: <?php echo htmlspecialchars($request['directeur_prenom'] . ' ' . $request['directeur_nom']); ?>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="workflow-step <?php echo $request['date_autorisation'] ? 'completed' : ($request['statut'] === STATUS_VALIDEE_DIRECTEUR ? 'active' : ''); ?>">
                    <div class="workflow-step-header">
                        <div class="workflow-step-title">
                            <i class="fas fa-user-crown"></i> Directeur Général - Autorisation
                        </div>
                        <?php if ($request['date_autorisation']): ?>
                        <div class="workflow-step-date">
                            <?php echo date('d/m/Y H:i', strtotime($request['date_autorisation'])); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php if ($request['dg_nom']): ?>
                    <div class="workflow-step-info">
                        Par: <?php echo htmlspecialchars($request['dg_prenom'] . ' ' . $request['dg_nom']); ?>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="workflow-step <?php echo $request['date_cloture'] ? 'completed' : (in_array($request['statut'], [STATUS_EN_ANALYSE_TECHNIQUE, STATUS_EN_ACQUISITION]) ? 'active' : ''); ?>">
                    <div class="workflow-step-header">
                        <div class="workflow-step-title">
                            <i class="fas fa-cogs"></i> Moyens Généraux - Traitement
                        </div>
                        <?php if ($request['date_traitement']): ?>
                        <div class="workflow-step-date">
                            <?php echo date('d/m/Y H:i', strtotime($request['date_traitement'])); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php if ($request['mg_nom']): ?>
                    <div class="workflow-step-info">
                        Par: <?php echo htmlspecialchars($request['mg_prenom'] . ' ' . $request['mg_nom']); ?>
                    </div>
                    <?php endif; ?>
                    <?php if ($request['date_cloture']): ?>
                    <div class="workflow-step-info" style="margin-top: 5px; color: #10b981;">
                        <i class="fas fa-check-circle"></i> Clôturée le <?php echo date('d/m/Y H:i', strtotime($request['date_cloture'])); ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- History Card -->
        <?php if (!empty($history)): ?>
        <div class="glass-card">
            <h2 class="section-title">
                <i class="fas fa-history"></i>
                Historique
            </h2>

            <?php foreach ($history as $entry): ?>
            <div class="history-item">
                <div class="history-header">
                    <div class="history-user">
                        <i class="fas fa-user"></i>
                        <?php echo htmlspecialchars($entry['prenom'] . ' ' . $entry['nom']); ?>
                        <span style="opacity: 0.7; font-size: 0.9em;">(<?php echo $entry['role']; ?>)</span>
                    </div>
                    <div class="history-date">
                        <?php echo date('d/m/Y H:i', strtotime($entry['date_action'])); ?>
                    </div>
                </div>
                <div class="history-action">
                    <?php echo ucfirst(str_replace('_', ' ', $entry['action'])); ?>
                </div>
                <?php if ($entry['commentaire']): ?>
                <div class="history-comment">
                    "<?php echo htmlspecialchars($entry['commentaire']); ?>"
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Action Modal -->
    <div id="actionModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle">Action</h3>
                <button class="close-modal" onclick="closeActionModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form id="actionForm">
                <input type="hidden" id="actionType" name="action">
                <input type="hidden" name="request_id" value="<?php echo $request_id; ?>">
                
                <div class="form-group">
                    <label for="commentaire">
                        Commentaire 
                        <span id="commentaireRequired" style="color: #ef4444; display: none;">*</span>
                    </label>
                    <textarea 
                        id="commentaire" 
                        name="commentaire" 
                        placeholder="Ajoutez un commentaire (optionnel pour approbation, requis pour rejet)..."
                    ></textarea>
                </div>

                <div class="action-buttons">
                    <button type="submit" class="btn btn-primary" id="submitActionBtn">
                        <i class="fas fa-paper-plane"></i>
                        <span>Confirmer</span>
                    </button>
                    <button type="button" class="btn" style="background: #6b7280; color: white;" onclick="closeActionModal()">
                        <i class="fas fa-times"></i>
                        Annuler
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
    let currentAction = '';
    
    function openActionModal(action, title) {
        currentAction = action;
        document.getElementById('modalTitle').textContent = title;
        document.getElementById('actionType').value = action;
        
        // Check if comment is required (for rejections)
        const isRejection = action.includes('reject');
        const commentField = document.getElementById('commentaire');
        const commentRequired = document.getElementById('commentaireRequired');
        
        if (isRejection) {
            commentField.required = true;
            commentRequired.style.display = 'inline';
        } else {
            commentField.required = false;
            commentRequired.style.display = 'none';
        }
        
        // Clear previous values
        document.getElementById('actionForm').reset();
        document.getElementById('actionType').value = action;
        
        // Show modal
        document.getElementById('actionModal').classList.add('active');
    }
    
    function closeActionModal() {
        document.getElementById('actionModal').classList.remove('active');
        document.getElementById('actionForm').reset();
    }
    
    // Close modal on background click
    document.getElementById('actionModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeActionModal();
        }
    });
    
    // Handle form submission
    document.getElementById('actionForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const submitBtn = document.getElementById('submitActionBtn');
        const btnText = submitBtn.querySelector('span');
        const btnIcon = submitBtn.querySelector('i');
        
        // Disable button
        submitBtn.disabled = true;
        btnText.textContent = 'Traitement...';
        btnIcon.className = 'fas fa-spinner fa-spin';
        
        fetch('ajax_workflow_actions.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erreur HTTP: ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                showAlert('success', data.message);
                closeActionModal();
                
                // Reload page after 2 seconds
                setTimeout(() => {
                    window.location.reload();
                }, 2000);
            } else {
                showAlert('error', data.message || 'Une erreur est survenue');
                submitBtn.disabled = false;
                btnText.textContent = 'Confirmer';
                btnIcon.className = 'fas fa-paper-plane';
            }
        })
        .catch(error => {
            showAlert('error', 'Erreur réseau: ' + error.message);
            submitBtn.disabled = false;
            btnText.textContent = 'Confirmer';
            btnIcon.className = 'fas fa-paper-plane';
        });
    });
    
    function showAlert(type, message) {
        const alertBox = document.getElementById('alertMsg');
        alertBox.className = 'alert ' + type + ' show';
        alertBox.innerHTML = '<i class="fas fa-' + (type === 'success' ? 'check-circle' : 'exclamation-circle') + '"></i> ' + message;
        
        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
        
        // Auto hide after 5 seconds
        setTimeout(() => {
            alertBox.classList.remove('show');
        }, 5000);
    }
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // ESC to close modal
        if (e.key === 'Escape') {
            closeActionModal();
        }
    });
    </script>
</body>
</html>