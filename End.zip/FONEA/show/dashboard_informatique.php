<?php
require_once '../Config/session.php';
require_once '../modules/permission.php';

AuthMiddleware::requireRole('informatique');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'informatique') {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit();
}

$user_name = $_SESSION['nom_complet'] ?? 'Équipe Informatique';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Informatique - FONEA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="../assets/css/dashboard-common.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body.dashboard-informatique {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%);
            min-height: 100vh;
            color: #e2e8f0;
            position: relative;
            overflow-x: hidden;
        }

        
        .floating-particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            pointer-events: none;
        }

        .particle {
            position: absolute;
            background: radial-gradient(circle, rgba(59, 130, 246, 0.4), transparent);
            border-radius: 50%;
            animation: float linear infinite;
        }

        @keyframes float {
            0% {
                transform: translateY(100vh) scale(0);
                opacity: 0;
            }
            10% {
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                transform: translateY(-100px) scale(1);
                opacity: 0;
            }
        }

        
        .header-section {
            background: linear-gradient(135deg, rgba(30, 58, 138, 0.95) 0%, rgba(30, 64, 175, 0.95) 100%);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(59, 130, 246, 0.2);
            padding: 2.5rem 2rem;
            margin: 2rem;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.05);
            text-align: center;
            position: relative;
            z-index: 1;
        }

        .header-title {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.8rem;
            color: #ffffff;
            text-shadow: 0 2px 20px rgba(59, 130, 246, 0.5);
            letter-spacing: -0.5px;
        }

        .header-title i {
            color: #60a5fa;
            filter: drop-shadow(0 0 10px rgba(96, 165, 250, 0.6));
        }

        .header-subtitle {
            font-size: 1.1rem;
            color: #bfdbfe;
            margin-bottom: 1.5rem;
            font-weight: 400;
        }

        .btn-accueil {
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid rgba(255, 255, 255, 0.2);
            color: #ffffff;
            font-weight: 600;
            border-radius: 12px;
            padding: 0.75rem 2rem;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            backdrop-filter: blur(10px);
        }

        .btn-accueil:hover {
            background: rgba(255, 255, 255, 0.2);
            border-color: #60a5fa;
            color: #ffffff;
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(96, 165, 250, 0.3);
        }

        
        .dashboard-container {
            padding: 0 2rem 2rem;
            position: relative;
            z-index: 1;
        }

        
        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2.5rem;
        }

        .informatique-dashboard-card {
            background: linear-gradient(135deg, rgba(30, 41, 59, 0.9) 0%, rgba(51, 65, 85, 0.9) 100%);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(100, 116, 139, 0.3);
            border-radius: 16px;
            padding: 2rem;
            text-align: center;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            text-decoration: none;
            color: inherit;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
            min-height: 200px;
        }

        .informatique-dashboard-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, transparent 0%, rgba(59, 130, 246, 0.1) 100%);
            opacity: 0;
            transition: opacity 0.4s ease;
        }

        .informatique-dashboard-card:hover::before {
            opacity: 1;
        }

        .informatique-dashboard-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(96, 165, 250, 0.5);
            border-color: rgba(96, 165, 250, 0.6);
        }

        .card-icon {
            font-size: 3.5rem;
            margin-bottom: 1.5rem;
            display: block;
            color: var(--card-color, #60a5fa);
            transition: all 0.4s ease;
            filter: drop-shadow(0 4px 12px var(--card-shadow, rgba(96, 165, 250, 0.3)));
            position: relative;
            z-index: 1;
        }

        .informatique-dashboard-card:hover .card-icon {
            transform: scale(1.15) rotate(5deg);
            filter: drop-shadow(0 8px 20px var(--card-shadow, rgba(96, 165, 250, 0.5)));
        }

        .card-title {
            font-size: 1.35rem;
            font-weight: 700;
            margin-bottom: 0.75rem;
            color: #f1f5f9;
            position: relative;
            z-index: 1;
            letter-spacing: -0.3px;
        }

        .card-description {
            font-size: 0.95rem;
            color: #cbd5e1;
            line-height: 1.6;
            position: relative;
            z-index: 1;
            font-weight: 400;
        }

        
        .informatique-dashboard-card:nth-child(1) {
            --card-color: #3b82f6;
            --card-shadow: rgba(59, 130, 246, 0.3);
        }

        .informatique-dashboard-card:nth-child(2) {
            --card-color: #8b5cf6;
            --card-shadow: rgba(139, 92, 246, 0.3);
        }

        .informatique-dashboard-card:nth-child(3) {
            --card-color: #10b981;
            --card-shadow: rgba(16, 185, 129, 0.3);
        }

        .informatique-dashboard-card:nth-child(4) {
            --card-color: #f59e0b;
            --card-shadow: rgba(245, 158, 11, 0.3);
        }

        .informatique-dashboard-card:nth-child(5) {
            --card-color: #06b6d4;
            --card-shadow: rgba(6, 182, 212, 0.3);
        }

        .informatique-dashboard-card:nth-child(6) {
            --card-color: #ec4899;
            --card-shadow: rgba(236, 72, 153, 0.3);
        }

        
        .informatique-side-panel {
            background: linear-gradient(135deg, rgba(30, 41, 59, 0.95) 0%, rgba(51, 65, 85, 0.95) 100%);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(100, 116, 139, 0.3);
            border-radius: 20px;
            padding: 2.5rem;
            margin: 0 2rem 2rem;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
            position: relative;
            z-index: 1;
        }

        .section-title {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: #ffffff;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            letter-spacing: -0.3px;
        }

        .section-title i {
            color: #60a5fa;
            filter: drop-shadow(0 0 8px rgba(96, 165, 250, 0.4));
        }

        
        .form-label {
            color: #cbd5e1;
            font-weight: 600;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
        }

        .form-control {
            background: rgba(15, 23, 42, 0.6);
            border: 1px solid rgba(100, 116, 139, 0.4);
            color: #f1f5f9;
            border-radius: 10px;
            padding: 0.75rem 1rem;
            transition: all 0.3s ease;
            font-size: 0.95rem;
        }

        .form-control::placeholder {
            color: #64748b;
        }

        .form-control:focus {
            background: rgba(15, 23, 42, 0.8);
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
            color: #ffffff;
        }

       
        .btn {
            border-radius: 10px;
            font-weight: 600;
            padding: 0.75rem 1.5rem;
            transition: all 0.3s ease;
            border: none;
            text-decoration: none;
            font-size: 0.95rem;
        }

        .btn-primary {
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
            color: white;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(59, 130, 246, 0.4);
        }

        .btn-success {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
        }

        .btn-success:hover {
            background: linear-gradient(135deg, #059669 0%, #047857 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(16, 185, 129, 0.4);
        }

        .btn-danger {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: white;
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        .btn-danger:hover {
            background: linear-gradient(135deg, #dc2626 0%, #b91c1c 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(239, 68, 68, 0.4);
        }

        
        .alert {
            border-radius: 12px;
            border: none;
            padding: 1.25rem;
            font-weight: 500;
            backdrop-filter: blur(10px);
        }

        .alert-success {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.2) 0%, rgba(5, 150, 105, 0.2) 100%);
            color: #6ee7b7;
            border: 1px solid rgba(16, 185, 129, 0.3);
        }

        .alert-danger {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.2) 0%, rgba(220, 38, 38, 0.2) 100%);
            color: #fca5a5;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }

        .alert-primary {
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.2) 0%, rgba(37, 99, 235, 0.2) 100%);
            color: #93c5fd;
            border: 1px solid rgba(59, 130, 246, 0.3);
        }

        
        @media (max-width: 1200px) {
            .cards-grid {
                grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            }
        }

        @media (max-width: 768px) {
            .cards-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }

            .header-section,
            .informatique-side-panel,
            .dashboard-container {
                margin: 1rem;
                padding: 1.5rem;
            }

            .header-title {
                font-size: 1.8rem;
            }

            .header-subtitle {
                font-size: 0.95rem;
            }

            .card-icon {
                font-size: 2.8rem;
            }

            .card-title {
                font-size: 1.15rem;
            }

            .section-title {
                font-size: 1.25rem;
            }
        }
    </style>
</head>
<body class="dashboard-informatique">
    
    <div class="floating-particles"></div>

    
    <div class="header-section">
        <h1 class="header-title">
            <i class="fas fa-microchip me-3"></i>
            Dashboard Informatique
        </h1>
        <p class="header-subtitle">
            Bienvenue <?= htmlspecialchars($user_name) ?> - Centre de contrôle technique FONEA
        </p>
        <div class="mt-3">
            <a href="../layout/header.php" class="btn-accueil">
                <i class="fas fa-home me-2"></i>Accueil
            </a>
        </div>
    </div>

    
    <div class="dashboard-container">
        <div class="cards-grid">
            <a href="it_equipment.php" class="informatique-dashboard-card">
                <div class="card-icon">
                    <i class="fas fa-laptop-code"></i>
                </div>
                <h3 class="card-title">Gestion du Matériel</h3>
                <p class="card-description">Gérez le pack informatique et les équipements</p>
            </a>
            
            <a href="it_tickets.php" class="informatique-dashboard-card">
                <div class="card-icon">
                    <i class="fas fa-ticket-alt"></i>
                </div>
                <h3 class="card-title">Tickets Support</h3>
                <p class="card-description">Consultez et gérez les demandes de support</p>
            </a>
            
            <a href="it_network.php" class="informatique-dashboard-card">
                <div class="card-icon">
                    <i class="fas fa-network-wired"></i>
                </div>
                <h3 class="card-title">Réseau & Infrastructure</h3>
                <p class="card-description">Surveillez l'état du réseau et des serveurs</p>
            </a>
            
            <a href="it_licenses.php" class="informatique-dashboard-card">
                <div class="card-icon">
                    <i class="fas fa-key"></i>
                </div>
                <h3 class="card-title">Licences Logicielles</h3>
                <p class="card-description">Gérez les licences et abonnements</p>
            </a>
            
            <a href="it_backup.php" class="informatique-dashboard-card">
                <div class="card-icon">
                    <i class="fas fa-database"></i>
                </div>
                <h3 class="card-title">Sauvegardes</h3>
                <p class="card-description">Gérez les sauvegardes et la récupération</p>
            </a>
            
            <a href="it_reports.php" class="informatique-dashboard-card">
                <div class="card-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <h3 class="card-title">Rapports</h3>
                <p class="card-description">Statistiques et analyses techniques</p>
            </a>
        </div>
    </div>
   
    <div class="informatique-side-panel">
        <h4 class="section-title">
            <i class="fas fa-clipboard-check"></i>
            Analyses Techniques en cours
        </h4>
        <form id="itAnalysisForm" class="row g-3">
            <?= CSRFProtection::getInputField('it_analysis_action') ?>
            <div class="col-md-3">
                <label class="form-label">ID Demande</label>
                <input type="number" min="1" name="id_besoin" class="form-control" placeholder="Numéro de demande" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Note d'analyse technique</label>
                <input type="text" name="note" class="form-control" placeholder="Observations et recommandations techniques" required>
            </div>
            <div class="col-md-3">
                <label class="form-label">Actions</label>
                <div class="btn-group w-100">
                    <button class="btn btn-primary" name="action" value="save" type="submit">
                        <i class="fas fa-save me-1"></i>Enregistrer
                    </button>
                    <button class="btn btn-success" name="action" value="finalize" type="submit">
                        <i class="fas fa-check me-1"></i>Finaliser
                    </button>
                </div>
            </div>
        </form>
        <div id="itAnalysisMsg" class="mt-3"></div>
    </div>
    
    <div class="text-center mb-4">
        <a href="../public/logout.php" class="btn btn-danger">
            <i class="fas fa-sign-out-alt me-2"></i>Se déconnecter
        </a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        
        function createFloatingParticles() {
            const particlesContainer = document.querySelector('.floating-particles');
            const particleCount = 20;
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                const size = Math.random() * 4 + 2;
                particle.style.width = size + 'px';
                particle.style.height = size + 'px';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDelay = Math.random() * 20 + 's';
                particle.style.animationDuration = (Math.random() * 15 + 20) + 's';
                particlesContainer.appendChild(particle);
            }
        }
        
        document.addEventListener('DOMContentLoaded', createFloatingParticles);

        document.getElementById('itAnalysisForm')?.addEventListener('submit', async function(e) {
            e.preventDefault();
            const fd = new FormData(this);
            const action = e.submitter.value;
            try {
                const res = await fetch('../public/api_it_analysis.php', { 
                    method: 'POST', 
                    body: fd, 
                    headers: { 'X-Requested-With': 'XMLHttpRequest' } 
                });
                const data = await res.json();
                const box = document.getElementById('itAnalysisMsg');
                if (!res.ok || data.error) throw new Error(data?.error || 'Erreur');
                box.className = 'alert alert-success';
                if (action === 'save') {
                    box.innerHTML = '<i class="fas fa-check-circle me-2"></i>Analyse enregistrée avec succès.';
                } else if (action === 'finalize') {
                    box.innerHTML = '<i class="fas fa-check-double me-2"></i>Analyse finalisée. ' + 
                                   (data.new_status ? ('Nouveau statut: ' + data.new_status) : '');
                }
               
                this.reset();
            } catch (err) {
                const box = document.getElementById('itAnalysisMsg');
                box.className = 'alert alert-danger';
                box.innerHTML = '<i class="fas fa-exclamation-triangle me-2"></i>Action impossible: ' + err.message;
            }
        });
    </script>
</body>
</html>