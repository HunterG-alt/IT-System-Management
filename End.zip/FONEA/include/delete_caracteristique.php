<?php
header('Content-Type: application/json');
include '../Config/db.php'; // Connexion PDO
$data = json_decode(file_get_contents("php://input"), true);
if (isset($data['id'])) {
    $stmt = $pdo->prepare("DELETE FROM caracteristiques WHERE id = ?");
    $success = $stmt->execute([$data['id']]);
    echo json_encode(["success" => $success]);
} else {
    echo json_encode(["success" => false, "message" => "Paramètre ID manquant"]);
}
