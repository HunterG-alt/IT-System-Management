<?php
require_once '../Config/session.php';
require_once __DIR__ . '/../public/user.php';
require_once '../include/besoin.php';
require_once '../include/materiel.php';
session_start();
require_login();
// Validate role constants and check authorization
if (!defined('ROLE_DIRECTEUR_GENERAL')) {
    throw new Exception('Role constants not defined');
}
if ($_SESSION['role'] !== ROLE_DIRECTEUR_GENERAL) {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/error.php?error=unauthorized");
    exit;
}
// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
try {
    $user = User::getById($_SESSION['user_id']);
    if (!$user) {
        throw new Exception('User not found');
    }
    // Get comprehensive statistics
    $stats = [
        'total_users' => User::count(),
        'active_agents' => User::countByRole(ROLE_AGENT),
        'active_chefs' => User::countByRole(ROLE_CHEF),
        'active_directeurs' => User::countByRole(ROLE_DIRECTEUR),
        'total_besoins' => Besoin::count(),
        'besoins_this_month' => Besoin::countThisMonth(),
        'pending_validation' => Besoin::countByStatut('EN_ATTENTE'),
        'approved_today' => Besoin::countApprovedToday(),
        'average_processing_time' => Besoin::getAverageProcessingTime()
    ];
    // Get recent activities
    $recent_besoins = Besoin::getRecentWithDetails(10);
    $pending_approvals = Besoin::getPendingApprovals();
    $system_alerts = []; // This would come from a monitoring system
    // Performance metrics
    $performance_metrics = [
        'approval_rate' => Besoin::getApprovalRate(),
        'rejection_rate' => Besoin::getRejectionRate(),
        'average_response_time' => Besoin::getAverageResponseTime()
    ];
} catch (Exception $e) {
    error_log($e->getMessage());
    $error_message = "Erreur lors du chargement des données de supervision.";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supervision - FONEA</title>
    <link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .supervision-header {
            background: linear-gradient(135deg, #dc3545 0%, #6f42c1 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 20px 20px;
        }
        .metric-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            border-left: 4px solid #dc3545;
        }
        .metric-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        .metric-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: #dc3545;
            margin-bottom: 0.5rem;
        }
        .metric-label {
            font-size: 0.9rem;
            color: #6c757d;
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        .activity-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            max-height: 500px;
            overflow-y: auto;
        }
        .activity-item {
            padding: 1rem;
            border-left: 3px solid #e9ecef;
            margin-bottom: 1rem;
            background: #f8f9fa;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .activity-item:hover {
            border-left-color: #dc3545;
            background: #fff;
        }
        .activity-time {
            font-size: 0.8rem;
            color: #6c757d;
        }
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 25px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        .status-approved {
            background-color: #d1e7dd;
            color: #0f5132;
        }
        .status-rejected {
            background-color: #f8d7da;
            color: #842029;
        }
        .alert-item {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 10px;
        }
        .performance-gauge {
            text-align: center;
            padding: 2rem;
        }
        .gauge-circle {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            font-size: 2rem;
            font-weight: bold;
            color: white;
        }
        .gauge-excellent {
            background: linear-gradient(135deg, #28a745, #20c997);
        }
        .gauge-good {
            background: linear-gradient(135deg, #ffc107, #fd7e14);
        }
        .gauge-poor {
            background: linear-gradient(135deg, #dc3545, #e83e8c);
        }
        .section-title {
            font-size: 1.25rem;
            font-weight: 700;
            color: #333;
            margin-bottom: 1rem;
            padding-left: 15px;
            border-left: 4px solid #dc3545;
        }
        .quick-action-btn {
            width: 100%;
            height: 50px;
            border-radius: 10px;
            font-weight: 600;
            margin-bottom: 10px;
            transition: all 0.3s ease;
        }
        .quick-action-btn:hover {
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="supervision-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="mb-0"><i class="fas fa-crown me-3"></i>Supervision Générale</h1>
                    <p class="mb-0 mt-2 opacity-75">Vue d'ensemble des opérations et performances</p>
                </div>
                <div class="col-md-4 text-end">
                    <div class="d-none d-md-block">
                        <i class="fas fa-eye" style="font-size: 4rem; opacity: 0.2;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>
        <!-- Key Metrics -->
        <div class="row">
            <div class="col-12">
                <h3 class="section-title">Métriques clés</h3>
            </div>
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="metric-card text-center">
                    <div class="metric-number"><?php echo $stats['total_users'] ?? 0; ?></div>
                    <div class="metric-label">Utilisateurs total</div>
                    <i class="fas fa-users text-muted" style="font-size: 1.5rem; margin-top: 0.5rem;"></i>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="metric-card text-center">
                    <div class="metric-number"><?php echo $stats['total_besoins'] ?? 0; ?></div>
                    <div class="metric-label">Demandes total</div>
                    <i class="fas fa-file-alt text-muted" style="font-size: 1.5rem; margin-top: 0.5rem;"></i>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="metric-card text-center">
                    <div class="metric-number"><?php echo $stats['besoins_this_month'] ?? 0; ?></div>
                    <div class="metric-label">Ce mois-ci</div>
                    <i class="fas fa-calendar-month text-muted" style="font-size: 1.5rem; margin-top: 0.5rem;"></i>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="metric-card text-center">
                    <div class="metric-number"><?php echo $stats['pending_validation'] ?? 0; ?></div>
                    <div class="metric-label">En attente</div>
                    <i class="fas fa-clock text-muted" style="font-size: 1.5rem; margin-top: 0.5rem;"></i>
                </div>
            </div>
        </div>
        <!-- Performance Indicators -->
        <div class="row mt-4">
            <div class="col-12">
                <h3 class="section-title">Indicateurs de performance</h3>
            </div>
            <div class="col-12 col-md-4">
                <div class="metric-card">
                    <div class="performance-gauge">
                        <div class="gauge-circle <?php echo ($performance_metrics['approval_rate'] ?? 0) > 80 ? 'gauge-excellent' : (($performance_metrics['approval_rate'] ?? 0) > 60 ? 'gauge-good' : 'gauge-poor'); ?>">
                            <?php echo round($performance_metrics['approval_rate'] ?? 0); ?>%
                        </div>
                        <div class="metric-label">Taux d'approbation</div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <div class="metric-card">
                    <div class="performance-gauge">
                        <div class="gauge-circle <?php echo ($performance_metrics['average_response_time'] ?? 0) < 24 ? 'gauge-excellent' : (($performance_metrics['average_response_time'] ?? 0) < 48 ? 'gauge-good' : 'gauge-poor'); ?>">
                            <?php echo round($performance_metrics['average_response_time'] ?? 0); ?>h
                        </div>
                        <div class="metric-label">Temps de réponse moyen</div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <div class="metric-card">
                    <div class="performance-gauge">
                        <div class="gauge-circle <?php echo ($performance_metrics['rejection_rate'] ?? 0) < 15 ? 'gauge-excellent' : (($performance_metrics['rejection_rate'] ?? 0) < 30 ? 'gauge-good' : 'gauge-poor'); ?>">
                            <?php echo round($performance_metrics['rejection_rate'] ?? 0); ?>%
                        </div>
                        <div class="metric-label">Taux de rejet</div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Recent Activities and Alerts -->
        <div class="row mt-4">
            <div class="col-12 col-lg-6">
                <h3 class="section-title">Activités récentes</h3>
                <div class="activity-card">
                    <?php if (!empty($recent_besoins)): ?>
                        <?php foreach ($recent_besoins as $besoin): ?>
                            <div class="activity-item">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <strong><?php echo htmlspecialchars($besoin['titre'] ?? 'N/A'); ?></strong>
                                        <br>
                                        <small class="text-muted">
                                            Par <?php echo htmlspecialchars($besoin['agent_nom'] ?? 'N/A'); ?>
                                        </small>
                                    </div>
                                    <span class="status-badge <?php 
                                        echo $besoin['statut'] === 'EN_ATTENTE' ? 'status-pending' : 
                                             ($besoin['statut'] === 'APPROUVE' ? 'status-approved' : 'status-rejected'); 
                                    ?>">
                                        <?php echo htmlspecialchars($besoin['statut'] ?? 'N/A'); ?>
                                    </span>
                                </div>
                                <div class="activity-time mt-2">
                                    <i class="fas fa-clock me-1"></i>
                                    <?php echo date('d/m/Y H:i', strtotime($besoin['date_creation'] ?? 'now')); ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="text-center text-muted py-4">
                            <i class="fas fa-inbox fa-2x mb-2"></i>
                            <p>Aucune activité récente</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <h3 class="section-title">Actions rapides</h3>
                <div class="activity-card">
                    <a href="../include/demande.php" class="btn btn-outline-primary quick-action-btn">
                        <i class="fas fa-list me-2"></i>Voir toutes les demandes
                    </a>
                    <a href="../modules/rapports.php" class="btn btn-outline-info quick-action-btn">
                        <i class="fas fa-chart-bar me-2"></i>Générer un rapport détaillé
                    </a>
                    <a href="../modules/manage.php" class="btn btn-outline-dark quick-action-btn">
                        <i class="fas fa-cogs me-2"></i>Gérer le système
                    </a>
                    <a href="../view/historique.php" class="btn btn-outline-secondary quick-action-btn">
                        <i class="fas fa-history me-2"></i>Consulter l'historique
                    </a>
                    <?php if (!empty($pending_approvals)): ?>
                        <div class="mt-3">
                            <h5 class="text-warning">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                Demandes urgentes (<?php echo count($pending_approvals); ?>)
                            </h5>
                            <?php foreach (array_slice($pending_approvals, 0, 3) as $urgent): ?>
                                <div class="alert alert-warning py-2 mb-2">
                                    <small>
                                        <strong><?php echo htmlspecialchars($urgent['titre'] ?? 'N/A'); ?></strong>
                                        <br>En attente depuis <?php echo $urgent['days_pending'] ?? 0; ?> jour(s)
                                    </small>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <!-- Team Overview -->
        <div class="row mt-4">
            <div class="col-12">
                <h3 class="section-title">Vue d'ensemble de l'équipe</h3>
            </div>
            <div class="col-12 col-md-4">
                <div class="metric-card text-center">
                    <div class="metric-number text-primary"><?php echo $stats['active_agents'] ?? 0; ?></div>
                    <div class="metric-label">Agents actifs</div>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <div class="metric-card text-center">
                    <div class="metric-number text-warning"><?php echo $stats['active_chefs'] ?? 0; ?></div>
                    <div class="metric-label">Chefs de service</div>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <div class="metric-card text-center">
                    <div class="metric-number text-success"><?php echo $stats['active_directeurs'] ?? 0; ?></div>
                    <div class="metric-label">Directeurs</div>
                </div>
            </div>
        </div>
    </div>
    <!-- Scripts -->
    <script src="../../assets/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-refresh every 5 minutes
        setInterval(function() {
            if (document.hidden === false) {
                location.reload();
            }
        }, 300000);
        // Add loading animation for buttons
        document.querySelectorAll('.quick-action-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const originalText = this.innerHTML;
                this.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Chargement...';
                this.disabled = true;
                setTimeout(() => {
                    this.innerHTML = originalText;
                    this.disabled = false;
                }, 1000);
            });
        });
    </script>
</body>
</html>