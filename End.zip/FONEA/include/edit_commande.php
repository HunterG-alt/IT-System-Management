<?php
require_once '../Config/db.php';
session_start();
// Initialize variables
$errors = [];
$success = "";
$pdo = null;
try {
    // Get database connection
    if (class_exists('Database')) {
        $pdo = Database::getInstance()->getConnection();
    } else {
        // Fallback to global $pdo if Database class doesn't exist
        global $pdo;
        if (!$pdo) {
            throw new Exception("Database connection not available");
        }
    }
} catch (Exception $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}
// Authentication check
function checkAuth() {
    if (!isset($_SESSION['user_id']) && !isset($_SESSION['logged_in'])) {
        header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
        exit();
    }
}
checkAuth();
// Get current user info
$current_user = $_SESSION['user_id'] ?? 1;
// Get order ID from URL
$id_commande = (int)($_GET['id'] ?? 0);
if ($id_commande <= 0) {
    $_SESSION['message'] = "ID de commande invalide.";
    $_SESSION['message_type'] = "danger";
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/commande.php");
    exit();
}
// Retrieve the order to edit
$commande = null;
try {
    $stmt = $pdo->prepare("
        SELECT c.*, f.nom AS fournisseur_nom, m.nom AS materiel_nom
        FROM commande c
        LEFT JOIN fournisseur f ON c.id_fournisseur = f.id
        LEFT JOIN materiel m ON c.id_materiel = m.id
        WHERE c.id = :id
    ");
    $stmt->execute([':id' => $id_commande]);
    $commande = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$commande) {
        $_SESSION['message'] = "Commande introuvable.";
        $_SESSION['message_type'] = "danger";
        header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/commande.php");
        exit();
    }
} catch (PDOException $e) {
    $_SESSION['message'] = "Erreur lors du chargement de la commande : " . $e->getMessage();
    $_SESSION['message_type'] = "danger";
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/commande.php");
    exit();
}
// Retrieve suppliers
$fournisseurs = [];
try {
    $stmt = $pdo->query("SELECT * FROM fournisseur ORDER BY nom ASC");
    $fournisseurs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = "Erreur lors du chargement des fournisseurs : " . $e->getMessage();
}
// Retrieve materials
$materiels = [];
try {
    $stmt = $pdo->query("SELECT * FROM materiel ORDER BY nom ASC");
    $materiels = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = "Erreur lors du chargement des matériels : " . $e->getMessage();
}
// Handle order update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_fournisseur = trim($_POST['id_fournisseur'] ?? '');
    $id_materiel = trim($_POST['id_materiel'] ?? '');
    $quantite = trim($_POST['quantite'] ?? '');
    $date_commande = trim($_POST['date_commande'] ?? '');
    $prix_unitaire = trim($_POST['prix_unitaire'] ?? '0');
    $statut = trim($_POST['statut'] ?? 'en_attente');
    // Validation
    if (empty($id_fournisseur) || !is_numeric($id_fournisseur)) {
        $errors[] = "Veuillez sélectionner un fournisseur valide.";
    }
    if (empty($id_materiel) || !is_numeric($id_materiel)) {
        $errors[] = "Veuillez sélectionner un matériel valide.";
    }
    if (empty($quantite) || !is_numeric($quantite) || $quantite <= 0) {
        $errors[] = "La quantité doit être un nombre positif.";
    }
    if (empty($date_commande)) {
        $errors[] = "La date de commande est requise.";
    }
    if (!empty($prix_unitaire) && (!is_numeric($prix_unitaire) || $prix_unitaire < 0)) {
        $errors[] = "Le prix unitaire doit être un nombre positif.";
    }
    if (empty($statut)) {
        $errors[] = "Le statut est requis.";
    }
    // Verify that supplier and material exist
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM fournisseur WHERE id = :id");
            $stmt->execute([':id' => $id_fournisseur]);
            if ($stmt->fetchColumn() == 0) {
                $errors[] = "Fournisseur introuvable.";
            }
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM materiel WHERE id = :id");
            $stmt->execute([':id' => $id_materiel]);
            if ($stmt->fetchColumn() == 0) {
                $errors[] = "Matériel introuvable.";
            }
        } catch (PDOException $e) {
            $errors[] = "Erreur de validation : " . $e->getMessage();
        }
    }
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("
                UPDATE commande 
                SET id_fournisseur = :fournisseur, 
                    id_materiel = :materiel, 
                    quantite = :quantite, 
                    prix_unitaire = :prix_unitaire, 
                    date_commande = :date_commande, 
                    statut = :statut,
                    updated_at = NOW()
                WHERE id = :id
            ");
            $result = $stmt->execute([
                ':fournisseur' => $id_fournisseur,
                ':materiel' => $id_materiel,
                ':quantite' => $quantite,
                ':prix_unitaire' => $prix_unitaire,
                ':date_commande' => $date_commande,
                ':statut' => $statut,
                ':id' => $id_commande
            ]);
            if ($result) {
                $pdo->commit();
                $_SESSION['message'] = "Commande mise à jour avec succès.";
                $_SESSION['message_type'] = "success";
                header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/commande.php");
                exit();
            } else {
                throw new Exception("Erreur lors de la mise à jour");
            }
        } catch (PDOException $e) {
            $pdo->rollBack();
            $errors[] = "Erreur lors de la mise à jour de la commande : " . $e->getMessage();
        }
    }
}
// Get session messages
if (isset($_SESSION['message'])) {
    $success = $_SESSION['message'];
    $message_type = $_SESSION['message_type'] ?? 'info';
    unset($_SESSION['message'], $_SESSION['message_type']);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier la Commande #<?= $id_commande ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card {
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .form-section {
            background: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1><i class="fas fa-edit"></i> Modifier la Commande #<?= $id_commande ?></h1>
            <div>
                <a href="commande.php" class="btn btn-outline-secondary me-2">
                    <i class="fas fa-arrow-left"></i> Retour aux commandes
                </a>
                <a href="../dashboard.php" class="btn btn-outline-primary">
                    <i class="fas fa-home"></i> Dashboard
                </a>
            </div>
        </div>
        <!-- Messages -->
        <?php if (!empty($success)): ?>
            <div class="alert alert-<?= $message_type ?? 'success' ?> alert-dismissible fade show" role="alert">
                <?= htmlspecialchars($success) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?= implode('<br>', array_map('htmlspecialchars', $errors)) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <!-- Current Order Info -->
        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0"><i class="fas fa-info-circle"></i> Informations actuelles</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <strong>Fournisseur:</strong><br>
                        <?= htmlspecialchars($commande['fournisseur_nom'] ?? 'N/A') ?>
                    </div>
                    <div class="col-md-3">
                        <strong>Matériel:</strong><br>
                        <?= htmlspecialchars($commande['materiel_nom'] ?? 'N/A') ?>
                    </div>
                    <div class="col-md-2">
                        <strong>Quantité:</strong><br>
                        <?= $commande['quantite'] ?>
                    </div>
                    <div class="col-md-2">
                        <strong>Prix unitaire:</strong><br>
                        <?= $commande['prix_unitaire'] ? number_format($commande['prix_unitaire'], 2) . ' €' : 'N/A' ?>
                    </div>
                    <div class="col-md-2">
                        <strong>Statut:</strong><br>
                        <span class="badge bg-secondary"><?= ucfirst($commande['statut']) ?></span>
                    </div>
                </div>
            </div>
        </div>
        <!-- Edit Form -->
        <div class="form-section">
            <h4 class="mb-3"><i class="fas fa-edit"></i> Modifier la Commande</h4>
            <form method="POST" class="needs-validation" novalidate>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="id_fournisseur" class="form-label">Fournisseur *</label>
                        <select id="id_fournisseur" name="id_fournisseur" class="form-select" required>
                            <option value="">-- Sélectionner un fournisseur --</option>
                            <?php foreach ($fournisseurs as $f): ?>
                                <option value="<?= $f['id'] ?>" 
                                    <?= (isset($_POST['id_fournisseur']) ? $_POST['id_fournisseur'] : $commande['id_fournisseur']) == $f['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($f['nom']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback">Veuillez sélectionner un fournisseur.</div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="id_materiel" class="form-label">Matériel *</label>
                        <select id="id_materiel" name="id_materiel" class="form-select" required>
                            <option value="">-- Sélectionner un matériel --</option>
                            <?php foreach ($materiels as $m): ?>
                                <option value="<?= $m['id'] ?>" 
                                    <?= (isset($_POST['id_materiel']) ? $_POST['id_materiel'] : $commande['id_materiel']) == $m['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($m['nom']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback">Veuillez sélectionner un matériel.</div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label for="quantite" class="form-label">Quantité *</label>
                        <input type="number" id="quantite" name="quantite" class="form-control" 
                               min="1" step="1" 
                               value="<?= htmlspecialchars(isset($_POST['quantite']) ? $_POST['quantite'] : $commande['quantite']) ?>" 
                               required>
                        <div class="invalid-feedback">Veuillez saisir une quantité valide.</div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="prix_unitaire" class="form-label">Prix unitaire (€)</label>
                        <input type="number" id="prix_unitaire" name="prix_unitaire" class="form-control" 
                               min="0" step="0.01" 
                               value="<?= htmlspecialchars(isset($_POST['prix_unitaire']) ? $_POST['prix_unitaire'] : ($commande['prix_unitaire'] ?? '')) ?>" 
                               placeholder="0.00">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="date_commande" class="form-label">Date de commande *</label>
                        <input type="date" id="date_commande" name="date_commande" class="form-control" 
                               value="<?= htmlspecialchars(isset($_POST['date_commande']) ? $_POST['date_commande'] : $commande['date_commande']) ?>" 
                               required>
                        <div class="invalid-feedback">Veuillez saisir une date valide.</div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="statut" class="form-label">Statut *</label>
                        <select id="statut" name="statut" class="form-select" required>
                            <?php 
                            $statuts = [
                                'en_attente' => 'En attente',
                                'confirmee' => 'Confirmée',
                                'livree' => 'Livrée',
                                'annulee' => 'Annulée'
                            ];
                            $current_statut = isset($_POST['statut']) ? $_POST['statut'] : $commande['statut'];
                            ?>
                            <?php foreach ($statuts as $value => $label): ?>
                                <option value="<?= $value ?>" <?= $current_statut == $value ? 'selected' : '' ?>>
                                    <?= $label ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback">Veuillez sélectionner un statut.</div>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Mettre à jour
                    </button>
                    <a href="commande.php" class="btn btn-outline-secondary">
                        <i class="fas fa-times"></i> Annuler
                    </a>
                </div>
            </form>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script>
        // Form validation
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                var forms = document.getElementsByClassName('needs-validation');
                Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();
        // Confirmation before leaving with unsaved changes
        let formChanged = false;
        const form = document.querySelector('form');
        const originalValues = new FormData(form);
        form.addEventListener('input', function() {
            const currentValues = new FormData(form);
            formChanged = false;
            for (let [key, value] of currentValues.entries()) {
                if (originalValues.get(key) !== value) {
                    formChanged = true;
                    break;
                }
            }
        });
        window.addEventListener('beforeunload', function(e) {
            if (formChanged) {
                e.preventDefault();
                e.returnValue = '';
            }
        });
        // Reset form changed flag on submit
        form.addEventListener('submit', function() {
            formChanged = false;
        });
    </script>
</body>
</html>