<?php
// Boot session and dependencies
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Config/config.php';
// Load User class without rendering the user page
if (!defined('USER_BYPASS_GUARD')) { define('USER_BYPASS_GUARD', true); }
require_once __DIR__ . '/user.php';
require_once __DIR__ . '/../include/besoin.php';
require_once __DIR__ . '/../include/materiel.php';
// Vérification de la connexion
require_login();
// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
// Variables par défaut
$stats = ['en_attente' => 0, 'approuve' => 0, 'rejete' => 0];
$user = null;
try {
    // Vérifier si user_id existe dans la session
    if (!isset($_SESSION['user_id'])) {
        throw new Exception('Session utilisateur invalide');
    }
    $user = User::getById($_SESSION['user_id']);
    if (!$user) {
        throw new Exception('Utilisateur non trouvé');
    }
    // Cache stats for 5 minutes to improve performance
    $cache_key = 'dashboard_stats_' . $_SESSION['user_id'];
    $cache_expired = !isset($_SESSION[$cache_key]) || 
                     !isset($_SESSION[$cache_key]['timestamp']) || 
                     (time() - $_SESSION[$cache_key]['timestamp'] > 300);
    if ($cache_expired) {
        // Vérifier si les méthodes existent avant de les appeler
        if (class_exists('Besoin') && method_exists('Besoin', 'countByStatut')) {
            $stats = [
                'en_attente' => Besoin::countByStatut('EN_ATTENTE') ?: 0,
                'approuve' => Besoin::countByStatut('APPROUVE') ?: 0,
                'rejete' => Besoin::countByStatut('REJETE') ?: 0
            ];
        }
        $_SESSION[$cache_key] = [
            'data' => $stats,
            'timestamp' => time()
        ];
    } else {
        $stats = $_SESSION[$cache_key]['data'];
    }
} catch (Exception $e) {
    error_log('Dashboard Error: ' . $e->getMessage());
    // Redirection plus sécurisée
    if (headers_sent()) {
        echo '<script>window.location.href="error.php";</script>';
        exit;
    }
    header('Location: error.php?msg=' . urlencode('Erreur de chargement du dashboard'));
    exit;
}
// Sécurité : s'assurer que $user n'est pas null
if (!$user) {
header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - FONEA</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Ajout du token CSRF dans un meta tag pour JS -->
    <meta name="csrf-token" content="<?php echo $_SESSION['csrf_token']; ?>">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .dashboard-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 20px 20px;
        }
        .stat-card {
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            transition: all 0.3s ease;
            border: none;
            overflow: hidden;
            position: relative;
            cursor: pointer;
        }
        .stat-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.15);
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, rgba(255,255,255,0.3), rgba(255,255,255,0.7), rgba(255,255,255,0.3));
        }
        .stat-card h3 {
            font-size: 1.3rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }
        .stat-number {
            font-size: 3rem;
            font-weight: 700;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }
        .stat-icon {
            font-size: 2.5rem;
            opacity: 0.3;
            position: absolute;
            top: 20px;
            right: 20px;
        }
        .action-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            border: 1px solid rgba(0,0,0,0.05);
        }
        .action-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        .action-btn {
            width: 100%;
            height: 60px;
            border-radius: 10px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            border: none;
            position: relative;
            overflow: hidden;
        }
        .action-btn:hover {
            transform: translateY(-2px);
        }
        .action-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }
        .action-btn:hover::before {
            left: 100%;
        }
        .welcome-section {
            background: white;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            margin-bottom: 2rem;
        }
        .role-badge {
            display: inline-block;
            padding: 0.5rem 1rem;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-radius: 25px;
            font-size: 0.9rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        @media (max-width: 768px) {
            .stat-number {
                font-size: 2.5rem;
            }
            .dashboard-header {
                padding: 1.5rem 0;
            }
            .welcome-section {
                padding: 1.5rem;
            }
        }
        .bg-pending {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }
        .bg-approved {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }
        .bg-rejected {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
        }
        .section-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: #333;
            margin-bottom: 1.5rem;
            position: relative;
            padding-left: 20px;
        }
        .section-title::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 4px;
            height: 30px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 2px;
        }
        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <div class="dashboard-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="mb-0"><i class="fas fa-tachometer-alt me-3"></i>Dashboard FONEA</h1>
                    <p class="mb-0 mt-2 opacity-75">Tableau de bord de gestion des demandes</p>
                </div>
                <div class="col-md-4 text-end">
                    <div class="d-none d-md-block">
                        <i class="fas fa-chart-line" style="font-size: 4rem; opacity: 0.2;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <!-- Welcome Section -->
        <div class="welcome-section">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h2 class="mb-3">
                        <i class="fas fa-user-circle me-2 text-primary"></i>
                        Bienvenue, <?php echo htmlspecialchars($user['prenom'] ?? 'Utilisateur', ENT_QUOTES, 'UTF-8'); ?>
                    </h2>
                    <p class="mb-0">
                        <strong>Rôle :</strong> 
                        <span class="role-badge"><?php echo htmlspecialchars($user['role'] ?? 'Non défini', ENT_QUOTES, 'UTF-8'); ?></span>
                    </p>
                </div>
                <div class="col-md-4 text-end">
                    <div class="text-muted">
                        <i class="fas fa-calendar-alt me-2"></i>
                        <?php echo date('d/m/Y H:i'); ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- Statistics Cards -->
        <h3 class="section-title">Statistiques des demandes</h3>
        <div class="row">
            <div class="col-12 col-sm-6 col-lg-4">
                <div class="stat-card p-4 text-center bg-pending text-white position-relative" 
                     role="button" tabindex="0" 
                     data-url="demandes.php?statut=EN_ATTENTE"
                     aria-label="Voir les demandes en attente">
                    <i class="fas fa-clock stat-icon"></i>
                    <h3>En attente</h3>
                    <div class="stat-number" aria-labelledby="pending-label">
                        <?php echo (int)$stats['en_attente']; ?>
                    </div>
                    <a href="demandes.php?statut=EN_ATTENTE" class="btn btn-light btn-sm mt-3">
                        <i class="fas fa-eye me-2"></i>Voir les détails
                    </a>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-lg-4">
                <div class="stat-card p-4 text-center bg-approved text-white position-relative"
                     role="button" tabindex="0"
                     data-url="demande.php?statut=APPROUVE"
                     aria-label="Voir les demandes approuvées">
                    <i class="fas fa-check-circle stat-icon"></i>
                    <h3>Approuvées</h3>
                    <div class="stat-number" aria-labelledby="approved-label">
                        <?php echo (int)$stats['approuve']; ?>
                    </div>
                    <a href="demande.php?statut=APPROUVE" class="btn btn-light btn-sm mt-3">
                        <i class="fas fa-eye me-2"></i>Voir les détails
                    </a>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-lg-4">
                <div class="stat-card p-4 text-center bg-rejected text-white position-relative"
                     role="button" tabindex="0"
                     data-url="demande.php?statut=REJETE"
                     aria-label="Voir les demandes rejetées">
                    <i class="fas fa-times-circle stat-icon"></i>
                    <h3>Rejetées</h3>
                    <div class="stat-number" aria-labelledby="rejected-label">
                        <?php echo (int)$stats['rejete']; ?>
                    </div>
                    <a href="demande.php?statut=REJETE" class="btn btn-light btn-sm mt-3">
                        <i class="fas fa-eye me-2"></i>Voir les détails
                    </a>
                </div>
            </div>
        </div>
        <!-- Quick Actions -->
        <h3 class="section-title mt-5">Actions rapides</h3>
        <div class="row">
            <?php 
            // FIXED: Sécuriser la vérification du rôle
            $userRole = $user['role'] ?? '';
            ?>
            <?php if ($userRole === 'demandeur'): ?>
                <!-- Agent -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="action-card">
                        <div class="text-center">
                            <i class="fas fa-plus-circle text-primary" style="font-size: 2rem;"></i>
                            <h5 class="mt-3 mb-3">Nouveau besoin</h5>
<a href="<?= $create_url ?>" class="action-btn btn btn-primary">
                                <i class="fas fa-plus me-2"></i>Créer un état de besoin
                            </a>
                        </div>
                    </div>
                </div>
            <?php elseif ($userRole === 'chef_service'): ?>
                <!-- Chef de Service -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="action-card">
                        <div class="text-center">
                            <i class="fas fa-clipboard-check text-warning" style="font-size: 2rem;"></i>
                            <h5 class="mt-3 mb-3">Pre-Validation</h5>
<a href="<?= BASE_URL ?>/modules/pre_validation.php" class="action-btn btn btn-warning">
                                <i class="fas fa-check me-2"></i>Valider les demandes
                            </a>
                        </div>
                    </div>
                </div>
            <?php elseif ($userRole === 'directeur'): ?>
                <!-- Directeur -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="action-card">
                        <div class="text-center">
                            <i class="fas fa-gavel text-success" style="font-size: 2rem;"></i>
                            <h5 class="mt-3 mb-3">Approbation</h5>
<a href="<?= BASE_URL ?>/modules/approve.php" class="action-btn btn btn-success">
                                <i class="fas fa-thumbs-up me-2"></i>Approuver / Rejeter
                            </a>
                        </div>
                    </div>
                </div>
            <?php elseif ($userRole === 'directeur_general'): ?>
                <!-- Directeur Général -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="action-card">
                        <div class="text-center">
                            <i class="fas fa-crown text-danger" style="font-size: 2rem;"></i>
                            <h5 class="mt-3 mb-3">Supervision</h5>
<a href="<?= BASE_URL ?>/modules/supervise.php" class="action-btn btn btn-danger">
                                <i class="fas fa-eye me-2"></i>Superviser
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="action-card">
                        <div class="text-center">
                            <i class="fas fa-users-cog text-dark" style="font-size: 2rem;"></i>
                            <h5 class="mt-3 mb-3">Gestion</h5>
<a href="<?= BASE_URL ?>/modules/manage.php" class="action-btn btn btn-dark">
                                <i class="fas fa-cogs me-2"></i>Gérer le système
                            </a>
                        </div>
                    </div>
                </div>
            <?php elseif ($userRole === 'moyens_generaux'): ?>
                <!-- Moyens Généraux -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="action-card">
                        <div class="text-center">
                            <i class="fas fa-boxes text-primary" style="font-size: 2rem;"></i>
                            <h5 class="mt-3 mb-3">Gestion des moyens</h5>
<a href="<?= BASE_URL ?>/modules/moyens.php" class="action-btn btn btn-primary">
                                <i class="fas fa-tools me-2"></i>Gérer le matériel
                            </a>
                        </div>
                    </div>
                </div>
            <?php elseif ($userRole === 'informatique'): ?>
                <!-- Informatique -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="action-card">
                        <div class="text-center">
                            <i class="fas fa-laptop-code text-success" style="font-size: 2rem;"></i>
                            <h5 class="mt-3 mb-3">Support Informatique</h5>
<a href="<?= BASE_URL ?>/modules/it_support.php" class="action-btn btn btn-success">
                                <i class="fas fa-headset me-2"></i>Assistance IT
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script>
        // Stat cards click navigation
        document.querySelectorAll('.stat-card').forEach(card => {
            card.addEventListener('click', function(e) {
                if (!e.target.closest('a')) {
                    window.location.href = this.dataset.url;
                }
            });
            card.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    window.location.href = this.dataset.url;
                }
            });
        });
    </script>
</body>
</html>