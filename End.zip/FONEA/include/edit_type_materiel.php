edit type de materiel.php: 
<?php
require_once '../Config/db.php';
require_login();
$pdo = Database::getInstance()->getConnection();
$errors = [];
$success = "";
// Vérifier que l'ID est fourni
$id = $_GET['id'] ?? null;
if (!$id) {
    die("ID type manquant.");
}
// Récupérer le type existant
try {
    $stmt = $pdo->prepare("SELECT * FROM Type_Materiel WHERE id_type = :id");
    $stmt->execute([':id' => $id]);
    $type = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$type) {
        die("Type de matériel non trouvé.");
    }
} catch (PDOException $e) {
    die("Erreur : " . $e->getMessage());
}
// Traitement de modification
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom_type = trim($_POST['nom_type'] ?? '');
    if (empty($nom_type)) $errors[] = "Le nom du type est requis.";
    // Vérifier si le nom existe déjà (sauf pour le type actuel)
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("SELECT id_type FROM Type_Materiel WHERE nom_type = :nom_type AND id_type != :id");
            $stmt->execute([':nom_type' => $nom_type, ':id' => $id]);
            if ($stmt->fetch()) {
                $errors[] = "Ce nom de type existe déjà.";
            }
        } catch (PDOException $e) {
            $errors[] = "Erreur de vérification : " . $e->getMessage();
        }
    }
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("UPDATE Type_Materiel SET nom_type = :nom_type WHERE id_type = :id");
            $stmt->execute([
                ':nom_type' => $nom_type,
                ':id' => $id
            ]);
            $success = "Type de matériel mis à jour avec succès.";
            $type['nom_type'] = $nom_type;
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de la mise à jour : " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier Type de Matériel</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        form { max-width: 400px; }
        input[type="text"] { width: 100%; padding: 8px; margin: 5px 0; }
        input[type="submit"] { padding: 10px 15px; background-color: #4CAF50; color: white; border: none; cursor: pointer; }
        .error { color: red; }
        .success { color: green; }
        a { text-decoration: none; color: #2196F3; }
    </style>
</head>
<body>
    <h1>Modifier Type de Matériel</h1>
    <?php if ($success) echo "<p class='success'>$success</p>"; ?>
    <?php if (!empty($errors)) echo "<p class='error'>" . implode('<br>', $errors) . "</p>"; ?>
    <form method="POST" action="">
        <label for="nom_type">Nom du Type:</label>
        <input type="text" id="nom_type" name="nom_type" value="<?= htmlspecialchars($type['nom_type']) ?>" required>
        <input type="submit" value="Mettre à jour">
    </form>
    <p><a href="type_materiel.php">← Retour à la liste</a></p>
</body>
</html>