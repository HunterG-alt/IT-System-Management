save.php
<?php
function saveWorkflow(int $id_etat, string $from_statut, string $to_statut, int $actor_user_id, ?string $commentaire = null): bool {
    try {
        $pdo = db(); // Using the same db() function as in your other files
        // Utiliser un nom de table sécurisé
        $sql = "
            INSERT INTO workflow_logs (id_etat, from_statut, to_statut, actor_user_id, commentaire, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ";
        $stmt = $pdo->prepare($sql);
        return $stmt->execute([$id_etat, $from_statut, $to_statut, $actor_user_id, $commentaire]);
    } catch (PDOException $e) {
        error_log("Erreur saveWorkflow: " . $e->getMessage());
        return false;
    }
}
?>