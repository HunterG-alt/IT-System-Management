<?php
require_once '../Config/session.php';
require_once __DIR__ . '/../public/user.php';
require_once '../include/besoin.php';
require_once '../include/materiel.php';
session_start();
require_login();
// Validate role constants and check authorization
if (!defined('ROLE_DIRECTEUR_GENERAL')) {
    throw new Exception('Role constants not defined');
}
if ($_SESSION['role'] !== ROLE_DIRECTEUR_GENERAL) {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/error.php?error=unauthorized");
    exit;
}
// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
// Handle form submissions
$message = '';
$message_type = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
    try {
        if (isset($_POST['action'])) {
            switch ($_POST['action']) {
                case 'create_user':
                    $result = User::create([
                        'nom' => $_POST['nom'],
                        'prenom' => $_POST['prenom'],
                        'email' => $_POST['email'],
                        'role' => $_POST['role'],
                        'password' => password_hash($_POST['password'], PASSWORD_DEFAULT)
                    ]);
                    if ($result) {
                        $message = "Utilisateur créé avec succès.";
                        $message_type = "success";
                    }
                    break;
                case 'update_user_role':
                    $result = User::updateRole($_POST['user_id'], $_POST['new_role']);
                    if ($result) {
                        $message = "Rôle utilisateur mis à jour avec succès.";
                        $message_type = "success";
                    }
                    break;
                case 'disable_user':
                    $result = User::disable($_POST['user_id']);
                    if ($result) {
                        $message = "Utilisateur désactivé avec succès.";
                        $message_type = "success";
                    }
                    break;
                case 'enable_user':
                    $result = User::enable($_POST['user_id']);
                    if ($result) {
                        $message = "Utilisateur activé avec succès.";
                        $message_type = "success";
                    }
                    break;
                case 'bulk_action':
                    if ($_POST['bulk_action'] === 'delete' && !empty($_POST['selected_users'])) {
                        $deleted = User::deleteMultiple($_POST['selected_users']);
                        $message = "$deleted utilisateur(s) supprimé(s) avec succès.";
                        $message_type = "success";
                    }
                    break;
            }
        }
    } catch (Exception $e) {
        $message = "Erreur : " . $e->getMessage();
        $message_type = "danger";
    }
}
try {
    $current_user = User::getById($_SESSION['user_id']);
    if (!$current_user) {
        throw new Exception('User not found');
    }
    // Get system statistics
    $system_stats = [
        'total_users' => User::count(),
        'active_users' => User::countActive(),
        'inactive_users' => User::countInactive(),
        'total_requests_today' => Besoin::countToday(),
        'system_uptime' => 99.8, // This would come from actual monitoring
        'last_backup' => date('Y-m-d H:i:s', strtotime('-2 hours')), // Mock data
        'disk_usage' => 67, // Percentage
        'database_size' => '2.3 GB'
    ];
    // Get all users for management
    $all_users = User::getAll();
    // Get recent system activities
    $recent_activities = User::getRecentActivities(10);
} catch (Exception $e) {
    error_log($e->getMessage());
    $error_message = "Erreur lors du chargement des données système.";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion Système - FONEA</title>
    <link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .management-header {
            background: linear-gradient(135deg, #343a40 0%, #495057 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 20px 20px;
        }
        .management-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
        }
        .management-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        .system-stat {
            text-align: center;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1rem;
            border-left: 4px solid #343a40;
        }
        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: #343a40;
        }
        .stat-label {
            font-size: 0.9rem;
            color: #6c757d;
            margin-top: 0.5rem;
        }
        .user-table {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }
        .table th {
            background-color: #343a40;
            color: white;
            border: none;
            font-weight: 600;
        }
        .table td {
            vertical-align: middle;
            border-color: #e9ecef;
        }
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #343a40, #495057);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        .role-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 25px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        .role-agent {
            background-color: #cff4fc;
            color: #055160;
        }
        .role-chef {
            background-color: #fff3cd;
            color: #664d03;
        }
        .role-directeur {
            background-color: #d1e7dd;
            color: #0a3622;
        }
        .role-directeur-general {
            background-color: #f8d7da;
            color: #58151c;
        }
        .status-active {
            color: #198754;
        }
        .status-inactive {
            color: #dc3545;
        }
        .section-title {
            font-size: 1.25rem;
            font-weight: 700;
            color: #333;
            margin-bottom: 1rem;
            padding-left: 15px;
            border-left: 4px solid #343a40;
        }
        .quick-action-btn {
            width: 100%;
            height: 50px;
            border-radius: 10px;
            font-weight: 600;
            margin-bottom: 10px;
            transition: all 0.3s ease;
        }
        .quick-action-btn:hover {
            transform: translateY(-2px);
        }
        .form-floating {
            margin-bottom: 1rem;
        }
        .progress-bar-animated {
            animation: progress-bar-stripes 1s linear infinite;
        }
        @keyframes progress-bar-stripes {
            0% { background-position: 1rem 0; }
            100% { background-position: 0 0; }
        }
    </style>
</head>
<body>
    <?php include '../../Include/navbar.php'; ?>
    <div class="management-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="mb-0"><i class="fas fa-cogs me-3"></i>Gestion Système</h1>
                    <p class="mb-0 mt-2 opacity-75">Administration et configuration du système FONEA</p>
                </div>
                <div class="col-md-4 text-end">
                    <div class="d-none d-md-block">
                        <i class="fas fa-server" style="font-size: 4rem; opacity: 0.2;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>
        <?php if (!empty($message)): ?>
            <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-triangle'; ?> me-2"></i>
                <?php echo htmlspecialchars($message); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <!-- System Overview -->
        <div class="row">
            <div class="col-12">
                <h3 class="section-title">Vue d'ensemble du système</h3>
            </div>
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="system-stat">
                    <div class="stat-number"><?php echo $system_stats['total_users']; ?></div>
                    <div class="stat-label">Utilisateurs total</div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="system-stat">
                    <div class="stat-number text-success"><?php echo $system_stats['active_users']; ?></div>
                    <div class="stat-label">Utilisateurs actifs</div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="system-stat">
                    <div class="stat-number text-warning"><?php echo $system_stats['total_requests_today']; ?></div>
                    <div class="stat-label">Demandes aujourd'hui</div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="system-stat">
                    <div class="stat-number text-info"><?php echo $system_stats['system_uptime']; ?>%</div>
                    <div class="stat-label">Disponibilité système</div>
                </div>
            </div>
        </div>
        <!-- System Status -->
        <div class="row mt-4">
            <div class="col-12 col-md-6">
                <div class="management-card">
                    <h5 class="mb-3"><i class="fas fa-server me-2"></i>État du système</h5>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span>Utilisation disque</span>
                            <span><?php echo $system_stats['disk_usage']; ?>%</span>
                        </div>
                        <div class="progress" style="height: 8px;">
                            <div class="progress-bar bg-<?php echo $system_stats['disk_usage'] > 80 ? 'danger' : ($system_stats['disk_usage'] > 60 ? 'warning' : 'success'); ?>" 
                                 style="width: <?php echo $system_stats['disk_usage']; ?>%"></div>
                        </div>
                    </div>
                    <div class="row text-center">
                        <div class="col-6">
                            <small class="text-muted">Taille base de données</small>
                            <div class="fw-bold"><?php echo $system_stats['database_size']; ?></div>
                        </div>
                        <div class="col-6">
                            <small class="text-muted">Dernière sauvegarde</small>
                            <div class="fw-bold"><?php echo date('H:i', strtotime($system_stats['last_backup'])); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="management-card">
                    <h5 class="mb-3"><i class="fas fa-tools me-2"></i>Actions système</h5>
                    <button class="quick-action-btn btn btn-primary" onclick="performBackup()">
                        <i class="fas fa-download me-2"></i>Créer une sauvegarde
                    </button>
                    <button class="quick-action-btn btn btn-warning" onclick="clearCache()">
                        <i class="fas fa-broom me-2"></i>Vider le cache
                    </button>
                    <button class="quick-action-btn btn btn-info" onclick="generateReport()">
                        <i class="fas fa-file-export me-2"></i>Exporter rapport système
                    </button>
                    <button class="quick-action-btn btn btn-secondary" onclick="viewLogs()">
                        <i class="fas fa-file-alt me-2"></i>Consulter les logs
                    </button>
                </div>
            </div>
        </div>
        <!-- User Management -->
        <div class="row mt-4">
            <div class="col-12">
                <h3 class="section-title">Gestion des utilisateurs</h3>
            </div>
            <div class="col-12 col-lg-4">
                <div class="management-card">
                    <h5 class="mb-3"><i class="fas fa-user-plus me-2"></i>Créer un utilisateur</h5>
                    <form method="POST" id="createUserForm">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        <input type="hidden" name="action" value="create_user">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="nom" name="nom" required>
                            <label for="nom">Nom</label>
                        </div>
                        <div class="form-floating">
                            <input type="text" class="form-control" id="prenom" name="prenom" required>
                            <label for="prenom">Prénom</label>
                        </div>
                        <div class="form-floating">
                            <input type="email" class="form-control" id="email" name="email" required>
                            <label for="email">Email</label>
                        </div>
                        <div class="form-floating">
                            <select class="form-select" id="role" name="role" required>
                                <option value="">Sélectionner un rôle</option>
                                <option value="<?php echo ROLE_AGENT; ?>">Agent</option>
                                <option value="<?php echo ROLE_CHEF; ?>">Chef de service</option>
                                <option value="<?php echo ROLE_DIRECTEUR; ?>">Directeur</option>
                            </select>
                            <label for="role">Rôle</label>
                        </div>
                        <div class="form-floating">
                            <input type="password" class="form-control" id="password" name="password" required>
                            <label for="password">Mot de passe</label>
                        </div>
                        <button type="submit" class="btn btn-success w-100">
                            <i class="fas fa-plus me-2"></i>Créer l'utilisateur
                        </button>
                    </form>
                </div>
            </div>
            <div class="col-12 col-lg-8">
                <div class="user-table">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>
                                        <input type="checkbox" id="selectAll" class="form-check-input">
                                    </th>
                                    <th>Utilisateur</th>
                                    <th>Email</th>
                                    <th>Rôle</th>
                                    <th>Statut</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($all_users)): ?>
                                    <?php foreach ($all_users as $user): ?>
                                        <tr>
                                            <td>
                                                <input type="checkbox" class="form-check-input user-checkbox" 
                                                       value="<?php echo $user['id']; ?>">
                                            </td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="user-avatar me-3">
                                                        <?php echo strtoupper(substr($user['prenom'], 0, 1)); ?>
                                                    </div>
                                                    <div>
                                                        <div class="fw-bold">
                                                            <?php echo htmlspecialchars($user['prenom'] . ' ' . $user['nom']); ?>
                                                        </div>
                                                        <small class="text-muted">
                                                            ID: <?php echo $user['id']; ?>
                                                        </small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                                            <td>
                                                <span class="role-badge role-<?php echo strtolower(str_replace('_', '-', $user['role'])); ?>">
                                                    <?php echo htmlspecialchars($user['role']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <i class="fas fa-circle <?php echo $user['is_active'] ? 'status-active' : 'status-inactive'; ?>"></i>
                                                <?php echo $user['is_active'] ? 'Actif' : 'Inactif'; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <button class="btn btn-outline-primary" 
                                                            onclick="editUser(<?php echo $user['id']; ?>)" 
                                                            title="Modifier">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <?php if ($user['is_active']): ?>
                                                        <button class="btn btn-outline-warning" 
                                                                onclick="toggleUserStatus(<?php echo $user['id']; ?>, 'disable')" 
                                                                title="Désactiver">
                                                            <i class="fas fa-pause"></i>
                                                        </button>
                                                    <?php else: ?>
                                                        <button class="btn btn-outline-success" 
                                                                onclick="toggleUserStatus(<?php echo $user['id']; ?>, 'enable')" 
                                                                title="Activer">
                                                            <i class="fas fa-play"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                    <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                                        <button class="btn btn-outline-danger" 
                                                                onclick="deleteUser(<?php echo $user['id']; ?>)" 
                                                                title="Supprimer">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted py-4">
                                            Aucun utilisateur trouvé
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- Bulk Actions -->
                    <div class="p-3 border-top bg-light">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <small class="text-muted">
                                    <span id="selectedCount">0</span> utilisateur(s) sélectionné(s)
                                </small>
                            </div>
                            <div class="col-md-6 text-end">
                                <form method="POST" class="d-inline" id="bulkActionForm">
                                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                    <input type="hidden" name="action" value="bulk_action">
                                    <input type="hidden" name="selected_users" id="selectedUsers">
                                    <div class="btn-group btn-group-sm">
                                        <button type="button" class="btn btn-outline-danger" onclick="bulkDelete()" id="bulkDeleteBtn" disabled>
                                            <i class="fas fa-trash me-1"></i>Supprimer sélection
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Recent Activities -->
        <?php if (!empty($recent_activities)): ?>
        <div class="row mt-4">
            <div class="col-12">
                <h3 class="section-title">Activités récentes du système</h3>
            </div>
            <div class="col-12">
                <div class="management-card">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Utilisateur</th>
                                    <th>Action</th>
                                    <th>Date/Heure</th>
                                    <th>IP</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_activities as $activity): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($activity['user_name'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($activity['action'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($activity['created_at'] ?? 'N/A'); ?></td>
                                        <td><code><?php echo htmlspecialchars($activity['ip_address'] ?? 'N/A'); ?></code></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <!-- Edit User Modal -->
    <div class="modal fade" id="editUserModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Modifier l'utilisateur</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="editUserForm">
                    <div class="modal-body">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        <input type="hidden" name="action" value="update_user_role">
                        <input type="hidden" name="user_id" id="editUserId">
                        <div class="form-floating mb-3">
                            <select class="form-select" id="editUserRole" name="new_role" required>
                                <option value="<?php echo ROLE_AGENT; ?>">Agent</option>
                                <option value="<?php echo ROLE_CHEF; ?>">Chef de service</option>
                                <option value="<?php echo ROLE_DIRECTEUR; ?>">Directeur</option>
                            </select>
                            <label for="editUserRole">Nouveau rôle</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Mettre à jour</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Scripts -->
    <script src="../../assets/js/bootstrap.bundle.min.js"></script>
    <script>
        // User selection management
        const selectAllCheckbox = document.getElementById('selectAll');
        const userCheckboxes = document.querySelectorAll('.user-checkbox');
        const selectedCountSpan = document.getElementById('selectedCount');
        const bulkDeleteBtn = document.getElementById('bulkDeleteBtn');
        const selectedUsersInput = document.getElementById('selectedUsers');
        selectAllCheckbox.addEventListener('change', function() {
            userCheckboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
            updateSelectedCount();
        });
        userCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', updateSelectedCount);
        });
        function updateSelectedCount() {
            const selected = document.querySelectorAll('.user-checkbox:checked');
            selectedCountSpan.textContent = selected.length;
            bulkDeleteBtn.disabled = selected.length === 0;
            const selectedIds = Array.from(selected).map(cb => cb.value);
            selectedUsersInput.value = JSON.stringify(selectedIds);
        }
        function editUser(userId) {
            document.getElementById('editUserId').value = userId;
            new bootstrap.Modal(document.getElementById('editUserModal')).show();
        }
        function toggleUserStatus(userId, action) {
            if (confirm(`Êtes-vous sûr de vouloir ${action === 'enable' ? 'activer' : 'désactiver'} cet utilisateur ?`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    <input type="hidden" name="action" value="${action}_user">
                    <input type="hidden" name="user_id" value="${userId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
        function deleteUser(userId) {
            if (confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ? Cette action est irréversible.')) {
                toggleUserStatus(userId, 'delete');
            }
        }
        function bulkDelete() {
            const selected = document.querySelectorAll('.user-checkbox:checked');
            if (selected.length === 0) return;
            if (confirm(`Êtes-vous sûr de vouloir supprimer ${selected.length} utilisateur(s) ? Cette action est irréversible.`)) {
                document.getElementById('bulkActionForm').innerHTML += '<input type="hidden" name="bulk_action" value="delete">';
                document.getElementById('bulkActionForm').submit();
            }
        }
        // System actions
        function performBackup() {
            if (confirm('Créer une sauvegarde du système ?')) {
                // Simulate backup process
                const btn = event.target;
                const originalText = btn.innerHTML;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Sauvegarde en cours...';
                btn.disabled = true;
                setTimeout(() => {
                    btn.innerHTML = originalText;
                    btn.disabled = false;
                    alert('Sauvegarde créée avec succès !');
                }, 3000);
            }
        }
        function clearCache() {
            if (confirm('Vider le cache système ?')) {
                // Simulate cache clearing
                const btn = event.target;
                const originalText = btn.innerHTML;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Nettoyage...';
                btn.disabled = true;
                setTimeout(() => {
                    btn.innerHTML = originalText;
                    btn.disabled = false;
                    alert('Cache vidé avec succès !');
                }, 2000);
            }
        }
        function generateReport() {
            // Simulate report generation
            const btn = event.target;
            const originalText = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Génération...';
            btn.disabled = true;
            setTimeout(() => {
                btn.innerHTML = originalText;
                btn.disabled = false;
                // Simulate download
                const link = document.createElement('a');
                link.href = '#';
                link.download = 'rapport_systeme_' + new Date().getTime() + '.pdf';
                link.click();
            }, 2000);
        }
        function viewLogs() {
            window.open('logs.php', '_blank');
        }
        // Form validation
        document.getElementById('createUserForm').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            if (password.length < 8) {
                e.preventDefault();
                alert('Le mot de passe doit contenir au moins 8 caractères.');
                return false;
            }
        });
        // Auto-refresh system stats every 2 minutes
        setInterval(function() {
            if (document.hidden === false) {
                // Only refresh stats, not the entire page
                fetch(window.location.href)
                    .then(response => response.text())
                    .then(html => {
                        // Update only the system stats section
                        const parser = new DOMParser();
                        const doc = parser.parseFromString(html, 'text/html');
                        const newStats = doc.querySelectorAll('.system-stat');
                        const currentStats = document.querySelectorAll('.system-stat');
                        newStats.forEach((newStat, index) => {
                            if (currentStats[index]) {
                                currentStats[index].innerHTML = newStat.innerHTML;
                            }
                        });
                    })
                    .catch(error => console.log('Auto-refresh failed:', error));
            }
        }, 120000);
    </script>
</body>
</html>