<?php
// Remove the require_once as this should be included by files that already have session management
// require_once '../Config/session.php';
function pdf_header($title) {
    echo "<!DOCTYPE html><html><head><title>" . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . "</title></head><body>";
}
function pdf_footer() {
    echo "</body></html>";
}
function pdf_print($content) {
    echo "<div class='pdf-content'>" . htmlspecialchars($content, ENT_QUOTES, 'UTF-8') . "</div>";
}
function pdf_download($filename, $content) {
    // Sanitize filename
    $filename = preg_replace('/[^a-zA-Z0-9._-]/', '_', $filename);
    if (!str_ends_with($filename, '.pdf')) {
        $filename .= '.pdf';
    }
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($content));
    echo $content;
}
function pdf_error($message) {
    http_response_code(500);
    echo "<h1>Erreur PDF</h1><p>" . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . "</p>";
}
function pdf_success($message) {
    echo "<h1>Succès</h1><p>" . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . "</p>";
}
function pdf_redirect($url) {
    // Basic URL validation
    if (filter_var($url, FILTER_VALIDATE_URL) || strpos($url, '/') === 0) {
        header('Location: ' . $url);
        exit;
    } else {
        pdf_error("URL de redirection invalide");
    }
}
function pdf_require_auth() {
    // Ensure session is started
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo "Authentification requise";
        exit;
    }
}
function pdf_require_role($roles) {
    pdf_require_auth();
    // Check if current_user function exists
    if (!function_exists('current_user')) {
        http_response_code(500);
        echo "Erreur système: fonction current_user non disponible";
        exit;
    }
    $user = current_user();   
    $roles = (array)$roles; 
    if (!$user || !isset($user['role']) || !in_array($user['role'], $roles)) {
        http_response_code(403);
        echo "Accès refusé";
        exit;
    }
}
function pdf_verify_csrf() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Ensure session is started
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        // Updated to match the fixed csrf.php token name
        $sessionToken = $_SESSION['csrf_token'] ?? '';
        $postToken = $_POST['csrf_token'] ?? '';
        if (empty($sessionToken) || empty($postToken) || !hash_equals($sessionToken, $postToken)) {
            http_response_code(419);
            echo "CSRF invalide";
            exit;
        }
    }
}