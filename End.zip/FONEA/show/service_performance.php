<?php
// service_performance.php
require_once '../Config/db.php'; // PDO connection
// Example: Fetch service performance metrics (replace with real queries)
try {
    $stmt = $pdo->query("
        SELECT COUNT(*) AS total_requests,
               SUM(CASE WHEN status='cloturee' THEN 1 ELSE 0 END) AS completed,
               SUM(CASE WHEN status='en_attente' THEN 1 ELSE 0 END) AS pending
        FROM etat_de_besoin
    ");
    $performance = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur SQL : " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Performance du Service</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: linear-gradient(135deg, #e0f7ff, #ffffff);
        }
        .panel {
            background: rgba(255, 255, 255, 0.25);
            border-radius: 15px;
            padding: 20px;
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 0 auto;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .panel:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
        }
        .panel-title {
            font-size: 20px;
            color: #0d47a1;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }
        .panel-title i {
            margin-right: 10px;
            color: #42a5f5;
        }
        .metric {
            display: flex;
            justify-content: space-between;
            padding: 15px 20px;
            margin-bottom: 12px;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.4);
            box-shadow: inset 0 2px 6px rgba(0,0,0,0.05);
            transition: background 0.3s ease;
        }
        .metric:hover {
            background: rgba(255, 255, 255, 0.55);
        }
        .metric-label {
            font-size: 16px;
            color: #333;
        }
        .metric-value {
            font-size: 18px;
            font-weight: bold;
            color: #0d47a1;
        }
    </style>
</head>
<body>
    <div class="panel">
        <h4 class="panel-title"><i class="fas fa-chart-line"></i> Performance du Service</h4>
        <div class="metric">
            <span class="metric-label">Total des demandes :</span>
            <span class="metric-value"><?= $performance['total_requests'] ?></span>
        </div>
        <div class="metric">
            <span class="metric-label">Demandes terminées :</span>
            <span class="metric-value"><?= $performance['completed'] ?></span>
        </div>
        <div class="metric">
            <span class="metric-label">Demandes en attente :</span>
            <span class="metric-value"><?= $performance['pending'] ?></span>
        </div>
    </div>
</body>
</html>
