<?php

require_once '../Config/session.php';
require_once '../modules/permission.php';

AuthMiddleware::requireRole('directeur_general');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/settings.php");
    exit();
}

$items_per_page = isset($_POST['items_per_page']) ? (int)$_POST['items_per_page'] : 10;
$theme = isset($_POST['theme']) ? trim($_POST['theme']) : 'light';

if ($items_per_page < 5 || $items_per_page > 50) {
    $items_per_page = 10; 
}
if (!in_array($theme, ['light', 'dark'])) {
    $theme = 'light'; 
}

require_once '../Config/db.php';
try {
    $pdo = Database::getInstance()->getConnection();
    $pdo->beginTransaction();
    
    $stmt = $pdo->prepare("REPLACE INTO app_settings (setting_key, setting_value) VALUES 
                          (:key1, :value1), (:key2, :value2)");
    $stmt->execute([
        ':key1' => 'items_per_page',
        ':value1' => $items_per_page,
        ':key2' => 'theme',
        ':value2' => $theme
    ]);
    $pdo->commit();
    
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/settings.php?success=1");
    exit();
} catch (PDOException $e) {
    $pdo->rollBack();
    error_log("Erreur mise à jour paramètres: " . $e->getMessage());
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/settings.php?error=1");
    exit();
}
