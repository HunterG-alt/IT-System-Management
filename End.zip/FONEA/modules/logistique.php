<?php
session_start();
require_once '../Config/session.php';
require_once __DIR__ . '/../public/user.php';
require_once '../include/besoin.php';
require_once '../include/materiel.php';
// Vérifier l'authentification et les droits
SessionAuth::requireLogin();
SessionAuth::requireRole(ROLE_MOYEN_GENERAUX);
// Générer le token CSRF
$csrf_token = CSRFProtection::generateToken();
// Traitement des actions
$message = '';
$message_type = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérifier le token CSRF
    CSRFProtection::requireToken();
    try {
        $action = $_POST['action'] ?? '';
        switch ($action) {
            case 'planifier_livraison':
                $besoin_id = (int)$_POST['besoin_id'];
                $date_livraison = $_POST['date_livraison'];
                $transporteur = trim($_POST['transporteur']);
                $numero_suivi = trim($_POST['numero_suivi']);
                $commentaire = trim($_POST['commentaire']);
                // Mettre à jour la livraison
                $result = DatabaseUtils::update(
                    'besoins',
                    [
                        'date_livraison_prevue' => $date_livraison,
                        'transporteur' => $transporteur,
                        'numero_suivi' => $numero_suivi,
                        'commentaire_logistique' => $commentaire,
                        'statut_logistique' => 'PLANIFIE'
                    ],
                    'id = ?',
                    [$besoin_id]
                );
                if ($result) {
                    $message = 'Livraison planifiée avec succès';
                    $message_type = 'success';
                    // Log de l'action
                    SessionConfig::logSecurityEvent('livraison_planifiee', $_SESSION['user_id'], [
                        'besoin_id' => $besoin_id,
                        'transporteur' => $transporteur
                    ]);
                } else {
                    throw new Exception('Erreur lors de la planification de la livraison');
                }
                break;
            case 'confirmer_livraison':
                $besoin_id = (int)$_POST['besoin_id'];
                $date_livraison_reelle = $_POST['date_livraison_reelle'];
                $commentaire_reception = trim($_POST['commentaire_reception']);
                $result = DatabaseUtils::update(
                    'besoins',
                    [
                        'date_livraison_reelle' => $date_livraison_reelle,
                        'commentaire_reception' => $commentaire_reception,
                        'statut_logistique' => 'LIVRE',
                        'statut' => 'TERMINE'
                    ],
                    'id = ?',
                    [$besoin_id]
                );
                if ($result) {
                    $message = 'Livraison confirmée avec succès';
                    $message_type = 'success';
                    SessionConfig::logSecurityEvent('livraison_confirmee', $_SESSION['user_id'], [
                        'besoin_id' => $besoin_id
                    ]);
                } else {
                    throw new Exception('Erreur lors de la confirmation de la livraison');
                }
                break;
            case 'update_transport':
                $transport_id = (int)$_POST['transport_id'];
                $nom_transporteur = trim($_POST['nom_transporteur']);
                $contact = trim($_POST['contact']);
                $tarif_km = (float)$_POST['tarif_km'];
                $zone_couverture = trim($_POST['zone_couverture']);
                if (empty($nom_transporteur)) {
                    throw new Exception('Le nom du transporteur est requis');
                }
                if ($transport_id > 0) {
                    // Mise à jour
                    $result = DatabaseUtils::update(
                        'transporteurs',
                        [
                            'nom' => $nom_transporteur,
                            'contact' => $contact,
                            'tarif_km' => $tarif_km,
                            'zone_couverture' => $zone_couverture
                        ],
                        'id = ?',
                        [$transport_id]
                    );
                    $message = 'Transporteur mis à jour avec succès';
                } else {
                    // Création
                    $result = DatabaseUtils::insert('transporteurs', [
                        'nom' => $nom_transporteur,
                        'contact' => $contact,
                        'tarif_km' => $tarif_km,
                        'zone_couverture' => $zone_couverture,
                        'created_at' => date('Y-m-d H:i:s')
                    ]);
                    $message = 'Transporteur ajouté avec succès';
                }
                if ($result) {
                    $message_type = 'success';
                } else {
                    throw new Exception('Erreur lors de la sauvegarde du transporteur');
                }
                break;
        }
    } catch (Exception $e) {
        $message = $e->getMessage();
        $message_type = 'danger';
        error_log("Logistique Error: " . $e->getMessage());
    }
}
// Récupération des données
try {
    // Demandes approuvées en attente de livraison
    $demandes_livraison = DatabaseUtils::fetchAll(
        "SELECT b.*, u.nom, u.prenom, 
                CASE 
                    WHEN b.date_livraison_prevue IS NOT NULL THEN 'PLANIFIE'
                    ELSE 'EN_ATTENTE'
                END as statut_livraison
         FROM besoins b 
         INNER JOIN users u ON b.user_id = u.id 
         WHERE b.statut = 'APPROUVE' AND (b.statut_logistique IS NULL OR b.statut_logistique != 'LIVRE')
         ORDER BY b.date_approbation ASC"
    );
    // Livraisons en cours
    $livraisons_cours = DatabaseUtils::fetchAll(
        "SELECT b.*, u.nom, u.prenom
         FROM besoins b 
         INNER JOIN users u ON b.user_id = u.id 
         WHERE b.statut_logistique = 'PLANIFIE'
         ORDER BY b.date_livraison_prevue ASC"
    );
    // Transporteurs
    $transporteurs = DatabaseUtils::fetchAll(
        "SELECT * FROM transporteurs ORDER BY nom ASC"
    );
    // Statistiques logistique
    $stats = [
        'en_attente' => DatabaseUtils::fetchOne("SELECT COUNT(*) as count FROM besoins WHERE statut = 'APPROUVE' AND (statut_logistique IS NULL OR statut_logistique = 'EN_ATTENTE')")['count'] ?? 0,
        'planifiees' => DatabaseUtils::fetchOne("SELECT COUNT(*) as count FROM besoins WHERE statut_logistique = 'PLANIFIE'")['count'] ?? 0,
        'livrees_mois' => DatabaseUtils::fetchOne("SELECT COUNT(*) as count FROM besoins WHERE statut_logistique = 'LIVRE' AND MONTH(date_livraison_reelle) = MONTH(CURRENT_DATE) AND YEAR(date_livraison_reelle) = YEAR(CURRENT_DATE)")['count'] ?? 0
    ];
} catch (Exception $e) {
    error_log("Error fetching logistique data: " . $e->getMessage());
    $demandes_livraison = [];
    $livraisons_cours = [];
    $transporteurs = [];
    $stats = ['en_attente' => 0, 'planifiees' => 0, 'livrees_mois' => 0];
}
$current_user = SessionAuth::getCurrentUser();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion Logistique - FONEA</title>
    <link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <meta name="csrf-token" content="<?php echo $csrf_token; ?>">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .header-section {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 20px 20px;
        }
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            border-left: 4px solid #28a745;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        .table-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }
        .badge-status {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        .status-en-attente { background-color: #ffeaa7; color: #2d3436; }
        .status-planifie { background-color: #74b9ff; color: white; }
        .status-livre { background-color: #00b894; color: white; }
        .btn-action {
            padding: 0.25rem 0.75rem;
            font-size: 0.875rem;
            border-radius: 20px;
            margin: 0 2px;
        }
        .modal-header {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
            border-radius: 15px 15px 0 0;
        }
        .form-control:focus, .form-select:focus {
            border-color: #28a745;
            box-shadow: 0 0 0 0.2rem rgba(40, 167, 69, 0.25);
        }
        @media (max-width: 768px) {
            .header-section {
                padding: 1.5rem 0;
            }
            .table-responsive {
                font-size: 0.875rem;
            }
        }
    </style>
</head>
<body>
    <div class="header-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="mb-0">
                        <i class="fas fa-shipping-fast me-3"></i>Gestion Logistique
                    </h1>
                    <p class="mb-0 mt-2 opacity-75">Planification et suivi des livraisons</p>
                </div>
                <div class="col-md-4 text-end">
                    <div class="d-none d-md-block">
                        <i class="fas fa-truck" style="font-size: 4rem; opacity: 0.2;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <!-- Messages Flash -->
        <?php if (!empty($message)): ?>
            <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-triangle'; ?> me-2"></i>
                <?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <!-- Statistiques -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="stat-card text-center">
                    <i class="fas fa-clock text-warning mb-2" style="font-size: 2rem;"></i>
                    <h3 class="mb-1"><?php echo $stats['en_attente']; ?></h3>
                    <p class="text-muted mb-0">En attente de livraison</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card text-center">
                    <i class="fas fa-calendar-check text-info mb-2" style="font-size: 2rem;"></i>
                    <h3 class="mb-1"><?php echo $stats['planifiees']; ?></h3>
                    <p class="text-muted mb-0">Livraisons planifiées</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card text-center">
                    <i class="fas fa-check-circle text-success mb-2" style="font-size: 2rem;"></i>
                    <h3 class="mb-1"><?php echo $stats['livrees_mois']; ?></h3>
                    <p class="text-muted mb-0">Livrées ce mois</p>
                </div>
            </div>
        </div>
        <!-- Onglets -->
        <ul class="nav nav-tabs mb-4" id="logistiqueTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="livraisons-tab" data-bs-toggle="tab" data-bs-target="#livraisons" type="button" role="tab">
                    <i class="fas fa-truck me-2"></i>Livraisons
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="transporteurs-tab" data-bs-toggle="tab" data-bs-target="#transporteurs" type="button" role="tab">
                    <i class="fas fa-users me-2"></i>Transporteurs
                </button>
            </li>
        </ul>
        <div class="tab-content" id="logistiqueTabContent">
            <!-- Onglet Livraisons -->
            <div class="tab-pane fade show active" id="livraisons" role="tabpanel">
                <!-- Demandes en attente de livraison -->
                <div class="table-card">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="mb-0">
                            <i class="fas fa-clock text-warning me-2"></i>
                            Demandes approuvées - À planifier
                        </h5>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Demandeur</th>
                                    <th>Description</th>
                                    <th>Date d'approbation</th>
                                    <th>Statut</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($demandes_livraison)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted py-4">
                                            <i class="fas fa-inbox fa-2x mb-2 d-block"></i>
                                            Aucune demande en attente de livraison
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($demandes_livraison as $demande): ?>
                                        <tr>
                                            <td><strong>#<?php echo $demande['id']; ?></strong></td>
                                            <td><?php echo htmlspecialchars($demande['prenom'] . ' ' . $demande['nom']); ?></td>
                                            <td><?php echo htmlspecialchars(substr($demande['description'] ?? '', 0, 50)) . (strlen($demande['description'] ?? '') > 50 ? '...' : ''); ?></td>
                                            <td><?php echo date('d/m/Y', strtotime($demande['date_approbation'])); ?></td>
                                            <td>
                                                <span class="badge-status status-<?php echo strtolower($demande['statut_livraison'] ?? 'en-attente'); ?>">
                                                    <?php echo $demande['statut_livraison'] ?? 'EN_ATTENTE'; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn btn-primary btn-action" 
                                                        onclick="planifierLivraison(<?php echo $demande['id']; ?>, '<?php echo htmlspecialchars($demande['prenom'] . ' ' . $demande['nom']); ?>')">
                                                    <i class="fas fa-calendar-plus"></i> Planifier
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- Livraisons en cours -->
                <div class="table-card">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="mb-0">
                            <i class="fas fa-shipping-fast text-info me-2"></i>
                            Livraisons en cours
                        </h5>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Demandeur</th>
                                    <th>Transporteur</th>
                                    <th>N° Suivi</th>
                                    <th>Date prévue</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($livraisons_cours)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted py-4">
                                            <i class="fas fa-truck fa-2x mb-2 d-block"></i>
                                            Aucune livraison en cours
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($livraisons_cours as $livraison): ?>
                                        <tr>
                                            <td><strong>#<?php echo $livraison['id']; ?></strong></td>
                                            <td><?php echo htmlspecialchars($livraison['prenom'] . ' ' . $livraison['nom']); ?></td>
                                            <td><?php echo htmlspecialchars($livraison['transporteur'] ?? 'N/A'); ?></td>
                                            <td>
                                                <?php if (!empty($livraison['numero_suivi'])): ?>
                                                    <code><?php echo htmlspecialchars($livraison['numero_suivi']); ?></code>
                                                <?php else: ?>
                                                    <span class="text-muted">N/A</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if (!empty($livraison['date_livraison_prevue'])): ?>
                                                    <?php echo date('d/m/Y', strtotime($livraison['date_livraison_prevue'])); ?>
                                                <?php else: ?>
                                                    <span class="text-muted">Non définie</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <button class="btn btn-success btn-action" 
                                                        onclick="confirmerLivraison(<?php echo $livraison['id']; ?>, '<?php echo htmlspecialchars($livraison['prenom'] . ' ' . $livraison['nom']); ?>')">
                                                    <i class="fas fa-check"></i> Confirmer
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Onglet Transporteurs -->
            <div class="tab-pane fade" id="transporteurs" role="tabpanel">
                <div class="table-card">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="mb-0">
                            <i class="fas fa-users text-primary me-2"></i>
                            Gestion des transporteurs
                        </h5>
                        <button class="btn btn-primary" onclick="ajouterTransporteur()">
                            <i class="fas fa-plus me-2"></i>Ajouter un transporteur
                        </button>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Nom</th>
                                    <th>Contact</th>
                                    <th>Tarif/km</th>
                                    <th>Zone de couverture</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($transporteurs)): ?>
                                    <tr>
                                        <td colspan="5" class="text-center text-muted py-4">
                                            <i class="fas fa-truck fa-2x mb-2 d-block"></i>
                                            Aucun transporteur enregistré
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($transporteurs as $transporteur): ?>
                                        <tr>
                                            <td><strong><?php echo htmlspecialchars($transporteur['nom']); ?></strong></td>
                                            <td><?php echo htmlspecialchars($transporteur['contact'] ?? 'N/A'); ?></td>
                                            <td>
                                                <?php if ($transporteur['tarif_km'] > 0): ?>
                                                    <?php echo number_format($transporteur['tarif_km'], 0); ?> FCFA/km
                                                <?php else: ?>
                                                    <span class="text-muted">N/A</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($transporteur['zone_couverture'] ?? 'N/A'); ?></td>
                                            <td>
                                                <button class="btn btn-outline-primary btn-action" 
                                                        onclick="modifierTransporteur(<?php echo htmlspecialchars(json_encode($transporteur)); ?>)">
                                                    <i class="fas fa-edit"></i> Modifier
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Planifier Livraison -->
    <div class="modal fade" id="modalPlanifierLivraison" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-calendar-plus me-2"></i>Planifier une livraison
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <input type="hidden" name="action" value="planifier_livraison">
                        <input type="hidden" name="besoin_id" id="planifier_besoin_id">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Demandeur</label>
                                <input type="text" class="form-control" id="planifier_demandeur" readonly>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Date de livraison prévue</label>
                                <input type="date" class="form-control" name="date_livraison" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Transporteur</label>
                                <input type="text" class="form-control" name="transporteur" placeholder="Nom du transporteur" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Numéro de suivi</label>
                                <input type="text" class="form-control" name="numero_suivi" placeholder="Optionnel">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Commentaire</label>
                            <textarea class="form-control" name="commentaire" rows="3" placeholder="Instructions spéciales, remarques..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Planifier la livraison
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Modal Confirmer Livraison -->
    <div class="modal fade" id="modalConfirmerLivraison" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-check me-2"></i>Confirmer la livraison
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <input type="hidden" name="action" value="confirmer_livraison">
                        <input type="hidden" name="besoin_id" id="confirmer_besoin_id">
                        <div class="mb-3">
                            <label class="form-label">Demandeur</label>
                            <input type="text" class="form-control" id="confirmer_demandeur" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Date de livraison réelle</label>
                            <input type="date" class="form-control" name="date_livraison_reelle" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Commentaire de réception</label>
                            <textarea class="form-control" name="commentaire_reception" rows="3" placeholder="État du colis, remarques..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-check me-2"></i>Confirmer la livraison
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Modal Transporteur -->
    <div class="modal fade" id="modalTransporteur" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-truck me-2"></i><span id="transporteur_modal_title">Ajouter un transporteur</span>
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <input type="hidden" name="action" value="update_transport">
                        <input type="hidden" name="transport_id" id="transport_id" value="0">
                        <div class="mb-3">
                            <label class="form-label">Nom du transporteur <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="nom_transporteur" id="nom_transporteur" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Contact (téléphone/email)</label>
                            <input type="text" class="form-control" name="contact" id="contact_transporteur" placeholder="+242 XX XX XX XX">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tarif par kilomètre (FCFA)</label>
                            <input type="number" class="form-control" name="tarif_km" id="tarif_km" min="0" step="50">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Zone de couverture</label>
                            <input type="text" class="form-control" name="zone_couverture" id="zone_couverture" placeholder="Ex: Pointe-Noire, Dolisie, Brazzaville">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Scripts -->
    <script src="../../assets/js/bootstrap.bundle.min.js"></script>
    <script>
        // Planifier une livraison
        function planifierLivraison(besoinId, demandeur) {
            document.getElementById('planifier_besoin_id').value = besoinId;
            document.getElementById('planifier_demandeur').value = demandeur;
            // Définir la date minimale à aujourd'hui
            const today = new Date().toISOString().split('T')[0];
            document.querySelector('input[name="date_livraison"]').min = today;
            document.querySelector('input[name="date_livraison"]').value = today;
            new bootstrap.Modal(document.getElementById('modalPlanifierLivraison')).show();
        }
        // Confirmer une livraison
        function confirmerLivraison(besoinId, demandeur) {
            document.getElementById('confirmer_besoin_id').value = besoinId;
            document.getElementById('confirmer_demandeur').value = demandeur;
            // Définir la date par défaut à aujourd'hui
            const today = new Date().toISOString().split('T')[0];
            document.querySelector('input[name="date_livraison_reelle"]').value = today;
            document.querySelector('input[name="date_livraison_reelle"]').max = today;
            new bootstrap.Modal(document.getElementById('modalConfirmerLivraison')).show();
        }
        // Ajouter un transporteur
        function ajouterTransporteur() {
            // Reset form
            document.getElementById('transport_id').value = '0';
            document.getElementById('nom_transporteur').value = '';
            document.getElementById('contact_transporteur').value = '';
            document.getElementById('tarif_km').value = '';
            document.getElementById('zone_couverture').value = '';
            document.getElementById('transporteur_modal_title').textContent = 'Ajouter un transporteur';
            new bootstrap.Modal(document.getElementById('modalTransporteur')).show();
        }
        // Modifier un transporteur
        function modifierTransporteur(transporteur) {
            document.getElementById('transport_id').value = transporteur.id;
            document.getElementById('nom_transporteur').value = transporteur.nom || '';
            document.getElementById('contact_transporteur').value = transporteur.contact || '';
            document.getElementById('tarif_km').value = transporteur.tarif_km || '';
            document.getElementById('zone_couverture').value = transporteur.zone_couverture || '';
            document.getElementById('transporteur_modal_title').textContent = 'Modifier le transporteur';
            new bootstrap.Modal(document.getElementById('modalTransporteur')).show();
        }
        // Validation des formulaires
        document.addEventListener('DOMContentLoaded', function() {
            // Formatage automatique du numéro de téléphone
            const contactInput = document.getElementById('contact_transporteur');
            if (contactInput) {
                contactInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    if (value.startsWith('242')) {
                        value = value.substring(3);
                    }
                    if (value.length > 0) {
                        value = '+242 ' + value.replace(/(\d{2})(?=\d)/g, '$1 ');
                    }
                    e.target.value = value;
                });
            }
            // Auto-complétion des transporteurs dans le formulaire de planification
            const transporteurInput = document.querySelector('input[name="transporteur"]');
            if (transporteurInput) {
                const transporteurs = <?php echo json_encode(array_column($transporteurs, 'nom')); ?>;
                transporteurInput.addEventListener('input', function(e) {
                    const value = e.target.value.toLowerCase();
                    // Simple auto-complétion (vous pouvez améliorer avec une vraie liste déroulante)
                    if (value.length > 0) {
                        const matches = transporteurs.filter(t => t.toLowerCase().includes(value));
                        if (matches.length === 1 && matches[0].toLowerCase() === value) {
                            e.target.style.borderColor = '#28a745';
                        }
                    }
                });
            }
            // Confirmation avant soumission
            const forms = document.querySelectorAll('form');
            forms.forEach(form => {
                form.addEventListener('submit', function(e) {
                    const action = form.querySelector('input[name="action"]').value;
                    if (action === 'confirmer_livraison') {
                        if (!confirm('Êtes-vous sûr de vouloir confirmer cette livraison ? Cette action est irréversible.')) {
                            e.preventDefault();
                            return false;
                        }
                    }
                    // Désactiver le bouton de soumission pour éviter les doubles clics
                    const submitBtn = form.querySelector('button[type="submit"]');
                    if (submitBtn) {
                        submitBtn.disabled = true;
                        const originalText = submitBtn.innerHTML;
                        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Traitement...';
                        // Réactiver après 3 secondes en cas d'erreur
                        setTimeout(() => {
                            submitBtn.disabled = false;
                            submitBtn.innerHTML = originalText;
                        }, 3000);
                    }
                });
            });
            // Mise à jour automatique des statistiques (polling léger)
            setInterval(function() {
                if (!document.hidden) {
                    // Recharger seulement si aucune modal n'est ouverte
                    const modals = document.querySelectorAll('.modal.show');
                    if (modals.length === 0) {
                        // Vous pouvez implémenter un refresh AJAX ici
                        // location.reload();
                    }
                }
            }, 300000); // 5 minutes
            // Gestion des notifications (si vous avez un système de notifications)
            if ('Notification' in window && Notification.permission === 'granted') {
                // Vérifier les nouvelles livraisons urgentes
                checkUrgentDeliveries();
            }
        });
        // Fonction pour vérifier les livraisons urgentes
        function checkUrgentDeliveries() {
            // Cette fonction peut faire un appel AJAX pour vérifier
            // les livraisons qui approchent de leur date limite
            const today = new Date();
            const tomorrow = new Date(today);
            tomorrow.setDate(tomorrow.getDate() + 1);
            // Exemple : notifier pour les livraisons prévues demain
            const rows = document.querySelectorAll('#livraisons tbody tr');
            rows.forEach(row => {
                const dateCell = row.cells[4]; // colonne date prévue
                if (dateCell && dateCell.textContent.trim() !== 'Non définie') {
                    const datePrevue = new Date(dateCell.textContent.split('/').reverse().join('-'));
                    if (datePrevue <= tomorrow && datePrevue >= today) {
                        // Marquer visuellement les livraisons urgentes
                        row.classList.add('table-warning');
                    }
                }
            });
        }
        // Fonctions utilitaires
        function formatDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString('fr-FR');
        }
        function formatCurrency(amount) {
            return new Intl.NumberFormat('fr-FR').format(amount) + ' FCFA';
        }
        // Gestion des erreurs réseau
        window.addEventListener('error', function(e) {
            console.error('Erreur JavaScript:', e.error);
        });
        // Gestion de la perte de connexion
        window.addEventListener('offline', function() {
            const alert = document.createElement('div');
            alert.className = 'alert alert-warning alert-dismissible fade show position-fixed';
            alert.style.top = '20px';
            alert.style.right = '20px';
            alert.style.zIndex = '9999';
            alert.innerHTML = `
                <i class="fas fa-wifi me-2"></i>
                Connexion internet perdue. Certaines fonctionnalités peuvent ne pas fonctionner.
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            document.body.appendChild(alert);
        });
        window.addEventListener('online', function() {
            const alert = document.createElement('div');
            alert.className = 'alert alert-success alert-dismissible fade show position-fixed';
            alert.style.top = '20px';
            alert.style.right = '20px';
            alert.style.zIndex = '9999';
            alert.innerHTML = `
                <i class="fas fa-wifi me-2"></i>
                Connexion internet rétablie.
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            document.body.appendChild(alert);
            setTimeout(() => {
                alert.remove();
            }, 3000);
        });
    </script>
</body>
</html>