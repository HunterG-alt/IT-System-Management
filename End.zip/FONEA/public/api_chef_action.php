<?php
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../modules/WorkflowManager.php';
header('Content-Type: application/json');
if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['error' => 'Non authentifié']);
    exit;
}
if (($_SESSION['role'] ?? '') !== 'chef_service') {
    http_response_code(403);
    echo json_encode(['error' => 'Accès refusé']);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Méthode non autorisée']);
    exit;
}
if (!CSRFProtection::verifyTokenFor('chef_request_action', $_POST['csrf_token_chef_request_action'] ?? null)) {
    http_response_code(403);
    echo json_encode(['error' => 'Token CSRF invalide']);
    exit;
}
$id_besoin = (int)($_POST['id_besoin'] ?? 0);
$action = $_POST['action'] ?? '';
$commentaire = trim($_POST['commentaire'] ?? '');
if ($id_besoin <= 0 || !in_array($action, ['approve', 'reject'], true)) {
    http_response_code(400);
    echo json_encode(['error' => 'Paramètres invalides']);
    exit;
}
try {
    $manager = new WorkflowManager();
    $ok = $manager->preValidateByChef($id_besoin, (int)$_SESSION['user_id'], $action, $commentaire);
    if (!$ok) {
        throw new Exception('Échec de la mise à jour');
    }
    $new = $action === 'approve' ? 'pre_validee' : 'refusee_chef';
    echo json_encode(['success' => true, 'new_status' => $new]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur serveur']);
}
?>
