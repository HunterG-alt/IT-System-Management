<?php
require_once '../Config/session.php';
require_once __DIR__ . '/../public/userClass.php';
require_once '../include/besoin.php';
require_once __DIR__ . '/../public/notifications.php';
require_once __DIR__ . '/../Config/titles.php'; 

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['agent', 'demandeur'])) {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit();
}

$user = User::getById($_SESSION['user_id']);
$user_name = $user ? $user['nom_complet'] : 'Agent';

$my_requests = 25; 
$pending_requests = Besoin::countByStatut('EN_ATTENTE');
$approved_requests = Besoin::countByStatut('APPROUVE');
$notif_stats = Notification::getStats($_SESSION['user_id']);
$total_notifications = $notif_stats['unread'];

$recent_requests = [
    ['title' => 'Ordinateur portable', 'created_at' => date('Y-m-d H:i:s', strtotime('-2 days')), 'status' => 'En attente'],
    ['title' => 'Imprimante laser', 'created_at' => date('Y-m-d H:i:s', strtotime('-5 days')), 'status' => 'Approuvé'],
    ['title' => 'Chaise de bureau', 'created_at' => date('Y-m-d H:i:s', strtotime('-1 week')), 'status' => 'Livré']
];
// Function to format time ago
function timeAgo($datetime) {
    $time = time() - strtotime($datetime);
    if ($time < 60) return 'À l\'instant';
    if ($time < 3600) return floor($time/60) . ' min';
    if ($time < 86400) return floor($time/3600) . ' h';
    if ($time < 2592000) return floor($time/86400) . ' j';
    if ($time < 31104000) return floor($time/2592000) . ' mois';
    return floor($time/31104000) . ' ans';
}
$currentPage = basename(__FILE__);
$pageTitle = $pageTitles[$currentPage] ?? 'Dashboard - FONEA';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="../assets/css/dashboard-common.css" rel="stylesheet">
    <style>
        
        .dashboard-agent .sidebar {
            background: linear-gradient(180deg, #6366f1 0%, #4f46e5 100%);
        }
        
        .dashboard-agent .btn-accueil {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 90%;
            margin: 30px auto 20px auto;
            padding: 14px 0;
            border-radius: 30px;
            font-size: 1.1rem;
            font-weight: bold;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: #fff !important;
            box-shadow: 0 4px 16px rgba(139,92,246,0.15);
            border: none;
            transition: background 0.3s, transform 0.2s;
            text-decoration: none !important;
        }
        .btn-accueil i {
            margin-right: 10px;
            font-size: 1.2em;
        }
        .btn-accueil:hover {
            background: linear-gradient(135deg, #4f46e5, #6366f1);
            color: #fff !important;
            transform: translateY(-2px) scale(1.03);
            text-decoration: none !important;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #ffffff;
            color: #1a1a1a;
            overflow-x: hidden;
        }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 240px;
            height: 100vh;
            background: linear-gradient(180deg, #8b5cf6 0%, #7c3aed 100%);
            z-index: 1000;
            transition: all 0.3s ease;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
        }
        .sidebar-header {
            padding: 30px 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .sidebar-logo {
            color: #ffffff;
            font-size: 24px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .sidebar-logo i {
            color: #ffffff;
            font-size: 28px;
        }
        .sidebar-nav {
            padding: 20px 0;
            padding-bottom: 180px;
        }
        .nav-item {
            margin: 8px 20px;
        }
        .nav-link {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
            gap: 15px;
        }
        .nav-link:hover {
            background: rgba(255, 255, 255, 0.1);
            color: #ffffff;
            transform: translateX(5px);
            text-decoration: none;
        }
        .nav-link.active {
            background: rgba(255, 255, 255, 0.2);
            color: #ffffff;
            box-shadow: 0 4px 15px rgba(139, 92, 246, 0.3);
        }
        .nav-link i {
            font-size: 18px;
            width: 20px;
        }
        /* Main Content */
        .main-content {
            margin-left: 240px;
            min-height: 100vh;
            background: #ffffff;
        }
        /* Top Header */
        .top-header {
            background: #ffffff;
            padding: 20px 40px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        .search-bar {
            flex: 1;
            max-width: 400px;
            margin: 0 30px;
            position: relative;
        }
        .search-input {
            width: 100%;
            padding: 12px 20px 12px 45px;
            border: 2px solid #e2e8f0;
            border-radius: 25px;
            background: #f8fafc;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        .search-input:focus {
            outline: none;
            border-color: #8b5cf6;
            background: #ffffff;
            box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.1);
        }
        .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
        }
        .header-actions {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .notification-btn {
            position: relative;
            background: #f8fafc;
            border: none;
            width: 45px;
            height: 45px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .notification-btn:hover {
            background: #8b5cf6;
            color: #ffffff;
            transform: translateY(-2px);
        }
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #ef4444;
            color: #ffffff;
            font-size: 11px;
            padding: 2px 6px;
            border-radius: 10px;
            font-weight: 600;
        }
        .profile-section {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 16px;
            background: #f8fafc;
            border-radius: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            color: inherit;
        }
        .profile-section:hover {
            background: #e2e8f0;
            text-decoration: none;
            color: inherit;
        }
        .profile-avatar {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            background: linear-gradient(135deg, #8b5cf6, #7c3aed);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            font-weight: 600;
            font-size: 16px;
        }
        .profile-info h6 {
            margin: 0;
            font-size: 14px;
            font-weight: 600;
            color: #1e293b;
        }
        .profile-info p {
            margin: 0;
            font-size: 12px;
            color: #64748b;
        }
        /* Welcome Section */
        .welcome-section {
            padding: 40px;
            background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);
        }
        .welcome-title {
            font-size: 32px;
            font-weight: 700;
            color: #4c1d95;
            margin-bottom: 8px;
        }
        .welcome-subtitle {
            font-size: 16px;
            color: #6366f1;
            margin-bottom: 0;
        }
        /* Dashboard Cards */
        .dashboard-section {
            padding: 40px;
        }
        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        .agent-dashboard-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 25px;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            border: 1px solid #e2e8f0;
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-decoration: none !important;
            color: inherit;
        }
        .agent-dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(139, 92, 246, 0.2);
        }
        .card-icon {
            width: 60px;
            height: 60px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: #ffffff;
            margin-bottom: 20px;
        }
        .card-title {
            font-size: 20px;
            font-weight: 600;
            color: #4c1d95;
            margin-bottom: 8px;
        }
        .card-description {
            font-size: 14px;
            color: #6366f1;
            margin-bottom: 15px;
            line-height: 1.5;
        }
        .card-metric {
            font-size: 28px;
            font-weight: 700;
            color: #4c1d95;
        }
        /* Card Colors - Purple/Indigo Theme */
        .card-requests .card-icon { background: linear-gradient(135deg, #8b5cf6, #7c3aed); }
        .card-create .card-icon { background: linear-gradient(135deg, #a855f7, #8b5cf6); }
        .card-status .card-icon { background: linear-gradient(135deg, #c084fc, #a855f7); }
        .card-history .card-icon { background: linear-gradient(135deg, #6366f1, #4f46e5); }
        .card-profile .card-icon { background: linear-gradient(135deg, #7c3aed, #6d28d9); }
        .card-notifications .card-icon { background: linear-gradient(135deg, #f59e0b, #d97706); }
        /* Side Panels */
        .side-panels {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
            margin-top: 30px;
        }
        .dashboard-card,
        .agent-side-panel {
            background: #ffffff;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            border: 1px solid #e2e8f0;
        }
        .panel-title {
            font-size: 18px;
            font-weight: 600;
            color: #4c1d95;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .request-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 0;
            border-bottom: 1px solid #f1f5f9;
        }
        .request-item:last-child {
            border-bottom: none;
        }
        .request-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: linear-gradient(135deg, #8b5cf6, #7c3aed);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            font-size: 14px;
        }
        .request-info h6 {
            margin: 0;
            font-size: 14px;
            font-weight: 500;
            color: #4c1d95;
        }
        .request-info p {
            margin: 0;
            font-size: 12px;
            color: #6366f1;
        }
        #userStatsChart {
             width: 100% !important;
             height: 220px !important;
             display: block !important;
             margin: 0 auto !important;
        }
        .logout-btn {
            position: fixed;
            bottom: 30px;
            left: 20px;
            width: 200px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #ffffff;
            padding: 12px 20px;
            border-radius: 12px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
        }
        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            color: #ffffff;
            text-decoration: none;
        }
        /* Chart container */
        .chart-container {
            position: relative;
            height: 220px;
            width: 100%;
        }
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .main-content {
                margin-left: 0;
            }
            .top-header {
                padding: 15px 20px;
            }
            .dashboard-section {
                padding: 20px;
            }
            .cards-grid {
                grid-template-columns: 1fr;
            }
            .side-panels {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body class="dashboard-agent">
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-user"></i>
                FONEA Agent
            </div>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-item">
                <a href="#" class="nav-link active">
                    <i class="fas fa-chart-pie"></i>
                    Dashboard
                </a>
            </div>
            <div class="nav-item">
                <a href="content.php#my_requests" class="nav-link">
                    <i class="fas fa-file-alt"></i>
                    Mes Demandes
                </a>
            </div>
            <div class="nav-item">
                <a href="../public/create.php" class="nav-link">
                    <i class="fas fa-plus-circle"></i>
                    Nouvelle Demande
                </a>
            </div>
            <div class="nav-item">
                <a href="../view/historique.php" class="nav-link">
                    <i class="fas fa-history"></i>
                    Historique
                </a>
            </div>
            <div class="nav-item">
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user-cog"></i>
                    Mon Profil
                </a>
            </div>
            <div class="nav-item">
                <a href="notifications.php" class="nav-link">
                    <i class="fas fa-bell"></i>
                    Notifications
                </a>
            </div>
            <div class="nav-item">
                <a href="help.php" class="nav-link">
                    <i class="fas fa-question-circle"></i>
                    Aide
                </a>
            </div>
        </nav>
        <a href="../layout/header.php" class="btn-accueil"><i class="fas fa-home"></i>Accueil</a>
        <a href="../public/logout.php" class="logout-btn">
            <i class="fas fa-sign-out-alt"></i>
            Se déconnecter
        </a>
    </div>
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <div class="search-bar position-relative">
                <i class="fas fa-search search-icon"></i>
                <input type="text" class="search-input" placeholder="Rechercher mes demandes...">
            </div>
            <div class="header-actions">
                <button class="notification-btn">
                    <i class="fas fa-bell"></i>
                    <?php if ($total_notifications > 0): ?>
                        <span class="notification-badge"><?= $total_notifications ?></span>
                    <?php endif; ?>
                </button>
                <a href="profile.php" class="profile-section">
                    <div class="profile-avatar">
                        <?= strtoupper(substr($user_name, 0, 2)) ?>
                    </div>
                    <div class="profile-info">
                        <h6><?= htmlspecialchars($user_name) ?></h6>
                        <p><?= ucfirst($_SESSION['role']) ?></p>
                    </div>
                </a>
            </div>
        </div>
        <!-- Welcome Section -->
        <div class="welcome-section">
            <h1 class="welcome-title">Bienvenue, <?= htmlspecialchars($user_name) ?></h1>
            <p class="welcome-subtitle">Tableau de bord personnel - Gestion de vos demandes d'équipement</p>
        </div>
        <!-- Dashboard Section -->
        <div class="dashboard-section">
            <div class="cards-grid">
                <a href="content.php#my_requests" class="agent-dashboard-card card-requests">
                    <div class="card-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <h3 class="card-title">Mes Demandes</h3>
                    <p class="card-description">Toutes vos demandes d'équipement soumises</p>
                    <div class="card-metric"><?= $my_requests ?></div>
                </a>
                <a href="../public/create.php" class="agent-dashboard-card card-create">
                    <div class="card-icon">
                        <i class="fas fa-plus-circle"></i>
                    </div>
                    <h3 class="card-title">Nouvelle Demande</h3>
                    <p class="card-description">Créer une nouvelle demande d'équipement</p>
                    <div class="card-metric">Créer</div>
                </a>
                <a href="content.php?status=pending" class="agent-dashboard-card card-status">
                    <div class="card-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <h3 class="card-title">Suivi Statut</h3>
                    <p class="card-description">Suivre l'état d'avancement de vos demandes</p>
                    <div class="card-metric"><?= $pending_requests ?></div>
                </a>
                <a href="../view/historique.php" class="agent-dashboard-card card-history">
                    <div class="card-icon">
                        <i class="fas fa-history"></i>
                    </div>
                    <h3 class="card-title">Historique</h3>
                    <p class="card-description">Consulter l'historique de toutes vos demandes</p>
                    <div class="card-metric"><?= $approved_requests ?></div>
                </a>
                <a href="profile.php" class="agent-dashboard-card card-profile">
                    <div class="card-icon">
                        <i class="fas fa-user-cog"></i>
                    </div>
                    <h3 class="card-title">Mon Profil</h3>
                    <p class="card-description">Gérer vos informations personnelles et préférences</p>
                    <div class="card-metric">Profil</div>
                </a>
                <a href="../public/notifications.php" class="agent-dashboard-card card-notifications">
                    <div class="card-icon">
                        <i class="fas fa-bell"></i>
                    </div>
                    <h3 class="card-title">Notifications</h3>
                    <p class="card-description">Alertes et mises à jour sur vos demandes</p>
                    <div class="card-metric"><?= $total_notifications ?></div>
                </a>
            </div>
            <!-- Side Panels -->
            <div class="side-panels">
                <div class="dashboard-card">
                    <h4 class="panel-title">
                        <i class="fas fa-clock"></i>
                        Demandes Récentes
                    </h4>
                    <?php foreach($recent_requests as $index => $req): ?>
                        <div class="request-item">
                            <div class="request-icon">
                                <?php if ($index == 0): ?>
                                    <i class="fas fa-laptop"></i>
                                <?php elseif ($index == 1): ?>
                                    <i class="fas fa-print"></i>
                                <?php else: ?>
                                    <i class="fas fa-chair"></i>
                                <?php endif; ?>
                            </div>
                            <div class="request-info">
                                <h6><?= htmlspecialchars($req['title']) ?></h6>
                                <p><?= timeAgo($req['created_at']) ?> • <?= htmlspecialchars($req['status']) ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="agent-side-panel">
                    <h4 class="panel-title">
                        <i class="fas fa-chart-bar"></i>
                        Mes Statistiques
                    </h4>
                    <div class="chart-container">
                        <canvas id="userStatsChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // User Stats Chart
        const ctx = document.getElementById('userStatsChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Soumises', 'Approuvées', 'En attente', 'Livrées'],
                datasets: [{
                    label: 'Mes Demandes',
                    data: [25, 18, 5, 15],
                    backgroundColor: ['#8b5cf6', '#a855f7', '#c084fc', '#6366f1'],
                    borderRadius: 8,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: '#f1f5f9'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        // Add click handlers to notification button
        document.querySelector('.notification-btn').addEventListener('click', function() {
            window.location.href = 'notifications.php';
        });
        // Add search functionality
        document.querySelector('.search-input').addEventListener('input', function(e) {
            // Implement search functionality here
            console.log('Searching for:', e.target.value);
        });
    </script>
</body>
</html>