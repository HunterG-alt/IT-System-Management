<?php
session_start();
require_once '../Config/db.php';
require_login();
$pdo = Database::getInstance()->getConnection();
$errors = [];
$success = "";
// Générer un token CSRF
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
// Vérifier que l'ID du fournisseur est présent et valide
$id = $_GET['id'] ?? null;
if (!$id || !is_numeric($id)) {
    $_SESSION['error'] = "ID fournisseur manquant ou invalide.";
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/fournisseur.php");
    exit;
}
// Récupérer le fournisseur existant
try {
    $stmt = $pdo->prepare("SELECT * FROM Fournisseur WHERE id_fournisseur = :id");
    $stmt->execute([':id' => $id]);
    $fournisseur = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$fournisseur) {
        $_SESSION['error'] = "Fournisseur non trouvé.";
        header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/fournisseur.php");
        exit;
    }
} catch (PDOException $e) {
    error_log("Erreur lors de la recherche du fournisseur: " . $e->getMessage());
    $_SESSION['error'] = "Erreur lors de l'accès à la base de données.";
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/fournisseur.php");
    exit;
}
// Traitement du formulaire de modification
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérification du token CSRF
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $errors[] = "Token de sécurité invalide.";
    } else {
        $nom = trim($_POST['nom'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $telephone = trim($_POST['telephone'] ?? '');
        $adresse = trim($_POST['adresse'] ?? '');
        // Validation détaillée
        if (empty($nom)) {
            $errors[] = "Le nom est requis.";
        } elseif (strlen($nom) < 2) {
            $errors[] = "Le nom doit contenir au moins 2 caractères.";
        } elseif (strlen($nom) > 100) {
            $errors[] = "Le nom ne peut pas dépasser 100 caractères.";
        }
        if (empty($email)) {
            $errors[] = "L'email est requis.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Format d'email invalide.";
        } elseif (strlen($email) > 150) {
            $errors[] = "L'email ne peut pas dépasser 150 caractères.";
        } else {
            // Vérifier que l'email n'existe pas déjà pour un autre fournisseur
            try {
                $stmt = $pdo->prepare("SELECT id_fournisseur FROM Fournisseur WHERE email = :email AND id_fournisseur != :id");
                $stmt->execute([':email' => $email, ':id' => $id]);
                if ($stmt->fetch()) {
                    $errors[] = "Cet email est déjà utilisé par un autre fournisseur.";
                }
            } catch (PDOException $e) {
                error_log("Erreur lors de la vérification de l'email: " . $e->getMessage());
                $errors[] = "Erreur lors de la validation.";
            }
        }
        if (empty($telephone)) {
            $errors[] = "Le téléphone est requis.";
        } elseif (!preg_match('/^[\d\s\-\+\(\)\.]{8,20}$/', $telephone)) {
            $errors[] = "Format de téléphone invalide.";
        }
        if (!empty($adresse) && strlen($adresse) > 255) {
            $errors[] = "L'adresse ne peut pas dépasser 255 caractères.";
        }
        if (empty($errors)) {
            try {
                $pdo->beginTransaction();
                $stmt = $pdo->prepare("UPDATE Fournisseur SET nom = :nom, email = :email, telephone = :telephone, adresse = :adresse, date_modification = NOW() WHERE id_fournisseur = :id");
                $result = $stmt->execute([
                    ':nom' => $nom,
                    ':email' => $email,
                    ':telephone' => $telephone,
                    ':adresse' => $adresse,
                    ':id' => $id
                ]);
                if ($result && $stmt->rowCount() > 0) {
                    $pdo->commit();
                    $success = "Fournisseur mis à jour avec succès.";
                    // Recharger les données après modification
                    $fournisseur['nom'] = $nom;
                    $fournisseur['email'] = $email;
                    $fournisseur['telephone'] = $telephone;
                    $fournisseur['adresse'] = $adresse;
                    // Option de redirection automatique après succès
                    // $_SESSION['success'] = $success;
                    // header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/fournisseur.php");
                    // exit;
                } else {
                    $pdo->rollBack();
                    $errors[] = "Aucune modification n'a été apportée.";
                }
            } catch (PDOException $e) {
                $pdo->rollBack();
                error_log("Erreur lors de la mise à jour du fournisseur: " . $e->getMessage());
                if ($e->getCode() == '23000') {
                    $errors[] = "Cette information existe déjà dans la base de données.";
                } else {
                    $errors[] = "Erreur lors de la mise à jour.";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier Fournisseur - <?= htmlspecialchars($fournisseur['nom']) ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #2c3e50, #34495e);
            color: white;
            padding: 30px;
            text-align: center;
        }
        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        .header .supplier-name {
            font-size: 16px;
            opacity: 0.9;
            font-weight: 300;
        }
        .form-container {
            padding: 40px;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-weight: 500;
        }
        .alert-success {
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        .alert-danger {
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }
        .form-group {
            margin-bottom: 25px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
            font-size: 14px;
        }
        .form-group label i {
            margin-right: 8px;
            color: #3498db;
        }
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
            background-color: #fafafa;
        }
        .form-control:focus {
            outline: none;
            border-color: #3498db;
            background-color: white;
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
        }
        .form-control.error {
            border-color: #e74c3c;
            background-color: #fdf2f2;
        }
        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        .btn {
            flex: 1;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            text-align: center;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .btn-primary {
            background: linear-gradient(135deg, #3498db, #2980b9);
            color: white;
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #2980b9, #21618c);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.4);
        }
        .btn-secondary {
            background: #95a5a6;
            color: white;
        }
        .btn-secondary:hover {
            background: #7f8c8d;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(149, 165, 166, 0.4);
        }
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 20px;
            color: #3498db;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .back-link:hover {
            color: #2980b9;
        }
        .required {
            color: #e74c3c;
        }
        @media (max-width: 480px) {
            .container {
                margin: 10px;
                border-radius: 10px;
            }
            .header {
                padding: 20px;
            }
            .form-container {
                padding: 20px;
            }
            .btn-group {
                flex-direction: column;
            }
        }
        /* Animation de chargement */
        .btn-primary:active {
            transform: translateY(0);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-edit"></i> Modifier le Fournisseur</h1>
            <div class="supplier-name">
                <i class="fas fa-building"></i> <?= htmlspecialchars($fournisseur['nom']) ?>
            </div>
        </div>
        <div class="form-container">
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i>
                    <?= implode('<br>', array_map('htmlspecialchars', $errors)) ?>
                </div>
            <?php endif; ?>
            <form method="POST" action="" novalidate>
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                <div class="form-group">
                    <label for="nom">
                        <i class="fas fa-building"></i>
                        Nom de l'entreprise <span class="required">*</span>
                    </label>
                    <input 
                        type="text" 
                        id="nom" 
                        name="nom" 
                        class="form-control <?= in_array('Le nom est requis.', $errors) || in_array('Le nom doit contenir au moins 2 caractères.', $errors) ? 'error' : '' ?>"
                        value="<?= htmlspecialchars($fournisseur['nom']) ?>" 
                        required 
                        maxlength="100"
                        placeholder="Nom de l'entreprise"
                    >
                </div>
                <div class="form-group">
                    <label for="email">
                        <i class="fas fa-envelope"></i>
                        Email professionnel <span class="required">*</span>
                    </label>
                    <input 
                        type="email" 
                        id="email" 
                        name="email" 
                        class="form-control <?= in_array('L\'email est requis.', $errors) || in_array('Format d\'email invalide.', $errors) ? 'error' : '' ?>"
                        value="<?= htmlspecialchars($fournisseur['email']) ?>" 
                        required 
                        maxlength="150"
                        placeholder="contact@entreprise.com"
                    >
                </div>
                <div class="form-group">
                    <label for="telephone">
                        <i class="fas fa-phone"></i>
                        Numéro de téléphone <span class="required">*</span>
                    </label>
                    <input 
                        type="tel" 
                        id="telephone" 
                        name="telephone" 
                        class="form-control <?= in_array('Le téléphone est requis.', $errors) || in_array('Format de téléphone invalide.', $errors) ? 'error' : '' ?>"
                        value="<?= htmlspecialchars($fournisseur['telephone']) ?>" 
                        required
                        pattern="[\d\s\-\+\(\)\.]{8,20}"
                        placeholder="+242 XX XX XX XX"
                    >
                </div>
                <div class="form-group">
                    <label for="adresse">
                        <i class="fas fa-map-marker-alt"></i>
                        Adresse (optionnel)
                    </label>
                    <input 
                        type="text" 
                        id="adresse" 
                        name="adresse" 
                        class="form-control"
                        value="<?= htmlspecialchars($fournisseur['adresse'] ?? '') ?>"
                        maxlength="255"
                        placeholder="Adresse complète de l'entreprise"
                    >
                </div>
                <div class="btn-group">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i>
                        Mettre à jour
                    </button>
                    <a href="fournisseur.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i>
                        Annuler
                    </a>
                </div>
            </form>
            <a href="fournisseur.php" class="back-link">
                <i class="fas fa-arrow-left"></i>
                Retour à la liste des fournisseurs
            </a>
        </div>
    </div>
    <script>
        // Validation en temps réel
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            const inputs = form.querySelectorAll('input[required]');
            // Validation en temps réel pour chaque champ
            inputs.forEach(input => {
                input.addEventListener('blur', function() {
                    validateField(this);
                });
                input.addEventListener('input', function() {
                    if (this.classList.contains('error')) {
                        validateField(this);
                    }
                });
            });
            function validateField(field) {
                const value = field.value.trim();
                field.classList.remove('error');
                switch (field.name) {
                    case 'nom':
                        if (!value || value.length < 2) {
                            field.classList.add('error');
                        }
                        break;
                    case 'email':
                        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                        if (!value || !emailPattern.test(value)) {
                            field.classList.add('error');
                        }
                        break;
                    case 'telephone':
                        const phonePattern = /^[\d\s\-\+\(\)\.]{8,20}$/;
                        if (!value || !phonePattern.test(value)) {
                            field.classList.add('error');
                        }
                        break;
                }
            }
            // Confirmation avant soumission
            form.addEventListener('submit', function(e) {
                const submitBtn = form.querySelector('button[type="submit"]');
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Mise à jour...';
                submitBtn.disabled = true;
            });
        });
    </script>
</body>
</html>