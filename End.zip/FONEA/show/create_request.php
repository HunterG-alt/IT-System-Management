<?php
require_once '../Config/db.php';
require_once '../Config/session.php';
require_once '../modules/permission.php';

// Check authentication
AuthMiddleware::requireLogin();

// Only users who can create requests
AuthMiddleware::requirePermission('requests.create');

$user_data = $_SESSION['user_data'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créer une Demande</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 40px 20px;
            position: relative;
            overflow-x: hidden;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: fixed;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px);
            background-size: 50px 50px;
            animation: moveBackground 20s linear infinite;
            z-index: 0;
        }

        @keyframes moveBackground {
            0% { transform: translate(0, 0); }
            100% { transform: translate(50px, 50px); }
        }

        .container {
            max-width: 700px;
            margin: 0 auto;
            position: relative;
            z-index: 1;
        }

        .header {
            text-align: center;
            margin-bottom: 40px;
            color: white;
            text-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }

        .header h2 {
            font-size: 2.5em;
            margin-bottom: 10px;
            animation: fadeInDown 0.6s ease-out;
        }

        .header p {
            font-size: 1.1em;
            opacity: 0.9;
            animation: fadeInUp 0.6s ease-out 0.2s both;
        }

        /* Glass morphism card */
        .glass-card {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
            border: 1px solid rgba(255, 255, 255, 0.18);
            animation: fadeInUp 0.6s ease-out 0.4s both;
        }

        .workflow-info {
            background: rgba(255, 255, 255, 0.2);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 30px;
            border-left: 4px solid rgba(255, 255, 255, 0.5);
        }

        .workflow-info h3 {
            color: white;
            font-size: 1.1em;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .workflow-steps {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .workflow-step {
            display: flex;
            align-items: center;
            gap: 12px;
            color: white;
            font-size: 0.95em;
            padding: 8px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .workflow-step:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(5px);
        }

        .workflow-step .step-number {
            background: rgba(255, 255, 255, 0.3);
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            flex-shrink: 0;
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: white;
            font-weight: 600;
            font-size: 1em;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        label .required {
            color: #fbbf24;
        }

        input[type="text"],
        textarea,
        select {
            width: 100%;
            padding: 15px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.9);
            font-size: 1em;
            transition: all 0.3s ease;
            color: #333;
        }

        input[type="text"]:focus,
        textarea:focus,
        select:focus {
            outline: none;
            border-color: rgba(255, 255, 255, 0.8);
            background: white;
            box-shadow: 0 0 0 4px rgba(255, 255, 255, 0.1);
        }

        textarea {
            min-height: 120px;
            resize: vertical;
            font-family: inherit;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        button {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        button:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3);
        }

        button:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        .result-message {
            margin-top: 20px;
            padding: 15px 20px;
            border-radius: 12px;
            display: none;
            animation: slideIn 0.3s ease-out;
            color: white;
            font-weight: 500;
        }

        .result-message.success {
            background: rgba(16, 185, 129, 0.9);
            border-left: 4px solid #059669;
            display: block;
        }

        .result-message.error {
            background: rgba(239, 68, 68, 0.9);
            border-left: 4px solid #dc2626;
            display: block;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 25px;
            padding: 12px 24px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            backdrop-filter: blur(5px);
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateX(-5px);
        }

        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .spinner {
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-top: 3px solid white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 0.8s linear infinite;
            display: none;
        }

        button:disabled .spinner {
            display: inline-block;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @media (max-width: 768px) {
            .container {
                padding: 0 15px;
            }

            .glass-card {
                padding: 25px;
            }

            .header h2 {
                font-size: 2em;
            }

            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2><i class="fas fa-file-alt"></i> Créer une Nouvelle Demande</h2>
            <p>Soumettez votre demande pour validation</p>
        </div>

        <div class="glass-card">
            <!-- Workflow Information -->
            <div class="workflow-info">
                <h3>
                    <i class="fas fa-route"></i>
                    Circuit de Validation
                </h3>
                <div class="workflow-steps">
                    <div class="workflow-step">
                        <span class="step-number">1</span>
                        <i class="fas fa-user-tie"></i>
                        <span><strong>Chef de Service</strong> - Pré-validation</span>
                    </div>
                    <div class="workflow-step">
                        <span class="step-number">2</span>
                        <i class="fas fa-user-shield"></i>
                        <span><strong>Directeur</strong> - Validation</span>
                    </div>
                    <div class="workflow-step">
                        <span class="step-number">3</span>
                        <i class="fas fa-user-crown"></i>
                        <span><strong>Directeur Général</strong> - Autorisation</span>
                    </div>
                    <div class="workflow-step">
                        <span class="step-number">4</span>
                        <i class="fas fa-cogs"></i>
                        <span><strong>Moyens Généraux</strong> - Traitement</span>
                    </div>
                </div>
            </div>

            <form id="createRequestForm">
                <div class="form-group">
                    <label>
                        <i class="fas fa-heading"></i>
                        Objet de la demande <span class="required">*</span>
                    </label>
                    <input type="text" name="objet" id="objet" required maxlength="255" placeholder="Ex: Demande d'équipement informatique">
                </div>

                <div class="form-group">
                    <label>
                        <i class="fas fa-align-left"></i>
                        Description détaillée <span class="required">*</span>
                    </label>
                    <textarea name="description" id="description" required placeholder="Décrivez votre demande en détail..."></textarea>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>
                            <i class="fas fa-sort-numeric-up"></i>
                            Quantité
                        </label>
                        <input type="number" name="quantite" id="quantite" min="1" value="1">
                    </div>

                    <div class="form-group">
                        <label>
                            <i class="fas fa-exclamation-circle"></i>
                            Priorité
                        </label>
                        <select name="priorite" id="priorite">
                            <option value="normale">Normale</option>
                            <option value="urgente">Urgente</option>
                            <option value="critique">Critique</option>
                        </select>
                    </div>
                </div>

                <button type="submit" id="submitBtn">
                    <i class="fas fa-paper-plane"></i>
                    <span>Soumettre la Demande</span>
                    <div class="spinner"></div>
                </button>
            </form>

            <div id="resultMsg" class="result-message"></div>

            <a href="my_requests.php" class="back-link">
                <i class="fas fa-arrow-left"></i>
                Retour à Mes Demandes
            </a>
        </div>
    </div>

    <script>
    document.getElementById('createRequestForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const form = e.target;
        const formData = new FormData(form);
        const submitBtn = document.getElementById('submitBtn');
        const resultMsg = document.getElementById('resultMsg');
        const btnText = submitBtn.querySelector('span');
        const btnIcon = submitBtn.querySelector('i');
        
        // Disable submit button
        submitBtn.disabled = true;
        btnText.textContent = 'Envoi en cours...';
        btnIcon.className = '';
        
        // Hide previous messages
        resultMsg.style.display = 'none';
        resultMsg.className = 'result-message';
        
        fetch('ajax_create_request.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erreur HTTP: ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                resultMsg.className = 'result-message success';
                resultMsg.innerHTML = `
                    <i class="fas fa-check-circle"></i>
                    <strong>Succès!</strong> Votre demande a été soumise avec succès.<br>
                    <small>Une notification a été envoyée au Chef de Service pour pré-validation.</small>
                `;
                resultMsg.style.display = 'block';
                form.reset();
                
                // Redirect after 3 seconds
                setTimeout(() => {
                    window.location.href = 'my_requests.php';
                }, 3000);
            } else {
                resultMsg.className = 'result-message error';
                resultMsg.innerHTML = `
                    <i class="fas fa-exclamation-circle"></i>
                    <strong>Erreur!</strong> ${data.message || 'Impossible de soumettre la demande.'}
                `;
                resultMsg.style.display = 'block';
            }
        })
        .catch(error => {
            resultMsg.className = 'result-message error';
            resultMsg.innerHTML = `
                <i class="fas fa-times-circle"></i>
                <strong>Erreur réseau!</strong> ${error.message}. Veuillez réessayer.
            `;
            resultMsg.style.display = 'block';
        })
        .finally(() => {
            submitBtn.disabled = false;
            btnText.textContent = 'Soumettre la Demande';
            btnIcon.className = 'fas fa-paper-plane';
        });
    });
    </script>
</body>
</html>