<?php
require_once __DIR__ . '/../Config/session.php';
require_login();
// Vérifier que l'utilisateur est connecté (session.php already handles this)
if (!isset($_SESSION['user_id'])) {
    header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit();
}
// Inclure les fichiers nécessaires
include '../public/notications.php';
require_once __DIR__ . '/../include/materiel.php';
require_once __DIR__ . '/../include/besoin.php';
$agent_id = $_SESSION['user_id'];
try {
    $besoins = besoin_par_agent($agent_id);
} catch (Exception $e) {
    error_log("Erreur lors de la récupération des besoins: " . $e->getMessage());
    $besoins = [];
    $error_message = "Erreur lors du chargement des données.";
}
// Gestion du filtre avec validation
$statut_filter = isset($_GET['statut']) ? trim($_GET['statut']) : '';
$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';
// Validation du statut
$statuts_valides = ['Validé', 'En attente', 'Rejeté'];
if ($statut_filter && !in_array($statut_filter, $statuts_valides)) {
    $statut_filter = '';
}
// Filtrer les besoins selon le statut et la recherche
$besoins = array_filter($besoins, function($b) use ($statut_filter, $search_query) {
    $match_statut = $statut_filter === '' || $b['statut'] === $statut_filter;
    $match_search = $search_query === '' || 
                   stripos($b['designation'], $search_query) !== false ||
                   stripos($b['besoin'], $search_query) !== false ||
                   stripos($b['justification'], $search_query) !== false;
    return $match_statut && $match_search;
});
// Fonction pour colorer les badges selon le statut
function badgeClass($statut) {
    return match(strtolower($statut)) {
        'validé' => 'success',
        'en attente' => 'warning',
        'rejeté' => 'danger',
        default => 'secondary'
    };
}
// Fonction pour formater les dates
function formatDate($date) {
    if (!$date) return '';
    try {
        $datetime = new DateTime($date);
        return $datetime->format('d/m/Y H:i');
    } catch (Exception $e) {
        return htmlspecialchars($date);
    }
}
// Pagination
$items_per_page = 10;
$total_items = count($besoins);
$current_page = max(1, intval($_GET['page'] ?? 1));
$total_pages = ceil($total_items / $items_per_page);
$offset = ($current_page - 1) * $items_per_page;
$besoins_paginated = array_slice($besoins, $offset, $items_per_page);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventaire - Besoins</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .card-header {
            background-color: #f8f9fa;
        }
        .badge {
            font-size: 0.75rem;
        }
        .search-highlight {
            background-color: yellow;
            font-weight: bold;
        }
        .pagination-wrapper {
            display: flex;
            justify-content: center;
            margin-top: 2rem;
        }
        .no-results {
            text-align: center;
            padding: 3rem;
            color: #6c757d;
        }
        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body class="bg-light">
<div class="container-fluid py-4">
    <!-- En-tête avec statistiques -->
    <div class="row mb-4">
        <div class="col-md-8">
            <h1 class="mb-3">
                <i class="fas fa-clipboard-list text-primary me-2"></i>
                Liste des besoins
            </h1>
        </div>
        <div class="col-md-4">
            <div class="stats-card">
                <h5><i class="fas fa-chart-bar me-2"></i>Statistiques</h5>
                <p class="mb-1">Total: <strong><?= $total_items ?></strong> besoins</p>
                <p class="mb-0">Page <?= $current_page ?> sur <?= $total_pages ?></p>
            </div>
        </div>
    </div>
    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <?= htmlspecialchars($error_message) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <!-- Formulaire de filtre et recherche amélioré -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-filter me-2"></i>Filtres et recherche</h5>
        </div>
        <div class="card-body">
            <form class="row g-3" method="get">
                <div class="col-md-5">
                    <label for="search" class="form-label">Rechercher</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" 
                               id="search" 
                               name="search" 
                               class="form-control" 
                               placeholder="Rechercher dans désignation, besoin ou justification..." 
                               value="<?= htmlspecialchars($search_query) ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <label for="statut" class="form-label">Statut</label>
                    <select name="statut" id="statut" class="form-select">
                        <option value="">Tous les statuts</option>
                        <?php foreach ($statuts_valides as $statut): ?>
                            <option value="<?= htmlspecialchars($statut) ?>" 
                                    <?= $statut_filter === $statut ? 'selected' : '' ?>>
                                <?= htmlspecialchars($statut) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4 d-flex align-items-end gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search me-1"></i>Filtrer
                    </button>
                    <a href="inventaire.php" class="btn btn-secondary">
                        <i class="fas fa-undo me-1"></i>Réinitialiser
                    </a>
                    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#newRequestModal">
                        <i class="fas fa-plus me-1"></i>Nouveau besoin
                    </button>
                </div>
            </form>
        </div>
    </div>
    <!-- Résultats -->
    <?php if (!empty($besoins_paginated)): ?>
        <div class="row">
            <?php foreach ($besoins_paginated as $besoin): ?>
                <div class="col-12 mb-3">
                    <div class="card shadow-sm">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <div>
                                <strong>Besoin #<?= htmlspecialchars($besoin['id']) ?></strong>
                                <small class="text-muted ms-2">
                                    <i class="fas fa-calendar me-1"></i>
                                    Soumis le <?= formatDate($besoin['date_soumission']) ?>
                                </small>
                            </div>
                            <span class="badge bg-<?= badgeClass($besoin['statut']) ?>">
                                <?php
                                $icon = match(strtolower($besoin['statut'])) {
                                    'validé' => 'fas fa-check-circle',
                                    'en attente' => 'fas fa-clock',
                                    'rejeté' => 'fas fa-times-circle',
                                    default => 'fas fa-question-circle'
                                };
                                ?>
                                <i class="<?= $icon ?> me-1"></i>
                                <?= htmlspecialchars($besoin['statut']) ?>
                            </span>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-8">
                                    <h6><i class="fas fa-tag text-primary me-2"></i>Désignation</h6>
                                    <p class="mb-3"><?= htmlspecialchars($besoin['designation']) ?></p>
                                    <h6><i class="fas fa-clipboard text-info me-2"></i>Description du besoin</h6>
                                    <p class="mb-3"><?= htmlspecialchars($besoin['besoin']) ?></p>
                                    <h6><i class="fas fa-comment-alt text-warning me-2"></i>Justification</h6>
                                    <p class="mb-3"><?= htmlspecialchars($besoin['justification']) ?></p>
                                </div>
                                <div class="col-md-4">
                                    <?php
                                    try {
                                        $materiels = materiel_par_etat($besoin['id']);
                                        if (!empty($materiels)): ?>
                                            <h6><i class="fas fa-boxes text-success me-2"></i>Matériels associés</h6>
                                            <div class="list-group list-group-flush">
                                                <?php foreach ($materiels as $materiel): ?>
                                                    <div class="list-group-item px-0 py-2 border-0">
                                                        <div class="d-flex justify-content-between align-items-start">
                                                            <div>
                                                                <strong><?= htmlspecialchars($materiel['designation']) ?></strong>
                                                                <br>
                                                                <small class="text-muted">
                                                                    <?= htmlspecialchars($materiel['categorie']) ?>
                                                                </small>
                                                            </div>
                                                            <span class="badge bg-<?= badgeClass($materiel['statut']) ?> ms-2">
                                                                <?= htmlspecialchars($materiel['statut']) ?>
                                                            </span>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php else: ?>
                                            <div class="text-center text-muted">
                                                <i class="fas fa-inbox fa-2x mb-2"></i>
                                                <p><em>Aucun matériel associé</em></p>
                                            </div>
                                        <?php endif;
                                    } catch (Exception $e) {
                                        error_log("Erreur lors de la récupération des matériels pour le besoin {$besoin['id']}: " . $e->getMessage());
                                        echo '<p class="text-danger"><em>Erreur lors du chargement des matériels</em></p>';
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer bg-transparent">
                            <div class="btn-group" role="group">
                                <button class="btn btn-outline-primary btn-sm" 
                                        onclick="viewDetails(<?= $besoin['id'] ?>)">
                                    <i class="fas fa-eye me-1"></i>Détails
                                </button>
                                <?php if ($besoin['statut'] === 'En attente'): ?>
                                    <button class="btn btn-outline-warning btn-sm" 
                                            onclick="editRequest(<?= $besoin['id'] ?>)">
                                        <i class="fas fa-edit me-1"></i>Modifier
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <div class="pagination-wrapper">
                <nav>
                    <ul class="pagination">
                        <li class="page-item <?= $current_page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $current_page - 1])) ?>">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                        </li>
                        <?php for ($i = max(1, $current_page - 2); $i <= min($total_pages, $current_page + 2); $i++): ?>
                            <li class="page-item <?= $i === $current_page ? 'active' : '' ?>">
                                <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>">
                                    <?= $i ?>
                                </a>
                            </li>
                        <?php endfor; ?>
                        <li class="page-item <?= $current_page >= $total_pages ? 'disabled' : '' ?>">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $current_page + 1])) ?>">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="no-results">
            <i class="fas fa-search fa-4x text-muted mb-3"></i>
            <h4>Aucun besoin trouvé</h4>
            <p class="text-muted">Essayez de modifier vos critères de recherche ou créez un nouveau besoin.</p>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newRequestModal">
                <i class="fas fa-plus me-2"></i>Créer un nouveau besoin
            </button>
        </div>
    <?php endif; ?>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<script>
    function viewDetails(id) {
        // Logique pour afficher les détails
        console.log('Voir détails du besoin:', id);
        // Vous pouvez rediriger vers une page de détails ou ouvrir une modale
    }
    function editRequest(id) {
        // Logique pour modifier la demande
        console.log('Modifier le besoin:', id);
        // Redirection vers le formulaire de modification
        window.location.href = `edit_request.php?id=${id}`;
    }
    // Auto-submit du formulaire après un délai lors de la saisie
    let searchTimeout;
    document.getElementById('search').addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            this.form.submit();
        }, 500);
    });
</script>
</body>
</html>