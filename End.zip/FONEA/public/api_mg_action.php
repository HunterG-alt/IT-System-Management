<?php
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../modules/WorkflowManager.php';
header('Content-Type: application/json');
if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['error' => 'Non authentifié']);
    exit;
}
if (($_SESSION['role'] ?? '') !== 'moyens_generaux') {
    http_response_code(403);
    echo json_encode(['error' => 'Accès refusé']);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Méthode non autorisée']);
    exit;
}
if (!CSRFProtection::verifyTokenFor('mg_request_action', $_POST['csrf_token_mg_request_action'] ?? null)) {
    http_response_code(403);
    echo json_encode(['error' => 'Token CSRF invalide']);
    exit;
}
$id_besoin = (int)($_POST['id_besoin'] ?? 0);
$action = $_POST['action'] ?? '';
$commentaire = trim($_POST['commentaire'] ?? '');
// actions: assign, process, complete
if ($id_besoin <= 0 || !in_array($action, ['assign', 'process', 'complete'], true)) {
    http_response_code(400);
    echo json_encode(['error' => 'Paramètres invalides']);
    exit;
}
try {
    $pdo = Database::getInstance()->getConnection();
    $pdo->beginTransaction();
    // Read current status
    $st = $pdo->prepare("SELECT statut FROM etat_de_besoin WHERE id_besoin = ?");
    $st->execute([$id_besoin]);
    $current = $st->fetchColumn();
    if (!$current) throw new Exception('Demande introuvable');
    $newStatus = $current;
    if ($action === 'assign' && $current === 'permission_dg_accordee') {
        $newStatus = 'en_acquisition';
    } elseif ($action === 'process' && in_array($current, ['en_acquisition','en_analyse_technique'])) {
        $newStatus = 'attribuee';
    } elseif ($action === 'complete' && in_array($current, ['attribuee'])) {
        $newStatus = 'cloturee';
    } else {
        throw new Exception('Transition invalide');
    }
    $up = $pdo->prepare("UPDATE etat_de_besoin SET statut = ?, commentaire_mg = ?, id_mg = ?, date_maj = NOW() WHERE id_besoin = ?");
    $up->execute([$newStatus, $commentaire, (int)$_SESSION['user_id'], $id_besoin]);
    $pdo->commit();
    echo json_encode(['success' => true, 'new_status' => $newStatus]);
} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Erreur serveur']);
}
?>
