<?php
require_once '../Config/session.php';
require_once __DIR__ . '/../public/userClass.php';
require_once '../include/besoin.php';
require_once __DIR__ . '/../public/notifications.php';
require_once __DIR__ . '/../Config/titles.php'; 

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'directeur') {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit();
}

$user = User::getById($_SESSION['user_id']);
$user_name = $user ? $user['nom_complet'] : 'Directeur';

$pending_validation = Besoin::countByStatut('EN_ATTENTE');
$approved_requests = Besoin::countByStatut('APPROUVE');
$notif_stats = Notification::getStats($_SESSION['user_id']);
$total_notifications = $notif_stats['unread'];

$currentPage = basename(__FILE__);
$pageTitle = $pageTitles[$currentPage] ?? 'Dashboard - FONEA';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="../assets/css/dashboard-common.css" rel="stylesheet">
   <style>
        
        .dashboard-directeur .sidebar {
            background: linear-gradient(180deg, #c2410c 0%, #9a3412 100%);
        }
        
        .dashboard-directeur .btn-accueil {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 90%;
            margin: 30px auto 20px auto;
            padding: 14px 0;
            border-radius: 30px;
            font-size: 1.1rem;
            font-weight: bold;
            background: linear-gradient(135deg, #c2410c, #f97316);
            color: #fff !important;
            box-shadow: 0 4px 16px rgba(249,115,22,0.15);
            border: none;
            transition: background 0.3s, transform 0.2s;
            text-decoration: none !important;
        }
        .btn-accueil i {
            margin-right: 10px;
            font-size: 1.2em;
        }
        .btn-accueil:hover {
            background: linear-gradient(135deg, #9a3412, #c2410c);
            color: #fff !important;
            transform: translateY(-2px) scale(1.03);
            text-decoration: none !important;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #ffffff;
            color: #1a1a1a;
            overflow-x: hidden;
        }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 240px;
            height: 100vh;
            background: linear-gradient(180deg, #f97316 0%, #ea580c 100%);
            z-index: 1000;
            transition: all 0.3s ease;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
        }
        .sidebar-header {
            padding: 30px 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .sidebar-logo {
            color: #ffffff;
            font-size: 24px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .sidebar-logo i {
            color: #ffffff;
            font-size: 28px;
        }
        .sidebar-nav {
            padding: 20px 0;
            padding-bottom: 180px;
        }
        .nav-item {
            margin: 8px 20px;
        }
        .nav-link {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
            gap: 15px;
        }
        .nav-link:hover {
            background: rgba(255, 255, 255, 0.1);
            color: #ffffff;
            transform: translateX(5px);
            text-decoration: none;
        }
        .nav-link.active {
            background: rgba(255, 255, 255, 0.2);
            color: #ffffff;
            box-shadow: 0 4px 15px rgba(249, 115, 22, 0.3);
        }
        .nav-link i {
            font-size: 18px;
            width: 20px;
        }
        /* Main Content */
        .main-content {
            margin-left: 240px;
            min-height: 100vh;
            background: #ffffff;
        }
        /* Top Header */
        .top-header {
            background: #ffffff;
            padding: 20px 40px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        .search-bar {
            flex: 1;
            max-width: 400px;
            margin: 0 30px;
            position: relative;
        }
        .search-input {
            width: 100%;
            padding: 12px 20px 12px 45px;
            border: 2px solid #e2e8f0;
            border-radius: 25px;
            background: #f8fafc;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        .search-input:focus {
            outline: none;
            border-color: #f97316;
            background: #ffffff;
            box-shadow: 0 0 0 3px rgba(249, 115, 22, 0.1);
        }
        .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
        }
        .header-actions {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .notification-btn {
            position: relative;
            background: #f8fafc;
            border: none;
            width: 45px;
            height: 45px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .notification-btn:hover {
            background: #f97316;
            color: #ffffff;
            transform: translateY(-2px);
        }
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #ef4444;
            color: #ffffff;
            font-size: 11px;
            padding: 2px 6px;
            border-radius: 10px;
            font-weight: 600;
        }
        .profile-section {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 16px;
            background: #f8fafc;
            border-radius: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            color: inherit;
        }
        .profile-section:hover {
            background: #e2e8f0;
            text-decoration: none;
            color: inherit;
        }
        .profile-avatar {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            background: linear-gradient(135deg, #f97316, #ea580c);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            font-weight: 600;
            font-size: 16px;
        }
        .profile-info h6 {
            margin: 0;
            font-size: 14px;
            font-weight: 600;
            color: #1e293b;
        }
        .profile-info p {
            margin: 0;
            font-size: 12px;
            color: #64748b;
        }
        /* Welcome Section */
        .welcome-section {
            padding: 40px;
            background: linear-gradient(135deg, #fff7ed 0%, #fed7aa 100%);
        }
        .welcome-title {
            font-size: 32px;
            font-weight: 700;
            color: #c2410c;
            margin-bottom: 8px;
        }
        .welcome-subtitle {
            font-size: 16px;
            color: #ea580c;
            margin-bottom: 0;
        }
        
        .dashboard-section {
            padding: 40px;
        }
        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        .directeur-dashboard-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 25px;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            border: 1px solid #e2e8f0;
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-decoration: none !important;
            color: inherit;
        }
        .directeur-dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(249, 115, 22, 0.2);
        }
        .card-icon {
            width: 60px;
            height: 60px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: #ffffff;
            margin-bottom: 20px;
        }
        .card-title {
            font-size: 20px;
            font-weight: 600;
            color: #c2410c;
            margin-bottom: 8px;
        }
        .card-description {
            font-size: 14px;
            color: #ea580c;
            margin-bottom: 15px;
            line-height: 1.5;
        }
        .card-metric {
            font-size: 28px;
            font-weight: 700;
            color: #c2410c;
        }
        
        .card-validation .card-icon { background: linear-gradient(135deg, #f97316, #ea580c); }
        .card-management .card-icon { background: linear-gradient(135deg, #f59e0b, #d97706); }
        .card-reports .card-icon { background: linear-gradient(135deg, #fbbf24, #f59e0b); }
        .card-decisions .card-icon { background: linear-gradient(135deg, #fb923c, #f97316); }
        .card-oversight .card-icon { background: linear-gradient(135deg, #fdba74, #fb923c); }
        .card-notifications .card-icon { background: linear-gradient(135deg, #ef4444, #dc2626); }
        /* Side Panels */
        .side-panels {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
            margin-top: 30px;
        }
        .dashboard-card,
        .directeur-side-panel {
            background: #ffffff;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            border: 1px solid #e2e8f0;
        }
        .panel-title {
            font-size: 18px;
            font-weight: 600;
            color: #c2410c;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .decision-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 0;
            border-bottom: 1px solid #f1f5f9;
        }
        .decision-item:last-child {
            border-bottom: none;
        }
        .decision-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: linear-gradient(135deg, #f97316, #ea580c);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            font-size: 14px;
        }
        .decision-info h6 {
            margin: 0;
            font-size: 14px;
            font-weight: 500;
            color: #c2410c;
        }
        .decision-info p {
            margin: 0;
            font-size: 12px;
            color: #ea580c;
        }
        #overviewChart {
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
            display: block !important;
            margin: 0 auto !important;
        }
        .logout-btn {
            position: fixed;
            bottom: 30px;
            left: 20px;
            width: 200px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #ffffff;
            padding: 12px 20px;
            border-radius: 12px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
        }
        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            color: #ffffff;
            text-decoration: none;
        }
        .chart-container {
            position: relative;
            height: 220px;
            width: 100%;
        }
        .actions-cell {
            text-align: center;
            vertical-align: middle;
            white-space: nowrap;
        }
        .btn-action {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            margin: 3px;
            min-width: 85px;
            justify-content: center;
        }
        a, a:hover, a:focus, a:active {
            text-decoration: none !important;
            outline: none;
        }
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .main-content {
                margin-left: 0;
            }
            .top-header {
                padding: 15px 20px;
            }
            .dashboard-section {
                padding: 20px;
            }
            .cards-grid {
                grid-template-columns: 1fr;
            }
            .side-panels {
                grid-template-columns: 1fr;
            }
        }
        .overViewChart {
             width: 100% !important;
             height: 220px !important;
             display: block !important;
             margin: 0 auto !important;
        }
    </style>

</head>
<body class="dashboard-directeur">
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-user-tie"></i>
                FONEA Directeur
            </div>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-item">
                <a href="#" class="nav-link active">
                    <i class="fas fa-chart-pie"></i>
                    Dashboard
                </a>
            </div>
            <div class="nav-item">
                <a href="../modules/Approve.php" class="nav-link">
                    <i class="fas fa-stamp"></i>
                    Validation Finale
                </a>
            </div>
            <div class="nav-item">
                <a href="content.php" class="nav-link">
                    <i class="fas fa-sitemap"></i>
                    Gestion Services
                </a>
            </div>
            <div class="nav-item">
                <a href="export_reports.php" class="nav-link">
                    <i class="fas fa-chart-line"></i>
                    Rapports Stratégiques
                </a>
            </div>
            <div class="nav-item">
                <a href="content.php#requests" class="nav-link">
                    <i class="fas fa-gavel"></i>
                    Centre Décisions
                </a>
            </div>
            <div class="nav-item">
                <a href="../view/historique.php" class="nav-link">
                    <i class="fas fa-eye"></i>
                    Supervision
                </a>
            </div>
            <div class="nav-item">
                <a href="../public/notifications.php" class="nav-link">
                    <i class="fas fa-bell"></i>
                    Notifications
                </a>
            </div>
            <div class="nav-item">
                <a href="settings.php" class="nav-link">
                    <i class="fas fa-cog"></i>
                    Paramètres
                </a>
            </div>
        </nav>
        <a href="../layout/header.php" class="btn-accueil"><i class="fas fa-home"></i>Accueil</a>
    </div>
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <div class="search-bar position-relative">
                <i class="fas fa-search search-icon"></i>
                <input type="text" class="search-input" placeholder="Rechercher...">
            </div>
            <div class="header-actions">
                <button class="notification-btn">
                    <i class="fas fa-bell"></i>
                    <?php if ($total_notifications > 0): ?>
                        <span class="notification-badge"><?= $total_notifications ?></span>
                    <?php endif; ?>
                </button>
                <div class="profile-section">
                    <div class="profile-avatar">
                        <?= strtoupper(substr($user_name, 0, 2)) ?>
                    </div>
                    <div class="profile-info">
                        <h6><?= htmlspecialchars($user_name) ?></h6>
                        <p>Directeur</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Welcome Section -->
        <div class="welcome-section">
            <h1 class="welcome-title">Bienvenue Directeur, <?= htmlspecialchars($user_name) ?></h1>
            <p class="welcome-subtitle">Tableau de bord de direction - Supervision stratégique et validation finale</p>
        </div>
        <!-- Dashboard Section -->
        <div class="dashboard-section">
            <div class="cards-grid">
                <a href="../modules/approve.php" class="directeur-dashboard-card card-validation">
                    <div class="card-icon">
                        <i class="fas fa-stamp"></i>
                    </div>
                    <h3 class="card-title">Validation Finale</h3>
                    <p class="card-description">Demandes en attente de votre approbation finale</p>
                    <div class="card-metric"><?= $pending_validation ?></div>
                </a>
                <a href="content.php" class="directeur-dashboard-card card-management">
                    <div class="card-icon">
                        <i class="fas fa-sitemap"></i>
                    </div>
                    <h3 class="card-title">Gestion Services</h3>
                    <p class="card-description">Supervision des chefs de service et coordination</p>
                    <div class="card-metric">Actif</div>
                </a>
                <a href="export_reports.php" class="directeur-dashboard-card card-reports">
                    <div class="card-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <h3 class="card-title">Rapports Stratégiques</h3>
                    <p class="card-description">Analyses et indicateurs de performance organisationnelle</p>
                    <div class="card-metric"><?= $approved_requests ?></div>
                </a>
                <a href="my_requests.php" class="directeur-dashboard-card card-decisions">
                    <div class="card-icon">
                        <i class="fas fa-gavel"></i>
                    </div>
                    <h3 class="card-title">Centre Décisions</h3>
                    <p class="card-description">Prise de décisions stratégiques et arbitrages</p>
                    <div class="card-metric">Prioritaire</div>
                </a>
                <a href="../view/historique.php" class="directeur-dashboard-card card-oversight">
                    <div class="card-icon">
                        <i class="fas fa-eye"></i>
                    </div>
                    <h3 class="card-title">Supervision</h3>
                    <p class="card-description">Surveillance globale des opérations et processus</p>
                    <div class="card-metric">Continu</div>
                </a>
                <a href="../public/notifications.php" class="directeur-dashboard-card card-notifications">
                    <div class="card-icon">
                        <i class="fas fa-bell"></i>
                    </div>
                    <h3 class="card-title">Notifications</h3>
                    <p class="card-description">Alertes critiques et notifications importantes</p>
                    <div class="card-metric"><?= $total_notifications ?></div>
                </a>
            </div>
            <!-- Side Panels -->
            <div class="side-panels">
                <div class="dashboard-card">
                    <h4 class="panel-title">
                        <i class="fas fa-tasks"></i>
                        <a href="decision.php" style="text-decoration:none; color:inherit; cursor:pointer;">
                                Décisions Récentes
                        </a>
                    </h4>
                    <div class="decision-item">
                        <div class="decision-icon">
                            <i class="fas fa-check"></i>
                        </div>
                        <div class="decision-info">
                            <h6>Demande Validée</h6>
                            <p class="decision-time"></p>
                        </div>
                    </div>
                    <div class="decision-item">
                        <div class="decision-icon">
                            <i class="fas fa-times"></i>
                        </div>
                        <div class="decision-info">
                            <h6>Demande Rejetée</h6>
                            <p class="decision-time"></p>
                        </div>
                    </div>
                    <div class="decision-item">
                        <div class="decision-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="decision-info">
                            <h6>Demande En révision</h6>
                            <p class="decision-time"></p>
                        </div>
                    </div>
                </div>
                <div class="directeur-side-panel">
                    <h4 class="panel-title">
                        <i class="fas fa-chart-area"></i>
                        Vue d'Ensemble
                    </h4>
                    <canvas id="overviewChart"></canvas>
                </div>
            </div>
            <!-- Pending Requests (Pré-validées) for Directeur -->
            <div class="mt-4">
                <div class="dashboard-card" style="max-width:100%">
                    <h4 class="panel-title"><i class="fas fa-stamp"></i> Demandes en attente de validation Directeur</h4>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Demandeur</th>
                                    <th>Désignation</th>
                                    <th>Statut</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($pending_list)): ?>
                                    <tr><td colspan="5" class="text-center text-muted">Aucune demande en attente</td></tr>
                                <?php else: foreach ($pending_list as $row): ?>
                                    <tr data-id="<?= (int)$row['id_besoin'] ?>">
                                        <td><?= (int)$row['id_besoin'] ?></td>
                                        <td><?= htmlspecialchars($row['prenom'] . ' ' . $row['nom']) ?></td>
                                        <td><?= htmlspecialchars($row['designation_materiel'] ?? '') ?></td>
                                        <td><span class="status-badge <?= htmlspecialchars($row['statut']) ?>"><?= htmlspecialchars($row['statut']) ?></span></td>
                                        <td class="actions-cell">
                                            <button type="button" class="btn btn-sm btn-success btn-action" onclick="window.location.href='../modules/approve.php?id=<?= (int)$row['id_besoin'] ?>'">
                                                <i class="fas fa-check"></i> Valider
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger btn-action" onclick="window.location.href='../modules/reject.php?id=<?= (int)$row['id_besoin'] ?>&reject=1'">
                                                <i class="fas fa-times"></i> Rejeter
                                            </button>
                                            <span class="status-badge status-<?= strtolower(htmlspecialchars($row['statut'])) ?>">
                                                <?= htmlspecialchars($row['statut']) ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Overview Chart
        const ctx = document.getElementById('overviewChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Validées', 'En attente', 'Rejetées', 'En révision'],
                datasets: [{
                    label: 'Demandes',
                    data: [45, 12, 8, 5],
                    backgroundColor: ['#f97316', '#fbbf24', '#ef4444', '#64748b'],
                    borderRadius: 8,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: '#f1f5f9'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        // Add click handlers to notification button
        document.querySelector('.notification-btn').addEventListener('click', function() {
            window.location.href = 'notifications.php';
        });
        function getFormattedDate() {
            const now = new Date();
            const options = {
              weekday: 'long',
              year: 'numeric',
              month: 'long',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            };
            return now.toLocaleDateString('fr-FR', options);
        }
        // Update all .decision-time elements
        document.querySelectorAll('.decision-time').forEach(el => {
            el.textContent = `Modifié le ${getFormattedDate()}`;
        });
    </script>
</body>
</html>