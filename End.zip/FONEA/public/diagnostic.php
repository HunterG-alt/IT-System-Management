<?php
// Minimal login.php for testing
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Login Debug Mode</h1>";

// Try to include required files
try {
    require_once '../Config/session.php';
    echo "<span style='color: green'>✓ session.php loaded</span><br>";
} catch (Exception $e) {
    echo "<span style='color: red'>✗ session.php failed: " . $e->getMessage() . "</span><br>";
}

try {
    define('USER_BYPASS_GUARD', true);
    require_once __DIR__ . '/../public/user.php';
    echo "<span style='color: green'>✓ user.php loaded</span><br>";
} catch (Exception $e) {
    echo "<span style='color: red'>✗ user.php failed: " . $e->getMessage() . "</span><br>";
}

try {
    require_once '../Config/db.php';
    echo "<span style='color: green'>✓ db.php loaded</span><br>";
} catch (Exception $e) {
    echo "<span style='color: red'>✗ db.php failed: " . $e->getMessage() . "</span><br>";
}

// Check if already logged in
echo "<h2>Session Check</h2>";
if (function_exists('is_logged_in')) {
    if (is_logged_in()) {
        echo "<span style='color: blue'>User is already logged in</span><br>";
        echo "Role: " . ($_SESSION['role'] ?? 'unknown') . "<br>";
        echo "User ID: " . ($_SESSION['user_id'] ?? 'unknown') . "<br>";
        
        // Test dashboard redirect
        $role = $_SESSION['role'] ?? '';
        switch ($role) {
            case 'directeur_general':
                $dashboard_url = 'http://localhost/FONEA/show/dashboard_dg.php';
                break;
            case 'directeur':
                $dashboard_url = 'http://localhost/FONEA/show/dashboard_directeur.php';
                break;
            case 'chef_service':
                $dashboard_url = 'http://localhost/FONEA/show/dashboard_chef.php';
                break;
            case 'demandeur':
                $dashboard_url = 'http://localhost/FONEA/show/dashboard_agent.php';
                break;
            case 'informatique':
                $dashboard_url = 'http://localhost/FONEA/show/dashboard_informatique.php';
                break;
            case 'moyens_generaux':
                $dashboard_url = 'http://localhost/FONEA/show/dashboard_moyens_generaux.php';
                break;
            default:
$dashboard_url = BASE_URL . '/public/mini_dashboard.php';
        }
        
        echo "Dashboard URL would be: <a href='{$dashboard_url}' target='_blank'>{$dashboard_url}</a><br>";
        echo "<a href='?logout=1'>Logout for testing</a><br>";
    } else {
        echo "<span style='color: orange'>User is not logged in</span><br>";
    }
} else {
    echo "<span style='color: red'>is_logged_in() function not available</span><br>";
}

// Handle logout
if (isset($_GET['logout'])) {
    if (function_exists('user_logout')) {
        user_logout();
        echo "<script>window.location.reload();</script>";
    } else {
        session_destroy();
        echo "<script>window.location.reload();</script>";
    }
}

// Simple login form
if (!function_exists('is_logged_in') || !is_logged_in()) {
    echo "<h2>Login Form</h2>";
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        
        echo "<h3>Login Attempt Debug:</h3>";
        echo "Email: " . htmlspecialchars($email) . "<br>";
        echo "Password length: " . strlen($password) . "<br>";
        
        if (class_exists('User') && method_exists('User', 'authenticate')) {
            echo "User class available<br>";
            
            $user = User::authenticate($email, $password);
            echo "Authentication result: " . ($user ? 'SUCCESS' : 'FAILED') . "<br>";
            
            if ($user) {
                echo "User data: <pre>" . print_r($user, true) . "</pre>";
                
                // Manual session setup for testing
                session_regenerate_id(true);
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['logged_in'] = true;
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['nom_complet'] = ($user['prenom'] ?? '') . ' ' . ($user['nom'] ?? '');
                $_SESSION['prenom'] = $user['prenom'] ?? '';
                
                echo "<span style='color: green'>Login successful! Reloading page...</span>";
                echo "<script>setTimeout(function(){ window.location.reload(); }, 2000);</script>";
            } else {
                echo "<span style='color: red'>Login failed</span><br>";
            }
        } else {
            echo "<span style='color: red'>User class not available</span><br>";
        }
    }
    
    ?>
    <form method="POST">
        <div>
            <label>Email:</label><br>
            <input type="email" name="email" required>
        </div>
        <div>
            <label>Password:</label><br>
            <input type="password" name="password" required>
        </div>
        <div>
            <button type="submit">Login</button>
        </div>
    </form>
    <?php
}

echo "<br><hr><br>";
echo "<strong>Next Steps:</strong><br>";
echo "1. Run the diagnostic.php script first<br>";
echo "2. Try logging in with this debug version<br>";
echo "3. Check what errors or information you get<br>";
echo "4. Test the dashboard links manually<br>";
?>