<?php
require_once '../Config/db.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit;
}
$requestId = $_GET['id'] ?? null;
if (!$requestId) {
    die('Request ID missing.');
}
$stmt = $pdo->prepare("SELECT * FROM requests WHERE id = :id AND user_id = :user_id");
$stmt->execute([
    'id' => $requestId,
    'user_id' => $_SESSION['user_id']
]);
$request = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$request) {
    die('Request not found or unauthorized.');
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Request Status</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9fafb;
            margin: 0;
            padding: 20px;
        }
        h2 {
            color: #333;
        }
        p {
            background: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            max-width: 600px;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #3b82f6;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<h2>Request Status</h2>
<h4><?= htmlspecialchars($request['title']) ?></h4>
<p><?= htmlspecialchars($request['description']) ?></p>
<p>Status: <?= htmlspecialchars($request['status']) ?></p>
<a href="my_requests.php">Back to My Requests</a>
</body>
</html>
