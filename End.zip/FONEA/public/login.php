<?php
require_once __DIR__ . '/../Config/session.php';
define('USER_BYPASS_GUARD', true);
require_once __DIR__ . '/../public/user.php';
require_once __DIR__ . '/../Config/db.php';
function getDirectDashboard($role) {
    
    $base = '';
    if (class_exists('SessionAuth') && method_exists('SessionAuth', 'getBaseUrl')) {
        $base = SessionConfig::getBaseUrl();
    } else {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost');
        $scriptPath = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
        $base = rtrim($scheme . '://' . $host . preg_replace('#/public$#i', '', $scriptPath), '/');
    }

    
    switch ($role) {
        case 'directeur_general':
        case 'dg':
            return $base . '/show/dashboard_dg.php';
        case 'directeur':
            return $base . '/show/dashboard_directeur.php';
        case 'chef_service':
            return $base . '/show/dashboard_chef.php';
        case 'demandeur':
        case 'agent':
            return $base . '/show/dashboard_agent.php';
        case 'informatique':
            return $base . '/show/dashboard_informatique.php';
        case 'moyens_generaux':
            return $base . '/show/dashboard_moyens_generaux.php';
        default:
            
            return $base . '/public/mini_dashboard.php';
    }
}


$redirect = $_GET['redirect'] ?? '';
if ($redirect && (strpos($redirect, 'login') !== false || strpos($redirect, 'javascript:') !== false)) {
    $redirect = ''; 
}


if (is_logged_in()) {
    if ($redirect) {
        header("Location: http://localhost/FONEA/" . ltrim($redirect, '/'));
    } else {
        header("Location: " . getDirectDashboard($_SESSION['role']));
    }
    exit();
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (empty($email) || empty($password)) {
        $error = "Email et mot de passe sont obligatoires.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Format d'email invalide.";
    } elseif (function_exists('csrf_verify') && !csrf_verify($csrf)) {
        $error = "Erreur de sécurité (token invalide).";
    } else {
        
        if (class_exists('User') && method_exists('User', 'authenticate')) {
            $user = User::authenticate($email, $password);
            
            if ($user && is_array($user)) {
                
                session_regenerate_id(true);
                
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['logged_in'] = true;
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['nom_complet'] = ($user['prenom'] ?? '') . ' ' . ($user['nom'] ?? '');
                $_SESSION['prenom'] = $user['prenom'] ?? '';
                $_SESSION['username'] = $user['prenom'] ?? '';
                $_SESSION['user_data'] = [
                    'id' => $user['id'] ?? null,
                    'id_agent' => $user['id_agent'] ?? ($user['id'] ?? null),
                    'role' => $_SESSION['role'],
                    'email' => $_SESSION['email'],
                    'prenom' => $_SESSION['prenom'],
                    'nom' => $user['nom'] ?? ''
                ];

                
                if ($redirect) {
                    
                    $safe_redirect = '';
                    if (!empty($redirect)) {
                        $rd = trim($redirect);
                        
                        if (!preg_match('#^(https?:)?//#i', $rd) && strpos($rd, '..') === false && stripos($rd, 'login.php') === false && stripos($rd, 'logout') === false) {
                            
                            if (class_exists('SessionAuth') && method_exists('SessionAuth', 'getBaseUrl')) {
                                $safe_redirect = SessionConfig::getBaseUrl() . '/' . ltrim($rd, '/');
                            } else {
                                $scriptPath = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
                                $base = rtrim(((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . preg_replace('#/public$#i', '', $scriptPath), '/');
                                $safe_redirect = $base . '/' . ltrim($rd, '/');
                            }
                        } else {
                           
                            $safe_redirect = '';
                        }
                    }
                    $target = $safe_redirect;
                } else {
                    
                    $target = getDirectDashboard($_SESSION['role']);
                }
                
                
                error_log("LOGIN SUCCESS: User {$user['email']} with role {$_SESSION['role']} redirecting to: {$target}");
                
                
                header("Location: " . $target);
                exit();
                
            } else {
                $error = "Email ou mot de passe incorrect.";
                error_log("LOGIN FAILED for email: $email");
            }
        } else {
            $error = "Erreur système: authentification non disponible.";
            error_log("User class not found or authenticate method missing");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Connexion - FONEA</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #0f0f23 0%, #1a1a2e 25%, #16213e 50%, #0f3460 75%, #533483 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        /* Animated background blur elements */
        body::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: 
                radial-gradient(circle at 20% 80%, rgba(120, 119, 198, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.2) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, rgba(120, 219, 255, 0.15) 0%, transparent 50%);
            animation: float 20s ease-in-out infinite;
            pointer-events: none;
            filter: blur(40px);
        }
        body::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><filter id="noiseFilter"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="1" stitchTiles="stitch"/><feColorMatrix type="saturate" values="0"/></filter></defs><rect width="100%" height="100%" filter="url(%23noiseFilter)" opacity="0.03"/></svg>');
            pointer-events: none;
        }
        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            33% { transform: translateY(-30px) rotate(2deg); }
            66% { transform: translateY(-20px) rotate(-1deg); }
        }
        .login-container {
            max-width: 420px;
            width: 100%;
            margin: 0 20px;
            position: relative;
            z-index: 1;
        }
        .login-card {
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(40px);
            -webkit-backdrop-filter: blur(40px);
            border-radius: 32px;
            padding: 48px 40px;
            box-shadow: 
                0 8px 32px rgba(0, 0, 0, 0.3),
                inset 0 1px 0 rgba(255, 255, 255, 0.2),
                0 0 0 1px rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.1);
            position: relative;
            overflow: hidden;
        }
        .login-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
            transition: left 0.8s;
        }
        .login-card:hover::before {
            left: 100%;
        }
        .login-title {
            font-size: 32px;
            font-weight: 300;
            color: rgba(255, 255, 255, 0.95);
            margin-bottom: 48px;
            text-align: center;
            letter-spacing: -0.02em;
        }
        .input-group {
            position: relative;
            margin-bottom: 24px;
        }
        .input-field {
            width: 100%;
            height: 56px;
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: 28px;
            padding: 0 24px 0 56px;
            font-size: 16px;
            font-weight: 400;
            color: rgba(255, 255, 255, 0.9);
            outline: none;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .input-field::placeholder {
            color: rgba(255, 255, 255, 0.5);
            font-weight: 500;
            border: 1px solid #4FC3F7; 
            border-radius: 28px;       
            padding: 6px 10px;         
            background: transparent
        }
        .input-field:focus {
            background: rgba(255, 255, 255, 0.12);
            border-color: rgba(255, 255, 255, 0.3);
            box-shadow: 
                0 0 0 2px rgba(255, 255, 255, 0.1),
                0 8px 32px rgba(255, 255, 255, 0.1);
            transform: translateY(-1px);
        }
        .input-icon {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.6);
            font-size: 16px;
            transition: color 0.3s ease;
            pointer-events: none;
        }
        .input-field:focus + .input-icon {
            color: rgba(255, 255, 255, 0.8);
        }
        .sign-in-btn {
            width: 100%;
            height: 56px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 28px;
            color: rgba(255, 255, 255, 0.95);
            font-size: 16px;
            font-weight: 500;
            letter-spacing: 0.02em;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            margin: 32px 0 24px 0;
        }
        .sign-in-btn:hover {
            background: rgba(255, 255, 255, 0.15);
            border-color: rgba(255, 255, 255, 0.3);
            box-shadow: 
                0 8px 32px rgba(255, 255, 255, 0.15),
                inset 0 1px 0 rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }
        .sign-in-btn:active {
            transform: translateY(0);
        }
        .sign-in-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
            transition: left 0.6s;
        }
        .sign-in-btn:hover::before {
            left: 100%;
        }
        .form-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 24px;
        }
        .remember-me {
            display: flex;
            align-items: center;
            gap: 8px;
            color: rgba(255, 255, 255, 0.7);
            font-size: 14px;
            font-weight: 300;
        }
        .remember-checkbox {
            width: 16px;
            height: 16px;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .remember-checkbox:checked {
            background: rgba(255, 255, 255, 0.2);
            border-color: rgba(255, 255, 255, 0.4);
        }
        .forgot-password {
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            font-size: 14px;
            font-weight: 300;
            transition: color 0.3s ease;
        }
        .forgot-password:hover {
            color: rgba(255, 255, 255, 0.9);
        }
        .alert {
            background: rgba(239, 68, 68, 0.1);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(239, 68, 68, 0.2);
            border-radius: 16px;
            padding: 16px 20px;
            margin-bottom: 24px;
            color: rgba(255, 255, 255, 0.9);
            font-size: 14px;
            font-weight: 400;
        }
        @media (max-width: 576px) {
            .login-card {
                padding: 40px 24px;
                margin: 20px;
                border-radius: 24px;
            }
            .login-title {
                font-size: 28px;
                margin-bottom: 40px;
            }
            .input-field {
                height: 52px;
                padding: 0 20px 0 48px;
                font-size: 15px;
            }
            .input-icon {
                left: 16px;
                font-size: 15px;
            }
            .sign-in-btn {
                height: 52px;
                font-size: 15px;
            }
        }
        /* Loading state */
        .loading .sign-in-btn {
            pointer-events: none;
            opacity: 0.7;
        }
        .loading .sign-in-btn::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 20px;
            height: 20px;
            border: 2px solid transparent;
            border-top: 2px solid rgba(255, 255, 255, 0.8);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: translate(-50%, -50%) rotate(0deg); }
            100% { transform: translate(-50%, -50%) rotate(360deg); }
        }
        /* Light blue for icons */
        .input-icon {
            color: #4FC3F7 !important; /* light blue */
        }
        /* Light blue Connexion button */
        .sign-in-btn {
            background: #4FC3F7 !important;
            border: none !important;
            color: #fff !important;
        }
        .sign-in-btn:hover {
            background: #29B6F6 !important;
        }
</style>
</head>
<body>
<div class="login-container">
    <div class="login-card">
        <h1 class="login-title">Bienvenue sur FONEA</h1>
        <?php if ($error): ?>
            <div class="alert">
                <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>
        <form method="POST" id="loginForm">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
            <div class="input-group">
                <input type="email" 
                       id="email" 
                       name="email" 
                       class="input-field" 
                       placeholder="Email"
                       value="<?= htmlspecialchars($email ?? '', ENT_QUOTES, 'UTF-8') ?>" 
                       required 
                       autocomplete="email">
                <i class="fas fa-envelope input-icon"></i>
            </div>
            <div class="input-group">
                <input type="password" 
                       id="password" 
                       name="password" 
                       class="input-field" 
                       placeholder="Password"
                       required 
                       autocomplete="current-password">
                <i class="fas fa-lock input-icon"></i>
            </div>
            <button type="submit" class="sign-in-btn">
                Connexion
            </button>
            <div class="form-footer">
                <label class="remember-me">
                    <input type="checkbox" class="remember-checkbox" name="remember">
                    Remember me
                </label>
                <a href="../public/forget_password.php" class="forgot-password">Forgot Password?</a>
            </div>
        </form>
    </div>
</div>
<script>
document.getElementById('loginForm').addEventListener('submit', function() {
    const btn = document.querySelector('.sign-in-btn');
    btn.classList.add('loading');
    btn.textContent = '';
});
// Add subtle floating animation to the card
document.addEventListener('DOMContentLoaded', function() {
    const card = document.querySelector('.login-card');
    setInterval(() => {
        card.style.transform = `translateY(${Math.sin(Date.now() * 0.001) * 2}px)`;
    }, 16);
});
</script>
</body>
</html>