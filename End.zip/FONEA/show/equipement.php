<?php
session_start();
require_once '../Config/db.php';
// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: ../public/login.php");
    exit();
}

$pdo = Database::getInstance()->getConnection();
$success = "";
$errors = [];
// Générer un token CSRF
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
// Paramètres de pagination et recherche
$page = max(1, $_GET['page'] ?? 1);
$per_page = 15;
$offset = ($page - 1) * $per_page;
$search = trim($_GET['search'] ?? '');
$filter_materiel = $_GET['filter_materiel'] ?? '';
$filter_caracteristique = $_GET['filter_caracteristique'] ?? '';
try {
    // Liste des matériels et caractéristiques pour les formulaires
    $materiels = $pdo->query("SELECT * FROM Materiel ORDER BY nom")->fetchAll(PDO::FETCH_ASSOC);
    $caracteristiques = $pdo->query("SELECT * FROM Caracteristique ORDER BY nom_caracteristique")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Erreur lors du chargement des données: " . $e->getMessage());
    $errors[] = "Erreur lors du chargement des données.";
}
// Ajouter équipement
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    // Vérification CSRF
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $errors[] = "Token de sécurité invalide.";
    } else {
        $id_materiel = $_POST['id_materiel'] ?? '';
        $id_caracteristique = !empty($_POST['id_caracteristique']) ? $_POST['id_caracteristique'] : null;
        $quantite = $_POST['quantite'] ?? '';
        $date_ajout = $_POST['date_ajout'] ?? '';
        $description = trim($_POST['description'] ?? '');
        // Validation
        if (empty($id_materiel) || !is_numeric($id_materiel)) {
            $errors[] = "Matériel requis et valide.";
        }
        if (empty($quantite) || !is_numeric($quantite) || $quantite <= 0 || $quantite > 999999) {
            $errors[] = "Quantité invalide (doit être entre 1 et 999999).";
        }
        if (empty($date_ajout)) {
            $errors[] = "Date d'ajout requise.";
        } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_ajout)) {
            $errors[] = "Format de date invalide.";
        }
        if (!empty($description) && strlen($description) > 500) {
            $errors[] = "La description ne peut pas dépasser 500 caractères.";
        }
        // Vérifier si le matériel existe
        if (empty($errors) && $id_materiel) {
            try {
                $stmt = $pdo->prepare("SELECT id_materiel FROM Materiel WHERE id_materiel = :id");
                $stmt->execute([':id' => $id_materiel]);
                if (!$stmt->fetch()) {
                    $errors[] = "Le matériel sélectionné n'existe pas.";
                }
            } catch (PDOException $e) {
                error_log("Erreur lors de la vérification du matériel: " . $e->getMessage());
                $errors[] = "Erreur lors de la validation.";
            }
        }
        // Vérifier si la caractéristique existe (si fournie)
        if (empty($errors) && $id_caracteristique) {
            try {
                $stmt = $pdo->prepare("SELECT id_caracteristique FROM Caracteristique WHERE id_caracteristique = :id");
                $stmt->execute([':id' => $id_caracteristique]);
                if (!$stmt->fetch()) {
                    $errors[] = "La caractéristique sélectionnée n'existe pas.";
                }
            } catch (PDOException $e) {
                error_log("Erreur lors de la vérification de la caractéristique: " . $e->getMessage());
                $errors[] = "Erreur lors de la validation.";
            }
        }
        if (empty($errors)) {
            try {
                $pdo->beginTransaction();
                $stmt = $pdo->prepare("INSERT INTO Equipement (id_materiel, id_caracteristique, quantite, date_ajout, description, date_creation) 
                                       VALUES (:id_materiel, :id_caracteristique, :quantite, :date_ajout, :description, NOW())");
                $stmt->execute([
                    ':id_materiel' => $id_materiel,
                    ':id_caracteristique' => $id_caracteristique,
                    ':quantite' => $quantite,
                    ':date_ajout' => $date_ajout,
                    ':description' => $description ?: null
                ]);
                $pdo->commit();
                $success = "Équipement ajouté avec succès.";
                // Réinitialiser le formulaire
                $_POST = [];
            } catch (PDOException $e) {
                $pdo->rollBack();
                error_log("Erreur lors de l'ajout de l'équipement: " . $e->getMessage());
                $errors[] = "Erreur lors de l'ajout de l'équipement.";
            }
        }
    }
}
// Construction de la requête de recherche avec pagination
try {
    $where_conditions = [];
    $params = [];
    if (!empty($search)) {
        $where_conditions[] = "(m.nom LIKE :search OR c.nom_caracteristique LIKE :search OR e.description LIKE :search)";
        $params[':search'] = "%$search%";
    }
    if (!empty($filter_materiel)) {
        $where_conditions[] = "e.id_materiel = :filter_materiel";
        $params[':filter_materiel'] = $filter_materiel;
    }
    if (!empty($filter_caracteristique)) {
        $where_conditions[] = "e.id_caracteristique = :filter_caracteristique";
        $params[':filter_caracteristique'] = $filter_caracteristique;
    }
    $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
    // Compter le total pour la pagination
    $count_sql = "SELECT COUNT(*) FROM Equipement e
                  LEFT JOIN Materiel m ON e.id_materiel = m.id_materiel
                  LEFT JOIN Caracteristique c ON e.id_caracteristique = c.id_caracteristique
                  $where_clause";
    $count_stmt = $pdo->prepare($count_sql);
    $count_stmt->execute($params);
    $total_equipements = $count_stmt->fetchColumn();
    $total_pages = ceil($total_equipements / $per_page);
    // Récupérer les équipements avec pagination
    $sql = "SELECT e.id_equipement, m.nom AS materiel, c.nom_caracteristique, e.quantite, e.date_ajout, e.description,
                   e.date_creation, m.id_materiel, c.id_caracteristique
            FROM Equipement e
            LEFT JOIN Materiel m ON e.id_materiel = m.id_materiel
            LEFT JOIN Caracteristique c ON e.id_caracteristique = c.id_caracteristique
            $where_clause
            ORDER BY e.date_creation DESC, e.id_equipement DESC
            LIMIT :limit OFFSET :offset";
    $stmt = $pdo->prepare($sql);
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $equipements = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Erreur lors de la récupération des équipements: " . $e->getMessage());
    $errors[] = "Erreur lors du chargement des équipements.";
    $equipements = [];
    $total_equipements = 0;
    $total_pages = 0;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Équipements</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --success-color: #27ae60;
            --danger-color: #e74c3c;
            --warning-color: #f39c12;
            --light-bg: #ecf0f1;
            --dark-bg: #34495e;
            --text-color: #2c3e50;
            --border-color: #bdc3c7;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: var(--text-color);
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            text-align: center;
        }
        .header h1 {
            color: var(--primary-color);
            font-size: 2.5rem;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-card i {
            font-size: 2rem;
            margin-bottom: 10px;
        }
        .stat-card .number {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .stat-card.total { color: var(--secondary-color); }
        .stat-card.recent { color: var(--success-color); }
        .stat-card.materials { color: var(--warning-color); }
        .main-content {
            display: grid;
            grid-template-columns: 350px 1fr;
            gap: 30px;
            align-items: start;
        }
        .form-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            position: sticky;
            top: 20px;
        }
        .form-section h2 {
            color: var(--primary-color);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.5rem;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--primary-color);
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
            background: white;
        }
        .form-control:focus {
            outline: none;
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
        }
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--secondary-color), #2980b9);
            color: white;
            width: 100%;
            justify-content: center;
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #2980b9, #21618c);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.4);
        }
        .btn-sm {
            padding: 6px 12px;
            font-size: 12px;
        }
        .btn-danger {
            background: var(--danger-color);
            color: white;
        }
        .btn-danger:hover {
            background: #c0392b;
        }
        .table-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 20px;
        }
        .table-header h2 {
            color: var(--primary-color);
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.5rem;
        }
        .search-filters {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }
        .search-box {
            position: relative;
        }
        .search-box input {
            padding: 10px 15px 10px 40px;
            border: 2px solid var(--border-color);
            border-radius: 25px;
            width: 250px;
            background: white;
            transition: all 0.3s ease;
        }
        .search-box input:focus {
            outline: none;
            border-color: var(--secondary-color);
            width: 300px;
        }
        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--border-color);
        }
        .filter-select {
            padding: 10px 15px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            background: white;
            min-width: 150px;
        }
        .table-container {
            overflow-x: auto;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }
        th {
            background: linear-gradient(135deg, var(--primary-color), var(--dark-bg));
            color: white;
            padding: 15px 12px;
            text-align: left;
            font-weight: 600;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            vertical-align: middle;
        }
        tr:hover {
            background-color: #f8f9fa;
        }
        .badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        .badge-primary {
            background: rgba(52, 152, 219, 0.1);
            color: var(--secondary-color);
        }
        .badge-secondary {
            background: rgba(149, 165, 166, 0.1);
            color: #95a5a6;
        }
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-top: 30px;
        }
        .pagination a {
            padding: 8px 12px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            text-decoration: none;
            color: var(--text-color);
            transition: all 0.3s ease;
        }
        .pagination a:hover,
        .pagination .active {
            background: var(--secondary-color);
            color: white;
            border-color: var(--secondary-color);
        }
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 500;
        }
        .alert-success {
            background: rgba(39, 174, 96, 0.1);
            color: var(--success-color);
            border-left: 4px solid var(--success-color);
        }
        .alert-danger {
            background: rgba(231, 76, 60, 0.1);
            color: var(--danger-color);
            border-left: 4px solid var(--danger-color);
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #7f8c8d;
        }
        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.5;
        }
        .quantity-badge {
            background: linear-gradient(135deg, var(--success-color), #229954);
            color: white;
            padding: 6px 12px;
            border-radius: 15px;
            font-weight: bold;
        }
        .description-tooltip {
            position: relative;
            display: inline-block;
            cursor: help;
        }
        .description-tooltip:hover::after {
            content: attr(data-description);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0,0,0,0.8);
            color: white;
            padding: 8px 12px;
            border-radius: 6px;
            white-space: nowrap;
            z-index: 1000;
            font-size: 12px;
        }
        @media (max-width: 1024px) {
            .main-content {
                grid-template-columns: 1fr;
            }
            .form-section {
                position: static;
            }
            .search-filters {
                flex-direction: column;
                align-items: stretch;
            }
            .search-box input {
                width: 100%;
            }
        }
        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }
            .header {
                padding: 20px;
            }
            .header h1 {
                font-size: 1.8rem;
                flex-direction: column;
                gap: 10px;
            }
            .stats {
                grid-template-columns: 1fr;
            }
            .table-header {
                flex-direction: column;
                align-items: stretch;
            }
            table {
                font-size: 14px;
            }
            th, td {
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>
                <i class="fas fa-tools"></i>
                Gestion des Équipements
            </h1>
            <p>Gérez vos équipements et matériels en toute simplicité</p>
        </div>
        <!-- Statistics -->
        <div class="stats">
            <div class="stat-card total">
                <i class="fas fa-boxes"></i>
                <div class="number"><?= number_format($total_equipements) ?></div>
                <div class="label">Total Équipements</div>
            </div>
            <div class="stat-card recent">
                <i class="fas fa-plus-circle"></i>
                <div class="number"><?= count(array_filter($equipements, fn($e) => strtotime($e['date_creation'] ?? '') > strtotime('-7 days'))) ?></div>
                <div class="label">Ajoutés cette semaine</div>
            </div>
            <div class="stat-card materials">
                <i class="fas fa-layer-group"></i>
                <div class="number"><?= count($materiels) ?></div>
                <div class="label">Types de Matériel</div>
            </div>
        </div>
        <!-- Alerts -->
        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle"></i>
                <?= implode('<br>', array_map('htmlspecialchars', $errors)) ?>
            </div>
        <?php endif; ?>
        <div class="main-content">
            <!-- Form Section -->
            <div class="form-section">
                <h2>
                    <i class="fas fa-plus"></i>
                    Ajouter un Équipement
                </h2>
                <form method="POST" id="equipmentForm">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                    <input type="hidden" name="action" value="add">
                    <div class="form-group">
                        <label for="id_materiel">
                            <i class="fas fa-cog"></i>
                            Matériel <span style="color: var(--danger-color);">*</span>
                        </label>
                        <select name="id_materiel" id="id_materiel" class="form-control" required>
                            <option value="">-- Sélectionner un matériel --</option>
                            <?php foreach ($materiels as $m): ?>
                                <option value="<?= $m['id_materiel'] ?>" <?= (($_POST['id_materiel'] ?? '') == $m['id_materiel']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($m['nom']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="id_caracteristique">
                            <i class="fas fa-tags"></i>
                            Caractéristique
                        </label>
                        <select name="id_caracteristique" id="id_caracteristique" class="form-control">
                            <option value="">-- Aucune caractéristique --</option>
                            <?php foreach ($caracteristiques as $c): ?>
                                <option value="<?= $c['id_caracteristique'] ?>" <?= (($_POST['id_caracteristique'] ?? '') == $c['id_caracteristique']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($c['nom_caracteristique']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="quantite">
                            <i class="fas fa-calculator"></i>
                            Quantité <span style="color: var(--danger-color);">*</span>
                        </label>
                        <input type="number" name="quantite" id="quantite" class="form-control" 
                               min="1" max="999999" value="<?= htmlspecialchars($_POST['quantite'] ?? '') ?>" 
                               placeholder="Ex: 10" required>
                    </div>
                    <div class="form-group">
                        <label for="date_ajout">
                            <i class="fas fa-calendar"></i>
                            Date d'ajout <span style="color: var(--danger-color);">*</span>
                        </label>
                        <input type="date" name="date_ajout" id="date_ajout" class="form-control" 
                               value="<?= htmlspecialchars($_POST['date_ajout'] ?? date('Y-m-d')) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="description">
                            <i class="fas fa-comment"></i>
                            Description
                        </label>
                        <textarea name="description" id="description" class="form-control" 
                                  rows="3" maxlength="500" placeholder="Description optionnelle..."><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
                        <small style="color: #7f8c8d; font-size: 12px;">Maximum 500 caractères</small>
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-plus"></i>
                        Ajouter l'Équipement
                    </button>
                </form>
            </div>
            <!-- Table Section -->
            <div class="table-section">
                <div class="table-header">
                    <h2>
                        <i class="fas fa-list"></i>
                        Liste des Équipements
                        <?php if ($total_equipements > 0): ?>
                            <span class="badge badge-primary"><?= number_format($total_equipements) ?></span>
                        <?php endif; ?>
                    </h2>
                    <div class="search-filters">
                        <div class="search-box">
                            <i class="fas fa-search"></i>
                            <input type="text" placeholder="Rechercher..." value="<?= htmlspecialchars($search) ?>" 
                                   onchange="updateFilters()" id="searchInput">
                        </div>
                        <select class="filter-select" onchange="updateFilters()" id="filterMateriel">
                            <option value="">Tous les matériels</option>
                            <?php foreach ($materiels as $m): ?>
                                <option value="<?= $m['id_materiel'] ?>" <?= ($filter_materiel == $m['id_materiel']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($m['nom']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <select class="filter-select" onchange="updateFilters()" id="filterCaracteristique">
                            <option value="">Toutes les caractéristiques</option>
                            <?php foreach ($caracteristiques as $c): ?>
                                <option value="<?= $c['id_caracteristique'] ?>" <?= ($filter_caracteristique == $c['id_caracteristique']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($c['nom_caracteristique']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <?php if (!empty($equipements)): ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th><i class="fas fa-hashtag"></i> ID</th>
                                    <th><i class="fas fa-cog"></i> Matériel</th>
                                    <th><i class="fas fa-tags"></i> Caractéristique</th>
                                    <th><i class="fas fa-calculator"></i> Quantité</th>
                                    <th><i class="fas fa-calendar"></i> Date d'ajout</th>
                                    <th><i class="fas fa-comment"></i> Description</th>
                                    <th><i class="fas fa-cogs"></i> Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($equipements as $e): ?>
                                <tr>
                                    <td><strong>#<?= $e['id_equipement'] ?></strong></td>
                                    <td>
                                        <span class="badge badge-primary">
                                            <?= htmlspecialchars($e['materiel']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($e['nom_caracteristique']): ?>
                                            <span class="badge badge-secondary">
                                                <?= htmlspecialchars($e['nom_caracteristique']) ?>
                                            </span>
                                        <?php else: ?>
                                            <span style="color: #95a5a6; font-style: italic;">Aucune</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="quantity-badge">
                                            <?= number_format($e['quantite']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <i class="fas fa-calendar-alt" style="color: #3498db; margin-right: 5px;"></i>
                                        <?= date('d/m/Y', strtotime($e['date_ajout'])) ?>
                                    </td>
                                    <td>
                                        <?php if ($e['description']): ?>
                                            <span class="description-tooltip" data-description="<?= htmlspecialchars($e['description']) ?>">
                                                <i class="fas fa-info-circle" style="color: #3498db;"></i>
                                                <?= htmlspecialchars(substr($e['description'], 0, 30)) ?>
                                                <?= strlen($e['description']) > 30 ? '...' : '' ?>
                                            </span>
                                        <?php else: ?>
                                            <span style="color: #95a5a6; font-style: italic;">Aucune description</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div style="display: flex; gap: 8px;">
                                            <a href="edit_equipement.php?id=<?= $e['id_equipement'] ?>" 
                                               class="btn btn-sm btn-primary" title="Modifier">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="delete_equipement.php?id=<?= $e['id_equipement'] ?>" 
                                               class="btn btn-sm btn-danger" title="Supprimer"
                                               onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet équipement ?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="?page=<?= $page - 1 ?>&search=<?= urlencode($search) ?>&filter_materiel=<?= urlencode($filter_materiel) ?>&filter_caracteristique=<?= urlencode($filter_caracteristique) ?>">
                                    <i class="fas fa-chevron-left"></i> Précédent
                                </a>
                            <?php endif; ?>
                            <?php
                            $start = max(1, $page - 2);
                            $end = min($total_pages, $page + 2);
                            if ($start > 1): ?>
                                <a href="?page=1&search=<?= urlencode($search) ?>&filter_materiel=<?= urlencode($filter_materiel) ?>&filter_caracteristique=<?= urlencode($filter_caracteristique) ?>">1</a>
                                <?php if ($start > 2): ?>
                                    <span>...</span>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php for ($i = $start; $i <= $end; $i++): ?>
                                <a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&filter_materiel=<?= urlencode($filter_materiel) ?>&filter_caracteristique=<?= urlencode($filter_caracteristique) ?>" 
                                   class="<?= $i == $page ? 'active' : '' ?>">
                                    <?= $i ?>
                                </a>
                            <?php endfor; ?>
                            <?php if ($end < $total_pages): ?>
                                <?php if ($end < $total_pages - 1): ?>
                                    <span>...</span>
                                <?php endif; ?>
                                <a href="?page=<?= $total_pages ?>&search=<?= urlencode($search) ?>&filter_materiel=<?= urlencode($filter_materiel) ?>&filter_caracteristique=<?= urlencode($filter_caracteristique) ?>"><?= $total_pages ?></a>
                            <?php endif; ?>
                            <?php if ($page < $total_pages): ?>
                                <a href="?page=<?= $page + 1 ?>&search=<?= urlencode($search) ?>&filter_materiel=<?= urlencode($filter_materiel) ?>&filter_caracteristique=<?= urlencode($filter_caracteristique) ?>">
                                    Suivant <i class="fas fa-chevron-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-box-open"></i>
                        <h3>Aucun équipement trouvé</h3>
                        <p>
                            <?php if (!empty($search) || !empty($filter_materiel) || !empty($filter_caracteristique)): ?>
                                Aucun équipement ne correspond à vos critères de recherche.
                                <br>
                                <a href="?" style="color: var(--secondary-color); text-decoration: none;">
                                    <i class="fas fa-undo"></i> Réinitialiser les filtres
                                </a>
                            <?php else: ?>
                                Commencez par ajouter votre premier équipement avec le formulaire à gauche.
                            <?php endif; ?>
                        </p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script>
        // Fonction pour mettre à jour les filtres
        function updateFilters() {
            const search = document.getElementById('searchInput').value;
            const filterMateriel = document.getElementById('filterMateriel').value;
            const filterCaracteristique = document.getElementById('filterCaracteristique').value;
            const params = new URLSearchParams();
            if (search) params.append('search', search);
            if (filterMateriel) params.append('filter_materiel', filterMateriel);
            if (filterCaracteristique) params.append('filter_caracteristique', filterCaracteristique);
            window.location.href = '?' + params.toString();
        }
        // Recherche avec délai pour éviter trop de requêtes
        let searchTimeout;
        document.getElementById('searchInput').addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(updateFilters, 500);
        });
        // Validation du formulaire en temps réel
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('equipmentForm');
            const quantiteInput = document.getElementById('quantite');
            const descriptionInput = document.getElementById('description');
            // Validation de la quantité
            quantiteInput.addEventListener('input', function() {
                const value = parseInt(this.value);
                if (value < 1 || value > 999999) {
                    this.style.borderColor = 'var(--danger-color)';
                } else {
                    this.style.borderColor = 'var(--border-color)';
                }
            });
            // Compteur de caractères pour la description
            if (descriptionInput) {
                const counter = document.createElement('div');
                counter.style.cssText = 'text-align: right; font-size: 12px; color: #7f8c8d; margin-top: 5px;';
                descriptionInput.parentNode.appendChild(counter);
                function updateCounter() {
                    const remaining = 500 - descriptionInput.value.length;
                    counter.textContent = `${remaining} caractères restants`;
                    counter.style.color = remaining < 50 ? 'var(--danger-color)' : '#7f8c8d';
                }
                descriptionInput.addEventListener('input', updateCounter);
                updateCounter();
            }
            // Animation du bouton de soumission
            form.addEventListener('submit', function() {
                const submitBtn = form.querySelector('button[type="submit"]');
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Ajout en cours...';
                submitBtn.disabled = true;
                // Réactiver le bouton après 3 secondes (au cas où il y aurait une erreur)
                setTimeout(() => {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }, 3000);
            });
            // Auto-complétion date actuelle
            const dateInput = document.getElementById('date_ajout');
            if (!dateInput.value) {
                dateInput.value = new Date().toISOString().split('T')[0];
            }
            // Tooltip amélioré pour les descriptions longues
            document.querySelectorAll('.description-tooltip').forEach(tooltip => {
                tooltip.addEventListener('mouseenter', function() {
                    this.style.position = 'relative';
                });
            });
        });
        // Raccourcis clavier
        document.addEventListener('keydown', function(e) {
            // Ctrl/Cmd + F pour focus sur la recherche
            if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                e.preventDefault();
                document.getElementById('searchInput').focus();
            }
            // Ctrl/Cmd + N pour focus sur le formulaire d'ajout
            if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
                e.preventDefault();
                document.getElementById('id_materiel').focus();
            }
        });
        // Animation d'apparition des lignes du tableau
        document.addEventListener('DOMContentLoaded', function() {
            const rows = document.querySelectorAll('tbody tr');
            rows.forEach((row, index) => {
                row.style.opacity = '0';
                row.style.transform = 'translateY(20px)';
                row.style.transition = 'all 0.3s ease';
                setTimeout(() => {
                    row.style.opacity = '1';
                    row.style.transform = 'translateY(0)';
                }, index * 50);
            });
        });
        // Confirmation améliorée pour la suppression
        document.addEventListener('click', function(e) {
            if (e.target.closest('.btn-danger[onclick]')) {
                e.preventDefault();
                const link = e.target.closest('a');
                if (confirm('⚠️ Attention !\n\nÊtes-vous sûr de vouloir supprimer cet équipement ?\nCette action est irréversible.')) {
                    window.location.href = link.href;
                }
            }
        });
    </script>
</body>
</html>