<?php
// Legacy CSRF helpers kept for backward compatibility.
// They now defer to CSRFProtection when available and avoid redeclaration.
// Do not require session config here; callers should have bootstrapped sessions.
if (!function_exists('csrf_token')) {
    function csrf_token() {
        if (class_exists('CSRFProtection')) {
            return CSRFProtection::generateToken();
        }
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
}
if (!function_exists('csrf_field')) {
    function csrf_field() {
        echo "<input type='hidden' name='csrf_token' value='" . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') . "'>";
    }
}
if (!function_exists('csrf_input')) {
    function csrf_input() {
        csrf_field();
    }
}
if (!function_exists('csrf_validate')) {
    function csrf_validate() {
        if (class_exists('CSRFProtection')) {
            CSRFProtection::requireToken();
            return;
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $sessionToken = $_SESSION['csrf_token'] ?? '';
            $postToken = $_POST['csrf_token'] ?? '';
            if (empty($sessionToken) || empty($postToken) || !hash_equals($sessionToken, $postToken)) {
                http_response_code(419);
                die("CSRF token validation failed");
            }
        }
    }
}
if (!function_exists('verify_csrf')) {
    function verify_csrf() {
        csrf_validate();
    }
}