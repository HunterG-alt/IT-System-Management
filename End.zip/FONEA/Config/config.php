<?php
define('BASE_URL', 'http://localhost/FONEA');
$dashboard_url = BASE_URL . '/public/mini_dashboard.php';
$create_url    = BASE_URL . '/public/create.php';
$logout_url    = BASE_URL . '/public/logout.php';
$login_url     = BASE_URL . '/public/login.php';
$register_url  = BASE_URL . '/public/register.php';
$user_url      = BASE_URL . '/public/user.php';
?>
