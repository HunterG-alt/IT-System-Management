//delete_besoin.php: 
<?php
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../modules/logique.php'; // For user functions
// Security: Only allow POST requests for delete operations
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['message'] = "Méthode non autorisée.";
    $_SESSION['message_type'] = "danger";
header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/besoin.php");
    exit;
}
// CSRF Protection
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
    $_SESSION['message'] = "Token de sécurité invalide.";
    $_SESSION['message_type'] = "danger";
header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/besoin.php");
    exit;
}
// Authentication check
if (!isset($_SESSION['user_id']) && !function_exists('current_user')) {
    $_SESSION['message'] = "Accès non autorisé.";
    $_SESSION['message_type'] = "danger";
header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit;
}
// Get current user
$current_user = null;
if (function_exists('current_user')) {
    $current_user = current_user();
} elseif (isset($_SESSION['user_id'])) {
    $current_user = ['id' => $_SESSION['user_id']];
}
if (!$current_user) {
    $_SESSION['message'] = "Utilisateur non identifié.";
    $_SESSION['message_type'] = "danger";
header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit;
}
// Validate input
if (!isset($_POST['id']) || empty($_POST['id'])) {
    $_SESSION['message'] = "ID du besoin manquant.";
    $_SESSION['message_type'] = "danger";
header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/besoin.php");
    exit;
}
$id = (int) $_POST['id'];
if ($id <= 0) {
    $_SESSION['message'] = "ID du besoin invalide.";
    $_SESSION['message_type'] = "danger";
header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/besoin.php");
    exit;
}
try {
    // Get database connection
    if (class_exists('Database')) {
        $pdo = Database::getInstance()->getConnection();
    } else {
        global $pdo;
        if (!$pdo) {
            throw new Exception("Connexion à la base de données indisponible");
        }
    }
    // Begin transaction for data integrity
    $pdo->beginTransaction();
    // Check if need exists and belongs to current user
    $stmt = $pdo->prepare("SELECT id, agent_id, designation, statut FROM besoin WHERE id = ?");
    $stmt->execute([$id]);
    $besoin = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$besoin) {
        $pdo->rollBack();
        $_SESSION['message'] = "Besoin introuvable.";
        $_SESSION['message_type'] = "danger";
header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/besoin.php");
        exit;
    }
    // Security: Check if user owns this need or has admin privileges
    $user_can_delete = false;
    // Check if user owns the need
    if ($besoin['agent_id'] == $current_user['id']) {
        $user_can_delete = true;
    }
    // Check if user has admin privileges (adjust based on your role system)
    if (isset($current_user['role']) && in_array($current_user['role'], ['admin', 'manager'])) {
        $user_can_delete = true;
    }
    if (!$user_can_delete) {
        $pdo->rollBack();
        $_SESSION['message'] = "Vous n'avez pas l'autorisation de supprimer ce besoin.";
        $_SESSION['message_type'] = "danger";
header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/besoin.php");
        exit;
    }
    // Business rule: Only allow deletion of pending needs
    if ($besoin['statut'] !== 'en_attente') {
        $pdo->rollBack();
        $_SESSION['message'] = "Impossible de supprimer un besoin qui n'est pas en attente.";
        $_SESSION['message_type'] = "warning";
header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/besoin.php");
        exit;
    }
    // Archive the need instead of hard delete (recommended for audit purposes)
    $archive_stmt = $pdo->prepare("
        INSERT INTO besoin_archive (
            original_id, agent_id, designation, besoin, justification, 
            date_soumission, statut, deleted_by, deleted_at
        ) 
        SELECT id, agent_id, designation, besoin, justification, 
               date_soumission, statut, ?, NOW() 
        FROM besoin WHERE id = ?
    ");
    $archive_result = $archive_stmt->execute([$current_user['id'], $id]);
    if (!$archive_result) {
        $pdo->rollBack();
        throw new Exception("Erreur lors de l'archivage du besoin");
    }
    // Delete related materials first (if exists)
    $delete_materials_stmt = $pdo->prepare("DELETE FROM besoin_materiel WHERE id_besoin = ?");
    $delete_materials_stmt->execute([$id]);
    // Delete the need
    $delete_stmt = $pdo->prepare("DELETE FROM besoin WHERE id = ?");
    $delete_result = $delete_stmt->execute([$id]);
    if (!$delete_result) {
        $pdo->rollBack();
        throw new Exception("Erreur lors de la suppression du besoin");
    }
    // Log the action (if you have a logging system)
    $log_stmt = $pdo->prepare("
        INSERT INTO activity_log (user_id, action, entity_type, entity_id, description, created_at) 
        VALUES (?, 'DELETE', 'besoin', ?, ?, NOW())
    ");
    $log_description = "Suppression du besoin: " . $besoin['designation'];
    $log_stmt->execute([$current_user['id'], $id, $log_description]);
    // Commit transaction
    $pdo->commit();
    $_SESSION['message'] = "Besoin '" . htmlspecialchars($besoin['designation']) . "' supprimé avec succès.";
    $_SESSION['message_type'] = "success";
} catch (PDOException $e) {
    // Rollback transaction on database error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Erreur de suppression de besoin: " . $e->getMessage());
    $_SESSION['message'] = "Erreur lors de la suppression du besoin.";
    $_SESSION['message_type'] = "danger";
} catch (Exception $e) {
    // Rollback transaction on any other error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Erreur de suppression de besoin: " . $e->getMessage());
    $_SESSION['message'] = "Erreur inattendue lors de la suppression.";
    $_SESSION['message_type'] = "danger";
}
// Redirect back to the needs list
header("Location: " . (class_exists('SessionConfig') ? SessionConfig::getBaseUrl() : "") . "/besoin.php");
exit;
