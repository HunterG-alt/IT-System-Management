<?php
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../Lib/csrf.php';
require_once __DIR__ . '/../public/userClass.php';
require_once __DIR__ .'/../modules/WorkflowManager.php';


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!defined('USER_BYPASS_GUARD')) {
    // Use is_logged_in() helper if available, else check user_id and role
    $logged_in = function_exists('is_logged_in') ? is_logged_in() : (isset($_SESSION['user_id']) && !empty($_SESSION['role']));
    if (!$logged_in) {
        header("Location: /FONEA/public/login.php");
        exit();
    }
}
$limit = 10;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $limit;
// Récupération des utilisateurs
$users = User::getAll($limit, $offset);
$totalUsers = User::count();
$totalPages = ceil($totalUsers / $limit);

if (defined('USER_BYPASS_GUARD')) {
    
    return;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard Utilisateurs</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
     * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    
    body {
        font-family: 'Inter', sans-serif;
        background: #0a0a1f;
        min-height: 100vh;
        color: #fff;
        overflow-x: hidden;
        position: relative;
    }
    
    body::before {
        content: '';
        position: fixed;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: 
            radial-gradient(circle at 20% 50%, rgba(88, 28, 135, 0.3) 0%, transparent 50%),
            radial-gradient(circle at 80% 80%, rgba(37, 99, 235, 0.3) 0%, transparent 50%),
            radial-gradient(circle at 40% 20%, rgba(139, 92, 246, 0.2) 0%, transparent 50%);
        animation: gradient-shift 20s ease infinite;
        z-index: 0;
    }
    
    @keyframes gradient-shift {
        0%, 100% { transform: translate(0, 0) rotate(0deg); }
        33% { transform: translate(5%, -5%) rotate(120deg); }
        66% { transform: translate(-5%, 5%) rotate(240deg); }
    }
    
    .container {
        position: relative;
        z-index: 1;
    }
    
    .header-section {
        margin-bottom: 40px;
        animation: fadeInDown 0.8s ease;
    }
    
    @keyframes fadeInDown {
        from {
            opacity: 0;
            transform: translateY(-30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .page-title {
        font-size: 2.5rem;
        font-weight: 800;
        background: linear-gradient(135deg, #fff 0%, #a5b4fc 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        margin-bottom: 10px;
        letter-spacing: -1px;
    }
    
    .page-subtitle {
        color: rgba(255, 255, 255, 0.6);
        font-size: 1rem;
        font-weight: 400;
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 40px;
        animation: fadeIn 1s ease;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    
    .stat-card {
        backdrop-filter: blur(20px) saturate(180%);
        -webkit-backdrop-filter: blur(20px) saturate(180%);
        background: rgba(255, 255, 255, 0.08);
        border-radius: 20px;
        padding: 25px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        position: relative;
        overflow: hidden;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .stat-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(135deg, rgba(139, 92, 246, 0.1) 0%, transparent 100%);
        opacity: 0;
        transition: opacity 0.4s ease;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        background: rgba(255, 255, 255, 0.12);
        border-color: rgba(139, 92, 246, 0.5);
        box-shadow: 0 20px 40px rgba(139, 92, 246, 0.2);
    }
    
    .stat-card:hover::before {
        opacity: 1;
    }
    
    .stat-label {
        font-size: 0.85rem;
        color: rgba(255, 255, 255, 0.6);
        text-transform: uppercase;
        letter-spacing: 1px;
        margin-bottom: 8px;
        font-weight: 600;
    }
    
    .stat-value {
        font-size: 2rem;
        font-weight: 700;
        background: linear-gradient(135deg, #fff 0%, #c7d2fe 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    .glass-container {
        backdrop-filter: blur(25px) saturate(180%);
        -webkit-backdrop-filter: blur(25px) saturate(180%);
        background: rgba(255, 255, 255, 0.06);
        border-radius: 24px;
        padding: 0;
        box-shadow: 
            0 8px 32px rgba(0, 0, 0, 0.3),
            inset 0 1px 0 rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.1);
        overflow: hidden;
        animation: fadeInUp 1s ease;
    }
    
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .table-header {
        background: rgba(255, 255, 255, 0.05);
        padding: 25px 30px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .table-title {
        font-size: 1.5rem;
        font-weight: 700;
        margin: 0;
    }
    
    .table-responsive {
        padding: 0;
    }
    
    table {
        background-color: transparent;
        color: #fff;
        margin: 0;
    }
    
    thead {
        background: rgba(255, 255, 255, 0.03);
        position: sticky;
        top: 0;
        z-index: 10;
    }
    
    thead th {
        font-weight: 600;
        font-size: 0.85rem;
        text-transform: uppercase;
        letter-spacing: 1px;
        color: rgba(255, 255, 255, 0.8);
        padding: 20px 25px;
        border: none;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    tbody tr {
        border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        transition: all 0.3s ease;
    }
    
    tbody tr:hover {
        background: rgba(139, 92, 246, 0.1);
        transform: scale(1.01);
    }
    
    tbody td {
        padding: 20px 25px;
        border: none;
        vertical-align: middle;
        font-size: 0.95rem;
    }
    
    .user-info {
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        font-size: 0.9rem;
        flex-shrink: 0;
    }
    
    .user-details {
        display: flex;
        flex-direction: column;
    }
    
    .user-name {
        font-weight: 600;
        color: #fff;
    }
    
    .role-badge {
        display: inline-block;
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .role-admin {
        background: linear-gradient(135deg, rgba(239, 68, 68, 0.2) 0%, rgba(220, 38, 38, 0.2) 100%);
        color: #fca5a5;
        border: 1px solid rgba(239, 68, 68, 0.3);
    }
    
    .role-user {
        background: linear-gradient(135deg, rgba(59, 130, 246, 0.2) 0%, rgba(37, 99, 235, 0.2) 100%);
        color: #93c5fd;
        border: 1px solid rgba(59, 130, 246, 0.3);
    }
    
    .role-moderator {
        background: linear-gradient(135deg, rgba(139, 92, 246, 0.2) 0%, rgba(124, 58, 237, 0.2) 100%);
        color: #c4b5fd;
        border: 1px solid rgba(139, 92, 246, 0.3);
    }
    
    .btn-action {
        padding: 8px 16px;
        border-radius: 10px;
        font-size: 0.85rem;
        font-weight: 600;
        border: none;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        overflow: hidden;
    }
    
    .btn-action::before {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        width: 0;
        height: 0;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.2);
        transform: translate(-50%, -50%);
        transition: width 0.6s, height 0.6s;
    }
    
    .btn-action:hover::before {
        width: 300px;
        height: 300px;
    }
    
    .btn-edit {
        background: linear-gradient(135deg, rgba(59, 130, 246, 0.3) 0%, rgba(37, 99, 235, 0.3) 100%);
        color: #93c5fd;
        border: 1px solid rgba(59, 130, 246, 0.4);
        margin-right: 8px;
    }
    
    .btn-edit:hover {
        background: linear-gradient(135deg, rgba(59, 130, 246, 0.5) 0%, rgba(37, 99, 235, 0.5) 100%);
        color: #fff;
        box-shadow: 0 8px 20px rgba(59, 130, 246, 0.3);
        transform: translateY(-2px);
    }
    
    .btn-delete {
        background: linear-gradient(135deg, rgba(239, 68, 68, 0.3) 0%, rgba(220, 38, 38, 0.3) 100%);
        color: #fca5a5;
        border: 1px solid rgba(239, 68, 68, 0.4);
    }
    
    .btn-delete:hover {
        background: linear-gradient(135deg, rgba(239, 68, 68, 0.5) 0%, rgba(220, 38, 38, 0.5) 100%);
        color: #fff;
        box-shadow: 0 8px 20px rgba(239, 68, 68, 0.3);
        transform: translateY(-2px);
    }
    
    .pagination-container {
        padding: 25px 30px;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        display: flex;
        justify-content: center;
    }
    
    .pagination {
        gap: 8px;
    }
    
    .pagination .page-item .page-link {
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: rgba(255, 255, 255, 0.8);
        border-radius: 10px;
        padding: 10px 16px;
        font-weight: 600;
        transition: all 0.3s ease;
        margin: 0;
    }
    
    .pagination .page-item .page-link:hover {
        background: rgba(139, 92, 246, 0.3);
        color: #fff;
        border-color: rgba(139, 92, 246, 0.5);
        transform: translateY(-2px);
    }
    
    .pagination .page-item.active .page-link {
        background: linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%);
        border-color: transparent;
        color: #fff;
        box-shadow: 0 8px 20px rgba(139, 92, 246, 0.4);
    }
    
    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: rgba(255, 255, 255, 0.5);
    }
    
    .empty-state-icon {
        font-size: 4rem;
        margin-bottom: 20px;
        opacity: 0.3;
    }
    
    @media (max-width: 768px) {
        .page-title {
            font-size: 1.8rem;
        }
        
        .stats-grid {
            grid-template-columns: 1fr;
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        tbody td {
            padding: 15px;
            font-size: 0.85rem;
        }
        
        .user-avatar {
            width: 35px;
            height: 35px;
            font-size: 0.8rem;
        }
    }
</style>
</head>
<body>
    <div class="container mt-5 mb-5">
    <div class="header-section">
        <h1 class="page-title">Gestion des Utilisateurs</h1>
        <p class="page-subtitle">Gérez et surveillez tous les comptes utilisateurs de votre plateforme</p>
    </div>
    
    <?php
    // Dynamic user stats
    // Total users already available as $totalUsers
    // Actifs: users who logged in within last 30 days (last_login not null and >= NOW() - INTERVAL 30 DAY)
    // Nouveaux (30j): users created in last 30 days
    // Administrateurs: users with role 'directeur_general' or 'directeur' (adjust as needed)
    $db = Database::getInstance()->getConnection();
    // Actifs
    $stmt = $db->query("SELECT COUNT(*) FROM agents WHERE last_login IS NOT NULL AND last_login >= (NOW() - INTERVAL 30 DAY)");
    $activeUsers = (int)$stmt->fetchColumn();
    // Nouveaux (30j)
    $stmt = $db->query("SELECT COUNT(*) FROM agents WHERE date_creation >= (NOW() - INTERVAL 30 DAY)");
    $newUsers = (int)$stmt->fetchColumn();
    // Administrateurs (roles: directeur_general, directeur)
    $stmt = $db->query("SELECT COUNT(*) FROM agents WHERE role IN ('directeur_general', 'directeur')");
    $adminUsers = (int)$stmt->fetchColumn();
    ?>
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-label">Total Utilisateurs</div>
            <div class="stat-value"><?= htmlspecialchars($totalUsers) ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Actifs</div>
            <div class="stat-value"><?= htmlspecialchars($activeUsers) ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Nouveaux (30j)</div>
            <div class="stat-value"><?= htmlspecialchars($newUsers) ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Administrateurs</div>
            <div class="stat-value"><?= htmlspecialchars($adminUsers) ?></div>
        </div>
    </div>
<div class="glass-container">
    <div class="table-header">
        <h2>Liste des utilisateurs</h2>
    </div>
<div class="table-responsive">
    <table class="table table-hover align-middle">
        <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Nom Complet</th>
                <th>Email</th>
                <th>Rôle</th>
                <th>Date de Création</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($users)) : ?>
                <tr><td colspan="6" class="text-center">Aucun utilisateur trouvé</td></tr>
            <?php else: ?>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= htmlspecialchars($user['id']) ?></td>
                        <td><?= htmlspecialchars($user['prenom'] . ' ' . $user['nom']) ?></td>
                        <td><?= htmlspecialchars($user['email']) ?></td>
                        <td><?= htmlspecialchars($user['role']) ?></td>
                        <td><?= htmlspecialchars($user['date_creation']) ?></td>
                        <td>
                            <a href="edit_user.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-primary">Modifier</a>
                            <form method="POST" action="delete_user.php" style="display:inline;" onsubmit="return confirm('Voulez-vous vraiment supprimer cet utilisateur ?');">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= $user['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-danger">Supprimer</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
    <!-- Pagination -->
<div class="pagination-container">
    <nav>
        <ul class="pagination mb-0" id="paginationContainer">
            <?php for($p=1; $p<=$totalPages; $p++): ?>
                <li class="page-item <?= ($p == $page) ? 'active' : '' ?>">
                    <a class="page-link" href="?page=<?= $p ?>"><?= $p ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
</div>
<!-- User Management JS (Pagination, Search, Table Sorting, Flash Messages) -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Pagination: highlight current page
    const urlParams = new URLSearchParams(window.location.search);
    const currentPage = parseInt(urlParams.get('page') || '1');
    document.querySelectorAll('.pagination .page-link').forEach(function(link) {
        if (parseInt(link.textContent) === currentPage) {
            link.classList.add('active');
        }
    });

    // Search filter (if search input exists)
    const searchInput = document.getElementById('user-search');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const filter = this.value.toLowerCase();
            document.querySelectorAll('table tbody tr').forEach(function(row) {
                row.style.display = row.textContent.toLowerCase().includes(filter) ? '' : 'none';
            });
        });
    }

    // Table sorting (simple, by clicking th)
    document.querySelectorAll('table thead th.sortable').forEach(function(th) {
        th.style.cursor = 'pointer';
        th.addEventListener('click', function() {
            const table = th.closest('table');
            const tbody = table.querySelector('tbody');
            const rows = Array.from(tbody.querySelectorAll('tr'));
            const idx = Array.from(th.parentNode.children).indexOf(th);
            const asc = !th.classList.contains('asc');
            rows.sort(function(a, b) {
                const aText = a.children[idx].textContent.trim();
                const bText = b.children[idx].textContent.trim();
                return asc ? aText.localeCompare(bText, undefined, {numeric:true}) : bText.localeCompare(aText, undefined, {numeric:true});
            });
            rows.forEach(row => tbody.appendChild(row));
            th.classList.toggle('asc', asc);
            th.classList.toggle('desc', !asc);
        });
    });

    // Flash message auto-dismiss
    setTimeout(function() {
        document.querySelectorAll('.alert-dismissible').forEach(function(alert) {
            alert.classList.remove('show');
            setTimeout(() => alert.remove(), 500);
        });
    }, 4000);
});
</script>
</body>
</html>
