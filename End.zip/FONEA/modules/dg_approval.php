<?php
/**
 * DG Final Approval System for FONEA
 * 
 * This file handles the final approval process by the Directeur Général (DG)
 * for validated requests from the directeur level.
 * 
 * @author Glory LOUSSI & Development Team
 * @version 2.0
 * @created 2025
 */
// Security and dependencies
require_once __DIR__ . '/../Config/session.php';
require_once __DIR__ . '/../Config/config.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../modules/permission.php';
// DG authorization check
AuthMiddleware::requirePermission('requests.final_approve', 'Accès réservé au Directeur Général pour les autorisations finales.');
// Initialize permission manager
$pm = PermissionManager::getInstance();
// Get base URL for redirects
$base_url = rtrim(defined('BASE_URL') ? BASE_URL : '', '/');
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validate CSRF token
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            throw new Exception('Token de sécurité invalide.');
        }
        $request_id = (int)($_POST['request_id'] ?? 0);
        $action = $_POST['action'] ?? '';
        $commentaire_dg = trim($_POST['commentaire_dg'] ?? '');
        if (!$request_id || !in_array($action, ['approve', 'reject'])) {
            throw new Exception('Paramètres invalides.');
        }
        // Verify permission for this specific request
        if (!$pm->hasResourcePermission('requests', 'final_approve', $request_id)) {
            throw new Exception('Vous n\'avez pas l\'autorisation pour cette demande.');
        }
        // Get request details
        $stmt = $pdo->prepare("
            SELECT eb.*, a.nom, a.prenom, a.email 
            FROM etat_de_besoin eb 
            JOIN agents a ON eb.id_agent = a.id_agent 
            WHERE eb.id_besoin = ? AND eb.statut = 'validee_directeur'
        ");
        $stmt->execute([$request_id]);
        $request = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$request) {
            throw new Exception('Demande non trouvée ou non éligible pour autorisation DG.');
        }
        // Begin transaction
        $pdo->beginTransaction();
        // Update request status and DG details
        if ($action === 'approve') {
            $new_status = 'permission_dg_accordee';
            $success_message = 'Demande autorisée avec succès.';
            $activity_description = 'Autorisation finale accordée par le DG';
        } else {
            $new_status = 'refusee_dg';
            $success_message = 'Demande refusée.';
            $activity_description = 'Demande refusée par le DG';
        }
        // Update the request
        $update_stmt = $pdo->prepare("
            UPDATE etat_de_besoin 
            SET statut = ?, 
                id_dg_validation = ?, 
                date_permission_dg = NOW(), 
                commentaire_dg = ?,
                date_maj = NOW()
            WHERE id_besoin = ?
        ");
        $update_stmt->execute([
            $new_status, 
            $_SESSION['user_data']['id_agent'], 
            $commentaire_dg,
            $request_id
        ]);
        // Log activity
        $activity_stmt = $pdo->prepare("
            INSERT INTO activity_log (user_id, action, entity_type, entity_id, description, created_at) 
            VALUES (?, ?, 'etat_de_besoin', ?, ?, NOW())
        ");
        $activity_stmt->execute([
            $_SESSION['user_data']['id_agent'],
            $action === 'approve' ? 'dg_approve' : 'dg_reject',
            $request_id,
            $activity_description
        ]);
        // Send notifications
        if ($action === 'approve') {
            // Notify requester
            $notify_stmt = $pdo->prepare("
                INSERT INTO notifications (user_id, type, message, related_id, created_at) 
                VALUES (?, 'request_approved_dg', ?, ?, NOW())
            ");
            $notify_stmt->execute([
                $request['id_agent'],
                'Votre demande a été autorisée par le Directeur Général et sera transmise aux moyens généraux.',
                $request_id
            ]);
            // Notify moyens généraux for next step
            $mg_stmt = $pdo->prepare("SELECT id_agent FROM agents WHERE role = 'moyens_generaux'");
            $mg_stmt->execute();
            $mg_users = $mg_stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($mg_users as $mg_user) {
                $notify_stmt->execute([
                    $mg_user['id_agent'],
                    'Nouvelle demande autorisée par le DG en attente de traitement.',
                    $request_id
                ]);
            }
        } else {
            // Notify requester of rejection
            $notify_stmt = $pdo->prepare("
                INSERT INTO notifications (user_id, type, message, related_id, created_at) 
                VALUES (?, 'request_rejected_dg', ?, ?, NOW())
            ");
            $notify_stmt->execute([
                $request['id_agent'],
                'Votre demande a été refusée par le Directeur Général.',
                $request_id
            ]);
        }
        // Commit transaction
        $pdo->commit();
        $_SESSION['success_message'] = $success_message;
        header("Location: " . $base_url . "/Show/Mini_dashboard.php");
        exit;
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $_SESSION['error_message'] = $e->getMessage();
        error_log("DG Approval Error: " . $e->getMessage());
    }
}
// Get pending requests for DG approval
try {
    $stmt = $pdo->prepare("
        SELECT eb.*, a.nom, a.prenom, a.email, a.role,
               CONCAT(a.prenom, ' ', a.nom) as demandeur_nom,
               eb.date_soumission,
               eb.date_validation_directeur,
               dir.nom as directeur_nom, dir.prenom as directeur_prenom,
               eb.commentaire_directeur
        FROM etat_de_besoin eb
        JOIN agents a ON eb.id_agent = a.id_agent
        LEFT JOIN agents dir ON eb.id_directeur_validation = dir.id_agent
        WHERE eb.statut = 'validee_directeur'
        ORDER BY eb.date_validation_directeur ASC, eb.date_soumission ASC
    ");
    $stmt->execute();
    $pending_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $pending_requests = [];
    error_log("Error fetching DG pending requests: " . $e->getMessage());
}
// Generate CSRF token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Autorisation Finale DG - FONEA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <style>
        .dg-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
        }
        .request-card {
            border: 1px solid #e9ecef;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            transition: all 0.3s ease;
        }
        .request-card:hover {
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transform: translateY(-2px);
        }
        .request-header {
            background: linear-gradient(90deg, #f8f9fa, #e9ecef);
            border-bottom: 1px solid #dee2e6;
            padding: 1rem;
            border-radius: 10px 10px 0 0;
        }
        .priority-urgent { border-left: 5px solid #dc3545; }
        .priority-normal { border-left: 5px solid #28a745; }
        .priority-low { border-left: 5px solid #6c757d; }
        .status-badge {
            font-size: 0.85rem;
            padding: 0.25rem 0.75rem;
        }
        .approval-actions {
            background: #f8f9fa;
            border-top: 1px solid #dee2e6;
            padding: 1rem;
            border-radius: 0 0 10px 10px;
        }
        .btn-approve { background: #28a745; border-color: #28a745; }
        .btn-approve:hover { background: #218838; border-color: #218838; }
        .btn-reject { background: #dc3545; border-color: #dc3545; }
        .btn-reject:hover { background: #c82333; border-color: #c82333; }
        .timeline-item {
            border-left: 2px solid #e9ecef;
            padding-left: 1rem;
            margin-bottom: 1rem;
        }
        .timeline-item:last-child { border-left: none; }
        .workflow-status {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 5px;
            padding: 0.75rem;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="dg-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1><i class="fas fa-stamp me-2"></i>Autorisations Finales DG</h1>
                    <p class="mb-0">Demandes validées par la direction en attente d'autorisation finale</p>
                </div>
                <div class="col-md-4 text-end">
                    <a href="<?= $base_url ?>/Show/Mini_dashboard.php" class="btn btn-light">
                        <i class="fas fa-arrow-left me-1"></i>Retour au tableau de bord
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <!-- Messages -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle me-2"></i><?= htmlspecialchars($_SESSION['success_message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-triangle me-2"></i><?= htmlspecialchars($_SESSION['error_message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>
        <!-- Summary Stats -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card text-center border-warning">
                    <div class="card-body">
                        <h3 class="text-warning"><?= count($pending_requests) ?></h3>
                        <p class="mb-0">En attente</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Pending Requests -->
        <?php if (empty($pending_requests)): ?>
            <div class="alert alert-info text-center">
                <i class="fas fa-info-circle fa-2x mb-3"></i>
                <h4>Aucune demande en attente</h4>
                <p class="mb-0">Toutes les demandes validées par la direction ont été traitées.</p>
            </div>
        <?php else: ?>
            <?php foreach ($pending_requests as $request): ?>
                <div class="request-card priority-normal">
                    <div class="request-header">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h5 class="mb-1">
                                    <i class="fas fa-desktop me-2 text-primary"></i>
                                    <?= htmlspecialchars($request['designation_materiel']) ?>
                                </h5>
                                <p class="text-muted mb-0">
                                    <i class="fas fa-user me-1"></i>Demandé par: <?= htmlspecialchars($request['demandeur_nom']) ?>
                                    <span class="ms-3"><i class="fas fa-calendar me-1"></i>Soumis: <?= date('d/m/Y', strtotime($request['date_soumission'])) ?></span>
                                </p>
                            </div>
                            <div class="col-md-4 text-end">
                                <span class="status-badge badge bg-warning">
                                    <i class="fas fa-clock me-1"></i>Attente autorisation DG
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- Workflow Status -->
                        <div class="workflow-status">
                            <span><i class="fas fa-info-circle me-2"></i>Cette demande a été validée par la direction</span>
                            <span class="badge bg-success">Validé: <?= date('d/m/Y', strtotime($request['date_validation_directeur'])) ?></span>
                        </div>
                        <!-- Request Details -->
                        <div class="row">
                            <div class="col-md-6">
                                <h6><i class="fas fa-clipboard-list me-1"></i>Justification</h6>
                                <p class="text-muted"><?= htmlspecialchars($request['justification']) ?></p>
                                <?php if ($request['date_limite']): ?>
                                <p><strong>Date limite:</strong> <?= date('d/m/Y', strtotime($request['date_limite'])) ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <h6><i class="fas fa-route me-1"></i>Historique de validation</h6>
                                <div class="timeline-item">
                                    <small class="text-success">
                                        <i class="fas fa-check-circle me-1"></i>
                                        Validé par: <?= htmlspecialchars($request['directeur_prenom'] . ' ' . $request['directeur_nom']) ?>
                                        <br>Date: <?= date('d/m/Y H:i', strtotime($request['date_validation_directeur'])) ?>
                                    </small>
                                    <?php if ($request['commentaire_directeur']): ?>
                                        <br><em>"<?= htmlspecialchars($request['commentaire_directeur']) ?>"</em>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <!-- DG Approval Form -->
                        <form method="POST" class="approval-actions">
                            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                            <input type="hidden" name="request_id" value="<?= $request['id_besoin'] ?>">
                            <div class="row align-items-end">
                                <div class="col-md-8">
                                    <label for="commentaire_dg_<?= $request['id_besoin'] ?>" class="form-label">
                                        <i class="fas fa-comment me-1"></i>Commentaire DG (optionnel)
                                    </label>
                                    <textarea 
                                        name="commentaire_dg" 
                                        id="commentaire_dg_<?= $request['id_besoin'] ?>"
                                        class="form-control" 
                                        rows="2" 
                                        placeholder="Ajoutez vos observations..."
                                    ></textarea>
                                </div>
                                <div class="col-md-4">
                                    <div class="d-grid gap-2">
                                        <button type="submit" name="action" value="approve" class="btn btn-approve text-white">
                                            <i class="fas fa-stamp me-1"></i>Autoriser
                                        </button>
                                        <button type="submit" name="action" value="reject" class="btn btn-reject text-white">
                                            <i class="fas fa-times-circle me-1"></i>Refuser
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Confirm actions
        document.querySelectorAll('button[name="action"]').forEach(button => {
            button.addEventListener('click', function(e) {
                const action = this.value;
                const actionText = action === 'approve' ? 'autoriser' : 'refuser';
                const confirmMessage = `Êtes-vous sûr de vouloir ${actionText} cette demande ?`;
                if (!confirm(confirmMessage)) {
                    e.preventDefault();
                }
            });
        });
        // Auto-dismiss alerts
        setTimeout(() => {
            document.querySelectorAll('.alert').forEach(alert => {
                if (alert.querySelector('.btn-close')) {
                    alert.querySelector('.btn-close').click();
                }
            });
        }, 5000);
    </script>
</body>
</html>