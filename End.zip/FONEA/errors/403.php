<?php
http_response_code(403);
?><!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>403 Interdit</title>
    <style>
        body {
            background: #1e293b;
            color: #fff;
            font-family: 'Inter', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }
        .error-code {
            font-size: 5rem;
            font-weight: 900;
            color: #ef4444;
        }
        .error-message {
            font-size: 2rem;
            margin-bottom: 20px;
        }
        .error-desc {
            color: #cbd5e1;
            font-size: 1.1rem;
            margin-bottom: 30px;
        }
        a {
            color: #fff;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            padding: 12px 28px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: bold;
            transition: background 0.3s;
        }
        a:hover {
            background: linear-gradient(135deg, #ef4444, #b91c1c);
        }
    </style>
</head>
<body>
    <div class="error-code">403</div>
    <div class="error-message">Accès interdit</div>
    <div class="error-desc">Vous n'avez pas la permission d'accéder à cette ressource.</div>
    <a href="/FONEA/public/login.php">Retour à l'accueil</a>
</body>
</html>
