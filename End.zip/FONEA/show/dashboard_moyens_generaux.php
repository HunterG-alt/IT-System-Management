<?php
require_once '../Config/session.php';
require_once __DIR__ . '/../public/userClass.php';
require_once '../include/besoin.php';
require_once __DIR__ . '/../public/notifications.php';
require_once __DIR__ . '/../Config/titles.php'; 

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'moyens_generaux') {
    header("Location: " . (class_exists('SessionAuth') ? SessionConfig::getBaseUrl() : "") . "/public/login.php");
    exit();
}

$user = User::getById($_SESSION['user_id']);
$user_name = $user ? $user['nom_complet'] : 'Moyens Généraux';

$total_equipment = 150; // Placeholder - would come from materiel table
$maintenance_requests = Besoin::countByStatut('EN_ATTENTE');
$notif_stats = Notification::getStats($_SESSION['user_id']);
$total_notifications = $notif_stats['unread'];

$currentPage = basename(__FILE__);
$pageTitle = $pageTitles[$currentPage] ?? 'Dashboard - FONEA';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="../assets/css/dashboard-common.css" rel="stylesheet">
    <style>
        
        .dashboard-moyens-generaux .sidebar {
            background: linear-gradient(180deg, #b91c1c 0%, #991b1b 100%);
        }
        
        .dashboard-moyens-generaux .btn-accueil {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 90%;
            margin: 30px auto 20px auto;
            padding: 14px 0;
            border-radius: 30px;
            font-size: 1.1rem;
            font-weight: bold;
            background: linear-gradient(135deg, #b91c1c, #ef4444);
            color: #fff !important;
            box-shadow: 0 4px 16px rgba(239,68,68,0.15);
            border: none;
            transition: background 0.3s, transform 0.2s;
            text-decoration: none !important;
        }
        .btn-accueil i {
            margin-right: 10px;
            font-size: 1.2em;
        }
        .btn-accueil:hover {
            background: linear-gradient(135deg, #991b1b, #b91c1c);
            color: #fff !important;
            transform: translateY(-2px) scale(1.03);
            text-decoration: none !important;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #ffffff;
            color: #1a1a1a;
            overflow-x: hidden;
        }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 240px;
            height: 100vh;
            background: linear-gradient(180deg, #ef4444 0%, #dc2626 100%);
            z-index: 1000;
            transition: all 0.3s ease;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
        }
        .sidebar-header {
            padding: 30px 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .sidebar-logo {
            color: #ffffff;
            font-size: 24px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .sidebar-logo i {
            color: #ffffff;
            font-size: 28px;
        }
        .sidebar-nav {
            padding: 20px 0;
            padding-bottom: 180px;
        }
        .nav-item {
            margin: 8px 20px;
        }
        .nav-link {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
            gap: 15px;
        }
        .nav-link:hover {
            background: rgba(255, 255, 255, 0.1);
            color: #ffffff;
            transform: translateX(5px);
            text-decoration: none;
        }
        .nav-link.active {
            background: rgba(255, 255, 255, 0.2);
            color: #ffffff;
            box-shadow: 0 4px 15px rgba(239, 68, 68, 0.3);
        }
        .nav-link i {
            font-size: 18px;
            width: 20px;
        }
        /* Main Content */
        .main-content {
            margin-left: 240px;
            min-height: 100vh;
            background: #ffffff;
        }
        /* Top Header */
        .top-header {
            background: #ffffff;
            padding: 20px 40px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        .search-bar {
            flex: 1;
            max-width: 400px;
            margin: 0 30px;
            position: relative;
        }
        .search-input {
            width: 100%;
            padding: 12px 20px 12px 45px;
            border: 2px solid #e2e8f0;
            border-radius: 25px;
            background: #f8fafc;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        .search-input:focus {
            outline: none;
            border-color: #ef4444;
            background: #ffffff;
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
        }
        .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
        }
        .header-actions {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .notification-btn {
            position: relative;
            background: #f8fafc;
            border: none;
            width: 45px;
            height: 45px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .notification-btn:hover {
            background: #ef4444;
            color: #ffffff;
            transform: translateY(-2px);
        }
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #ef4444;
            color: #ffffff;
            font-size: 11px;
            padding: 2px 6px;
            border-radius: 10px;
            font-weight: 600;
        }
        .profile-section {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 16px;
            background: #f8fafc;
            border-radius: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            color: inherit;
        }
        .profile-section:hover {
            background: #e2e8f0;
            text-decoration: none;
            color: inherit;
        }
        .profile-avatar {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            background: linear-gradient(135deg, #ef4444, #dc2626);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            font-weight: 600;
            font-size: 16px;
        }
        .profile-info h6 {
            margin: 0;
            font-size: 14px;
            font-weight: 600;
            color: #1e293b;
        }
        .profile-info p {
            margin: 0;
            font-size: 12px;
            color: #64748b;
        }
        
        .welcome-section {
            padding: 40px;
            background: linear-gradient(135deg, #fef2f2 0%, #fecaca 100%);
        }
        .welcome-title {
            font-size: 32px;
            font-weight: 700;
            color: #b91c1c;
            margin-bottom: 8px;
        }
        .welcome-subtitle {
            font-size: 16px;
            color: #dc2626;
            margin-bottom: 20px;
        }
       
        .dashboard-section {
            padding: 40px;
        }
        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        .moyens-generaux-dashboard-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 25px;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            border: 1px solid #e2e8f0;
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-decoration: none !important;
            color: inherit;
        }
        .moyens-generaux-dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(239, 68, 68, 0.2);
        }
        .card-icon {
            width: 60px;
            height: 60px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: #ffffff;
            margin-bottom: 20px;
        }
        .card-title {
            font-size: 20px;
            font-weight: 600;
            color: #b91c1c;
            margin-bottom: 8px;
        }
        .card-description {
            font-size: 14px;
            color: #dc2626;
            margin-bottom: 15px;
            line-height: 1.5;
        }
        .card-metric {
            font-size: 28px;
            font-weight: 700;
            color: #b91c1c;
            display: inline-block;
            padding: 6px 12px;
            border-radius: 6px;
            background-color: #28a745;
            color: #fff;
            transition: background-color 0.3s, color 0.3s;
        }
        .card-metric.inactive {
            background-color: #dc3545;
        }
        
        .card-equipment .card-icon { background: linear-gradient(135deg, #ef4444, #dc2626); }
        .card-maintenance .card-icon { background: linear-gradient(135deg, #f87171, #ef4444); }
        .card-logistics .card-icon { background: linear-gradient(135deg, #fca5a5, #f87171); }
        .card-facilities .card-icon { background: linear-gradient(135deg, #dc2626, #b91c1c); }
        .card-procurement .card-icon { background: linear-gradient(135deg, #991b1b, #7f1d1d); }
        .card-notifications .card-icon { background: linear-gradient(135deg, #f59e0b, #d97706); }
        
        .side-panels {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
            margin-top: 30px;
        }
        .dashboard-card,
        .moyens-generaux-side-panel {
            background: #ffffff;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            border: 1px solid #e2e8f0;
        }
        .panel-title {
            font-size: 18px;
            font-weight: 600;
            color: #b91c1c;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .equipment-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 0;
            border-bottom: 1px solid #f1f5f9;
        }
        .equipment-item:last-child {
            border-bottom: none;
        }
        .equipment-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: linear-gradient(135deg, #ef4444, #dc2626);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            font-size: 14px;
        }
        .equipment-info h6 {
            margin: 0;
            font-size: 14px;
            font-weight: 500;
            color: #b91c1c;
        }
        .equipment-info p {
            margin: 0;
            font-size: 12px;
            color: #dc2626;
        }
        #equipementChart {
             width: 100% !important;
             height: 220px !important;
             display: block !important;
             margin: 0 auto !important;
        }
        .logout-btn {
            position: fixed;
            bottom: 30px;
            left: 20px;
            width: 200px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #ffffff;
            padding: 12px 20px;
            border-radius: 12px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
        }
        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            color: #ffffff;
            text-decoration: none;
        }
        .chart-container {
            position: relative;
            height: 220px;
            width: 100%;
        }
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .main-content {
                margin-left: 0;
            }
            .top-header {
                padding: 15px 20px;
            }
            .dashboard-section {
                padding: 20px;
            }
            .cards-grid {
                grid-template-columns: 1fr;
            }
            .side-panels {
                grid-template-columns: 1fr;
            }
        }
        .btn-action {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            margin: 3px;
            min-width: 90px;
            justify-content: center;
        }
        .actions-cell {
            text-align: center;
            white-space: nowrap;
        }
        .actions-cell .btn-action {
                margin: 0 4px 4px 0;
        }
        .quick-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        .quick-buttons .btn {
            flex: 1;
            text-align: center;
            background: linear-gradient(135deg, #42a5f5, #81d4fa);
            color: #fff;
            padding: 12px 0;
            border-radius: 10px;
            text-decoration: none;
            font-weight: bold;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .quick-buttons .btn i {
            margin-right: 8px;
        }
        .quick-buttons .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.2);
        }
    </style>

</head>
<body class="dashboard-moyens-generaux">
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-tools"></i>
                FONEA Moyens Généraux
            </div>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-item">
                <a href="#" class="nav-link active">
                    <i class="fas fa-chart-pie"></i>
                    Dashboard
                </a>
            </div>
            <div class="nav-item">
                <a href="document_management.php" class="nav-link">
                    <i class="fas fa-cogs"></i>
                    Équipements
                </a>
            </div>
            <div class="nav-item">
                <a href="../modules/it_support" class="nav-link">
                    <i class="fas fa-wrench"></i>
                    Maintenance
                </a>
            </div>
            <div class="nav-item">
                <a href="../modules/logistique" class="nav-link">
                    <i class="fas fa-truck"></i>
                    Logistique
                </a>
            </div>
            <div class="nav-item">
                <a href="../public/notifications.php" class="nav-link">
                    <i class="fas fa-bell"></i>
                    Notifications
                </a>
            </div>
        </nav>
        <a href="../layout/header.php" class="btn-accueil"><i class="fas fa-home"></i>Accueil</a>
    </div>
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <div class="search-bar position-relative">
                <i class="fas fa-search search-icon"></i>
                <input type="text" class="search-input" placeholder="Rechercher équipements...">
            </div>
            <div class="header-actions">
                <button class="notification-btn">
                    <i class="fas fa-bell"></i>
                    <?php if ($total_notifications > 0): ?>
                        <span class="notification-badge"><?= $total_notifications ?></span>
                    <?php endif; ?>
                </button>
                <div class="profile-section">
                    <div class="profile-avatar">
                        <?= strtoupper(substr($user_name, 0, 2)) ?>
                    </div>
                    <div class="profile-info">
                        <h6><?= htmlspecialchars($user_name) ?></h6>
                        <p>Moyens Généraux</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Welcome Section -->
        <div class="welcome-section">
            <h1 class="welcome-title">Bienvenue Moyens Généraux, <?= htmlspecialchars($user_name) ?></h1>
            <p class="welcome-subtitle">Tableau de bord opérationnel - Gestion des équipements et moyens techniques</p>
            <div class="quick-buttons">
                <a href="../include/livraison.php" class="btn">
                    <i class="fas fa-truck"></i> Livraisons
                </a>
                <a href="../include/commande.php" class="btn">
                    <i class="fas fa-shopping-cart"></i> Commandes
                </a>
                <a href="../modules/List.php" class="btn">
                    <i class="fas fa-list"></i> États de besoin
                </a>
                <a href="../modules/logistique.php" class="btn">
                    <i class="fas fa-dolly"></i> Logistique
                </a>
            </div>
        </div>
        <!-- Dashboard Section -->
        <div class="dashboard-section">
            <div class="cards-grid">
                <a href="document_management.php" class="moyens-generaux-dashboard-card card-equipment">
                    <div class="card-icon">
                        <i class="fas fa-cogs"></i>
                    </div>
                    <h3 class="card-title">Gestion Équipements</h3>
                    <p class="card-description">Inventaire et suivi de tous les équipements techniques</p>
                    <div class="card-metric"><?= $total_equipment ?></div>
                </a>
                <a href="../modules/it_support" class="moyens-generaux-dashboard-card card-maintenance">
                    <div class="card-icon">
                        <i class="fas fa-wrench"></i>
                    </div>
                    <h3 class="card-title">Maintenance</h3>
                    <p class="card-description">Planification et suivi des opérations de maintenance</p>
                    <div class="card-metric"><?= $maintenance_requests ?></div>
                </a>
                <a href="../modules/logistique" class="moyens-generaux-dashboard-card card-logistics">
                    <div class="card-icon">
                        <i class="fas fa-truck"></i>
                    </div>
                    <h3 class="card-title">Logistique</h3>
                    <p class="card-description">Coordination des livraisons et transport d'équipements</p>
                    <div class="card-metric" id="logistique-status">Actif</div>
                </a>
                <a href="facilities" class="moyens-generaux-dashboard-card card-facilities">
                    <div class="card-icon">
                        <i class="fas fa-building"></i>
                    </div>
                    <h3 class="card-title">Installations</h3>
                    <p class="card-description">Gestion des infrastructures et espaces techniques</p>
                    <div class="card-metric">Suivi</div>
                </a>
                <a href="procurement_mg.php" class="moyens-generaux-dashboard-card card-procurement">
                    <div class="card-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <h3 class="card-title">Achats</h3>
                    <p class="card-description">Processus d'acquisition et commandes d'équipements</p>
                    <div class="card-metric">En cours</div>
                </a>
                <a href="../public/notifications.php" class="moyens-generaux-dashboard-card card-notifications">
                    <div class="card-icon">
                        <i class="fas fa-bell"></i>
                    </div>
                    <h3 class="card-title">Notifications</h3>
                    <p class="card-description">Alertes de maintenance et notifications techniques</p>
                    <div class="card-metric"><?= $total_notifications ?></div>
                </a>
            </div>
            <!-- Side Panels -->
            <div class="side-panels">
                <div class="dashboard-card">
                    <h4 class="panel-title">
                        <i class="fas fa-exclamation-triangle"></i>
                        Équipements Critiques
                    </h4>
                    <div class="equipment-item">
                        <div class="equipment-icon">
                            <i class="fas fa-server"></i>
                        </div>
                        <div class="equipment-info">
                            <h6>Serveur Principal</h6>
                            <p>Maintenance requise</p>
                        </div>
                    </div>
                    <div class="equipment-item">
                        <div class="equipment-icon">
                            <i class="fas fa-print"></i>
                        </div>
                        <div class="equipment-info">
                            <h6>Imprimante Réseau</h6>
                            <p>Remplacement toner</p>
                        </div>
                    </div>
                    <div class="equipment-item">
                        <div class="equipment-icon">
                            <i class="fas fa-wifi"></i>
                        </div>
                        <div class="equipment-info">
                            <h6>Routeur Principal</h6>
                            <p>Mise à jour firmware</p>
                        </div>
                    </div>
                </div>
                <div class="moyens-generaux-side-panel">
                    <h4 class="panel-title">
                        <i class="fas fa-chart-pie"></i>
                        <a href="equipement_etat.php" style="text-decoration:none; color:inherit;">
                            État des Équipements
                        </a>
                    </h4>
                    <canvas id="equipmentChart"></canvas>
                </div>
            </div>
            <!-- Requests ready for MG actions -->
            <div class="mt-4">
                <div class="dashboard-card" style="max-width:100%">
                    <h4 class="panel-title"><i class="fas fa-shopping-cart"></i> Demandes prêtes pour acquisition</h4>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Demandeur</th>
                                    <th>Désignation</th>
                                    <th>Statut</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <?php if (empty($pending_list)): ?>
                                    <tr><td colspan="5" class="text-center text-muted">Aucune demande prête</td></tr>
                                <?php else: foreach ($pending_list as $row): ?>
                                    <tr data-id="<?= (int)$row['id_besoin'] ?>">
                                        <td><?= (int)$row['id_besoin'] ?></td>
                                        <td><?= htmlspecialchars($row['prenom'] . ' ' . $row['nom']) ?></td>
                                        <td><?= htmlspecialchars($row['designation_materiel'] ?? '') ?></td>
                                        <td><span class="status-badge <?= htmlspecialchars($row['statut']) ?>"><?= htmlspecialchars($row['statut']) ?></span></td>
                                        <td class="actions-cell">
                                            <button type="button" class="btn btn-sm btn-primary btn-action" 
                                                onclick="window.location.href='assigner.php?id=<?= (int)$row['id_besoin'] ?>'">
                                                <i class="fas fa-tasks"></i> Assigner
                                            </button>
                                            <button type="button" class="btn btn-sm btn-warning btn-action" 
                                                onclick="window.location.href='traiter.php?id=<?= (int)$row['id_besoin'] ?>'">
                                                <i class="fas fa-cogs"></i> Traiter
                                            </button>
                                            <button type="button" class="btn btn-sm btn-success btn-action" 
                                                onclick="window.location.href='cloture.php?id=<?= (int)$row['id_besoin'] ?>'">
                                                <i class="fas fa-check"></i> Clôturer
                                            </button>
                                            <span class="status-badge status-<?= strtolower(htmlspecialchars($row['statut'])) ?>">
                                                <?= htmlspecialchars($row['statut']) ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Equipment Chart
        const ctx = document.getElementById('equipmentChart').getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Opérationnel', 'Maintenance', 'Hors service'],
                datasets: [{
                    data: [75, 20, 5],
                    backgroundColor: ['#ef4444', '#f87171', '#fca5a5'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                }
            }
        });
        // Add click handlers to notification button
        document.querySelector('.notification-btn').addEventListener('click', function() {
            window.location.href = 'notifications.php';
        });
        const statusEl = document.getElementById('logistique-status');
        let isActive = true;
        function updateStatus() {
            if (isActive) {
                statusEl.textContent = 'Actif';
                statusEl.classList.remove('inactive');
            } else {
                statusEl.textContent = 'Inactif';
                statusEl.classList.add('inactive');
            }
        }
        setInterval(() => {
            isActive = !isActive;
            updateStatus();
        }, 5000);
        updateStatus();
        // MG Action AJAX handling
        document.querySelectorAll('.mg-action-form').forEach(form => {
            form.addEventListener('submit', async function (e) {
                e.preventDefault();
                const row = this.closest('tr');
                const fd = new FormData(this);
                try {
                    const res = await fetch('../Public/api_mg_action.php', { method: 'POST', body: fd, headers: { 'X-Requested-With': 'XMLHttpRequest' } });
                    const data = await res.json();
                    if (!res.ok || !data || data.error) throw new Error(data?.error || 'Erreur');
                    const statusEl = row.querySelector('.status-badge');
                    if (statusEl) {
                        statusEl.textContent = data.new_status;
                        statusEl.className = 'status-badge ' + data.new_status;
                    }
                    if (data.new_status === 'cloturee') {
                        row.querySelectorAll('.mg-action-form').forEach(f => f.remove());
                    }
                } catch (err) {
                    alert('Action impossible: ' + err.message);
                }
            });
        });
    </script>
</body>
</html>