<?php
// Path to your documents folder
$dir = __DIR__ . '/documents';
// Get all files
$files = array_diff(scandir($dir), array('.', '..'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Documents</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        h1 { color: #333; }
        ul { list-style: none; padding: 0; }
        li { margin: 8px 0; }
        a { text-decoration: none; color: #0066cc; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <h1>Documents Disponible</h1>
    <?php if(!empty($files)): ?>
        <ul>
            <?php foreach($files as $file): ?>
                <li>
                    <a href="download.php?file=<?= urlencode($file) ?>"><?= htmlspecialchars($file) ?></a>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>Document non disponible.</p>
    <?php endif; ?>
</body>
</html>
